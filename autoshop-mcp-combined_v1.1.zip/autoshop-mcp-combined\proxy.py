"""autoshop-combined: 把三个 AutoShop MCP 聚合成一个 stdio 服务器。

FastMCP 4.x ProxyProvider + MCPConfig 多后端：
- kit_ 前缀 -> AutoShop-AI-Kit（操作型：工程树/开关视图/读写ST/保存/导表，14 工具）
- r_   前缀 -> autoshop-mcp-server 解读版（LD/FB 解读、调用图、符号搜索、ST生成，22 工具）
- b_   前缀 -> plc-bridges/autoshop-mcp 桥（进程探活+标题解析、离线读工程树/符号表、
              对话框扫描/精确点按钮，5 工具）

后端路径默认相对本文件所在目录解析，整个包解压到任意位置即可运行；
Node 解释器可用环境变量 AUTOSHOP_MCP_NODE 覆盖，AutoShop 主程序用 AUTOSHOP_EXE 覆盖。
"""
import os

from fastmcp import FastMCP
from fastmcp.server.providers.proxy import ProxyProvider, ProxyClient

BASE = os.path.dirname(os.path.abspath(__file__))

# Node 18+：优先环境变量，其次 PATH 中的 node
NODE = os.environ.get("AUTOSHOP_MCP_NODE") or "node"

BACKENDS = {
    "mcpServers": {
        "kit": {
            "command": NODE,
            "args": [os.path.join(BASE, "AutoShop-AI-Kit", "mcp", "server.mjs")],
            "env": {"AUTOSHOP_TOOLS_DIR": os.path.join(BASE, "AutoShop-AI-Kit", "tools")},
        },
        "r": {
            "command": NODE,
            "args": [os.path.join(BASE, "autoshop-mcp-server", "dist", "index.js")],
            "cwd": os.path.join(BASE, "autoshop-mcp-server"),
        },
        "b": {
            "command": NODE,
            "args": [os.path.join(BASE, "plc-bridges-autoshop-mcp", "server.mjs")],
            "cwd": os.path.join(BASE, "plc-bridges-autoshop-mcp"),
        },
    }
}

# 换机器时如 AutoShop 不在桥的默认路径，解注释并把 AUTOSHOP_EXE 注入 b 后端 env：
# BACKENDS["mcpServers"]["b"]["env"] = {"AUTOSHOP_EXE": r"C:\path\to\AutoShop.exe"}

mcp = FastMCP("autoshop-combined")
mcp.add_provider(ProxyProvider(lambda: ProxyClient(BACKENDS)))

if __name__ == "__main__":
    mcp.run()
