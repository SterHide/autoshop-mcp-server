# Post a key to a window that exposes no UIA Invoke and no Win32 child buttons (Qt-drawn dialogs).
#   -Hwnd N   target window (usually a #32770 host or its Qt child)
#   -Key Esc|Enter|Tab|Y|N   which key to send
#   -Child    also post to every child window
# PostMessage is used rather than SendInput so the desktop is not hijacked and the user's
# keyboard/mouse stay free.
param(
  [Parameter(Mandatory = $true)][long]$Hwnd,
  [ValidateSet('Esc', 'Enter', 'Tab', 'Space', 'Y', 'N')][string]$Key = 'Enter',
  [switch]$Child
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -Namespace W -Name K32 -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumWindowsProc cb, IntPtr l);
public delegate bool EnumWindowsProc(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern IntPtr GetClassName(IntPtr h, System.Text.StringBuilder s, int n);
'@

$vk = switch ($Key) { 'Esc' { 0x1B } 'Enter' { 0x0D } 'Tab' { 0x09 } 'Space' { 0x20 } 'Y' { 0x59 } 'N' { 0x4E } }
$WM_KEYDOWN = 0x0100; $WM_KEYUP = 0x0101; $WM_CHAR = 0x0102

function Send-Key([long]$h, [int]$vkCode, [string]$label) {
  $extra = [IntPtr](1 -bor ([int][char]$vkCode -shl 16))
  [void][W.K32]::PostMessage([IntPtr]$h, $WM_KEYDOWN, [IntPtr]$vkCode, $extra)
  [void][W.K32]::PostMessage([IntPtr]$h, $WM_KEYUP, [IntPtr]$vkCode, [IntPtr](-1 -bor ([int][char]$vkCode -shl 16)))
  if ($vkCode -in 0x59, 0x4E) {
    [void][W.K32]::PostMessage([IntPtr]$h, $WM_CHAR, [IntPtr]$vkCode, $extra)
  }
  "posted $label -> $h"
}

$targets = @($Hwnd)
if ($Child) {
  $kids = [System.Collections.Generic.List[long]]::new()
  $cb = [W.K32+EnumWindowsProc] {
    param($h, $l)
    $kids.Add([long]$h)
    $true
  }
  [void][W.K32]::EnumChildWindows([IntPtr]$Hwnd, $cb, [IntPtr]::Zero)
  $targets += $kids
}
foreach ($t in $targets) { Send-Key $t $vk $Key }

$state = foreach ($t in $targets) {
  $sb = New-Object System.Text.StringBuilder 260
  [void][W.K32]::GetWindowText([IntPtr]$t, $sb, 260)
  $cn = New-Object System.Text.StringBuilder 260
  [void][W.K32]::GetClassName([IntPtr]$t, $cn, 260)
  [pscustomobject]@{ hwnd = $t; class = $cn.ToString(); text = $sb.ToString() }
}
$state | ConvertTo-Json -Compress
