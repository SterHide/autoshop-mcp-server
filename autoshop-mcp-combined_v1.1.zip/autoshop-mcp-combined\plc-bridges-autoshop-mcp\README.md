# autoshop-mcp(MCP 名 `autoshop`)

汇川 Inovance AutoShop 的桥。实测版本 4.12.0.0,2026-11-13 通。

工具:`autoshop_status`、`autoshop_project_open`、`autoshop_project_inspect`、`autoshop_dialog_scan`、`autoshop_dialog_click`。

- `autoshop_status` 从 UIA 标题解析 `version / projectDir / currentProgram`,例如 `AutoShop V4.12.0.0  D:\公司\...\DAA-副本 - [SBR_流程控制]`。
- `autoshop_project_inspect` 读工程目录里的明文:`folder.txt`(UTF-8 制表符缩进的程序树)和全部 `*.csv` 符号表(UTF-16LE)、`config.ini`。AutoShop 自己会往工程目录写东西,**只对副本试写**。
- `.LD/.ST/.gvt/.enum/.stru/.fbi/.gdt` 正文是 `AutoShop\0` 魔数 + 版本对 + 密文,桥不解密。
- 菜单是 MFC 命令带,`GetMenu` 返回 null → 没有命令 ID 通道;对话框是标准 Win32,可以读和点。

换机器:`AUTOSHOP_EXE`。校验:`pwsh -File ..\verify-bridge.ps1 -Bridge autoshop`
