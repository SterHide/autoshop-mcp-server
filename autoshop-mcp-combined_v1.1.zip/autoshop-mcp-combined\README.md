# autoshop-mcp-combined

把三个汇川 AutoShop MCP 聚合成**一个** MCP 服务器（stdio），共 41 个工具：

| 前缀 | 后端 | 能力 |
|---|---|---|
| `kit_` | AutoShop-AI-Kit（UI 自动化） | 工程树、开关节点视图、读写 ST 源码、保存、表格导入导出、新建/删除块（14 工具） |
| `r_` | autoshop-mcp-server v1.5.1（只读解读） | LD/FB 二进制源码提取、块/项目解读、调用图、符号搜索、LD→ST 生成（22 工具） |
| `b_` | plc-bridges/autoshop-mcp 桥（零依赖 Win32 探针） | 进程探活+标题解析（pid/工程目录/当前程序）、离线读 folder.txt 程序树与 CSV 符号表、对话框扫描/按 hwnd 精确点按钮（5 工具） |

聚合方式：FastMCP 4.x `ProxyProvider` + 多后端 `MCPConfig`，零自研桥接代码，启动时自动连接三个后端并发现全部工具，工具名自动加 `kit_` / `r_` / `b_` 前缀防冲突。

## 目录结构

```
autoshop-mcp-combined/
├── proxy.py                  # 聚合入口（相对路径解析，解压即用）
├── requirements.txt          # Python 依赖（fastmcp==4.1.8）
├── mcp-config.example.json   # MCP 客户端注册样例
├── AutoShop-AI-Kit/
│   ├── mcp/server.mjs        # Kit MCP 服务器（Node）
│   ├── tools/*.ps1           # 69 个 UI 自动化脚本（已打多实例过滤补丁）
│   ├── SKILL.md / AUTOSHOP_操作要点.md / README.md
├── autoshop-mcp-server/
│   ├── dist/                 # 解读版编译产物（可直接运行）
│   ├── src/ docs/ examples/ manifest/
│   └── package.json / package-lock.json / tsconfig.json
└── plc-bridges-autoshop-mcp/
    ├── server.mjs            # 桥入口（零 npm 依赖）
    ├── lib/bridge.mjs        # Win32 探针公共库
    ├── tools/*.ps1           # keypost / uia-dump / winprobe 辅助脚本
    └── README.md
```

## 依赖与安装

1. **Node.js 18+**（两个后端都是 Node 程序）
2. **Python 3.10+**，安装聚合层依赖：
   ```
   pip install -r requirements.txt
   ```
3. **恢复解读版依赖**（本包不含 node_modules，约 52 MB）：
   ```
   cd autoshop-mcp-server
   npm install
   ```
   dist 运行需要 @modelcontextprotocol/sdk、express、zod 等依赖，`npm install` 后无需再 `tsc`。

## 注册到 MCP 客户端（mcp.json）

```json
{
  "mcpServers": {
    "autoshop": {
      "command": "C:\\path\\to\\python.exe",
      "args": ["D:\\AI\\MCP\\autoshop-mcp-combined\\proxy.py"],
      "cwd": "D:\\AI\\MCP\\autoshop-mcp-combined"
    }
  }
}
```

- `proxy.py` 内部用**相对自身的路径**找后端，解压到任意目录均可运行。
- Node 不在 PATH 时，设置环境变量 `AUTOSHOP_MCP_NODE` 指向 node.exe 完整路径。
- 配置后需在客户端的连接器管理页对新条目点“信任”才会启用。

## 多 AutoShop 实例注意事项（Kit 工具）

Kit 的 ps1 脚本通过窗口标题选择 AutoShop 实例，已打补丁：

- 设置 `AUTOSHOP_TITLE_FILTER`（如 `DAA-副本`）→ 只匹配标题含该串的实例；
- 未设置时兜底：标题**不含盘符路径**（`*:\*`）的视为临时工程/活动工程实例。

在 MCP 配置的 `env` 里加 `"AUTOSHOP_TITLE_FILTER": "工程名"` 即可，多个实例同时打开时强烈建议设置。

推荐做法：先调 `b_autoshop_status` 列出全部 AutoShop 实例（pid + 工程目录 + 当前程序），确认目标工程后再把工程名填进 `AUTOSHOP_TITLE_FILTER`，避免 Kit 选错实例。

## b_ 桥的使用建议

- `b_autoshop_status`：探活/列实例，从窗口标题解析 version/projectDir/currentProgram，只读。
- `b_autoshop_project_inspect`：不开 IDE 离线读工程（folder.txt 程序树 + CSV 符号表 UTF-16LE/GBK 自适应 + 加密源清单）；`.LD/.ST` 正文为厂商家密文，桥不解密。
- `b_autoshop_dialog_scan` + `b_autoshop_dialog_click`：标准 Win32 对话框（确认删除、报错框）用 scan 拿按钮 hwnd 后精确点击，比 Kit 的像素偏移安全。
- AutoShop 主程序不在默认路径时：在 MCP 配置 `env` 加 `"AUTOSHOP_EXE": "C:\\...\\AutoShop.exe"`。

## 版本快照信息

- AutoShop-AI-Kit tools：2026-11-13 已打 `AUTOSHOP_TITLE_FILTER` 补丁版（备份 tools_bak_20261113 未包含在包内）
- autoshop-mcp-server：v1.5.1，dist 已预编译（TypeScript 源码一并附带）
- FastMCP：4.1.8（4.x 已移除 `as_proxy`，须用 `add_provider(ProxyProvider(...))` 写法）
- plc-bridges/autoshop-mcp 桥：零依赖 server.mjs（lib/bridge.mjs 自带 Win32 探针），AutoShop V4.12.0.0 实测通过

## 快速自检

```
python proxy.py            # 正常时应阻塞等待 stdio 输入，无异常退出
```

或用 MCP 客户端连接后调用 `kit_autoshop_tree` / `r_autoshop_scan_project` 验证两端连通（需已打开 AutoShop 工程）。
