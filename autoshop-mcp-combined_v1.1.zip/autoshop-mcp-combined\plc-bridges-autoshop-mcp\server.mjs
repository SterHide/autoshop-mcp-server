// AutoShop (Inovance) MCP bridge. Zero npm deps.
//
// Verified on this machine (AutoShop V4.12.0.0, D:\app\major\INOVANCE\AutoShop\AutoShop.exe):
//  - Registry: .hcp opens as  D:\app\major\INOVANCE\AutoShop\AutoShop.exe "%1".
//  - A .hcp is only the entry point. The project is a FOLDER of sidecar files; AutoShop refuses
//    to load a lone .hcp and raises a #32770 error naming the missing sidecar (verified with a
    //  one-file copy: "打开文件：...\VarList.gdt 时出错"), then exits once dismissed.
//  - Main window title while open: "AutoShop V4.12.0.0  <project folder> - [MAIN]"
//  - Main frame class is Afx:* (MFC) and GetMenu returns NULL: no native menu bar.
//  - UIA reaches the frame but exposes only Pane/Window with no usable patterns.
//  - Program sources (.LD ladder, .ST structured text, .gvt, .enum, .stru, .fbi, .gdt) all start
//    with the magic "AutoShop\0" then a version pair and an encrypted body. Not decrypted here.
//  - folder.txt (tab-indented tree), config.ini and the per-table *.csv symbol tables are plaintext.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
// Packaged layout: lib\ and tools\ sit beside this file (in mcp-scaffold they were one level up).
import { processes, topWindows, dialogs, clickButton, bestTitle, launchGuard, launch, sleep, serve } from './lib/bridge.mjs';

const EXE = process.env.AUTOSHOP_EXE || 'D:\\app\\major\\INOVANCE\\AutoShop\\AutoShop.exe';
const PROC = 'AutoShop';
const ENCRYPTED_MAGIC = 'AutoShop';
const gbk = new TextDecoder('gbk');
// folder.txt and the CSVs in this AutoShop version are UTF-8 / UTF-16LE; older installs write GBK,
// so UTF-8 is tried strictly first and GBK is the fallback.
const utf8Strict = new TextDecoder('utf-8', { fatal: true });

function parseTitle(title) {
  // "AutoShop V4.12.0.0  <project folder> - [MAIN]"
  const out = { raw: title, version: null, projectDir: null, currentProgram: null };
  if (!title) return out;
  const vm = title.match(/AutoShop\s+V([\d.]+)/i);
  if (vm) out.version = vm[1];
  const tail = title.match(/\[(.*?)\]\s*$/);
  if (tail) out.currentProgram = tail[1];
  const mid = title.match(/V[\d.]+\s+(.+?)\s+-\s+\[/);
  if (mid) out.projectDir = mid[1];
  return out;
}

async function status() {
  const procs = await processes(PROC);
  const frames = [];
  for (const p of procs) {
    const t = await bestTitle(p.mainHwnd, p.title);
    frames.push({ pid: p.pid, mainHwnd: p.mainHwnd, responding: p.responding, started: p.start, titleSource: t.source, title: t.title, parsed: parseTitle(t.title) });
  }
  return { ok: true, value: { autoShopExe: EXE, frames } };
}

async function projectOpen(args) {
  const projectPath = args?.projectPath;
  if (!projectPath || !/\.hcp$/i.test(projectPath)) return { ok: false, code: 'bad_path', error: 'projectPath must end in .hcp' };
  if (!existsSync(projectPath)) return { ok: false, code: 'not_found', error: projectPath };
  const dir = join(projectPath, '..');
  const procs = await processes(PROC);
  const already = (await status()).value.frames.filter((f) => f.parsed.projectDir && f.parsed.projectDir.toLowerCase() === dir.toLowerCase());
  if (already.length) {
    return { ok: true, value: { action: 'already-open', launched: false, frame: already[0].parsed, note: 'Already loaded in a running AutoShop; nothing launched.' } };
  }
  const guard = launchGuard([], procs.map((p) => p.pid));
  if (!guard.ok) return guard;
  launch(EXE, [`"${projectPath}"`], join(EXE, '..'));
  await sleep(20000);
  const st = await status();
  const ds = await dialogs(st.value.frames[0]?.pid ?? 0);
  return { ok: st.value.frames.length > 0, value: {
    action: 'launched', launched: true,
    frames: st.value.frames.map((f) => f.parsed),
    dialogs: ds.map((d) => ({ texts: d.texts, buttons: d.buttons.map((b) => b.text) })),
    note: 'AutoShop needs the whole project folder, not just the .hcp; a missing sidecar raises an error dialog and the app quits.',
  } };
}

function readTextSmart(buf) {
  if (buf[0] === 0xff && buf[1] === 0xfe) return buf.toString('utf16le').replace(/^\uFEFF/, '');
  if (buf[0] === 0xef && buf[1] === 0xbb) return buf.toString('utf8').replace(/^\uFEFF/, '');
  try { return utf8Strict.decode(buf); } catch { return gbk.decode(buf); }
}

// folder.txt is a tab-indented project tree: PROG/VAR sections, FOLDER and FILE entries.
function parseFolderTxt(text) {
  const sections = [];
  let current = null;
  for (const raw of text.split(/\r?\n/)) {
    if (!raw) continue;
    const indent = (raw.match(/^\t+/) || [''])[0].length;
    const line = raw.trim();
    if (indent === 0 && (line === 'PROG' || line === 'VAR' || line === 'ROOT')) {
      if (line === 'ROOT') continue;
      current = { section: line, nodes: [] };
      sections.push(current);
      continue;
    }
    if (!current) continue;
    const parts = line.split('\t');
    const kind = parts[0];
    const name = parts.slice(1).join('\t');
    if (kind === 'FILE' || kind === 'FOLDER' || kind === 'STRUROOT' || kind === 'ENUMROOT') {
      current.nodes.push({ depth: indent, kind, name });
    }
  }
  return sections;
}

function parseCsvTable(text) {
  const rows = text.split(/\r?\n/).map((l) => l.split('\t'));
  const meta = {};
  for (const r of rows) if (r.length === 2 && !r[0].startsWith('_')) meta[r[0]] = r[1];
  const headerIdx = rows.findIndex((r) => r[0] === 'FullName');
  const header = headerIdx >= 0 ? rows[headerIdx] : [];
  const body = headerIdx >= 0 ? rows.slice(headerIdx + 1).filter((r) => r[0] && !r[0].startsWith('_')) : [];
  return { meta, header, symbolCount: body.length, sample: body.slice(0, 12).map((r) => r.map((c) => c.trim())) };
}

async function projectInspect(args) {
  const projectPath = args?.projectPath;
  // Accept either the project folder or its .hcp; a .hcp alone is not enough to inspect.
  const dir = statSyncSafe(projectPath) ? join(projectPath, '..') : projectPath;
  if (!dir || !existsSync(dir)) return { ok: false, code: 'not_found', error: projectPath };
  const files = [];
  const walk = (d, rel) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const abs = join(d, e.name);
      const r = rel ? join(rel, e.name) : e.name;
      if (e.isDirectory()) walk(abs, r);
      else { const st = statSync(abs); files.push({ name: r, size: st.size, mtime: st.mtime.toISOString() }); }
    }
  };
  walk(dir, '');

  const out = { ok: true, projectDir: dir, entryFiles: [], tree: [], symbolTables: [], encryptedSources: [], notes: [] };
  for (const f of files) {
    const ext = extname(f.name).toLowerCase();
    if (ext === '.hcp' || ext === '.hcpp') out.entryFiles.push(f);
    if (ext === '.ld' || ext === '.st' || ext === '.gvt' || ext === '.enum' || ext === '.stru' || ext === '.fbi' || ext === '.gdt' || ext === '.fb' || ext === '.fc' || ext === '.flib') {
      out.encryptedSources.push({ name: f.name, size: f.size, mtime: f.mtime, header: readHeader(join(dir, f.name)) });
    }
  }
  const ft = join(dir, 'folder.txt');
  if (existsSync(ft)) out.tree = parseFolderTxt(readTextSmart(readFileSync(ft)));
  else out.notes.push('no folder.txt in this folder: pass the folder that contains it, or the matching .hcp');

  for (const f of files.filter((x) => extname(x.name).toLowerCase() === '.csv')) {
    try { out.symbolTables.push({ name: f.name, size: f.size, ...parseCsvTable(readTextSmart(readFileSync(join(dir, f.name)))) }); }
    catch (e) { out.notes.push(`could not parse ${f.name}: ${e.message}`); }
  }
  out.notes.push('program bodies (.LD/.ST/.gvt/...) carry the "AutoShop" magic and an encrypted body; this tool reads structure and symbol tables only');
  out.notes.push('nothing is written to the project folder');
  return { ok: true, value: out };
}

function statSyncSafe(p) { try { return statSync(p).isFile(); } catch { return false; } }
function readHeader(p) {
  try {
    const b = readFileSync(p).subarray(0, 48);
    return { magic: gbk.decode(b.subarray(0, 9)), versions: (gbk.decode(b.subarray(20, 32)).match(/[\d.]{3,}/g) || []).slice(0, 2) };
  } catch { return null; }
}

async function dialogScan(args) {
  const pid = Number(args?.pid) || (await processes(PROC))[0]?.pid;
  if (!pid) return { ok: false, code: 'no_process', error: 'AutoShop is not running and no pid was given' };
  const ds = await dialogs(pid);
  const wins = await topWindows(pid);
  return { ok: true, value: { pid, dialogs: ds, topLevels: wins.filter((w) => w.visible).map((w) => ({ hwnd: w.hwnd, cls: w.cls, title: w.title })) } };
}

async function dialogClick(args) {
  const hwnd = Number(args?.hwnd);
  if (!Number.isInteger(hwnd) || hwnd <= 0) return { ok: false, code: 'bad_args', error: 'hwnd must be a positive integer (from dialog_scan buttons)' };
  const r = await clickButton(hwnd);
  await sleep(1000);
  const st = await status();
  return { ok: true, value: { clicked: r, frames: st.value.frames.map((f) => f.parsed) } };
}

const T = (name, description, props = {}, required = []) => ({
  name, description,
  inputSchema: { type: 'object', properties: props, required, additionalProperties: false },
});

serve({
  name: 'autoshop-bridge',
  version: '0.1.0',
  instructions: 'AutoShop projects are folders; pass the folder or its .hcp to autoshop_project_inspect to get the program tree and the plaintext symbol tables. Program logic is encrypted by the vendor and is not exposed. Before any launch, check autoshop_status; while another instance runs, opening from the command line is refused.',
  tools: [
    T('autoshop_status', 'List AutoShop processes with pid, main window handle and the parsed version / project folder / current program. Read-only.'),
    T('autoshop_project_open', 'Open a .hcp project folder in AutoShop. Refuses when another instance is already running.', { projectPath: { type: 'string' } }, ['projectPath']),
    T('autoshop_project_inspect', 'Read an AutoShop project folder without the IDE: folder.txt program tree, every *.csv symbol table (FullName rows), config.ini, and an inventory of the encrypted .LD/.ST sources. Never writes.', { projectPath: { type: 'string' } }, ['projectPath']),
    T('autoshop_dialog_scan', 'List visible dialogs of AutoShop with their Static text, buttons (hwnd + dlgId) and edits. This is how errors and confirmations are detected before clicking.', { pid: { type: 'integer' } }),
    T('autoshop_dialog_click', 'Press one dialog button by hwnd, then report the new frame titles. Intended for dismissing/confirming dialogs found by autoshop_dialog_scan.', { hwnd: { type: 'integer' } }, ['hwnd']),
  ],
  handlers: {
    autoshop_status: status,
    autoshop_project_open: projectOpen,
    autoshop_project_inspect: projectInspect,
    autoshop_dialog_scan: dialogScan,
    autoshop_dialog_click: dialogClick,
  },
});
