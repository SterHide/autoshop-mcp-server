#!/usr/bin/env node
// Thin MCP server that exposes the AutoShop UI-automation PowerShell scripts as MCP tools.
//
// WHY A THIN WRAPPER (and not a rewrite):
//   * The verified logic already lives in D:\AI\MCP\AutoShop-AI-Kit\tools\*.ps1 (MSAA + Win32 driving the real
//     AutoShop UI). Rewriting it in Node would throw away every measured offset and judgement rule.
//   * Wrapping it means ANY MCP client can drive AutoShop -- the client only needs to call tools, it
//     does not need a shell, and it does not need to read a 250 KB SKILL.md to know the menu offsets.
//   * The offsets that took hours to measure (per-view import offsets, per-node context-menu offsets)
//     are baked in HERE, so a model cannot get them wrong.
//
// DISCIPLINE BAKED IN (this is the real value):
//   * every import ends with autoshop-save-until-clean (dismiss the box -> press Save -> verify the
//     dirty marker cleared) because a Save whose click was swallowed by a modal box looks like success
//   * every tool call runs in its OWN powershell process (several scripts share the .NET type W.U and
//     would otherwise silently skip their own Add-Pe and then fail on a missing method)
//   * arguments travel in a UTF-8 JSON file, never on a command line (Chinese + quoting + ANSI)
//
// stdio transport, newline-delimited JSON-RPC 2.0, ZERO npm dependencies.
// Nothing but JSON-RPC may be written to stdout; diagnostics go to stderr.

import { spawn } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const TOOLS_DIR = process.env.AUTOSHOP_TOOLS_DIR || join(HERE, '..', 'tools');
const POWERSHELL = process.env.AUTOSHOP_POWERSHELL ||
  join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
const PROTOCOL = '2024-11-05';

// ---------------------------------------------------------------- per-view offsets (measured)
// Import row offsets / popup heights, measured on AutoShop V4.11.0.5. NEVER guess these.
const IMPORT_PRESET = {
  fb:     { ImportOffsetY: 456, ExpectedMenuH: 512 },   // FB / FC variable table
  struct: { ImportOffsetY: 386, ExpectedMenuH: 442 },   // struct editor
  gvl:    { ImportOffsetY: 409, ExpectedMenuH: 632 },   // global variable table
  fbi:    { ImportOffsetY: 409, ExpectedMenuH: 476 },   // FB-instance table
};

// Context-menu offsets for creating a node, per parent node type (measured).
const CREATE_PRESET = {
  fb:         { Node: '功能块(FB)', ClickOffsetY: 18, ExpectedMenuH: 168, dialog: true,  bare: true  },
  struct:     { Node: '结构体',     ClickOffsetY: 18, ExpectedMenuH: 64,  dialog: true,  bare: false },
  gvl:        { Node: '全局变量',   ClickOffsetY: 18, ExpectedMenuH: 64,  dialog: false, bare: false },
  subprogram: { Node: '程序块',     ClickOffsetY: 72, ExpectedMenuH: 116, dialog: true,  bare: true  },
};

function step(script, params) { return { script, params: params || {} }; }

// ---------------------------------------------------------------- tools
const TOOLS = [
  {
    name: 'autoshop_preflight',
    description: 'AutoShop 开工自检：窗体位置/尺寸、左栏宽度、折叠状态、已开视图数、是否有模态框。任何一批操作前后都该跑。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        fix:  { type: 'boolean', description: '自动修复（归位窗体、把左栏拖回 346px、展开所有文件夹）' },
        deep: { type: 'boolean', description: '连折叠状态一起查并全部展开' },
        widen_pane: { type: 'boolean', description: '已废弃（保留以兼容旧调用）' },
        keep_views: { type: 'boolean', description: '不关闭开着的块视图（默认 true —— 关视图可能丢未保存的改动）' },
      },
    },
    build: (p) => [step('autoshop-preflight.ps1', {
      Fix: !!p.fix, Deep: !!p.deep, WidenPane: !!p.widen_pane, KeepViews: p.keep_views !== false,
    })],
  },
  {
    name: 'autoshop_tree',
    description: '读 AutoShop 工程树的全部节点（id + 名称，MSAA 名字索引）。用来确认某节点是否已建好。',
    readOnly: true,
    schema: { type: 'object', properties: {} },
    build: () => [step('autoshop-node-menu.ps1', { ListNodes: true })],
  },
  {
    name: 'autoshop_open_node',
    description: '按名字选中并打开一个工程树节点（块/变量表/结构体都会打开对应视图）。',
    schema: { type: 'object', properties: { node: { type: 'string', description: '节点名，如 FB_气缸 / GVL_SYS / SBR_气缸' } }, required: ['node'] },
    build: (p) => [step('autoshop-open-node.ps1', { Node: p.node })],
  },
  {
    name: 'autoshop_read_block',
    description: '只读回读块正文（不改动、不保存）。给 diff 就与本地文件逐字符比对并给 IDENTICAL/DIFF。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        block: { type: 'string' },
        diff: { type: 'string', description: '本地 .st/.md 路径，逐字符比对' },
        out_file: { type: 'string', description: '把读到的正文写到这个文件' },
        max_show: { type: 'integer', description: '顺带回显前 N 行' },
      },
      required: ['block'],
    },
    build: (p) => [step('autoshop-read-block.ps1', { Block: p.block, Diff: p.diff || '', OutFile: p.out_file || '', MaxShow: p.max_show || 0 })],
  },
  {
    name: 'autoshop_write_block',
    description: '把一段正文写进已打开的块编辑器（WM_SETTEXT，自动回读校验 MATCHES）。★写完必须调 autoshop_save。',
    schema: {
      type: 'object',
      properties: { block: { type: 'string' }, text_file: { type: 'string', description: 'UTF-8 正文文件（纯代码，无 md 围栏）' } },
      required: ['block', 'text_file'],
    },
    build: (p) => [step('autoshop-write-block.ps1', { Block: p.block, TextFile: p.text_file })],
  },
  {
    name: 'autoshop_save',
    description: '保存：先按掉弹窗（成功框是模态的，不按掉会吞掉保存点击）→ 再按工具栏保存 → 复读标题看 ` *` 是否消失，没消失就再点。这是唯一可信的保存验证。',
    schema: { type: 'object', properties: { max_rounds: { type: 'integer' } } },
    build: (p) => [step('autoshop-save-until-clean.ps1', { MaxRounds: p.max_rounds || 6 })],
  },
  {
    name: 'autoshop_close_all',
    description: '关闭所有块视图（.stru/.gvt/.FB 等只在关视图时真正落盘）。★先保存再关。',
    schema: { type: 'object', properties: {} },
    build: () => [step('autoshop-close-all-blocks.ps1', {})],
  },
  {
    name: 'autoshop_create_node',
    description: '新建工程树节点：fb（功能块）/ struct（结构体）/ gvl（全局变量表，会自动改名）/ subprogram（子程序，AutoShop 自动加 SBR_ 前缀）。菜单位置已内置，不用记偏移。',
    schema: {
      type: 'object',
      properties: {
        kind: { type: 'string', enum: ['fb', 'struct', 'gvl', 'subprogram'] },
        name: { type: 'string', description: '名称（子程序与 FB 给裸名，AutoShop 自己加前缀的只加 SBR_）' },
      },
      required: ['kind'],
    },
    build: (p) => {
      const c = CREATE_PRESET[p.kind];
      if (!c) throw new Error('unknown kind: ' + p.kind + ' (use fb|struct|gvl|subprogram)');
      const steps = [step('autoshop-node-menu.ps1', { Node: c.Node, ClickOffsetY: c.ClickOffsetY, ExpectedMenuH: c.ExpectedMenuH })];
      if (c.dialog) {
        if (!p.name) throw new Error('name is required for kind=' + p.kind);
        steps.push(step('autoshop-fill-newdialog.ps1', { Name: p.name }));
      } else if (p.name) {
        // a new GVL table is created as 变量表_1 and opened: rename it (two-step: menu item, then inline edit)
        steps.push(step('autoshop-node-menu.ps1', { Match: '变量表_', ClickOffsetY: 96, ExpectedMenuH: 168 }));
        steps.push(step('autoshop-rename-inline.ps1', { NewName: p.name }));
      }
      return steps;
    },
  },
  {
    name: 'autoshop_import_table',
    description: '导入整张表（结构体成员 / GVL 变量 / FB 变量表 / 功能块实例）——整表替换。preset 决定该视图的导入偏移（fb/gvl/struct/fbi，已内置）。默认：先开视图 → 导入 → 保存并验星号。',
    schema: {
      type: 'object',
      properties: {
        view: { type: 'string', description: '已打开视图名，如 ST_气缸 / GVL_SYS / FB_气缸 / 功能块实例' },
        csv: { type: 'string', description: '整表 CSV（GBK，全量，含表头）' },
        preset: { type: 'string', enum: ['fb', 'gvl', 'struct', 'fbi'] },
        open: { type: 'boolean', description: '导入前先按名字打开该表（默认 true）' },
        confirm: { type: 'boolean', description: '自动确认「当前表格将被清空且不支持撤销恢复」（默认 true）' },
        save: { type: 'boolean', description: '导入后自动保存并验星号（默认 true）' },
      },
      required: ['view', 'csv', 'preset'],
    },
    build: (p) => {
      const pre = IMPORT_PRESET[p.preset];
      if (!pre) throw new Error('unknown preset: ' + p.preset + ' (use fb|gvl|struct|fbi)');
      const steps = [];
      if (p.open !== false) steps.push(step('autoshop-open-node.ps1', { Node: p.view }));
      steps.push(step('autoshop-import-vartable.ps1', {
        View: p.view, CsvPath: p.csv, ConfirmImport: p.confirm !== false,
        ImportOffsetY: pre.ImportOffsetY, ExpectedMenuH: pre.ExpectedMenuH,
      }));
      if (p.save !== false) steps.push(step('autoshop-save-until-clean.ps1', {}));
      return steps;
    },
  },
  {
    name: 'autoshop_check_block',
    description: '五条铁律自查：ST 基本结构、局部变量声明、全局变量存在、调用的 FB 已实例化、TON/TRIG 实例存在。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        mirror_dir: { type: 'string', description: '镜像根目录' },
        block: { type: 'string' },
        body_file: { type: 'string', description: '.md（围栏正文）或纯 .st' },
        inst_name: { type: 'string' }, fb_type: { type: 'string' },
        table_dir: { type: 'string', description: '镜像内放 GVL csv 的目录，如 变量表' },
        fbi_path: { type: 'string', description: '功能块实例 csv 的完整路径' },
      },
      required: ['mirror_dir', 'block'],
    },
    build: (p) => [step('autoshop-check-block.ps1', {
      MirrorDir: p.mirror_dir, Block: p.block, BodyFile: p.body_file || '',
      InstName: p.inst_name || '', FbType: p.fb_type || '',
      TableDir: p.table_dir || '', FbiPath: p.fbi_path || '',
    })],
  },
  {
    name: 'autoshop_make_tables',
    description: '由一个 UTF-8 规格文件生成全部 AutoShop 表（GBK 导入表 + UTF-8 设计稿）。改设计只改规格文件，不要手写 CSV。',
    schema: { type: 'object', properties: { spec: { type: 'string' }, mirror: { type: 'string' } }, required: ['spec', 'mirror'] },
    build: (p) => [step('make-cylinder-tables.ps1', { Spec: p.spec, Mirror: p.mirror })],
  },
  {
    name: 'autoshop_md_to_st',
    description: '从镜像 .md 里抽出围栏正文成纯 .st（写入通道要文件）。兼容单反引号的畸形围栏。',
    schema: { type: 'object', properties: { md: { type: 'string' }, out: { type: 'string' } }, required: ['md', 'out'] },
    build: (p) => [step('md-to-st.ps1', { Md: p.md, Out: p.out })],
  },
  {
    name: 'autoshop_set_pane',
    description: '把工程树左栏拖到指定像素宽度（修「左栏过宽」）。默认 346px。',
    schema: { type: 'object', properties: { width: { type: 'integer' } } },
    build: (p) => [step('autoshop-set-pane.ps1', { Width: p.width || 346 })],
  },
  {
    name: 'autoshop_dialogs',
    description: '列出当前所有模态弹窗及其按钮；action=ok/cancel 时按文字（确定/是 / 否/取消）回答，认不出的框不动它。',
    schema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'ok', 'cancel'] } } },
    build: (p) => {
      const a = p.action || 'list';
      const map = { list: 'None', ok: 'OK', cancel: 'Cancel' };
      return [step('autoshop-dialog-answer.ps1', { Button: map[a] || 'None', List: a === 'list' })];
    },
  },
];

// ---------------------------------------------------------------- runner
// ★ ONCE PER SESSION (user rule, 2026-09-20: "软件打开一次控制 autoshop 判断一次"):
//   every time AutoShop is (re)started it comes back MAXIMISED and with a ~198px tree pane, and
//   offset-based actions then land wrong. Instead of hoping the caller remembers, the server runs the
//   preflight itself before the FIRST tool call of the process.
//   -KeepViews is deliberate: closing block views can discard unsaved edits (WM_CLOSE raises a save
//   prompt and the preflight answers No/Cancel by design), so an automatic pass must never close them.
//   If the pass fails (AutoShop not up yet) it is simply retried on the next call.
let sessionReady = false;
async function ensureSessionPreflight() {
  if (sessionReady) return '';
  const r = await runPowershell(step('autoshop-preflight.ps1', { Fix: true, Deep: true, KeepViews: true }));
  if (r.code === 0) sessionReady = true;
  const head = '### [session start] AutoShop normalised once (window geometry + pane 346px + expand folders; views NOT closed)\n';
  const tail = r.code === 0
    ? ''
    : '\n(NOTE: this startup pass did not succeed - is AutoShop running? It will be retried on the next call.)';
  return head + (r.out || '').trim() + (r.err ? '\n[stderr] ' + r.err.trim() : '') + tail + '\n\n';
}

function runPowershell(spec) {
  return new Promise((resolve) => {
    const dir = mkdtempSync(join(tmpdir(), 'autoshop-mcp-'));
    const specFile = join(dir, 'spec.json');
    try {
      writeFileSync(specFile, JSON.stringify(spec), 'utf8');
      const args = ['-STA', '-NoProfile', '-ExecutionPolicy', 'Bypass',
        '-File', join(HERE, 'mcp-invoke.ps1'),
        '-SpecFile', specFile, '-ScriptDir', TOOLS_DIR];
      const child = spawn(POWERSHELL, args, { windowsHide: true });
      let out = '', err = '';
      child.stdout.setEncoding('utf8');
      child.stderr.setEncoding('utf8');
      child.stdout.on('data', (d) => { out += d; });
      child.stderr.on('data', (d) => { err += d; });
      child.on('error', (e) => { cleanup(); resolve({ code: -1, out, err: err + String(e && e.message || e) }); });
      child.on('close', (code) => { cleanup(); resolve({ code: code === null ? -1 : code, out, err }); });
      function cleanup() { try { rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ } }
    } catch (e) {
      try { rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
      resolve({ code: -1, out: '', err: String(e && e.message || e) });
    }
  });
}

async function callTool(name, args) {
  const tool = TOOLS.find((t) => t.name === name);
  if (!tool) return { text: 'unknown tool: ' + name, isError: true };
  let steps;
  try { steps = tool.build(args || {}); }
  catch (e) { return { text: String(e && e.message || e), isError: true }; }

  // ★ ONCE PER SESSION (user rule 2026-09-20: "每次开始控制 AutoShop 就判断一次"):
  //   normalise the AutoShop window before the first real tool call. An explicit autoshop_preflight
  //   call IS that check, so it is not run twice.
  let pre = '';
  if (name !== 'autoshop_preflight') pre = await ensureSessionPreflight();

  const parts = [];
  let failed = false;
  for (let i = 0; i < steps.length; i++) {
    const r = await runPowershell(steps[i]);
    parts.push('--- step ' + (i + 1) + '/' + steps.length + ': ' + steps[i].script + ' (exit ' + r.code + ') ---');
    if (r.out) parts.push(r.out.replace(/\s+$/, ''));
    if (r.err) parts.push('[stderr]\n' + r.err.replace(/\s+$/, ''));
    if (r.code !== 0) { failed = true; break; }   // a failed step invalidates the rest (dependencies)
  }
  return { text: pre + parts.join('\n'), isError: failed };
}

// ---------------------------------------------------------------- JSON-RPC over stdio
function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n'); }

function handle(msg) {
  const { id, method, params } = msg;
  const isNotification = (id === undefined || id === null);

  if (method === 'initialize') {
    send({ jsonrpc: '2.0', id, result: {
      protocolVersion: PROTOCOL,
      capabilities: { tools: {} },
      serverInfo: { name: 'autoshop-uia', version: '1.0.0' },
    } });
    return;
  }
  if (method === 'notifications/initialized' || method === 'initialized') return;
  if (method === 'ping') { if (!isNotification) send({ jsonrpc: '2.0', id, result: {} }); return; }
  if (method === 'tools/list') {
    send({ jsonrpc: '2.0', id, result: { tools: TOOLS.map((t) => ({
      name: t.name,
      description: t.description,
      inputSchema: t.schema,
      annotations: { readOnlyHint: !!t.readOnly },
    })) } });
    return;
  }
  if (method === 'tools/call') {
    const name = params && params.name;
    const args = (params && params.arguments) || {};
    // ★ SERIALIZE every tool call. These tools drive ONE real AutoShop window with the mouse, the
    //   keyboard, MSAA selection and modal dialogs -- two of them running at once fight over focus and
    //   destroy each other's work. Measured: firing open_node + read_block + close_all together made
    //   read_block run BEFORE open_node finished ("no open block view titled 'FB_气缸'"). A client is
    //   allowed to send calls in parallel, so the SERVER must be the one that queues them.
    pending++;
    queue = queue.then(() => callTool(name, args)).then((r) => {
      send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: r.text }], isError: r.isError } });
    }).catch((e) => {
      send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: String(e && e.message || e) }], isError: true } });
    }).finally(() => {
      pending--;
      if (stdinEnded && pending === 0) process.exit(0);
    });
    return;
  }
  if (!isNotification) {
    send({ jsonrpc: '2.0', id, error: { code: -32601, message: 'method not found: ' + method } });
  }
}

let buf = '';
// ★ 2026-09-20: a piped stdin (tests, `echo | server`) closes long before a tool call finishes. Exiting
// on 'end' alone truncated in-flight calls and the response was lost, so exit only when stdin has ended
// AND nothing is pending.
let stdinEnded = false;
let pending = 0;
let queue = Promise.resolve();   // serializes tool calls: only ONE may touch AutoShop at a time
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buf += chunk;
  let idx;
  while ((idx = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, idx).trim();
    buf = buf.slice(idx + 1);
    if (!line) continue;
    let msg;
    try { msg = JSON.parse(line); }
    catch { process.stderr.write('autoshop-mcp: bad JSON line, ignored\n'); continue; }
    try { handle(msg); }
    catch (e) { process.stderr.write('autoshop-mcp: handler error: ' + String(e && e.message || e) + '\n'); }
  }
});
process.stdin.on('end', () => { stdinEnded = true; if (pending === 0) process.exit(0); });
process.stderr.write('autoshop-mcp: ready (tools dir ' + TOOLS_DIR + ')\n');
