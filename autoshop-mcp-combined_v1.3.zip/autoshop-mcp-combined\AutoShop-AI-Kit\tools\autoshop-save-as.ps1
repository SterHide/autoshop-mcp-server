# Drive the AutoShop "save as" dialog WITHOUT relying on its geometry.
#
# The dialog's height changes between 600 and 209 px depending on its state, so clicking a computed
# pixel for the filename box is fragile. The robust route (verified): its filename Edit already has
# the keyboard focus, so paste the full target path and press Enter. Focus is CONFIRMED first via
# GetGUIThreadInfo (works across processes, unlike GetFocus) rather than assumed.
#
# Chinese must go in via the CLIPBOARD: SendKeys cannot type it reliably, and the path contains
# Chinese folder names plus parentheses that SendKeys would treat as special characters.
#
# Safety: never presses Yes/OK on an unknown dialog. No/Cancel when present, ESC otherwise -- ESC
# dismisses an information box just as well and can never confirm anything.
#
# KEEP PURE ASCII (the path arrives as a parameter).
param(
  [string]$Path = '',            # full target path to save as
  [switch]$Abort,                # cancel the dialog instead of saving
  [string]$DialogTitle = '',     # optional caption filter
  [int]$WaitMs = 1500
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$ErrorActionPreference = 'Continue'   # clipboard can transiently fail; handle it explicitly
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint tid, ref GUITHREADINFO gti);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
[StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
  public uint cbSize; public uint flags; public IntPtr hwndActive; public IntPtr hwndFocus;
  public IntPtr hwndCapture; public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret;
  public RECT rcCaret; }
'@
}
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88
$S_SAVE   = [string][char]0x4FDD + [string][char]0x5B58      # save
$LD = 0x02; $LU = 0x04

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function Send([string]$k, [int]$w = 150) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function ClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }

function Get-Dialogs {
  $d = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$d.Add($h) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $d }
function Get-Kids([IntPtr]$dlg) {
  $k = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ([W.U]::IsWindowVisible($h)) { [void]$k.Add($h) }
    return $true }
  [void][W.U]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $k }

# Dismiss a dialog safely: No > Cancel > ESC. Never Yes/OK.
function Dismiss([IntPtr]$dlg) {
  foreach ($b in (Get-Kids $dlg)) {
    $t = TxtOf $b
    if ((ClsOf $b) -eq 'Button' -and ($t.Contains($S_NO) -or $t.Contains($S_CANCEL))) {
      $r = RectOf $b
      ClickRaw ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2))
      Write-Output ("   dismissed '{0}' by pressing '{1}'" -f (TxtOf $dlg), $t)
      Start-Sleep -Milliseconds 400
      return
    }
  }
  Send '{ESC}' 400
  Write-Output ("   dismissed '{0}' with ESC (no No/Cancel button)" -f (TxtOf $dlg))
}

$target = [IntPtr]::Zero
foreach ($d in (Get-Dialogs)) {
  $t = TxtOf $d
  if ($DialogTitle -and $t -notlike "*$DialogTitle*") { continue }
  $target = $d; break
}
if ($target -eq [IntPtr]::Zero) { Write-Output 'no dialog found - nothing to do'; exit 0 }
$dr = RectOf $target
Write-Output ("dialog hwnd={0} '{1}' rect={{ {2},{3} {4}x{5} }}" -f $target, (TxtOf $target), $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))

if ($Abort) {
  Dismiss $target
  Write-Output 'aborted.'
  exit 0
}
if (-not $Path) { throw 'pass -Path or -Abort' }

# --- confirm the filename Edit really has focus -----------------------------------------------
$tid = [W.U]::GetWindowThreadProcessId($target, [IntPtr]::Zero)
$gti = New-Object W.U+GUITHREADINFO
$gti.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($gti)
$ok = [W.U]::GetGUIThreadInfo($tid, [ref]$gti)
if (-not $ok) { throw 'GetGUIThreadInfo failed' }
$focus = $gti.hwndFocus
$focusCls = if ($focus -ne [IntPtr]::Zero) { ClsOf $focus } else { '' }
Write-Output ("focused control = {0} class='{1}'" -f $focus, $focusCls)
if ($focusCls -ne 'Edit') {
  Write-Output 'WARNING: the focused control is not an Edit; the paste may land somewhere else.'
}

# --- paste the path and commit -----------------------------------------------------------------
$set = $false
for ($i = 0; $i -lt 5 -and -not $set; $i++) {
  try { [System.Windows.Forms.Clipboard]::SetText($Path); $set = $true }
  catch { Start-Sleep -Milliseconds 250 }
}
if (-not $set) { throw 'could not put the path on the clipboard' }
Write-Output ("clipboard <- '{0}'" -f $Path)
Send '^a' 200
Send '^v' 400
Send '{ENTER}' 200
Start-Sleep -Milliseconds $WaitMs

# --- deal with whatever comes next -------------------------------------------------------------
for ($round = 0; $round -lt 6; $round++) {
  $rest = Get-Dialogs
  if ($rest.Count -eq 0) { break }
  foreach ($d in $rest) {
    # ★ 2026-09-20: both branches are the same action, so the Chinese test was dead weight -- and a
    # Chinese literal in a BOM-less .ps1 is read as ANSI by PowerShell 5.1 (mojibake), which is how the
    # import tool's success-box dismissal silently stopped working. Keep it explicit and literal-free.
    Dismiss $d        # the save dialog or an info box - backing out is correct for both
  }
  Start-Sleep -Milliseconds 600
}
$left = Get-Dialogs
Write-Output ("dialogs remaining: {0}" -f $left.Count)
foreach ($d in $left) { Write-Output ("   STILL OPEN: '{0}'" -f (TxtOf $d)) }

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }