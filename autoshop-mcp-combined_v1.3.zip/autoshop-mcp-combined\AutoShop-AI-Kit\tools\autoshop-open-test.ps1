﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Two short, mostly read-only experiments that decide the extractor's design.
#
# BACKGROUND: the coordinate route (read accLocation -> double-click the rect) is the most fragile
# part of the sweep. In a real run 8 blocks in a row failed with "title was ''": the double-clicks
# opened nothing, and consecutive nodes reported y=918 then y=178 -- 740px apart, impossible for
# adjacent rows.
#
# EXPERIMENT A -- are accLocation rects STALE?
#   Read each node's rect, sleep, read it again. Compare. Also check the row-grid invariant
#   (verified row height is 20px, so consecutive rows must differ by a multiple of 20).
#   A rect that changes between two reads, or a dy that is not a multiple of 20, proves staleness.
#
# EXPERIMENT B -- can a block be opened with NO MOUSE AT ALL?
#   MSAA IAccessible::accDoDefaultAction() asks the control to perform an item's default action.
#   If AutoShop's tree honours it, opening a block needs no coordinates: no stale rect, no missed
#   click, no chance of hitting a folder and popping the modal "program block properties" dialog.
#   Read-only to the project: if a view opens it is closed again with WM_CLOSE.
#
# The tree is left at the top on exit -- an earlier probe left it scrolled to the bottom and that
# was a mistake worth not repeating.
#
# KEEP PURE ASCII. Run with -STA.
param([int]$GridSteps = 40, [int]$MaxSteps = 150)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000;
         selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88
$LD = 0x02; $LU = 0x04
$WM_CLOSE = 0x0010

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function RawClick([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }
function Dialogs {
  $d = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$d.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero); return $d }
function AssertNoDialog([string]$where) {
  $hit = 0
  foreach ($d in (Dialogs)) {
    $kids = New-Object System.Collections.ArrayList
    $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d, $cb, [IntPtr]::Zero)
    Write-Output ("   [dialog] ({0}) '{1}' buttons=[{2}]" -f $where, (TxtOf $d), (($kids | ForEach-Object { TxtOf $_ }) -join '/'))
    $pressed = $false
    foreach ($b in $kids) {
      $t = TxtOf $b
      if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) {
        $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$r)
        RawClick ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2)); $pressed = $true; break } }
    if (-not $pressed) { Send '{ESC}' 400 }
    Start-Sleep -Milliseconds 350; $hit++ }
  return $hit }
function ClickChecked([int]$x, [int]$y, [string]$where) { RawClick $x $y; Start-Sleep -Milliseconds 160; [void](AssertNoDialog $where) }

function MdiInfo([IntPtr]$mainHwnd) {
  $root = [System.Windows.Automation.AutomationElement]::FromHandle($mainHwnd)
  $AE = [System.Windows.Automation.AutomationElement]
  $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Window)
  $w = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  $names = @(); foreach ($x in $w) { $names += $x.Current.Name }
  return [pscustomobject]@{ Count = $w.Count; Names = ($names -join ' | ') } }

function CloseAll([IntPtr]$mainHwnd) {
  $script:mdiT = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'MDIClient') { $script:mdiT = $h }; return $true }
  [void][W.U]::EnumChildWindows($mainHwnd, $cb, [IntPtr]::Zero)
  $mdi = $script:mdiT
  if ($null -eq $mdi -or $mdi -eq [IntPtr]::Zero) { return 0 }
  $n = 0
  for ($i = 0; $i -lt 80; $i++) {
    $script:kid = [IntPtr]::Zero
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { $script:kid = $h; return $false }; return $true }
    [void][W.U]::EnumChildWindows($mdi, $cb2, [IntPtr]::Zero)
    $k = $script:kid
    if ($null -eq $k -or $k -eq [IntPtr]::Zero) { break }
    [void][W.U]::SendMessageW($k, $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 320; [void](AssertNoDialog 'closing'); $n++ }
  return $n }

# --- setup -----------------------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$script:MainHwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows($script:MainHwnd, $cb, [IntPtr]::Zero)
$tree = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:acc = $null
$hr = [W.U]::AccessibleObjectFromWindow($tree.hwnd, [uint32]4294967292, [ref]$iid, [ref]$script:acc)
if ($hr -ne 0) { throw ("AccessibleObjectFromWindow hr=0x{0:X8}" -f $hr) }
Write-Output ("tree rect = {{ {0},{1} {2}x{3} }}  (row grid top={1}, height={4}px, usable rows={5})" -f `
  $tree.rect.Left, $tree.rect.Top, ($tree.rect.Right-$tree.rect.Left), ($tree.rect.Bottom-$tree.rect.Top), 20, `
  [int](($tree.rect.Bottom - $tree.rect.Top)/20))

[void][W.U]::SetForegroundWindow($script:MainHwnd); Start-Sleep -Milliseconds 350
[void](AssertNoDialog 'pre-flight')
Write-Output ("stale windows closed: {0}" -f (CloseAll $script:MainHwnd))

function ReadSel {
  $id = $null
  try { $id = $script:acc.accSelection } catch { }
  $o = [pscustomobject]@{ Id=$null; Name=''; State=-1; X=0; Y=0; W=0; H=0 }
  if ($null -eq $id -or $id -isnot [int]) { return $o }
  try { $o.Name  = [string]$script:acc.accName([int]$id) } catch { }
  try { $o.State = [int]$script:acc.accState([int]$id) } catch { }
  $x=0;$y=0;$w=0;$h=0
  try { $script:acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$id) } catch { }
  $o.X=$x;$o.Y=$y;$o.W=$w;$o.H=$h;$o.Id=[int]$id
  return $o }

ClickChecked ($tree.rect.Left + 40) ($tree.rect.Top + 10) 'focus tree'
Send '^({HOME})' 600
$s = ReadSel
if ($s.Name -notlike 'ST*') {
  $prev = $s.Name
  for ($i = 0; $i -lt 400; $i++) { Send '{UP}' 35; $s = ReadSel; if ($s.Name -eq $prev) { break }; $prev = $s.Name } }
Write-Output ("walk starts at id={0} '{1}'" -f $s.Id, $s.Name)

# --- EXPERIMENT A: rect staleness + row-grid invariant ---------------------------------------
Write-Output ''
Write-Output '=== A) is accLocation stale? (two reads per node, 120ms apart) ==='
$stale = 0; $gridBad = 0; $prevY = $null; $n = 0
for ($i = 1; $i -le $GridSteps; $i++) {
  $a = ReadSel
  Start-Sleep -Milliseconds 120
  $b = ReadSel
  if ($a.Id -and $a.Name) {
    $n++
    $isStale = ($a.Y -ne $b.Y -or $a.X -ne $b.X -or $a.W -ne $b.W -or $a.H -ne $b.H)
    $dy = if ($null -ne $prevY) { $a.Y - $prevY } else { $null }
    $gridOk = ($null -eq $dy) -or ($dy % 20 -eq 0)
    if ($isStale) { $stale++ }
    if (-not $gridOk) { $gridBad++ }
    if ($isStale -or -not $gridOk) {
      Write-Output ("  !! step {0,3} id={1,4} '{2}'  read1=({3},{4})  read2=({5},{6})  stale={7}  dy={8} gridOk={9}" -f `
        $i, $a.Id, $a.Name, $a.X, $a.Y, $b.X, $b.Y, $isStale, $dy, $gridOk)
    } elseif ($i -le 8) {
      Write-Output ("     step {0,3} id={1,4} '{2}'  y={3} dy={4}" -f $i, $a.Id, $a.Name, $a.Y, $dy)
    }
    $prevY = $a.Y
  }
  Send '{DOWN}' 80
}
Write-Output ("  nodes read: {0}   STALE (two reads disagree): {1}   GRID-BAD (dy not a multiple of 20): {2}" -f $n, $stale, $gridBad)
if ($stale -gt 0 -or $gridBad -gt 0) { Write-Output '  => accLocation IS unreliable for click targeting; prefer a coordinate-free way to open a block.' }
else { Write-Output '  => rects were consistent in this sample; staleness did not reproduce here.' }

# --- EXPERIMENT B: accDoDefaultAction --------------------------------------------------------
Write-Output ''
Write-Output '=== B) can accDoDefaultAction open a block with no mouse at all? ==='
$folderTxt = 'C:\Users\Administrator\Desktop\ST妗嗘灦\folder.txt'
$blocks = @{}
$section = $null
foreach ($raw in [System.IO.File]::ReadAllLines($folderTxt, [System.Text.Encoding]::UTF8)) {
  if ([string]::IsNullOrWhiteSpace($raw)) { continue }
  $body = $raw.Trim()
  if ($body -eq 'PROG' -or $body -eq 'FB' -or $body -eq 'FC') { $section = $body; continue }
  if ($body -like 'FILE*' -and $section) { $blocks[[System.IO.Path]::GetFileNameWithoutExtension($body.Substring(4).Trim())] = $true } }
Write-Output ("  block names loaded: {0}" -f $blocks.Count)

$target = $null
for ($i = 0; $i -lt $MaxSteps; $i++) {
  $s = ReadSel
  if ($s.Id -and $blocks.ContainsKey($s.Name)) { $target = $s; break }
  Send '{DOWN}' 70
}
if ($null -eq $target) { Write-Output ('  no block found within {0} steps' -f $MaxSteps) }
else {
  Write-Output ("  target block: id={0} '{1}' rect=({2},{3},{4},{5})" -f $target.Id, $target.Name, $target.X, $target.Y, $target.W, $target.H)
  try { $script:acc.accSelect(3, [int]$target.Id) } catch { }
  Start-Sleep -Milliseconds 300
  $before = MdiInfo $script:MainHwnd
  Write-Output ("  before: MDI windows={0} [{1}]" -f $before.Count, $before.Names)

  $method = 'accDoDefaultAction'
  $err = ''
  try { $script:acc.accDoDefaultAction([int]$target.Id) } catch { $err = $_.Exception.Message }
  if ($err) { Write-Output ("  accDoDefaultAction threw: {0}" -f $err) }
  Start-Sleep -Milliseconds 1200
  [void](AssertNoDialog 'after accDoDefaultAction')
  $after = MdiInfo $script:MainHwnd
  Write-Output ("  after {0}: MDI windows={1} [{2}]" -f $method, $after.Count, $after.Names)

  if ($after.Count -gt $before.Count) {
    Write-Output '  *** SUCCESS: a view opened with no mouse input -> the coordinate route can be dropped.'
  } else {
    Write-Output '  no new view -> accDoDefaultAction does not open blocks here.'
    # fall back: try the coordinate double-click, and compare
    $cx = $target.X + [Math]::Min(25, [Math]::Max(6, [int]($target.W/2)))
    $cy = $target.Y + [int]($target.H/2)
    Write-Output ("  control test: double-click at ({0},{1})" -f $cx, $cy)
    [void][W.U]::SetCursorPos($cx, $cy); Start-Sleep -Milliseconds 110
    [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
    [W.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 60
    [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
    [W.U]::mouse_event($LU,0,0,0,0)
    Start-Sleep -Milliseconds 1200
    [void](AssertNoDialog 'after double-click')
    $after2 = MdiInfo $script:MainHwnd
    Write-Output ("  after double-click: MDI windows={0} [{1}]" -f $after2.Count, $after2.Names)
    if ($after2.Count -gt $before.Count) { Write-Output '  coordinate double-click DID work here (so the earlier failures were rect-specific).' }
    else { Write-Output '  coordinate double-click also failed here.' }
  }
}

# --- restore ---------------------------------------------------------------------------------
$closed = CloseAll $script:MainHwnd
Send '^({HOME})' 600
[void](AssertNoDialog 'restore')
$end = ReadSel
Write-Output ''
Write-Output ("cleanup: {0} view(s) closed; tree left at id={1} '{2}'" -f $closed, $end.Id, $end.Name)

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }
