# Fill the "new subprogram" dialog that `autoshop-node-menu.ps1` just opened, confirm it, and verify
# where the new block actually landed in the project tree.
#
# MEASURED FACTS (AutoShop V4.11.0.5, Easy523):
#   * the dialog is a plain #32770 (TITLE = the two chars for "new"), 435x183 at 746,523, with
#       Edit     857,567 252x23   -> the name
#       ComboBox 857,604 251x21   -> 2 items: [0] ladder (LD)   [1] structured text (LiteST)  cursel=1
#       Button   829,650 / 953,650 -> OK / Cancel   (OK is the LEFT button)
#   * the LANGUAGE combo already defaults to index 1 = structured text (LiteST), which is what a
#     pure-ST project wants, so it only has to be touched when LD is actually wanted.
#   * AutoShop ALWAYS PREPENDS "SBR_" for a subprogram: typing DSH_TEST01 produced SBR_DSH_TEST01,
#     typing SBR_DSH_TEST02 produced SBR_SBR_DSH_TEST02. The user confirmed this prefix is the
#     software's INTENDED behaviour, so it is not worked around: pass the BARE name and let AutoShop
#     add the prefix, and name the local .md after the FINAL block name (SBR_<bare>).
#   * GetWindowText() CANNOT read a control in another process -- it returns '' and makes it look as
#     if WM_SETTEXT failed. Read it back with WM_GETTEXT, which does work across processes.
#   * the dialog is driven with NO click and NO foreground grab: WM_SETTEXT into the Edit, BM_CLICK
#     into the OK button. Clicks/keys are unreliable while a modal dialog is up.
#
# KEEP PURE ASCII: powershell.exe reads this file as ANSI, so Chinese literals turn to mojibake.
param(
  [Parameter(Mandatory=$true)][string]$Name,   # BARE name; AutoShop adds the SBR_ prefix itself
  [int]$Language = 1,                          # 1 = structured text (LiteST)
  [switch]$NoConfirm,                          # fill the dialog but leave it open (do not press OK)
  [switch]$KeepView                            # do not close the editor view AutoShop opens
)

# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

$ErrorActionPreference = 'Stop'
if (-not ('A.U' -as [type])) {
if (-not ('A.U' -as [type])) {
Add-Type -Namespace A -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, System.Text.StringBuilder lp);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, string lp);
[DllImport("user32.dll", EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
}
function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][A.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function RectOf([IntPtr]$h){$r=New-Object A.U+RECT;[void][A.U]::GetWindowRect($h,[ref]$r);return $r}
function CtrlText([IntPtr]$h){ $sb=New-Object System.Text.StringBuilder 512; [void][A.U]::SendMessageW($h,0x000D,[IntPtr]512,$sb); $sb.ToString() }

# --- find the dialog ---------------------------------------------------------------------------
$dl = New-Object System.Collections.ArrayList
$cb = [A.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq '#32770' -and [A.U]::IsWindowVisible($h)){ [void]$dl.Add($h) }; return $true }
[void][A.U]::EnumWindows($cb,[IntPtr]::Zero)
if ($dl.Count -eq 0) { throw 'no visible #32770 dialog - open the node menu and pick "insert subprogram" first' }
$dlg = $dl[0]
if ($dl.Count -gt 1) { Write-Output ("  WARNING: {0} dialogs are up; using the first" -f $dl.Count) }
$dr = RectOf $dlg
Write-Output ("dialog hwnd={0} {{ {1},{2} {3}x{4} }}" -f $dlg,$dr.Left,$dr.Top,($dr.Right-$dr.Left),($dr.Bottom-$dr.Top))

$kids = New-Object System.Collections.ArrayList
$cb2 = [A.U+EnumProc]{ param($h,$p) [void]$kids.Add($h); return $true }
[void][A.U]::EnumChildWindows($dlg,$cb2,[IntPtr]::Zero)
$edit = $null; $combo = $null; $okBtn = $null; $cancelBtn = $null
foreach ($k in $kids) {
  $c = ClsOf $k
  if ($c -eq 'Edit'     -and $null -eq $edit)  { $edit = $k }
  if ($c -eq 'ComboBox' -and $null -eq $combo) { $combo = $k }
  if ($c -eq 'Button') {
    # Tell OK from Cancel without embedding Chinese: OK is the LEFT button (829 vs 953 measured).
    if ($null -eq $okBtn -or (RectOf $k).Left -lt (RectOf $okBtn).Left) { $cancelBtn = $okBtn; $okBtn = $k }
    else { $cancelBtn = $k }
  }
}
if ($null -eq $edit)  { throw 'no Edit in the dialog' }
if ($null -eq $okBtn) { throw 'no Button in the dialog' }
Write-Output ("  Edit hwnd={0}  ComboBox hwnd={1}  OK-button hwnd={2}" -f $edit,$(if($combo){$combo}else{'(none)'}),$okBtn)

# --- language (only the new-subprogram dialog has this combo; the new-FOLDER dialog has none) ---
if ($null -ne $combo) {
  $nItems = [int][A.U]::SendMessageW($combo,0x0146,[IntPtr]::Zero,[IntPtr]::Zero)   # CB_GETCOUNT
  $cur    = [int][A.U]::SendMessageW($combo,0x0147,[IntPtr]::Zero,[IntPtr]::Zero)   # CB_GETCURSEL
  Write-Output ("  language combo: {0} item(s), cursel={1}" -f $nItems,$cur)
  if ($Language -ne $cur) { [void][A.U]::SendMessageW($combo,0x014E,[IntPtr]$Language,[IntPtr]::Zero) }  # CB_SETCURSEL
  $cur2 = [int][A.U]::SendMessageW($combo,0x0147,[IntPtr]::Zero,[IntPtr]::Zero)
  Write-Output ("  language cursel now {0} (1 = structured text / LiteST)" -f $cur2)
} else {
  Write-Output '  no ComboBox in this dialog - nothing to pick (a FOLDER has no language).'
}

# --- name -------------------------------------------------------------------------------------
[void][A.U]::SendMessageW($edit,0x000C,[IntPtr]::Zero,$Name)                       # WM_SETTEXT
Start-Sleep -Milliseconds 250
$back = CtrlText $edit
Write-Output ("  name written; read back with WM_GETTEXT: '{0}'" -f $back)
if ($back -ne $Name) { Write-Output '  NOTE: the control echoes something else (the app may display a fixed prefix).' }

if ($NoConfirm) { Write-Output '  -NoConfirm: dialog left open on purpose.'; exit 0 }

# --- confirm ----------------------------------------------------------------------------------
Write-Output '  pressing OK (BM_CLICK)'
[void][A.U]::SendMessageW($okBtn,0x00F5,[IntPtr]::Zero,[IntPtr]::Zero)
Start-Sleep -Milliseconds 2500

$dl2 = New-Object System.Collections.ArrayList
$cb3 = [A.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq '#32770' -and [A.U]::IsWindowVisible($h)){ [void]$dl2.Add($h) }; return $true }
[void][A.U]::EnumWindows($cb3,[IntPtr]::Zero)
Write-Output ("dialogs still up after OK: {0}" -f $dl2.Count)

if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1') }
$p = Get-Process -Name AutoShop  | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $p)
Write-Output ("main window title: '{0}'" -f (CtrlText $main))

# --- verify in the project tree ---------------------------------------------------------------
$trees = New-Object System.Collections.ArrayList
$cbt = [A.U+EnumProc]{ param($h,$x) if((ClsOf $h) -eq 'SysTreeView32' -and [A.U]::IsWindowVisible($h)){[void]$trees.Add($h)}; return $true }
[void][A.U]::EnumChildWindows($main,$cbt,[IntPtr]::Zero)
$tree = (@($trees) | Sort-Object { (RectOf $_).Left } | Select-Object -First 1)
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
[void][A.U]::AccessibleObjectFromWindow([IntPtr]$tree,[uint32]4294967292,[ref]$iid,[ref]$acc)
$count = [int]$acc.accChildCount
$maxId = $count + 800
$map = New-Object System.Collections.ArrayList
for ($i=1; $i -le $maxId; $i++) {
  $n = ''; try { $n = [string]$acc.accName($i) } catch { $n = '' }
  if ([string]::IsNullOrWhiteSpace($n)) { continue }
  [void]$map.Add([pscustomobject]@{ Id=$i; Name=$n })
}
$hit = @($map | Where-Object { $_.Name -like ('*' + $Name + '*') })
if ($hit.Count -eq 0) { Write-Output ("  could not find '*{0}*' in the tree (named nodes={1})" -f $Name,$map.Count); exit 0 }
foreach ($h in $hit) {
  $x=0;$y=0;$w=0;$hh=0
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$hh,[int]$h.Id) } catch {}
  Write-Output ("  FOUND id={0} '{1}'  indent x={2}" -f $h.Id,$h.Name,$x)
  Write-Output '    neighbours (indent x shows the level; the parent has the smaller x):'
  for ($d=-3; $d -le 3; $d++) {
    $k = [int]$h.Id + $d
    $nk = @($map | Where-Object { $_.Id -eq $k })
    if ($nk.Count -eq 0) { continue }
    $kx=0;$ky=0;$kw=0;$kh=0
    try { $acc.accLocation([ref]$kx,[ref]$ky,[ref]$kw,[ref]$kh,$k) } catch {}
    $mark = ''; if ($k -eq [int]$h.Id) { $mark = '   <== NEW' }
    Write-Output ("      id={0,-4} x={1,-5} '{2}'{3}" -f $k,$kx,$nk[0].Name,$mark)
  }
}

# --- close the editor view AutoShop opened for the new block -----------------------------------
# (an MDI child whose title carries the block name; WM_CLOSE, then verify it is gone)
if (-not $KeepView) {
  $mdic = [IntPtr]::Zero
  $cb4 = [A.U+EnumProc]{ param($h,$x) if((ClsOf $h) -eq 'MDIClient'){ $script:mdic = $h }; return $true }
  [void][A.U]::EnumChildWindows($main,$cb4,[IntPtr]::Zero)
  if ($mdic -ne [IntPtr]::Zero) {
    $docs = New-Object System.Collections.ArrayList
    $cb5 = [A.U+EnumProc]{ param($h,$x) [void]$docs.Add($h); return $true }
    [void][A.U]::EnumChildWindows($mdic,$cb5,[IntPtr]::Zero)
    foreach ($d in $docs) {
      $t = CtrlText $d
      if ($t -like ('*' + $Name + '*')) {
        Write-Output ("  closing view '{0}'" -f $t)
        [void][A.U]::PostMessageW($d,0x0010,[IntPtr]::Zero,[IntPtr]::Zero)   # WM_CLOSE
      }
    }
    Start-Sleep -Milliseconds 900
    $left = New-Object System.Collections.ArrayList
    $cb6 = [A.U+EnumProc]{ param($h,$x) $t2=(CtrlText $h); if($t2 -like ('*' + $Name + '*')){[void]$left.Add($t2)}; return $true }
    [void][A.U]::EnumChildWindows($mdic,$cb6,[IntPtr]::Zero)
    Write-Output ("  views for this block still open: {0}" -f $left.Count)
  }
}
if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
