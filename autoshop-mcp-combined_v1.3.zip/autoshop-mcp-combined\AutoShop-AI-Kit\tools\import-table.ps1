# import-table.ps1 -- drive an AutoShop table import (variable table / struct / FB instance) and then
# REALLY save, in the order the user demands: dismiss the success box FIRST, then Ctrl+S.
#
# WHY NOT THE BUILT-IN SAVE OF autoshop-import-vartable.ps1: that path looks for the success box with
# its own match, reported "(no success box found - continuing)" on V4.12.0.2, and then clicked the
# toolbar Save button at (88,71). Two consequences, both measured:
#   * the click lands in the modal box, so the save silently does nothing;
#   * the cursor is left hovering the toolbar, which raises a tooltip + 'SysShadow' window and makes
#     Process.MainWindowHandle return the shadow -> every later script "cannot find AutoShop".
# So: import with -NoSave, dismiss the box explicitly, park the cursor, then Ctrl+S.
#
# PURE ASCII. Chinese arrives via parameters.
param(
  [Parameter(Mandatory=$true)][string]$View,
  [Parameter(Mandatory=$true)][string]$CsvPath,
  [int]$ImportOffsetY = 456,
  [int]$ExpectedMenuH = 512,
  [string]$ButtonText = '',        # '' = press the leftmost button of whatever box is up
  [switch]$SkipSave
)
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'prelude.ps1')
$T = $PSScriptRoot

[void](Focus-AutoShopMain)

Write-Output '--- 1) import ---'
& (Join-Path $T 'autoshop-import-vartable.ps1') -View $View -CsvPath $CsvPath `
    -ImportOffsetY $ImportOffsetY -ExpectedMenuH $ExpectedMenuH -ConfirmImport -NoSave 2>&1 |
  ForEach-Object { Write-Output ('  ' + $_) }

Start-Sleep -Milliseconds 500
Write-Output '--- 2) dismiss the result box ---'
if ($ButtonText) {
  & (Join-Path $T 'press-dialog-button.ps1') -Title 'AutoShop' -ButtonText $ButtonText 2>&1 |
    ForEach-Object { Write-Output ('  ' + $_) }
} else {
  # no button text given: just report what is up (press-dialog-button has no -Leftmost switch)
  & (Join-Path $T 'press-dialog-button.ps1') -Title 'AutoShop' -List 2>&1 |
    ForEach-Object { Write-Output ('  ' + $_) }
}

if (-not $SkipSave) {
  Start-Sleep -Milliseconds 400
  Write-Output '--- 3) park the cursor, then Ctrl+S ---'
  Park-Cursor
  [void](Focus-AutoShopMain)
  $r = Save-AutoShop
  Write-Output ('  before: ' + $r.Before)
  Write-Output ('  after : ' + $r.After)
  Write-Output ('  marker cleared = ' + $r.MarkerCleared)
}
