# Verification harness for autoshop-mcp-server fixes.
# Runs the four checks that correspond to the four reported defects and prints a compact,
# diffable report. Keep this file ASCII-only: Windows PowerShell 5.1 reads a BOM-less file as
# ANSI, so any Chinese literal in the source would turn into mojibake. Paths with Chinese are
# therefore passed in as parameters from the caller.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File autoshop-verify.ps1 -ProjectPath '<abs project dir>' -Label before
param(
  [Parameter(Mandatory = $true)][string]$ProjectPath,
  [string]$Label = 'run',
  [int]$Port = 18711
)

Add-Type -AssemblyName System.Net.Http

function Invoke-McpTool {
  param([string]$Tool, [hashtable]$Arguments, [int]$Port)
  $payload = @{ jsonrpc = '2.0'; id = 1; method = 'tools/call'; params = @{ name = $Tool; arguments = $Arguments } }
  $body = $payload | ConvertTo-Json -Depth 12 -Compress
  $client = New-Object System.Net.Http.HttpClient
  $client.Timeout = [TimeSpan]::FromMinutes(3)
  $request = New-Object System.Net.Http.HttpRequestMessage ([System.Net.Http.HttpMethod]::Post), "http://127.0.0.1:$Port/mcp"
  [void]$request.Headers.Add('Accept', 'application/json, text/event-stream')
  $request.Content = New-Object System.Net.Http.StringContent ($body, [Text.Encoding]::UTF8, 'application/json')
  $response = $client.SendAsync($request).Result
  $text = $response.Content.ReadAsStringAsync().Result
  return [pscustomobject]@{
    ContentType = $response.Content.Headers.ContentType.ToString()
    Body        = ($text | ConvertFrom-Json)
  }
}

Write-Output "===== VERIFY [$Label] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ====="

# --- Check 1: does scan_active_project locate the open project without an explicit path? -------
Write-Output ""
Write-Output "--- 1) autoshop_scan_active_project (no projectPath) ---"
try {
  $r = Invoke-McpTool -Tool 'autoshop_scan_active_project' -Arguments @{ response_format = 'json' } -Port $Port
  if ($r.Body.result.isError) {
    Write-Output "FAIL  isError: $($r.Body.result.content[0].text)"
  }
  else {
    $sc = $r.Body.result.structuredContent
    Write-Output "OK    active_project_path = $($sc.active_project_path)"
    Write-Output "      programs=$($sc.scan.counts.programs) ld=$($sc.scan.counts.ladder_blocks) st=$($sc.scan.counts.st_blocks)"
  }
}
catch { Write-Output "FAIL  $($_.Exception.Message)" }

Write-Output ""
Write-Output "--- 1b) autoshop_detect_open_instances ---"
try {
  $r = Invoke-McpTool -Tool 'autoshop_detect_open_instances' -Arguments @{ response_format = 'json' } -Port $Port
  $si = $r.Body.result.structuredContent.selected_instance
  Write-Output "      projectPath   = $($si.projectPath)"
  Write-Output "      projectExists = $($si.projectExists)"
  Write-Output "      activeBlock   = $($si.activeBlock)"
}
catch { Write-Output "FAIL  $($_.Exception.Message)" }

# --- Check 2: instruction catalog with DEFAULT install path (no installPath argument) ----------
Write-Output ""
Write-Output "--- 2) autoshop_list_instruction_catalog (no installPath) ---"
try {
  $r = Invoke-McpTool -Tool 'autoshop_list_instruction_catalog' -Arguments @{ response_format = 'json'; limit = 1 } -Port $Port
  $sc = $r.Body.result.structuredContent
  Write-Output "      source_file = $($sc.source_file)"
  Write-Output "      total_count = $($sc.total_count)"
  Write-Output "      warnings    = $($sc.warnings -join ' | ')"
}
catch { Write-Output "FAIL  $($_.Exception.Message)" }

# --- Check 3: HTTP Content-Type carries charset=utf-8 -----------------------------------------
Write-Output ""
Write-Output "--- 3) HTTP Content-Type charset ---"
try {
  $r = Invoke-McpTool -Tool 'autoshop_bootstrap' -Arguments @{ response_format = 'markdown' } -Port $Port
  $ct = $r.ContentType
  if ($ct -match 'charset=utf-8') { Write-Output "OK    Content-Type = $ct" }
  else { Write-Output "FAIL  Content-Type = $ct  (no charset=utf-8)" }
}
catch { Write-Output "FAIL  $($_.Exception.Message)" }

# --- Check 4: instruction extraction coverage on a real LD container --------------------------
Write-Output ""
Write-Output "--- 4) autoshop_read_block_source MAIN.LD (instruction coverage) ---"
try {
  $r = Invoke-McpTool -Tool 'autoshop_read_block_source' -Arguments @{ projectPath = $ProjectPath; blockName = 'MAIN.LD'; response_format = 'json' } -Port $Port
  if ($r.Body.result.isError) {
    Write-Output "FAIL  isError: $($r.Body.result.content[0].text)"
  }
  else {
    $sc = $r.Body.result.structuredContent
    Write-Output "      calls        = $($sc.summary.calls.Count)"
    Write-Output "      instructions = $($sc.summary.instructions.Count)"
    Write-Output "      symbols      = $($sc.summary.symbols.Count)"
    Write-Output "      first 12 instructions:"
    $sc.summary.instructions | Select-Object -First 12 | ForEach-Object { Write-Output "        - $_" }
  }
}
catch { Write-Output "FAIL  $($_.Exception.Message)" }

Write-Output ""
Write-Output "===== END [$Label] ====="
