# Dump the AutoShop PROJECT TREE via MSAA.
#
# This is the fix for "blind double-clicking": we now know every row's NAME and exact screen
# rectangle before touching it, so a "program block" row (whose double-click pops the modal
# "program block properties" dialog and freezes the UI) can simply be skipped.
#
# Channel: oleacc!AccessibleObjectFromWindow(hwnd, OBJID_CLIENT, IID_IAccessible) -> IDispatch,
# then late-bound accName/accRole/accState/accLocation. Verified working:
#   accName(1)              = 'ST框架 [Easy523]'      (root)
#   accLocation(ref,ref,ref,ref,1) = 58,119,101,20    (MSAA wants BYREF ints)
# Gotchas that cost time:
#   * 0xFFFFFFFC is parsed by PowerShell as Int32 -4 -> must write [uint32]4294967292
#   * accLocation needs [ref] arguments; plain ints silently return nothing
#   * a uint32/double child id makes the provider throw E_INVALIDARG -> pass a plain int
#   * there are THREE SysTreeView32 in the main window; only the one at x<400 is the project tree
#     (the right-hand pair sits at x=1030 and exposes 1002 children that reject accName)
#
# KEEP THIS FILE PURE ASCII.
param(
  [string]$OutCsv = '',
  [int]$Max = 0,           # 0 = all
  [int]$TreeIndex = -1     # -1 = auto-pick the leftmost tree
)

# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

$ErrorActionPreference = 'Stop'
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }

function Get-Tree([int]$index) {
  $proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
  $hwnd = (Get-AutoShopMainWindow $proc)
  $trees = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq 'SysTreeView32') {
      $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
      [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r })
    }
    return $true
  }
  [void][W.U]::EnumChildWindows($hwnd, $cb, [IntPtr]::Zero)
  if ($index -ge 0) { return $trees[$index] }
  # auto: the project tree is the leftmost one (the MDI panes on the right start around x=1030)
  $best = $null
  foreach ($t in $trees) { if ($null -eq $best -or $t.rect.Left -lt $best.rect.Left) { $best = $t } }
  return $best
}

$t = Get-Tree $TreeIndex
if ($null -eq $t) { throw 'no SysTreeView32 found under the AutoShop main window' }
Write-Output ("project tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $t.hwnd, $t.rect.Left, $t.rect.Top, ($t.rect.Right-$t.rect.Left), ($t.rect.Bottom-$t.rect.Top))

$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'   # IID_IAccessible
$acc = $null
$hr = [W.U]::AccessibleObjectFromWindow($t.hwnd, [uint32]4294967292, [ref]$iid, [ref]$acc)
if ($hr -ne 0 -or $null -eq $acc) { throw ("AccessibleObjectFromWindow failed, hr=0x{0:X8}" -f $hr) }
$n = [int]$acc.accChildCount
Write-Output ("accChildCount = {0}" -f $n)
if ($Max -gt 0 -and $n -gt $Max) { $n = $Max }

$rows = New-Object System.Collections.ArrayList
for ($i = 1; $i -le $n; $i++) {
  $name = $null; $role = $null; $state = $null
  $x = 0; $y = 0; $w = 0; $h = 0
  try { $name = [string]$acc.accName([int]$i) } catch { $name = $null }
  try { $role = [int]$acc.accRole([int]$i) } catch { $role = -1 }
  try { $state = [int]$acc.accState([int]$i) } catch { $state = -1 }
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$i) } catch { }
  [void]$rows.Add([pscustomobject]@{ id=$i; role=$role; state=$state; x=$x; y=$y; w=$w; h=$h; name=$name })
}

# state flag decode (MSAA STATE_SYSTEM_*)
$F = @{ invisible=0x8000; offscreen=0x10000; collapsed=0x4000; expanded=0x2000; selected=0x2; focused=0x4; focusable=0x100000 }
function Flags([int]$s) {
  $f = New-Object System.Collections.ArrayList
  foreach ($k in @('expanded','collapsed','selected','focused','focusable','invisible','offscreen')) {
    if ($s -band $F[$k]) { [void]$f.Add($k) }
  }
  return ($f -join '+')
}

Write-Output ''
Write-Output ("{0,4} {1,5} {2,-28} {3,5} {4,5} {5,4} {6,3}  {7}" -f 'id','role','state','x','y','w','h','name')
foreach ($r in $rows) {
  Write-Output ("{0,4} {1,5} {2,-28} {3,5} {4,5} {5,4} {6,3}  {7}" -f $r.id, $r.role, (Flags $r.state), $r.x, $r.y, $r.w, $r.h, $r.name)
}

if ($OutCsv) {
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.AppendLine('id,role,state,x,y,w,h,name')
  foreach ($r in $rows) {
    $esc = if ($null -eq $r.name) { '' } else { '"' + ($r.name -replace '"','""') + '"' }
    [void]$sb.AppendLine(('{0},{1},{2},{3},{4},{5},{6},{7}' -f $r.id,$r.role,$r.state,$r.x,$r.y,$r.w,$r.h,$esc))
  }
  [System.IO.File]::WriteAllText($OutCsv, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
  Write-Output ''
  Write-Output ("wrote {0}" -f $OutCsv)
}

# quick sanity: how many rects fall outside the tree's own rectangle (=> scrolled out of view)
$outside = @($rows | Where-Object { $_.y -lt $t.rect.Top -or ($_.y + $_.h) -gt $t.rect.Bottom -or $_.w -le 0 })
Write-Output ''
Write-Output ("rows with rects outside the tree box / zero width: {0}" -f $outside.Count)
foreach ($o in ($outside | Select-Object -First 10)) { Write-Output ("   id={0} y={1} h={2} w={3} name='{4}'" -f $o.id,$o.y,$o.h,$o.w,$o.name) }
