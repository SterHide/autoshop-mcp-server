"""autoshop-combined: 把两个 AutoShop MCP 聚合成一个 stdio 服务器。

FastMCP 4.x ProxyProvider + MCPConfig 多后端：
- kit_ 前缀 -> AutoShop-AI-Kit 操作型（工程树/开关视图/读写块正文/保存/导表 +
              并入的原桥功能：进程探活标题解析、离线读工程树/符号表、
              对话框扫描/精确点按钮，共 19 工具）
              依赖 AutoShop 已打开，靠 MSAA + WM_SETTEXT + 像素点菜单
- r_   前缀 -> autoshop-mcp-server 解读版（LD/FB 解读、调用图、符号搜索、ST 生成，22 工具）
              离线读 .hcp；另含 Modbus TCP 读写实时点（风险最高，自行斟酌）

工具名加前缀防冲突，总共 41 个。启动时自动连接后端并发现工具。

可移植性（全部走环境变量，默认值就是本机可用值）：
- AUTOSHOP_MCP_NODE           Node 解释器；默认 PATH 里的 node
- AUTOSHOP_EXE                AutoShop 主程序（kit 后端 autoshop_project_open 用）；默认本机安装路径
- AUTOSHOP_TOOLS_DIR          kit 后端的 ps1 目录；默认包内 AutoShop-AI-Kit\tools
- AUTOSHOP_COMBINED_BACKENDS  只启用部分后端，逗号分隔（kit,r）；
                              某个后端缺依赖时可用它跳过，其余照常工作
"""
import os

from fastmcp import FastMCP
from fastmcp.server.providers.proxy import ProxyProvider, ProxyClient

BASE = os.path.dirname(os.path.abspath(__file__))
NODE = os.environ.get("AUTOSHOP_MCP_NODE") or "node"
DEFAULT_AUTOSHOP_EXE = r"D:\app\major\INOVANCE\AutoShop\AutoShop.exe"

ALL_BACKENDS = {
    "kit": {
        "command": NODE,
        "args": [os.path.join(BASE, "AutoShop-AI-Kit", "mcp", "server.mjs")],
        "env": {
            "AUTOSHOP_TOOLS_DIR": os.environ.get("AUTOSHOP_TOOLS_DIR")
            or os.path.join(BASE, "AutoShop-AI-Kit", "tools"),
            "AUTOSHOP_EXE": os.environ.get("AUTOSHOP_EXE") or DEFAULT_AUTOSHOP_EXE,
        },
    },
    "r": {
        "command": NODE,
        "args": [os.path.join(BASE, "autoshop-mcp-server", "dist", "index.js")],
        "cwd": os.path.join(BASE, "autoshop-mcp-server"),
    },
}

wanted = [s.strip() for s in os.environ.get("AUTOSHOP_COMBINED_BACKENDS", "").split(",") if s.strip()]
unknown = [s for s in wanted if s not in ALL_BACKENDS]
if unknown:
    raise SystemExit(f"AUTOSHOP_COMBINED_BACKENDS: unknown backend(s) {unknown}; valid: kit, r, b")
names = wanted or list(ALL_BACKENDS)
missing = [n for n in names if not os.path.exists(ALL_BACKENDS[n]["args"][0])]
if missing:
    raise SystemExit(f"backend entry script(s) missing: {missing}; trim with AUTOSHOP_COMBINED_BACKENDS")

BACKENDS = {"mcpServers": {n: ALL_BACKENDS[n] for n in names}}

mcp = FastMCP("autoshop-combined")
mcp.add_provider(ProxyProvider(lambda: ProxyClient(BACKENDS)))

if __name__ == "__main__":
    mcp.run()
