# Five-rule self check for a block I authored (user's discipline, 2026-09-20):
#   1) ST basics        -- IF/END_IF, CASE/END_CASE, FOR/END_FOR, WHILE/END_WHILE balance,
#                          no "???" placeholders (AutoShop STRIPS them on save), no full-width punctuation
#   2) local variables  -- names assigned/called in the body must be declared in this FB/FC variable table
#   3) global variables -- <VarPrefix>.<member> must exist in the global variable tables
#   4) called FBs       -- the FB must exist in the FB-instance table AND the body must call the INSTANCE
#   5) TON / TRIG       -- every ton*/rtrig*/ftrig* call must be an FB-instance row or an internal VAR
#
# PURE ASCII ON PURPOSE. Chinese in a .ps1 -- even inside a COMMENT -- is read as ANSI by PowerShell 5.1
# and can swallow the neighbouring syntax (that is how a parameter literally disappeared from this file's
# first version). Every Chinese value arrives as a PARAMETER from the command line, which is safe.
param(
  [Parameter(Mandatory=$true)][string]$MirrorDir,
  [Parameter(Mandatory=$true)][string]$Block,
  [string]$BodyFile = '',
  [string]$VarPrefix = '',
  [string]$InstName = '',
  [string]$FbType = '',
  [string]$TableDir = '',                                # relative folder inside the mirror holding the GVL csvs
  [string]$FbiPath = ''                                  # full path of the FB-instance table csv
)
$ErrorActionPreference = 'Stop'
$gbk = [System.Text.Encoding]::GetEncoding('GB2312')
$u8  = New-Object System.Text.UTF8Encoding($false)
$fail = 0
function Say([string]$s) { Write-Output $s }
function Bad([string]$s) { $script:fail++; Write-Output ('  FAIL ' + $s) }
function Ok([string]$s)  { Write-Output ('  ok   ' + $s) }

# --- locate the body (client-side name match: -Filter with a non-ASCII name is unreliable) ---------
if ($BodyFile -eq '') {
  $want = $Block + '.md'
  $hit = @(Get-ChildItem -LiteralPath $MirrorDir -Recurse -File -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -eq $want })
  if ($hit.Count -eq 0) { throw ('no .md named ' + $want + ' under ' + $MirrorDir) }
  $BodyFile = $hit[0].FullName
}
$raw = $u8.GetString([System.IO.File]::ReadAllBytes($BodyFile))
$m = [regex]::Match($raw, '(?s)```st\r?\n(.*?)```')
if (-not $m.Success) { throw ('no st code block in ' + $BodyFile) }
$body = $m.Groups[1].Value
$live = [regex]::Replace($body, '(?s)\(\*.*?\*\)', '')      # strip block comments (wiring templates)
Say ('body: ' + $BodyFile)
Say ('  total {0} chars, live {1} chars' -f ($body -replace "`r|`n", '').Length, ($live -replace "`r|`n", '').Length)

Say '--- rule 1: ST basics ---'
foreach ($p in @(@('IF','END_IF'), @('CASE','END_CASE'), @('FOR','END_FOR'), @('WHILE','END_WHILE'), @('REPEAT','END_REPEAT'))) {
  $o = @([regex]::Matches($live, '\b' + $p[0] + '\b')).Count
  $c = @([regex]::Matches($live, '\b' + $p[1] + '\b')).Count
  if ($o -ne $c) { Bad ("{0}={1} but {2}={3}" -f $p[0], $o, $p[1], $c) } else { Ok ("{0}/{1} = {2}" -f $p[0], $p[1], $o) }
}
if ($live.Contains('???')) { Bad 'live code still has a ??? placeholder (AutoShop strips it on save)' } else { Ok 'no ??? placeholder in live code' }
$fw = @()
foreach ($fx in @(0xFF0C, 0xFF1B, 0xFF08, 0xFF09, 0xFF1A, 0xFF1D)) { if ($live.Contains([string][char]$fx)) { $fw += ('U+{0:X4}' -f $fx) } }
if ($fw.Count -gt 0) { Bad ('full-width punctuation in live code: ' + ($fw -join ' ')) } else { Ok 'no full-width punctuation in live code' }

Say '--- rule 3: global variables ---'
if ($VarPrefix -ne '') {
  if ($TableDir -eq '') { throw 'pass -TableDir with -VarPrefix' }
  $dir = Join-Path $MirrorDir $TableDir
  $gvls = @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -eq '.csv' })
  $all = New-Object System.Collections.Generic.List[string]
  foreach ($g in $gvls) {
    foreach ($l in ($gbk.GetString([System.IO.File]::ReadAllBytes($g.FullName)) -split "`r`n|`n")) {
      if ($l -eq '') { continue }
      $f = $l -split ','
      if ($f.Count -gt 1 -and $f[1] -ne '') { [void]$all.Add($f[1]) }
    }
  }
  $refs = @([regex]::Matches($live, [regex]::Escape($VarPrefix) + '\.([A-Za-z0-9_\u4e00-\u9fa5]+)') |
            ForEach-Object { $VarPrefix + '.' + $_.Groups[1].Value } | Sort-Object -Unique)
  $miss = @($refs | Where-Object { $all -notcontains $_ })
  if ($miss.Count -gt 0) { Bad ('not present in the global tables: ' + ($miss -join ', ')) }
  else { Ok ("all {0} referenced globals exist ({1} csv file(s), {2} names)" -f $refs.Count, $gvls.Count, $all.Count) }
} else { Ok '(skipped: no -VarPrefix)' }

Say '--- rule 4: called FB must be INSTANTIATED ---'
$fbi = @()
if ($FbiPath -ne '' -and (Test-Path -LiteralPath $FbiPath)) {
  $fbi = @($gbk.GetString([System.IO.File]::ReadAllBytes($FbiPath)) -split "`r`n|`n" | Where-Object { $_ -ne '' })
}
Say ('  fb-instance table rows: {0}' -f $fbi.Count)
if ($InstName -ne '' -and $FbType -ne '') {
  $row = @($fbi | Where-Object { $_ -match ('^\d+,' + [regex]::Escape($InstName) + ',' + [regex]::Escape($FbType) + ',') })
  if ($row.Count -eq 0) { Bad ("no FB-instance row '" + $InstName + ',' + $FbType + "' -- an FB is called through an instance") }
  else { Ok ('instance row present: ' + $row[0]) }
  $callsType = @([regex]::Matches($live, [regex]::Escape($FbType) + '\s*\(')).Count
  $callsInst = @([regex]::Matches($live, [regex]::Escape($InstName) + '\s*\(')).Count
  if ($callsType -gt 0) { Bad ("body calls the FB TYPE '" + $FbType + "(...)' instead of its instance") }
  if ($callsInst -eq 0) { Bad ("body never calls the instance '" + $InstName + "(...)'") }
  if ($callsType -eq 0 -and $callsInst -gt 0) { Ok ('body calls the instance x' + $callsInst) }
} else { Ok '(skipped: no -InstName/-FbType)' }

Say '--- rule 5: TON / edge instances ---'
$tonRefs = @([regex]::Matches($live, '\b((?:ton|fbton|rtrig|ftrig)[A-Za-z0-9_\u4e00-\u9fa5]*)\s*\(') |
             ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
if ($tonRefs.Count -eq 0) { Ok 'no ton/trig call in live code' }
else {
  $instNames = @($fbi | Where-Object { $_ -match '^\d+,' } | ForEach-Object { (($_ -split ',')[1]) })
  $ownVars = @()
  foreach ($sub in @('FB', 'FC')) {
    $p = Join-Path $MirrorDir ($sub + '\' + $Block + '\' + $Block + '.csv')
    if (Test-Path -LiteralPath $p) {
      $ownVars = @($gbk.GetString([System.IO.File]::ReadAllBytes($p)) -split "`r`n|`n" |
        Where-Object { $_ -match ',VAR,' } | ForEach-Object { (($_ -split ',')[2]) })
    }
  }
  foreach ($t in $tonRefs) {
    if ($ownVars -contains $t) { Ok ($t + ': internal VAR of this FB') }
    elseif ($instNames -contains $t) { Ok ($t + ': FB-instance row') }
    else { Bad ($t + ' is neither an FB-instance row nor an internal VAR of this FB') }
  }
}

Say '--- rule 2: local variables (FB/FC only) ---'
$own = ''
foreach ($sub in @('FB', 'FC')) {
  $p = Join-Path $MirrorDir ($sub + '\' + $Block + '\' + $Block + '.csv')
  if (Test-Path -LiteralPath $p) { $own = $p }
}
if ($own -ne '') {
  $decl = @($gbk.GetString([System.IO.File]::ReadAllBytes($own)) -split "`r`n|`n" | Where-Object { $_ -ne '' } |
    ForEach-Object { (($_ -split ',')[2]) } | Where-Object { $_ -ne '' } | Sort-Object -Unique)
  $used = @([regex]::Matches($live, '(?m)^\s*([A-Za-z_][A-Za-z0-9_\u4e00-\u9fa5]*)\s*(?::=|\()') |
            ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
  $kw = @('IF', 'CASE', 'FOR', 'WHILE', 'ELSIF', 'ELSE', 'END_IF', 'END_CASE', 'RETURN', 'EXIT', 'REPEAT')
  $unknown = @($used | Where-Object { $decl -notcontains $_ -and $kw -notcontains $_ })
  if ($unknown.Count -gt 0) { Say ('  names used but not declared here (check manually): ' + ($unknown -join ', ')) }
  else { Ok ('every assigned/called name is declared (' + $decl.Count + ' declared names)') }
} else { Ok '(skipped: no own variable table -- this block is a program)' }

Say ''
if ($fail -eq 0) { Say 'RESULT: PASS - all five rules clean' } else { Say ('RESULT: {0} problem(s) found' -f $fail) }
