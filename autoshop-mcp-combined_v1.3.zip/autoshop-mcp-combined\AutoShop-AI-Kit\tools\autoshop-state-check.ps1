# State check before/after a sweep: is a modal dialog blocking AutoShop, and which MDI children
# (block views) are still open?
# Modal = the main window reports IsEnabled = false. When that happens every click/composite key is
# swallowed, so it must be cleared before any navigation is trusted.
# KEEP PURE ASCII.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationTypes

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$root = [System.Windows.Automation.AutomationElement]::FromHandle((Get-AutoShopMainWindow $proc))
$AE = [System.Windows.Automation.AutomationElement]
Write-Output ("title      : {0}" -f $proc.MainWindowTitle)
Write-Output ("isEnabled  : {0}   <-- false means a modal dialog is up" -f $root.Current.IsEnabled)

$cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Window)
$wins = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
Write-Output ("MDI child windows open : {0}" -f $wins.Count)
foreach ($w in $wins) {
  $r = $w.Current.BoundingRectangle
  Write-Output ("   - '{0}'  rect={1},{2},{3},{4}" -f $w.Current.Name, [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height)
}

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }