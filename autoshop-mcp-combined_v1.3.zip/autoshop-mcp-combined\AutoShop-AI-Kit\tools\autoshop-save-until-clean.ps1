# Press the AutoShop toolbar Save button UNTIL the active block's dirty marker (" *") is gone.
#
# WHY (user, 2026-09-20): "你虽然鼠标在那，但是你有可能点击失败" / "存在就继续点保存啊".
# The cursor being parked on the Save button is NOT proof the click took effect: a modal box can swallow
# it, the button can be mid-repaint, or the window can have moved. The ONLY proof is the state change --
# the " *" on the active tab must disappear. So: click, VERIFY, and click again while it is still dirty.
#
# Evidence printed per round (so a failure can be diagnosed, not guessed):
#   - the click point AND where the cursor actually ended up (GetCursorPos) -- a mismatch means the
#     SetCursorPos/click pair went somewhere else
#   - the main window title (the active tab's dirty marker lives here: "... - [FB_气缸 *]")
#   - how many modal #32770 boxes are up
#
# KEEP PURE ASCII. Buttons are pressed through the shared dismiss helper (leftmost answer button,
# language independent) -- never by guessing a control id.
param(
  [int]$MaxRounds = 6,
  [int]$SaveOffsetX = 88,
  [int]$SaveOffsetY = 70
)
$ErrorActionPreference = 'Stop'
if (-not ('CU' -as [type])) {
  Add-Type -Namespace CU -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
public struct RECT { public int Left, Top, Right, Bottom; }
public struct POINT { public int X, Y; }
'@
}
function ClsOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 256; [void][CU.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 512; [void][CU.U]::GetWindowTextW($h,$b,512); $b.ToString() }
function DialogList {
  $l = New-Object System.Collections.ArrayList
  $cb = [CU.U+EnumProc]{ param($h,$x) if ([CU.U]::IsWindowVisible($h) -and (ClsOf $h) -eq '#32770') { [void]$l.Add($h) }; return $true }
  [void][CU.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $l
}
function DismissBoxes([int]$maxPass = 6) {
  $total = 0
  for ($pass = 1; $pass -le $maxPass; $pass++) {
    $dlgs = @(DialogList)
    if ($dlgs.Count -eq 0) { return $total }
    $pressedThisPass = 0
    foreach ($d in $dlgs) {
      $kids = New-Object System.Collections.ArrayList
      $cb = [CU.U+EnumProc]{ param($h,$x) if ([CU.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
      [void][CU.U]::EnumChildWindows($d, $cb, [IntPtr]::Zero)
      $target = [IntPtr]::Zero; $tid = 0; $ttxt = ''
      $cands = New-Object System.Collections.ArrayList
      foreach ($k in $kids) {
        if ((ClsOf $k) -eq 'Button') {
          $id = [int][CU.U]::GetWindowLong($k, -12)
          if ($id -eq 8 -or $id -eq 9) { continue }
          $r = New-Object CU.U+RECT; [void][CU.U]::GetWindowRect($k, [ref]$r)
          [void]$cands.Add([pscustomobject]@{ H = $k; Id = $id; T = (TxtOf $k); L = $r.Left })
        }
      }
      if ($cands.Count -gt 0) {
        $pick = @($cands | Sort-Object L | Select-Object -First 1)[0]
        $target = $pick.H; $tid = $pick.Id; $ttxt = $pick.T
      }
      if ($target -ne [IntPtr]::Zero) {
        Write-Output ("  box '{0}' -> pressing leftmost answer button id={1} text='{2}'" -f (TxtOf $d), $tid, $ttxt)
        [void][CU.U]::SendMessageW($d, 0x0111, [IntPtr]$tid, [IntPtr]$target)
        Start-Sleep -Milliseconds 900
        $pressedThisPass++; $total++
      } else {
        Write-Output ("  box '{0}' has no pressable answer button - leaving it alone" -f (TxtOf $d))
      }
    }
    if ($pressedThisPass -eq 0) { return $total }
    Start-Sleep -Milliseconds 400
  }
  return $total
}

function Get-Main { Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Where-Object { ($_.MainWindowHandle -ne 0) -and ((-not $env:AUTOSHOP_TITLE_FILTER) -or ($_.MainWindowTitle -like ("*"+$env:AUTOSHOP_TITLE_FILTER+"*"))) } | Select-Object -First 1 }
function Is-Dirty([string]$t){ return ($t -match '\[\s*[^\[\]]*\*\s*\]') }

$proc = Get-Main
if (-not $proc) { Write-Output 'AutoShop is not running - nothing to save'; exit 2 }
$mh = $proc.MainWindowHandle

$title0 = TxtOf $mh
$boxes0 = @(DialogList)
Write-Output ("before: title=[{0}] dirty={1} dialogs={2}" -f $title0, (Is-Dirty $title0), $boxes0.Count)
# ★ 2026-09-20 FIX: dismiss modal boxes even when there is nothing to save. The early exit used to skip
# this, so a leftover "导入数据成功！" box survived the call and sat there blocking every later click
# (measured: dialogs=1 while the script printed "nothing to do" and returned).
if ($boxes0.Count -gt 0) {
  Write-Output ("  {0} modal box(es) up - dismissing them FIRST (a modal box swallows every click)" -f $boxes0.Count)
  [void](DismissBoxes 3)
  Start-Sleep -Milliseconds 500
  $title0 = TxtOf $mh
  Write-Output ("  after dismissing: title=[{0}] dirty={1} dialogs={2}" -f $title0, (Is-Dirty $title0), @(DialogList).Count)
}
if (-not (Is-Dirty $title0)) { Write-Output 'nothing to save: the active tab has no dirty marker (any modal box has been dismissed)'; exit 0 }

$ok = $false
for ($round = 1; $round -le $MaxRounds; $round++) {
  Write-Output ("--- round {0}/{1} ---" -f $round, $MaxRounds)

  # 1) clear anything modal first: with a box up, the Save click lands in the box and is swallowed
  $boxes = @(DialogList)
  if ($boxes.Count -gt 0) {
    Write-Output ("  {0} modal box(es) up - dismissing before saving" -f $boxes.Count)
    [void](DismissBoxes 3)
    Start-Sleep -Milliseconds 500
  }

  # 2) foreground, leave any in-place cell edit, then click Save
  for ($i = 1; $i -le 4; $i++) { [void][CU.U]::SetForegroundWindow($mh); Start-Sleep -Milliseconds 250 }
  $mr = New-Object CU.U+RECT; [void][CU.U]::GetWindowRect($mh, [ref]$mr)
  if ($mr.Left -lt -2000 -or ($mr.Right - $mr.Left) -lt 400) {
    Write-Output ("  ABORT: main window is minimized/off-screen rect={{ {0},{1} {2}x{3} }}" -f $mr.Left, $mr.Top, ($mr.Right-$mr.Left), ($mr.Bottom-$mr.Top))
    exit 3
  }
  # ui scale from the real toolbar height (30px was the reference measurement)
  $tbs = New-Object System.Collections.ArrayList
  $cbTb = [CU.U+EnumProc]{
    param($h, $x)
    if ([CU.U]::IsWindowVisible($h)) {
      $c = ClsOf $h
      if ($c -like 'Afx:ToolBar*' -or $c -like '*ToolbarWindow32*') {
        $r = New-Object CU.U+RECT; [void][CU.U]::GetWindowRect($h, [ref]$r)
        [void]$tbs.Add([pscustomobject]@{ T = $r.Top; Hh = ($r.Bottom-$r.Top) })
      }
    }
    return $true }
  [void][CU.U]::EnumChildWindows($mh, $cbTb, [IntPtr]::Zero)
  $uiScale = 1.0
  if ($tbs.Count -gt 0) {
    $minTop = (@($tbs | Measure-Object T -Minimum).Minimum)
    $below = @($tbs | Where-Object { $_.T -gt $minTop })
    $pool = $(if ($below.Count -gt 0) { $below } else { $tbs })
    $hh = @($pool | Sort-Object T | Select-Object -First 1)[0].Hh
    if ($hh -gt 0) { $uiScale = $hh / 30.0 }
  }
  $sx = [int]$mr.Left + [int][Math]::Round($SaveOffsetX * $uiScale)
  $sy = [int]$mr.Top + [int][Math]::Round($SaveOffsetY * $uiScale)

  [void][CU.U]::SetCursorPos($sx, $sy); Start-Sleep -Milliseconds 250
  $pt = New-Object CU.U+POINT; [void][CU.U]::GetCursorPos([ref]$pt)
  Write-Output ("  target=({0},{1}) cursorNow=({2},{3}) {4}" -f $sx, $sy, $pt.X, $pt.Y, $(if ($pt.X -eq $sx -and $pt.Y -eq $sy) { 'CURSOR-ON-TARGET' } else { 'CURSOR-MISMATCH' }))
  # the window can move between measure and click -> re-measure and re-park once
  if ($pt.X -ne $sx -or $pt.Y -ne $sy) { [void][CU.U]::SetCursorPos($sx, $sy); Start-Sleep -Milliseconds 200 }
  [CU.U]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 80; [CU.U]::mouse_event(0x04,0,0,0,0)
  Start-Sleep -Milliseconds 2200

  # 3) VERIFY: dirty marker gone?  (this is the only accepted proof)
  $title1 = TxtOf $mh
  $dirty = Is-Dirty $title1
  Write-Output ("  after click: title=[{0}] dirty={1} dialogs={2}" -f $title1, $dirty, @(DialogList).Count)
  if (-not $dirty) { $ok = $true; break }

  # still dirty -> answer any prompt that just appeared (e.g. "save?" ) and go again
  $n = DismissBoxes 3
  if ($n -gt 0) { Write-Output ("  answered {0} prompt(s) after the click" -f $n); Start-Sleep -Milliseconds 600 }
  $title2 = TxtOf $mh
  if (-not (Is-Dirty $title2)) { Write-Output ("  dirty cleared by the prompt round: [{0}]" -f $title2); $ok = $true; break }
}

$titleEnd = TxtOf $mh
Write-Output ("=== result: {0} ; title=[{1}] ; dialogs={2}" -f $(if ($ok) { 'SAVED (dirty marker gone)' } else { 'STILL DIRTY after all rounds' }), $titleEnd, @(DialogList).Count)
if (-not $ok) { exit 4 }
exit 0
