# Report ONE tree node's geometry by name: id, indent (x), y, size, state -- WITHOUT scanning/walking rows.
#
# WHY THIS EXISTS (user, 2026-09-20): I kept running the row-scanning jump tool after every create just to
# see where the new node landed -- the user asked why. The scan pages the whole tree; this tool does not.
# I kept running autoshop-jump.ps1 -Scan after every create just to see where the new node landed. That
# tool PAGES THROUGH THE WHOLE TREE (nPos jumping around) -- exactly the "row-by-row" method the user
# told me to abandon, and the reason the left pane scrolls. This tool never walks rows:
#   1) one MSAA name sweep (accName over ids 1..N) -- pure reads, does NOT scroll
#   2) accLocation(id) for the target only -> x is the INDENT, y is the POSITION
#   3) for context, report the ids already realized with the SAME x (same level) -- measured, not guessed
#   4) print the tree's scroll position BEFORE and AFTER, so "did this move the tree?" is provable
#
# PURE ASCII. Names and node titles arrive as parameters/collected data.
param(
  [Parameter(Mandatory=$true)][string]$Node,
  [int]$MaxId = 0,                     # default accChildCount + 3000
  [switch]$SelectTarget                # accSelect the target (one targeted scroll, then restore)
)

# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }
$ErrorActionPreference = 'Stop'
if (-not ('NI' -as [type])) {
  Add-Type -Namespace NI -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
public struct RECT { public int Left, Top, Right, Bottom; }
public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin, nMax; public uint nPage; public int nPos, nTrackPos; }
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Interface)] out object acc);
'@
}
function ClsOf([IntPtr]$h) { $b = New-Object System.Text.StringBuilder 256; [void][NI.U]::GetClassNameW($h, $b, 256); $b.ToString().Trim() }
function NPos([IntPtr]$tree) {
  $si = New-Object NI.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = 0x17
  if ([NI.U]::GetScrollInfo($tree, 1, [ref]$si)) { return [int]$si.nPos } else { return -1 }
}

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
# the project tree = the LEFTMOST SysTreeView32 (the right-hand toolbox tree is a different one)
$trees = New-Object System.Collections.ArrayList
$cb = [NI.U+EnumProc]{
  param($h, $p)
  if ((ClsOf $h) -eq 'SysTreeView32') {
    $r = New-Object NI.U+RECT; [void][NI.U]::GetWindowRect($h, [ref]$r)
    [void]$trees.Add([pscustomobject]@{ H = $h; L = $r.Left; R = $r })
  }
  return $true
}
[void][NI.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
$tree = (@($trees | Sort-Object L | Select-Object -First 1)[0]).H
$tr = (@($trees | Sort-Object L | Select-Object -First 1)[0]).R
$nposBefore = NPos $tree
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}   scroll nPos BEFORE = {5}" -f $tree, $tr.Left, $tr.Top, ($tr.Right-$tr.Left), ($tr.Bottom-$tr.Top), $nposBefore)

$acc = $null
$iid = [Guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$hr = [NI.U]::AccessibleObjectFromWindow($tree, [uint32]4294967292, [ref]$iid, [ref]$acc)
if ($hr -ne 0 -or $null -eq $acc) { throw ("AccessibleObjectFromWindow failed hr=0x{0:X8}" -f $hr) }

# one name sweep -- reads only
$maxId = $MaxId; if ($maxId -le 0) { $maxId = [int]$acc.accChildCount + 3000 }
$named = 0
$hits = New-Object System.Collections.ArrayList
$all = New-Object System.Collections.ArrayList
for ($i = 1; $i -le $maxId; $i++) {
  $nm = ''
  try { $nm = [string]$acc.accName([int]$i) } catch { continue }
  if ([string]::IsNullOrWhiteSpace($nm)) { continue }
  $named++
  [void]$all.Add([pscustomobject]@{ Id = $i; Name = $nm })
  if ($nm -eq $Node) { [void]$hits.Add($i) }
}
Write-Output ("name sweep: {0} named ids (swept 1..{1}); matches for '{2}' = {3}" -f $named, $maxId, $Node, $hits.Count)
if ($hits.Count -eq 0) { throw ("node '{0}' not found" -f $Node) }

foreach ($id in $hits) {
  $x = 0; $y = 0; $w = 0; $h = 0
  try { $acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$id) } catch { }
  if ($h -le 0) {
    Write-Output ("  id={0}  NOT realized (no rect yet; x/y unavailable without a targeted select)" -f $id)
    continue
  }
  $indent = $x - $tr.Left
  Write-Output ("  id={0}  x={1} (indent {2}px from the tree's left edge)  y={3}  {4}x{5}" -f $id, $x, $indent, $y, $w, $h)
}

# context: which named ids already have a real rect at the SAME indent (same level) -- measured, not guessed
$targetId = $hits[0]
$tx = 0; $ty = 0; $tw = 0; $th = 0
try { $acc.accLocation([ref]$tx, [ref]$ty, [ref]$tw, [ref]$th, [int]$targetId) } catch { }
if ($th -gt 0) {
  Write-Output 'same-level nodes that are currently realized (measured, may be partial):'
  $same = New-Object System.Collections.ArrayList
  foreach ($n in $all) {
    if ($n.Id -eq $targetId) { continue }
    $x = 0; $y = 0; $w = 0; $hh = 0
    try { $acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$hh, [int]$n.Id) } catch { continue }
    if ($hh -le 0) { continue }
    if ($x -eq $tx -and $y -ge $tr.Top -and $y -le $tr.Bottom) { [void]$same.Add([pscustomobject]@{ Id = $n.Id; Name = $n.Name; Y = $y }) }
  }
  foreach ($s in (@($same | Sort-Object Y))) { Write-Output ("  y={0,4}  id={1,-4} {2}" -f $s.Y, $s.Id, $s.Name) }
  if ($same.Count -eq 0) { Write-Output '  (none realized at that indent right now)' }
}

if ($SelectTarget) {
  try { [void]$acc.accSelect(3, [int]$targetId) } catch { }
  Start-Sleep -Milliseconds 300
  $x = 0; $y = 0; $w = 0; $h = 0
  try { $acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$targetId) } catch { }
  Write-Output ("after a targeted select: id={0} x={1} y={2} {3}x{4}  (scroll nPos now = {5})" -f $targetId, $x, $y, $w, $h, (NPos $tree))
}

$nposAfter = NPos $tree
Write-Output ("scroll nPos AFTER = {0}   -> tree scroll {1}" -f $nposAfter, $(if ($nposAfter -eq $nposBefore) { 'UNTOUCHED (no paging, no walking)' } else { 'MOVED by the targeted select' }))
