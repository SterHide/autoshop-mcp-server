#!/usr/bin/env node
// Minimal stdio client for the AutoShop MCP server (mcp/server.mjs).
//
// WHY: any MCP-capable host drives server.mjs over newline-delimited JSON-RPC on stdio. When the
// host in use has no MCP client wired up (e.g. driving it from a shell), this gives the exact same
// tool surface: same server, same baked-in offsets, same serialization discipline.
//
// ★ --batch matters: the server runs its one-shot session preflight before the FIRST tool call of
//   its process. One process per call would therefore re-run the geometry/pane/fold pass every time.
//   A batch keeps ONE server process for the whole sequence, so the preflight runs exactly once and
//   the calls stay strictly ordered (they must: they all drive one AutoShop window).
//
// Arguments ALWAYS travel in a UTF-8 JSON file, never on the command line (Chinese + quoting).
//
// Usage:
//   node mcp-client.mjs --list
//   node mcp-client.mjs <toolName> <argsJsonFile>
//   node mcp-client.mjs --batch <batchJsonFile>      # [{ "tool": "...", "args": { ... } }, ...]
//
// Exit code: 0 ok, 1 a tool reported isError, 2 usage/protocol failure.
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const SERVER = process.env.AUTOSHOP_MCP_SERVER || join(HERE, 'server.mjs');
const NODE = process.execPath;
const TIMEOUT_MS = Number(process.env.AUTOSHOP_MCP_TIMEOUT_MS || 1800000);

const argv = process.argv.slice(2);
const listOnly = argv.includes('--list');
const batchIx = argv.indexOf('--batch');
const pos = argv.filter((a, i) => !a.startsWith('--') && !(batchIx >= 0 && i === batchIx + 1));

let calls = [];
if (listOnly) {
  calls = [{ tool: null }];
} else if (batchIx >= 0) {
  const file = argv[batchIx + 1];
  if (!file) { process.stderr.write('--batch needs a json file\n'); process.exit(2); }
  try {
    const items = JSON.parse(readFileSync(file, 'utf8'));
    calls = items.map((it) => ({ tool: it.tool, args: it.args || {} }));
  } catch (e) {
    process.stderr.write('bad batch json: ' + String(e && e.message || e) + '\n');
    process.exit(2);
  }
} else {
  const tool = pos[0];
  const argsFile = pos[1] || null;
  if (!tool) { process.stderr.write('usage: node mcp-client.mjs --list | <tool> [argsFile] | --batch <file>\n'); process.exit(2); }
  let a = {};
  if (argsFile) {
    try { a = JSON.parse(readFileSync(argsFile, 'utf8')); }
    catch (e) { process.stderr.write('bad args json: ' + String(e && e.message || e) + '\n'); process.exit(2); }
  }
  calls = [{ tool, args: a }];
}

const child = spawn(NODE, [SERVER], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
child.stdout.setEncoding('utf8');
child.stderr.setEncoding('utf8');

let buf = '';
const pendingReply = new Map();   // id -> {resolve}
let errText = '';
child.stderr.on('data', (d) => { errText += d; });

child.stdout.on('data', (d) => {
  buf += d;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    let m;
    try { m = JSON.parse(line); } catch { continue; }
    if (m && m.id !== undefined && pendingReply.has(m.id)) {
      const r = pendingReply.get(m.id);
      pendingReply.delete(m.id);
      r(m);
    }
  }
});

function sendRaw(obj) { child.stdin.write(JSON.stringify(obj) + '\n'); }

function rpc(id, method, params) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pendingReply.delete(id); reject(new Error('timeout on ' + method)); }, TIMEOUT_MS);
    pendingReply.set(id, (m) => { clearTimeout(timer); resolve(m); });
    sendRaw({ jsonrpc: '2.0', id, method, params });
  });
}

(async () => {
  await rpc(1, 'initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'mcp-client.mjs', version: '1.1.0' } });
  sendRaw({ jsonrpc: '2.0', method: 'notifications/initialized' });

  let worst = 0;
  if (listOnly) {
    const m = await rpc(2, 'tools/list', {});
    for (const t of (m.result && m.result.tools) || []) {
      process.stdout.write(t.name.padEnd(24) + ' ' + (t.description || '') + '\n');
    }
  } else {
    let id = 10;
    for (let k = 0; k < calls.length; k++) {
      const c = calls[k];
      process.stdout.write('\n########## [' + (k + 1) + '/' + calls.length + '] ' + c.tool + '  args=' + JSON.stringify(c.args) + '\n');
      const m = await rpc(id++, 'tools/call', { name: c.tool, arguments: c.args });
      if (m.error) { process.stdout.write('JSON-RPC ERROR: ' + JSON.stringify(m.error) + '\n'); worst = 2; break; }
      const res = m.result || {};
      for (const cc of res.content || []) process.stdout.write((cc.text || '') + '\n');
      if (res.isError) {
        process.stdout.write('>>> TOOL REPORTED isError (stopping the batch here)\n');
        worst = 1;
        break;
      }
    }
  }
  try { child.stdin.end(); } catch { }
  setTimeout(() => { try { child.kill(); } catch { } ; process.exit(worst); }, 300);
})().catch((e) => {
  process.stderr.write('client failure: ' + String(e && e.message || e) + '\n');
  if (errText) process.stderr.write('[server stderr]\n' + errText);
  try { child.kill(); } catch { }
  process.exit(2);
});
