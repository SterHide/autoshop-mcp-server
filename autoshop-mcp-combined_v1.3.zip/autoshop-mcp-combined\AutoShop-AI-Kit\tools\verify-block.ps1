# verify-block.ps1 -- re-extract ONE block from AutoShop and diff it against the local .st source.
#
# WHY A FILE AND NOT AN INLINE COMMAND: passing this logic inline through
# powershell -EncodedCommand over several layers of quoting mangled backticks and quotes. A .ps1 that
# is written to disk and invoked with -File has no escaping layer at all.
#
# PURE ASCII on purpose: PowerShell 5.1 reads a BOM-less .ps1 as ANSI, so a Chinese literal inside
# would turn to mojibake and can even eat neighbouring syntax. Chinese only arrives via parameters.
param(
  [Parameter(Mandatory=$true)][string]$Block,
  [Parameter(Mandatory=$true)][string]$StFile,
  [string]$Engine     = '',
  [string]$ProjectDir = 'D:\AI\autoshop-work\proj\TEST',
  [string]$MirrorDir  = 'D:\AI\autoshop-work\mirror',
  [string]$FbDir      = 'FB',
  [string]$MdPath     = ''
)
$ErrorActionPreference = 'Continue'

if (-not $Engine) { $Engine = Join-Path $PSScriptRoot 'autoshop-extract-blocks2.ps1' }
if (-not $MdPath) { $MdPath = Join-Path (Join-Path (Join-Path $MirrorDir $FbDir) $Block) ($Block + '.md') }

Write-Output ('=== verify ' + $Block + ' ===')
& $Engine -ProjectDir $ProjectDir -MirrorDir $MirrorDir -FlatLayout -FbDir $FbDir `
          -OnlyBlock $Block -Limit 2 -Write -UseSkeleton:$false -Redo 2>&1 |
  ForEach-Object { if ($_ -match 'BLOCK |MISMATCH|NOT-IN-TREE|OK  |failed|chars|targets') { Write-Output ('  [engine] ' + $_) } }

if (-not (Test-Path -LiteralPath $MdPath)) { Write-Output ('  FAIL: no read-back file at ' + $MdPath); exit 2 }
$md = [System.IO.File]::ReadAllText($MdPath, [System.Text.Encoding]::UTF8)

$fence = [string][char]96 + [string][char]96 + [string][char]96
# the engine tags the fence with the block language: programs -> ```st, FB/FC -> ```fb
$m = [regex]::Match($md, '(?s)' + $fence + '[A-Za-z]*\r?\n(.*?)\r?\n' + $fence)
if (-not $m.Success) { Write-Output '  FAIL: no fenced source block in the read-back file'; exit 2 }
$body = $m.Groups[1].Value
$body = ($body -replace "`r`n", "`n").Trim("`n")
$src  = ([System.IO.File]::ReadAllText($StFile, [System.Text.Encoding]::UTF8) -replace "`r`n", "`n").Trim("`n")

Write-Output ('  source chars   = ' + $src.Length)
Write-Output ('  readback chars = ' + $body.Length)
$same = ($src -ceq $body)
Write-Output ('  IDENTICAL      = ' + $same)
if (-not $same) {
  $a = $src -split "`n"; $b = $body -split "`n"
  Write-Output ('  lines: src=' + $a.Count + ' readback=' + $b.Count)
  $shown = 0
  for ($k = 0; $k -lt [Math]::Max($a.Count, $b.Count); $k++) {
    $x = ''
    $y = ''
    if ($k -lt $a.Count) { $x = $a[$k] }
    if ($k -lt $b.Count) { $y = $b[$k] }
    if ($x -cne $y) {
      $shown++
      if ($shown -le 10) { Write-Output ('  line ' + ($k + 1) + "  SRC: '" + $x + "'"); Write-Output ('              RB : ' + "'" + $y + "'") }
    }
  }
  if ($shown -gt 10) { Write-Output ('  ... and ' + ($shown - 10) + ' more differing line(s)') }
}
if ($same) { Write-Output '  RESULT: PASS' } else { Write-Output '  RESULT: DIFF' }
