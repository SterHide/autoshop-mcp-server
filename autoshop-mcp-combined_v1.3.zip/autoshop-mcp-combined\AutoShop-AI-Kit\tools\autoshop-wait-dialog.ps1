# Wait-for / press AutoShop dialogs with EXPLICIT, CHECKABLE state transitions.
#
# The question this answers (user, 2026-09-20): "你怎么判断提示窗体已经关闭?"
# Never assume a click closed a box. Four independent checks, in order:
#   (1) the box's own handle: IsWindowVisible(hwnd) == false  (or IsWindow(hwnd) == 0)
#   (2) the owner: IsWindowEnabled(mainHwnd) == true          (a modal disables its owner)
#   (3) a fresh enumeration: zero visible #32770 windows remain
#   (4) the process is still alive -- a CRASH also makes every dialog disappear, and that must never be
#       mistaken for "the box closed" (that is exactly how a Save click ended up being sent into a dying app)
#
# Buttons are matched by CONTROL ID, never by Chinese text (a .ps1 with Chinese literals is read as ANSI
# by PowerShell 5.1 and the parser breaks):
#   id 2 = OK / 确定        id 6 = Yes / 是        id 7 = No / 否
#
# KEEP PURE ASCII.
param(
  [int]$AppearTimeoutSec = 15,
  [int]$GoneTimeoutSec = 15,
  [int]$AfterPressMs = 700,
  [switch]$List
)

# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }
$ErrorActionPreference = 'Stop'
if (-not ('CW' -as [type])) {
  Add-Type -Namespace CW -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 256; [void][CW.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 512; [void][CW.U]::GetWindowTextW($h,$b,512); $b.ToString() }
function MainHwnd { $p = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { return (Get-AutoShopMainWindow $p) } else { return [IntPtr]::Zero } }
function AppAlive { return (@(Get-Process -Name AutoShop -ErrorAction SilentlyContinue).Count -gt 0) }

function VisibleDialogs {
  $l = New-Object System.Collections.ArrayList
  $cb = [CW.U+EnumProc]{ param($h,$x) if ([CW.U]::IsWindowVisible($h) -and (ClsOf $h) -eq '#32770') { [void]$l.Add($h) }; return $true }
  [void][CW.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $l
}
function ButtonsOf([IntPtr]$dlg) {
  $l = New-Object System.Collections.ArrayList
  $cb = [CW.U+EnumProc]{ param($h,$x) if ([CW.U]::IsWindowVisible($h) -and (ClsOf $h) -eq 'Button') { [void]$l.Add([pscustomobject]@{ H = $h; Id = [int][CW.U]::GetWindowLong($h,-12); T = (TxtOf $h) }) }; return $true }
  [void][CW.U]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $l
}
function Describe([IntPtr]$dlg) {
  $bs = @(ButtonsOf $dlg) | ForEach-Object { ('id={0}' -f $_.Id) }
  return ("hwnd={0} title='{1}' buttons=[{2}]" -f $dlg, (TxtOf $dlg), ($bs -join ','))
}

if ($List) {
  $d = @(VisibleDialogs)
  Write-Output ("visible #32770 dialogs: {0}; AutoShop alive: {1}" -f $d.Count, (AppAlive))
  foreach ($x in $d) { Write-Output ('  ' + (Describe $x)) }
  exit 0
}

# --- 1) find the box to dismiss ----------------------------------------------------------------
# NOTE: do NOT require the dialog to be "new". The success box is raised DURING the import, so by the
# time this script starts it is already visible -- my first version filtered it out and timed out.
# The right rule: pick a visible #32770 that has an OK button (control id 2) and does NOT have a
# Yes/No pair (id 6/7, i.e. the "clear the table?" prompt, which the caller already answered).
$seen = @(VisibleDialogs)
Write-Output ("step 1: looking for an OK box (up to {0}s; {1} dialog(s) visible now)" -f $AppearTimeoutSec, $seen.Count)
$dlg = [IntPtr]::Zero
$deadline = (Get-Date).AddSeconds($AppearTimeoutSec)
while ((Get-Date) -lt $deadline) {
  if (-not (AppAlive)) { throw 'CRASH: AutoShop process disappeared while waiting for the dialog' }
  foreach ($x in @(VisibleDialogs)) {
    $bs = @(ButtonsOf $x)
    $hasOk = @($bs | Where-Object { $_.Id -eq 2 }).Count -gt 0
    $hasYesNo = @($bs | Where-Object { $_.Id -eq 6 -or $_.Id -eq 7 }).Count -gt 0
    if ($hasOk -and -not $hasYesNo) { $dlg = $x; break }
  }
  if ($dlg -ne [IntPtr]::Zero) { break }
  Start-Sleep -Milliseconds 250
}
if ($dlg -eq [IntPtr]::Zero) { throw ("no OK-style dialog appeared within {0}s" -f $AppearTimeoutSec) }
Write-Output ('  found: ' + (Describe $dlg))

# --- 2) press OK (id 2) if present, else Yes (id 6) --------------------------------------------
$bs = @(ButtonsOf $dlg)
$target = $bs | Where-Object { $_.Id -eq 2 } | Select-Object -First 1
if (-not $target) { $target = $bs | Where-Object { $_.Id -eq 6 } | Select-Object -First 1 }
if (-not $target) { throw ('the dialog has no OK(id2)/Yes(id6) button: ' + (Describe $dlg)) }
Write-Output ("step 2: pressing button id={0} on {1}" -f $target.Id, $dlg)
[void][CW.U]::SendMessageW($dlg, 0x0111, [IntPtr]$target.Id, [IntPtr]$target.H)
Start-Sleep -Milliseconds $AfterPressMs

# --- 3) wait until it is really gone: three checks + the process check -------------------------
Write-Output ("step 3: waiting up to {0}s for it to close" -f $GoneTimeoutSec)
$gone = $false; $why = ''
$deadline = (Get-Date).AddSeconds($GoneTimeoutSec)
while ((Get-Date) -lt $deadline) {
  if (-not (AppAlive)) { throw 'CRASH: AutoShop process disappeared (this is NOT "the dialog closed")' }
  $alive = [CW.U]::IsWindow($dlg)
  $vis = [CW.U]::IsWindowVisible($dlg)
  $mh = MainHwnd
  $ownerOk = ($mh -ne [IntPtr]::Zero) -and [CW.U]::IsWindowEnabled($mh)
  $rest = @(VisibleDialogs).Count
  $why = ("IsWindow={0} IsWindowVisible={1} ownerEnabled={2} visibleDialogs={3}" -f $alive, $vis, $ownerOk, $rest)
  if ((-not $alive) -or (-not $vis)) { if ($ownerOk) { $gone = $true; break } }
  Start-Sleep -Milliseconds 250
}
if (-not $gone) { throw ('the dialog did not close: ' + $why) }
Write-Output ('  CLOSED - proof: ' + $why)
Write-Output ('  (checks: own handle not visible + owner window re-enabled + no visible #32770 + process alive)')
