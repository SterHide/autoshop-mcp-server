# Probe 2: narrow down WHY accName(childId) fails under PowerShell late binding.
# accChildCount works, so the object is a live IDispatch; only the parameterised getters fail.
# Cheap experiment before writing a full C# IAccessible wrapper.
# KEEP PURE ASCII.
param([int]$Which = 2)   # 0 = leftmost tree (project tree)

$ErrorActionPreference = 'Stop'
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$hwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') {
    $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
    [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r })
  }
  return $true
}
[void][W.U]::EnumChildWindows($hwnd, $cb, [IntPtr]::Zero)
$tree = $trees[$Which].hwnd
Write-Output ("tree[{0}] hwnd={1}" -f $Which, $tree)

$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'   # IID_IAccessible (dual)
$acc = $null
$hr = [W.U]::AccessibleObjectFromWindow($tree, [uint32]4294967292, [ref]$iid, [ref]$acc)
Write-Output ("hr=0x{0:X8} type={1}" -f $hr, $acc.GetType().FullName)
Write-Output ("accChildCount = {0}" -f $acc.accChildCount)

function Try-Call([string]$label, [scriptblock]$sb) {
  try { $v = & $sb; Write-Output ("  {0,-46} => '{1}'" -f $label, $v) }
  catch { Write-Output ("  {0,-46} => ERR {1}" -f $label, $_.Exception.Message) }
}

Write-Output '--- accName with different argument shapes ---'
Try-Call 'accName(0)            [CHILDID_SELF]' { $acc.accName(0) }
Try-Call 'accName(1)'                          { $acc.accName(1) }
Try-Call 'accName([int]1)'                     { $acc.accName([int]1) }
Try-Call 'accName([int32]1)'                   { $acc.accName([int32]1) }
Try-Call 'accName([uint32]1)'                  { $acc.accName([uint32]1) }
Try-Call 'accName([double]1)'                  { $acc.accName([double]1) }
Try-Call 'accName([object]1)'                  { $acc.accName([object]1) }
Try-Call 'accName($acc.accChild(1))'           { $acc.accName($acc.accChild(1)) }
Try-Call 'InvokeMember GetProperty accName'    { $acc.GetType().InvokeMember('accName','GetProperty',$null,$acc,@([int]1)) }
Try-Call 'InvokeMember GetProperty accName 0'  { $acc.GetType().InvokeMember('accName','GetProperty',$null,$acc,@([object]0)) }

Write-Output '--- accChild / accRole / accValue ---'
Try-Call 'accChild(1)'                  { $acc.accChild(1) }
Try-Call 'accChild(@(0,1))'             { $acc.accChild(@(0,1)) }
Try-Call 'accRole(0)'                   { $acc.accRole(0) }
Try-Call 'accValue(0)'                  { $acc.accValue(0) }
Try-Call 'accName(0) via nested child'  { $c = $acc.accChild(@(0,1)); $c.accName(0) }

Write-Output '--- accLocation forms ---'
Try-Call 'accLocation(0,0,0,0,0)'       { $acc.accLocation(0,0,0,0,0) }
Try-Call 'accLocation(ref..,0)'         { $a=0;$b=0;$c=0;$d=0; $acc.accLocation([ref]$a,[ref]$b,[ref]$c,[ref]$d,0); "$a,$b,$c,$d" }
Try-Call 'accLocation(ref..,1)'         { $a=0;$b=0;$c=0;$d=0; $acc.accLocation([ref]$a,[ref]$b,[ref]$c,[ref]$d,1); "$a,$b,$c,$d" }

Write-Output '--- accFocus (which item is selected) ---'
Try-Call 'accFocus'                     { $acc.accFocus }
