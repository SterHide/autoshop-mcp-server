﻿param([string]$Src,[string]$Out,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$Zoom=2)
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile($Src)
$bmp = New-Object System.Drawing.Bitmap ($W*$Zoom), ($H*$Zoom)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.DrawImage($img, (New-Object System.Drawing.Rectangle 0,0,($W*$Zoom),($H*$Zoom)), (New-Object System.Drawing.Rectangle $X,$Y,$W,$H), [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose(); $img.Dispose()
"cropped ($X,$Y) ${W}x${H} zoom ${Zoom}x -> $Out"
