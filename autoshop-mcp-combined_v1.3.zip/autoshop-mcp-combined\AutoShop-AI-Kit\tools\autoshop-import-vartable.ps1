# Drive the AutoShop variable-table IMPORT: right-click the grid -> 导入(M) -> pick the CSV.
#
# Context (all measured on this machine, see the autoshop-uia skill):
#   * the grid's right-click menu is an MFC toolbar-style popup (class 'Afx:...', NOT '#32768'),
#     UIA exposes no MenuItems, and mnemonics do not reach it -> the row must be clicked by offset.
#   * GVL/变量表 view  : menu 219x632, 导出(X) at +100,+383, 导入(M) is the NEXT row  -> +100,+409
#   * FB/FC block view: menu 219x512, 导出(X) at +100,+430, 导入(M) is the NEXT row  -> +100,+456
#   * do NOT warm up with a left click on a GVL grid: it starts editing a cell (ComboBox appears)
#     and the right-click then fails to open the menu.
#   * 导入 opens a standard '打开' file dialog. Its filename field is a ComboBoxEx32 whose inner
#     Edit does NOT necessarily hold the focus, so the field is clicked by rect before pasting.
#
# SAFETY: this script never confirms anything by itself. It drives the file picker and then simply
# REPORTS whatever dialog comes back, leaving it open, so the decision to confirm is made on sight.
#
# KEEP PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$View,        # the open variable-table view's title
  [Parameter(Mandatory=$true)][string]$CsvPath,     # full path of the CSV to import
  [int]$GridOffsetY = 60,                           # right-click point = grid.Top + this
  [int]$MenuOffsetX = 100,
  [int]$ImportOffsetY = 409,                        # GVL menu: 导出 +383, 导入 +409
  [int]$ExpectedMenuH = 632,
  [int]$MenuHTolerance = 60,
  [string]$PopupShot = '',
  [switch]$ConfirmImport,       # press 是 on the "table will be cleared, cannot be undone" prompt
  [switch]$NoSave,              # skip the trailing Ctrl+S (the user's rule is: ALWAYS save after an import)
  [switch]$NoWarmup = $true
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$LD = 0x02; $LU = 0x04; $RD = 0x08; $RU = 0x10
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function ClickRaw([int]$x,[int]$y) { [void][W.U]::SetCursorPos($x,$y); Start-Sleep -Milliseconds 120; [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60; [W.U]::mouse_event($LU,0,0,0,0) }
function RClickRaw([int]$x,[int]$y) { [void][W.U]::SetCursorPos($x,$y); Start-Sleep -Milliseconds 120; [W.U]::mouse_event($RD,0,0,0,0); Start-Sleep -Milliseconds 80; [W.U]::mouse_event($RU,0,0,0,0) }
function TopWindows {
  $l = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { $r = RectOf $h
      [void]$l.Add([pscustomobject]@{ Hwnd=$h; Cls=(ClsOf $h); X=$r.Left; Y=$r.Top; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top); Text=(TxtOf $h) }) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero); return $l }
function Dialogs { return @((TopWindows) | Where-Object { $_.Cls -eq '#32770' }) }
function SavePng([IntPtr]$hwnd,[int]$w,[int]$h,[string]$path) {
  try {
    Add-Type -AssemblyName System.Drawing
    $hs=[W.U]::GetDC([IntPtr]::Zero); $hm=[W.U]::CreateCompatibleDC($hs); $hb=[W.U]::CreateCompatibleBitmap($hs,$w,$h)
    $ho=[W.U]::SelectObject($hm,$hb); $ok=[W.U]::PrintWindow($hwnd,$hm,2); if(-not $ok){$ok=[W.U]::PrintWindow($hwnd,$hm,0)}
    $img=[System.Drawing.Image]::FromHbitmap($hb); $img.Save($path,[System.Drawing.Imaging.ImageFormat]::Png); $img.Dispose()
    [void][W.U]::SelectObject($hm,$ho); [void][W.U]::DeleteObject($hb); [void][W.U]::DeleteDC($hm); [void][W.U]::ReleaseDC([IntPtr]::Zero,$hs)
    Write-Output ("  popup captured -> {0}" -f $path)
  } catch { Write-Output ("  capture failed: {0}" -f $_.Exception.Message) }
}
# USER RULE (2026-09-20): "长时间没点击效果，截图看看现在弹什么框" -- whenever a click produces no
# visible effect, or an expected control cannot be found, capture the WHOLE SCREEN and print the path.
# The real cause is almost always a modal dialog (or the window is not where we think); guessing costs rounds.
function ShotOnStall([string]$why) {
  $p = Join-Path $env:TEMP ("dsh-stall_{0}.png" -f (Get-Date -Format 'HHmmss'))
  try {
    & powershell -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'fullscreen-shot.ps1') -Path $p | Out-Null
    Write-Output ("  [STALL] {0}" -f $why)
    Write-Output ("  [STALL] full-screen shot -> {0}" -f $p)
  } catch { Write-Output ("  [STALL] {0} (screenshot failed: {1})" -f $why, $_.Exception.Message) }
}

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
[void][W.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 400

# --- the open view and its grid ---------------------------------------------------------------
# A MODIFIED view's title carries a trailing ' *' (measured live: '[ST_气缸 *]'), so an exact match
# silently reports "no open view titled ..." and the ENTIRE import is skipped without any prompt.
# Trim it first -- autoshop-write-block.ps1 already had this fix (skill 16.2), this file did not.
$mc = [IntPtr]::Zero
$cb = [W.U+EnumProc]{ param($h,$p) $t=(TxtOf $h).TrimEnd(' ','*'); if ($t -eq $View) { $script:mcHit = $h; return $false }; return $true }
[void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero); $mc = $script:mcHit
if ($null -eq $mc -or $mc -eq [IntPtr]::Zero) { throw ("no open view titled '{0}'" -f $View) }
$grids = New-Object System.Collections.ArrayList
$cb2 = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -like 'VSFlexGrid*' -and [W.U]::IsWindowVisible($h)) {
    $r = RectOf $h; if (($r.Right-$r.Left) -gt 50) { [void]$grids.Add([pscustomobject]@{ Hwnd=$h; R=$r }) } }
  return $true }
[void][W.U]::EnumChildWindows($mc, $cb2, [IntPtr]::Zero)
if ($grids.Count -eq 0) { throw 'no visible variable-table grid in that view' }
$g = $grids[0]
$gx = [int](($g.R.Left + $g.R.Right)/2); $gy = $g.R.Top + $GridOffsetY
Write-Output ("view '{0}'  grid={{ {1},{2} {3}x{4} }}  right-click at ({5},{6})" -f $View, $g.R.Left, $g.R.Top, ($g.R.Right-$g.R.Left), ($g.R.Bottom-$g.R.Top), $gx, $gy)

# --- open the context menu --------------------------------------------------------------------
$before = TopWindows; $beforeIds = @($before | ForEach-Object { $_.Hwnd })
if ($NoWarmup) { [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Start-Sleep -Milliseconds 250 }
else { ClickRaw $gx $gy; Start-Sleep -Milliseconds 350 }
RClickRaw $gx $gy
Start-Sleep -Milliseconds 1300
$popup = @((TopWindows) | Where-Object { $beforeIds -notcontains $_.Hwnd } | Sort-Object { -($_.W * $_.H) })
if ($popup.Count -eq 0) { ShotOnStall 'right-click raised no context menu'; throw 'no context menu appeared' }
$p = $popup[0]
Write-Output ("popup {0}x{1} at {2},{3}" -f $p.W, $p.H, $p.X, $p.Y)
if ([Math]::Abs($p.H - $ExpectedMenuH) -gt $MenuHTolerance) {
  if ($PopupShot) { SavePng $p.Hwnd $p.W $p.H $PopupShot }
  [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
  throw ("popup height {0} != expected {1} - refusing to guess the row" -f $p.H, $ExpectedMenuH)
}
# PORTABILITY: the recorded offsets were measured at $ExpectedMenuH px. Menu items are laid out
# proportionally, so scale the offset by the ACTUALLY measured popup height -- that keeps the same ITEM
# under the cursor on a different DPI / font size / screen. The height tolerance above still guards
# against a genuinely different menu structure.
$menuScale = 1.0
if ($ExpectedMenuH -gt 0) { $menuScale = $p.H / [double]$ExpectedMenuH }
$dy = [int][Math]::Round($ImportOffsetY * $menuScale)
Write-Output ("clicking 导入(M) at ({0},{1})  [popup + {2},{3}; scale {4:N3} = {5}/{6}]" -f ($p.X+$MenuOffsetX), ($p.Y+$dy), $MenuOffsetX, $dy, $menuScale, $p.H, $ExpectedMenuH)
ClickRaw ($p.X + $MenuOffsetX) ($p.Y + $dy)
Start-Sleep -Milliseconds 1600

# --- the file dialog --------------------------------------------------------------------------
$dlg = @((Dialogs) | Where-Object { $_.Text -eq [string]::Concat([char]0x6253,[char]0x5F00) })   # 'Open'
if ($dlg.Count -eq 0) {
  Write-Output '  NO file dialog appeared. Dialogs now open:'
  ShotOnStall 'clicked 导入 but no file dialog appeared'
  foreach ($d in (Dialogs)) { Write-Output ("    '{0}' {{ {1},{2} {3}x{4} }}" -f $d.Text, $d.X, $d.Y, $d.W, $d.H) }
  Get-ChildItem -Path $env:TEMP -Filter 'dsh-stall_*.png' | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | ForEach-Object { Write-Output ("  look at the screenshot: {0}" -f $_.FullName) }
  exit 2
}
$d0 = $dlg[0]
Write-Output ("file dialog '{0}' {{ {1},{2} {3}x{4} }}" -f $d0.Text, $d0.X, $d0.Y, $d0.W, $d0.H)
# the filename field: click it (its Edit does not reliably own the focus)
$box = [IntPtr]::Zero
$cb3 = [W.U+EnumProc]{ param($h,$p)
  $c = ClsOf $h
  if ($c -eq 'ComboBoxEx32' -or ($c -eq 'Edit' -and $script:boxHit -eq [IntPtr]::Zero)) { $script:boxHit = $h; return $false }
  return $true }
[void][W.U]::EnumChildWindows($d0.Hwnd, $cb3, [IntPtr]::Zero); $box = $script:boxHit
if ($box -eq [IntPtr]::Zero) { Write-Output '  could not find the filename field'; exit 3 }
$br = RectOf $box
Write-Output ("filename field {0} {{ {1},{2} {3}x{4} }}" -f (ClsOf $box), $br.Left, $br.Top, ($br.Right-$br.Left), ($br.Bottom-$br.Top))
ClickRaw ([int](($br.Left+$br.Right)/2)) ([int](($br.Top+$br.Bottom)/2))
Start-Sleep -Milliseconds 300

$set = $false
$ErrorActionPreference = 'Continue'
for ($i=0; $i -lt 6 -and -not $set; $i++) { try { [System.Windows.Forms.Clipboard]::SetText($CsvPath); $set = $true } catch { Start-Sleep -Milliseconds 250 } }
$ErrorActionPreference = 'Stop'
if (-not $set) { throw 'could not set the clipboard' }
Write-Output ("clipboard <- '{0}'" -f $CsvPath)
[System.Windows.Forms.SendKeys]::SendWait('^a'); Start-Sleep -Milliseconds 200
[System.Windows.Forms.SendKeys]::SendWait('^v'); Start-Sleep -Milliseconds 450
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
Start-Sleep -Milliseconds 2000

# --- optionally CONFIRM the import ------------------------------------------------------------
# Importing a variable table first asks (verified text):
#     '当前表格将被清空且不支持撤销恢复，是否继续？'  with buttons 是(&Y) / 否(&N)
# i.e. the import REPLACES the whole table and cannot be undone -- so the CSV must be a COMPLETE
# table (every existing variable plus the additions), never just a delta.
# This confirmation is the SECOND (and last) place in this project where a 是 button may be pressed,
# and it is gated behind an explicit switch. Buttons are CHILD windows of the dialog, so they are
# found with EnumChildWindows -- using EnumWindows here silently finds nothing.
if ($ConfirmImport) {
  $dlgKey = [string][char]0x6E05 + [string][char]0x7A7A      # '清空'
  $yesTxt = [string][char]0x662F                              # '是'
  foreach ($d in (Dialogs)) {
    $kids = New-Object System.Collections.ArrayList
    $cb5 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d.Hwnd, $cb5, [IntPtr]::Zero)
    $hasKey = $false
    foreach ($k in $kids) { if ((TxtOf $k).Contains($dlgKey)) { $hasKey = $true; break } }
    if (-not $hasKey) { continue }
    foreach ($k in $kids) {
      $t = TxtOf $k
      if ((ClsOf $k) -eq 'Button' -and $t.Contains($yesTxt)) {
        $kr = RectOf $k
        Write-Output ("  import prompt recognised -> pressing '{0}'" -f $t)
        ClickRaw ([int](($kr.Left+$kr.Right)/2)) ([int](($kr.Top+$kr.Bottom)/2))
        Start-Sleep -Milliseconds 2500
        break
      }
    }
  }
}

# --- REPORT whatever came back; confirm nothing beyond the above -------------------------------
Write-Output ''
Write-Output '=== dialogs now open ==='
$now = Dialogs
if ($now.Count -eq 0) { Write-Output '  (none - the import dialog closed by itself)' }
foreach ($d in $now) {
  Write-Output ("  '{0}' {{ {1},{2} {3}x{4} }}" -f $d.Text, $d.X, $d.Y, $d.W, $d.H)
  $kids = New-Object System.Collections.ArrayList
  $cb4 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
  [void][W.U]::EnumChildWindows($d.Hwnd, $cb4, [IntPtr]::Zero)
  foreach ($k in $kids) {
    $t = TxtOf $k
    if ($t) { $kr = RectOf $k; Write-Output ("      {0,-22} '{{ {1},{2} {3}x{4} }}' text='{5}'" -f (ClsOf $k), $kr.Left, $kr.Top, ($kr.Right-$kr.Left), ($kr.Bottom-$kr.Top), $t) }
  }
}

# --- SAVE the project (USER RULE 2026-09-20: "你每次导入完保存一下文件") -------------------------
# The import only changes the table IN MEMORY; without Ctrl+S the change is lost on close/reload.
# So: leave any edit mode, give AutoShop the foreground, press Ctrl+S, then report the file times.
if (-not $NoSave) {
  Write-Output ''
  # USER RULE 2026-09-20: "你导入之后，他会提示已导入的提示框，你按了确定，再按保存"
  # ORDER MATTERS: the success box ("导入数据成功！") is MODAL -- any click sent while it is up goes to
  # that box, so the Save click must come AFTER dismissing it. (My first version saved first and the
  # save click was swallowed -> the import looked successful but nothing was written.)
  # ★★ 2026-09-20 ROOT CAUSE of a SILENT failure in this block (user spotted the order was wrong:
  #    "在导入后有弹窗成功，你会先按保存判断一轮才会按那个确定弹窗"):
  #    it used to match the button by the Chinese LITERAL '确定'. THIS FILE IS BOM-LESS UTF-8 and
  #    PowerShell 5.1 reads it as ANSI, so that literal arrives as MOJIBAKE and NEVER matches -- the box
  #    stayed up, the Save click below was swallowed by the modal box, and the log printed
  #    "no success box found" while the dump directly above listed `Button ... text='确定'`.
  #    The rest of this file already builds Chinese from char codes ($dlgKey / $yesTxt) -- same trick
  #    here, PLUS the language-proof fallback: the AFFIRMATIVE is the LEFTMOST button (help ids 8/9 out).
  Write-Output '=== 1) dismiss the success box (press its OK) BEFORE any Save click ==='
  $okTxt   = [string][char]0x786E + [string][char]0x5B9A                                    # '确定'
  $yesTxt2 = [string][char]0x662F                                                           # '是'
  $succTxt = [string][char]0x5BFC + [string][char]0x5165 + [string][char]0x6570 + `
             [string][char]0x636E + [string][char]0x6210 + [string][char]0x529F              # '导入数据成功'
  $pressed = 0
  for ($pass = 1; $pass -le 6; $pass++) {
    $pressedThisPass = 0
    foreach ($d in (Dialogs)) {
      $kids0 = New-Object System.Collections.ArrayList
      $cb6 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { [void]$kids0.Add($h) }; return $true }
      [void][W.U]::EnumChildWindows($d.Hwnd, $cb6, [IntPtr]::Zero)
      $statTxt = ''
      $cands = New-Object System.Collections.ArrayList
      foreach ($k in $kids0) {
        if ((ClsOf $k) -eq 'Static') { $statTxt += (TxtOf $k); continue }
        if ((ClsOf $k) -eq 'Button') {
          $bid = [int][W.U]::GetWindowLong($k, -12)
          if ($bid -eq 8 -or $bid -eq 9) { continue }
          [void]$cands.Add([pscustomobject]@{ H=$k; Id=$bid; T=(TxtOf $k); L=(RectOf $k).Left })
        }
      }
      if ($cands.Count -eq 0) { continue }
      $pick = $null
      $byText = @($cands | Where-Object { $_.T -like ('*' + $okTxt + '*') -or $_.T -like ('*' + $yesTxt2 + '*') } | Sort-Object L | Select-Object -First 1)
      if ($byText.Count -gt 0) { $pick = $byText[0] }
      elseif ($statTxt -like ('*' + $succTxt + '*')) { $pick = @($cands | Sort-Object L | Select-Object -First 1)[0] }
      if ($null -eq $pick) {
        Write-Output ("  box '{0}' is not a success/save prompt - LEAVING IT ALONE (static='{1}')" -f (TxtOf $d.Hwnd), $statTxt)
        continue
      }
      # ★ 2026-09-20: the box does NOT always say 导入数据成功！ It can say 导入完成失败N条 (N rows FAILED).
      #   Measured: importing an FB-instance row whose FB TYPE does not exist yet fails exactly one row,
      #   and the box still only offers 确定 -- so without this check the failure looked like a success.
      $failTxt = [string][char]0x5931 + [string][char]0x8D25                       # '失败'
      if ($statTxt -like ('*' + $failTxt + '*')) {
        Write-Output ("  *** IMPORT REPORTED FAILURES: static='{0}' ***" -f $statTxt)
        Write-Output  '      most common cause: dependency order -- an FB-instance row needs its FB type to already exist;'
        Write-Output  '      a struct-typed variable needs its struct to already exist. Re-import AFTER creating the dependency.'
      }
      Write-Output ("  box '{0}' static='{1}' -> pressing id={2} text='{3}'" -f (TxtOf $d.Hwnd), $statTxt, $pick.Id, $pick.T)
      [void][W.U]::SendMessageW($d.Hwnd, 0x0111, [IntPtr]$pick.Id, [IntPtr]$pick.H)
      Start-Sleep -Milliseconds 800
      $pressed++; $pressedThisPass++
    }
    if ($pressedThisPass -eq 0) { break }
  }
  $boxesLeft = @(Dialogs).Count
  Write-Output ("  pressed {0} button(s); modal boxes left = {1}" -f $pressed, $boxesLeft)
  if ($boxesLeft -gt 0) { Write-Output '  WARNING: a box SURVIVED - the Save click below will be swallowed by it' }

  Add-Type -AssemblyName System.Windows.Forms
  if (-not ('SV' -as [type])) {
    Add-Type -Namespace SV -Name U -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
'@
  }
  $procx = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($procx) {
    $mh = (Get-AutoShopMainWindow $procx)
    for ($i = 1; $i -le 4; $i++) { [void][SV.U]::SetForegroundWindow($mh); Start-Sleep -Milliseconds 250 }
    [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Start-Sleep -Milliseconds 300   # leave any cell edit mode
    # Save button: 3rd item in the top toolbar, measured at (88,71) when the window is at (0,1)
    $mr = New-Object W.U+RECT; [void][W.U]::GetWindowRect($mh, [ref]$mr)
    $sx = $mr.Left + 88; $sy = $mr.Top + 70
    # ★ USER RULE 2026-09-20: the PROOF of a save is the ' *' leaving the active tab's title -- not the
    #   fact that a click was sent. So: click, re-read the title, and retry while it is still dirty.
    #   (The old code clicked once, slept 4s, and printed nothing about the result, so a swallowed click
    #    passed as a successful save.)
    for ($s = 1; $s -le 4; $s++) {
      Write-Output ("  [{0}] clicking the toolbar Save button at ({1},{2})   title before=[{3}]" -f $s, $sx, $sy, (TxtOf $mh))
      ClickRaw $sx $sy
      Start-Sleep -Milliseconds 2500
      # answer any prompt that the save itself raised (save-confirm etc.), leftmost/affirmative button
      foreach ($d in (Dialogs)) {
        $kids1 = New-Object System.Collections.ArrayList
        $cb8 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { [void]$kids1.Add($h) }; return $true }
        [void][W.U]::EnumChildWindows($d.Hwnd, $cb8, [IntPtr]::Zero)
        $c2 = New-Object System.Collections.ArrayList
        foreach ($k in $kids1) {
          if ((ClsOf $k) -eq 'Button') {
            $bid = [int][W.U]::GetWindowLong($k, -12)
            if ($bid -eq 8 -or $bid -eq 9) { continue }
            [void]$c2.Add([pscustomobject]@{ H=$k; Id=$bid; T=(TxtOf $k); L=(RectOf $k).Left })
          }
        }
        if ($c2.Count -gt 0) {
          $p = @($c2 | Where-Object { $_.T -like ('*' + $yesTxt2 + '*') -or $_.T -like ('*' + $okTxt + '*') } | Sort-Object L | Select-Object -First 1)
          if ($p.Count -eq 0) { $p = @($c2 | Sort-Object L | Select-Object -First 1) }
          Write-Output ("    save-time prompt '{0}' -> pressing id={1} text='{2}'" -f (TxtOf $d.Hwnd), $p[0].Id, $p[0].T)
          [void][W.U]::SendMessageW($d.Hwnd, 0x0111, [IntPtr]$p[0].Id, [IntPtr]$p[0].H)
          Start-Sleep -Milliseconds 1200
        }
      }
      $after = TxtOf $mh
      $clean = -not ($after -match '\[\s*[^\[\]]*\*\s*\]')
      Write-Output ("      title after=[{0}]   dirty={1}" -f $after, (-not $clean))
      if ($clean) { break }
    }
  } else {
    Write-Output '  WARNING: AutoShop process not found - could not save'
  }
  foreach ($f in @((Join-Path (Split-Path -Parent (Split-Path -Parent $CsvPath)) 'ST框架.hcp'))) {
    if (Test-Path -LiteralPath $f) { $it = Get-Item -LiteralPath $f; Write-Output ("  {0}  {1} bytes  {2}" -f $it.Name, $it.Length, $it.LastWriteTime.ToString('HH:mm:ss')) }
  }
}
