# Build an AutoShop table import file from the table's OWN fresh export (the baseline) plus new rows.
#
# WHY (user's rule, AGENTS.md): "导入 = 整表替换, 不可撤销" and "导入/改动的基准必须来自 AutoShop 当前的导出
# -- 不要拿镜像当基准". A stale snapshot would silently revert whatever changed in AutoShop since. So this
# tool NEVER invents a baseline: it reads one that was just exported from the live table, keeps its exact
# header line and encoding, and appends rows in that same format.
#
# Encoding matters: AutoShop exports these tables as GBK (GB2312), no BOM. Feeding it UTF-8 produces
# mojibake column names. The output is therefore written back as GBK too.
#
# KEEP PURE ASCII: all Chinese arrives via -Baseline / -Row / -VarName / -Comment parameters or the file.
param(
  [Parameter(Mandatory=$true)][string]$Baseline,   # freshly exported CSV (the live table's current state)
  [Parameter(Mandatory=$true)][string]$Out,        # where to write the import file
  [string[]]$Row = @(),                            # raw rows to append, already comma-joined
  [string]$VarName  = '',                          # convenience: build a GVL top-level struct-variable row
  [string]$StructName = '',
  [string]$Comment = '',
  [string]$Cols = 'gvl',                           # gvl = 9 columns ; fbi = 6 columns
  [int]$StartIndex = 1,
  [switch]$KeepBlanks
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Baseline)) { throw ("no baseline file: " + $Baseline) }

$gbk = [System.Text.Encoding]::GetEncoding(936)
$raw = [System.IO.File]::ReadAllBytes($Baseline)
$txt = $gbk.GetString($raw)
# AutoShop's export ends with a blank line; appending after it would create an empty row in the middle.
$lines = @($txt -split "`r?`n")
while (-not $KeepBlanks -and $lines.Count -gt 0 -and $lines[$lines.Count-1].Trim() -eq '') {
  $lines = @($lines[0..($lines.Count-2)])
}
if ($lines.Count -eq 0) { throw 'the baseline file has no header line' }
$header = $lines[0]
$cols = @($header -split ',')
Write-Output ("baseline : {0}" -f $Baseline)
Write-Output ("  header : {0}  ({1} column slots)" -f $header, $cols.Count)
Write-Output ("  existing data rows: {0}" -f ($lines.Count - 1))

$out_lines = New-Object System.Collections.ArrayList
[void]$out_lines.Add($header)
for ($i = 1; $i -lt $lines.Count; $i++) { if ($lines[$i].Trim() -ne '') { [void]$out_lines.Add($lines[$i]) } }

$idx = $StartIndex + ($out_lines.Count - 1)
foreach ($r in $Row) {
  [void]$out_lines.Add($r)
  Write-Output ("  + row : {0}" -f $r)
  $idx++
}
if ($VarName -ne '') {
  # GVL / FB-instance top-level row: <index>,<name>,<type>,then the remaining slots empty.
  # The SKILL (§2336) says a struct-typed variable is imported as its TOP-LEVEL ROW ONLY -- AutoShop
  # expands the members itself -- so the trailing slots stay blank.
  $n = $cols.Count
  if ($Cols -eq 'fbi') {
    # 序号,变量名,数据类型,隐藏初始值,初始值,注释,
    $line = ('{0},{1},{2},,,{3},' -f $idx, $VarName, $StructName, $Comment)
  } else {
    # 序号,变量名,数据类型,隐藏初始值,初始值,掉电保持,网络公开,注释,软元件地址,
    $line = ('{0},{1},{2},,,,,{3},,' -f $idx, $VarName, $StructName, $Comment)
  }
  [void]$out_lines.Add($line)
  Write-Output ("  + row : {0}" -f $line)
  $idx++
}

$body = ($out_lines -join "`r`n") + "`r`n"
$d = Split-Path -Parent $Out
if ($d -and -not (Test-Path -LiteralPath $d)) { [void](New-Item -ItemType Directory -Force -Path $d) }
[System.IO.File]::WriteAllBytes($Out, $gbk.GetBytes($body))
Write-Output ("wrote {0}  ({1} lines, {2} bytes, GBK)" -f $Out, $out_lines.Count, (Get-Item -LiteralPath $Out).Length)
Write-Output '--- full import file ---'
foreach ($l in $out_lines) { Write-Output ('  |' + $l) }
