# Full-screen screenshot — the FIRST thing to do when an operation seems stuck / never returns.
#
# WHY: when a click or keypress "does nothing", the cause is usually INVISIBLE from the API side
# (a modal dialog waiting for input, a 'Save As' box left open by a mis-clicked menu offset,
# a window moved off-screen, AutoShop busy). Guessing costs many rounds; one full screenshot shows it.
#
# Usage:
#   powershell -STA -NoProfile -ExecutionPolicy Bypass -File fullscreen-shot.ps1
#   powershell ... -File fullscreen-shot.ps1 -Path D:\tmp\now.png -ScaleTo 1600
#
# KEEP PURE ASCII.
param(
  [string]$Path = '',
  [int]$ScaleTo = 1600,        # 0 = native resolution
  [switch]$Quiet
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
if (-not $Path) {
  $dir = Join-Path $env:TEMP 'dsh-shots'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $Path = Join-Path $dir ('screen_{0}.png' -f (Get-Date -Format 'HHmmss'))
}
$bmp = New-Object System.Drawing.Bitmap $vs.Width, $vs.Height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($vs.Left, $vs.Top, 0, 0, (New-Object System.Drawing.Size $vs.Width, $vs.Height))
$g.Dispose()

$out = $bmp
if ($ScaleTo -gt 0 -and $bmp.Width -gt $ScaleTo) {
  $r = $ScaleTo / $bmp.Width
  $out = New-Object System.Drawing.Bitmap $ScaleTo, ([int]($bmp.Height * $r))
  $g2 = [System.Drawing.Graphics]::FromImage($out)
  $g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g2.DrawImage($bmp, 0, 0, $out.Width, $out.Height)
  $g2.Dispose()
}
$out.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
if ($out -ne $bmp) { $out.Dispose() }
$bmp.Dispose()

if (-not $Quiet) {
  Write-Output ("saved {0}  (virtual screen {1}x{2} at {3},{4})" -f $Path, $vs.Width, $vs.Height, $vs.Left, $vs.Top)
  # a cheap, dependency-free summary of the foreground window so the shot can be interpreted fast
  Add-Type -Namespace FS -Name U -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
'@
  $h = [FS.U]::GetForegroundWindow()
  $sb = New-Object System.Text.StringBuilder 512
  [void][FS.U]::GetWindowTextW($h, $sb, 512)
  Write-Output ("foreground: '{0}'" -f $sb.ToString())
}
