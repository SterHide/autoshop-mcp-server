# Dismiss any AutoShop confirmation box, THEN press the toolbar Save button.
#
# WHY (user, 2026-09-20): "你导入之后，他会提示已导入的提示框 你按了确定 再按保存" and
# "你没成功按掉这个就按保存". The success box ("导入数据成功！") is MODAL: clicking Save while it is up
# sends the click to the box, so the save silently does nothing. ORDER: dismiss first, save second.
#
# Buttons are matched by CONTROL ID, never by Chinese text (a .ps1 with Chinese literals is read as ANSI
# Button matching: NEVER guess by control id. Measured on this AutoShop build:
#   import-success box  -> 确定 = id 2        (non-canonical!)
#   delete-confirm box  -> 确定 = id 1        (canonical IDOK)
# so an id-based rule presses Cancel in one of them. Instead:
#   1) if -ButtonText is given, match the button TEXT (passed from the command line, so Chinese is safe)
#   2) otherwise press the LEFTMOST button (excluding help ids 8/9) -- in every dialog seen so far the
#      affirmative (是 / 确定) is leftmost, which is language-independent.
#
# ProjectDir has NO Chinese default on purpose: a Chinese literal inside a .ps1 is read as ANSI by
# PowerShell 5.1 and turns into mojibake (that is how the first version lost its timestamp report).
#
# KEEP PURE ASCII.
param(
  [string]$ProjectDir = '',
  [string]$ButtonText = '',
  [int]$SaveOffsetX = 88,
  [int]$SaveOffsetY = 70,
  [switch]$NoSave
)
$ErrorActionPreference = 'Stop'
if (-not ('CS' -as [type])) {
  Add-Type -Namespace CS -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 256; [void][CS.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 512; [void][CS.U]::GetWindowTextW($h,$b,512); $b.ToString() }
function DialogList {
  $l = New-Object System.Collections.ArrayList
  $cb = [CS.U+EnumProc]{ param($h,$x) if ([CS.U]::IsWindowVisible($h) -and (ClsOf $h) -eq '#32770') { [void]$l.Add($h) }; return $true }
  [void][CS.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $l
}
# press a button by control id (2 = OK, 6 = Yes) in every dialog that has one; returns how many were pressed
function DismissBoxes([int]$maxPass = 6) {
  $total = 0
  for ($pass = 1; $pass -le $maxPass; $pass++) {
    $dlgs = @(DialogList)
    if ($dlgs.Count -eq 0) { return $total }
    $pressedThisPass = 0
    foreach ($d in $dlgs) {
      $kids = New-Object System.Collections.ArrayList
      $cb = [CS.U+EnumProc]{ param($h,$x) if ([CS.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
      [void][CS.U]::EnumChildWindows($d, $cb, [IntPtr]::Zero)
      # pick the button: by TEXT when -ButtonText was supplied, else the LEFTMOST (excluding help ids 8/9)
      $target = [IntPtr]::Zero; $tid = 0; $ttxt = ''
      $cands = New-Object System.Collections.ArrayList
      foreach ($k in $kids) {
        if ((ClsOf $k) -eq 'Button') {
          $id = [int][CS.U]::GetWindowLong($k, -12)
          if ($id -eq 8 -or $id -eq 9) { continue }        # help / close glyphs, not answers
          $r = New-Object CS.U+RECT; [void][CS.U]::GetWindowRect($k, [ref]$r)
          [void]$cands.Add([pscustomobject]@{ H = $k; Id = $id; T = (TxtOf $k); L = $r.Left })
        }
      }
      if ($ButtonText -ne '') {
        $hit = @($cands | Where-Object { $_.T -like ('*' + $ButtonText + '*') } | Select-Object -First 1)
        if ($hit.Count -gt 0) { $target = $hit[0].H; $tid = $hit[0].Id; $ttxt = $hit[0].T }
      } elseif ($cands.Count -gt 0) {
        $pick = @($cands | Sort-Object L | Select-Object -First 1)[0]
        $target = $pick.H; $tid = $pick.Id; $ttxt = $pick.T
      }
      if ($target -ne [IntPtr]::Zero) {
        Write-Output ("  pass {0}: dialog '{1}' -> pressing the leftmost/offered button id={2} text='{3}'" -f $pass, (TxtOf $d), $tid, $ttxt)
        [void][CS.U]::SendMessageW($d, 0x0111, [IntPtr]$tid, [IntPtr]$target)
        Start-Sleep -Milliseconds 900
        $pressedThisPass++
        $total++
      } else {
        Write-Output ("  pass {0}: dialog '{1}' has no pressable answer button - leaving it alone" -f $pass, (TxtOf $d))
      }
    }
    if ($pressedThisPass -eq 0) { return $total }
    Start-Sleep -Milliseconds 400
  }
  return $total
}

Write-Output '=== step 1: dismiss every confirmation box ==='
$n = DismissBoxes
Write-Output ("  dismissed {0} button(s); dialogs left = {1}" -f $n, @(DialogList).Count)

if ($NoSave) { Write-Output 'step 2 skipped (-NoSave)'; exit 0 }

Write-Output '=== step 2: press the toolbar Save button ==='
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

$p = Get-Process -Name AutoShop | Select-Object -First 1
$mh = (Get-AutoShopMainWindow $p)
for ($i = 1; $i -le 4; $i++) { [void][CS.U]::SetForegroundWindow($mh); Start-Sleep -Milliseconds 250 }
[System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Start-Sleep -Milliseconds 300   # leave any cell edit mode
$mr = New-Object CS.U+RECT; [void][CS.U]::GetWindowRect($mh, [ref]$mr)
# GUARD: a minimized window reports rect { -32000,-32000 160x28 } and a click there goes nowhere useful.
if ($mr.Left -lt -2000 -or ($mr.Right - $mr.Left) -lt 400) {
  throw ("AutoShop's main window is minimized or off-screen (rect={{ {0},{1} {2}x{3} }}) - restore it first" -f $mr.Left, $mr.Top, ($mr.Right-$mr.Left), ($mr.Bottom-$mr.Top))
}
# PORTABILITY: (88,70) was measured as WINDOW-relative when the main toolbar was 30px tall. Clicking
# relative to the window breaks when the window grows a caption/border (measured live: a MAXIMIZED window
# reports rect { -8,-8 ... } and the click landed 8px off) or when the DPI changes the toolbar metrics.
# So locate the MAIN TOOLBAR itself and click inside ITS rect: the menu bar is also an Afx:ToolBar, so
# take the toolbar-like children, drop the topmost one (the menu bar) and use the next one down.
$refToolH = 30
$refOffsetInToolbarY = 42          # 70 (window-relative) - 28 (menu bar height) = 42 inside the toolbar
$tbs = New-Object System.Collections.ArrayList
$cbTb = [CS.U+EnumProc]{
  param($h, $x)
  if ([CS.U]::IsWindowVisible($h)) {
    $c = ClsOf $h
    if ($c -like 'Afx:ToolBar*' -or $c -like '*ToolbarWindow32*') {
      $r = New-Object CS.U+RECT; [void][CS.U]::GetWindowRect($h, [ref]$r)
      [void]$tbs.Add([pscustomobject]@{ H = $h; L = $r.Left; T = $r.Top; W = ($r.Right-$r.Left); Hh = ($r.Bottom-$r.Top) })
    }
  }
  return $true
}
[void][CS.U]::EnumChildWindows($mh, $cbTb, [IntPtr]::Zero)
$tb = $null
if ($tbs.Count -gt 0) {
  # The toolbars sit side by side on the SAME row (measured: two Afx:ToolBar children at window-relative
  # x=0 and x=540, both 30px tall, under the 28px menu bar). The Save button is on the LEFTMOST one, so:
  # drop the topmost row (the menu bar), then take the smallest x of what remains.
  $minTop = (@($tbs | Measure-Object T -Minimum).Minimum)
  $below = @($tbs | Where-Object { $_.T -gt $minTop })
  $pool = $(if ($below.Count -gt 0) { $below } else { $tbs })
  $tb = @($pool | Sort-Object T, L | Select-Object -First 1)[0]
}
$uiScale = 1.0
if ($null -ne $tb -and $tb.Hh -gt 0) { $uiScale = $tb.Hh / [double]$refToolH }
# ★ 用【窗口相对】坐标点击 (88,70)，不要用"工具栏相对" ✗
# 实测教训：把 (88,70) 换成"工具栏相对 (88,42)"后，挑到的工具栏行不同 ⇒ 42 落到 30px 高的工具栏外面 ✗
# ⇒ 点了保存但其实点在工具栏下方的空白处，保存静默失败 ✓（用户一眼看出来了 ✓）。
# 屏幕实测（窗口在 0,1 时抓图）：保存按钮中心 ≈ 屏幕 (81,67) ⇒ 窗口相对 ≈ (81,66) ✓ 与 (88,70) 吻合 ✓
# 硬编码兜底：实测发现 $SaveOffsetX 在运行时可能是空/0 ⇒ $sx 变成 0 ⇒ 点到屏幕最左边 ✗
# （判据：点完鼠标应停在 (88,71)；曾实测停在 (0,71) ✗）。所以这里不再依赖参数是否有值 ✓。
$offX = 88; $offY = 70
if ($null -ne $SaveOffsetX -and [int]$SaveOffsetX -gt 0) { $offX = [int]$SaveOffsetX }
if ($null -ne $SaveOffsetY -and [int]$SaveOffsetY -gt 0) { $offY = [int]$SaveOffsetY }
$sx = [int]$mr.Left + [int][Math]::Round($offX * $uiScale)
$sy = [int]$mr.Top + [int][Math]::Round($offY * $uiScale)
Write-Output ("  clicking Save at (" + $sx + "," + $sy + ")  [window " + $mr.Left + "," + $mr.Top + " " + ($mr.Right-$mr.Left) + "x" + ($mr.Bottom-$mr.Top) + "; scale " + $uiScale.ToString('N3') + "]")
Write-Output ("  clicking Save at ({0},{1})  [window {{ {2},{3} {4}x{5} }}; ui scale {6:N3}; toolbar {{ {7} }}]" -f `
  $sx, $sy, $mr.Left, $mr.Top, ($mr.Right-$mr.Left), ($mr.Bottom-$mr.Top), $uiScale, $(if ($null -ne $tb) { "$($tb.L),$($tb.T) $($tb.W)x$($tb.Hh)" } else { 'n/a' }))
[void][CS.U]::SetCursorPos($sx, $sy); Start-Sleep -Milliseconds 150
[CS.U]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 70; [CS.U]::mouse_event(0x04,0,0,0,0)
Start-Sleep -Milliseconds 4000

Write-Output '=== step 3: answer any save prompt with Yes ==='
$n2 = DismissBoxes 3
Write-Output ("  dismissed {0} further button(s); dialogs left = {1}" -f $n2, @(DialogList).Count)

Write-Output '=== proof: file timestamps ==='
Get-ChildItem -LiteralPath $ProjectDir -File | Where-Object { $_.Name -match '\.hcp$|\.gvt$|\.fbi$' } |
  Sort-Object LastWriteTime -Descending | Select-Object -First 6 |
  ForEach-Object { Write-Output ("  {0,-22} {1,9} bytes  {2}" -f $_.Name, $_.Length, $_.LastWriteTime.ToString('HH:mm:ss')) }
