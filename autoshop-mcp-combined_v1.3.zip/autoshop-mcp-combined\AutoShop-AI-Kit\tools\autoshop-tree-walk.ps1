﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Validate the core loop the new extractor will be built on:
#     walk the tree with the DOWN key, and after each step ask MSAA WHICH node is selected
#     (accSelection -> accName / accState / accLocation).
#
# Why this instead of sweeping child ids: the child-id space is DYNAMIC. A sweep right after
# scrolling found SBR_* names at ids 189..230; a sweep with the tree back at the top made those
# same ids answer nothing (188 nodes only). The selection, by contrast, is unambiguous -- exactly
# one node, and MSAA reports its id, name, fold state and screen rect.
#
# Also validates: accSelect() (selection with NO mouse input at all) and RIGHT-to-expand.
# KEEP PURE ASCII.
param(
  [int]$Steps = 18,
  [switch]$ExpandWalk
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000; selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88
$LD = 0x02; $LU = 0x04

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function Dec([int]$s) {
  $f = New-Object System.Collections.ArrayList
  foreach ($k in @('selected','focused','expanded','collapsed','focusable','selectable','invisible','offscreen')) { if ($s -band $ST[$k]) { [void]$f.Add($k) } }
  if ($f.Count) { return ($f -join '+') } else { return '-' } }

function Assert-NoDialog {
  $hit = $false
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  foreach ($d in $dlgs) {
    $hit = $true
    $kids = New-Object System.Collections.ArrayList
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d, $cb2, [IntPtr]::Zero)
    $caps = ($kids | ForEach-Object { TxtOf $_ }) -join '/'
    Write-Output ("   [dialog] '{0}' buttons=[{1}]" -f (TxtOf $d), $caps)
    foreach ($want in @($S_NO, $S_CANCEL)) {
      foreach ($b in $kids) {
        if ((TxtOf $b) -eq $want) {
          $br = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$br)
          Click ([int](($br.Left+$br.Right)/2)) ([int](($br.Top+$br.Bottom)/2))
          Start-Sleep -Milliseconds 450
          Write-Output ("   [dialog] pressed '{0}'" -f (TxtOf $b)); break } }
      if ($hit) { }
    }
  }
  return $hit
}

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows((Get-AutoShopMainWindow $proc), $cb, [IntPtr]::Zero)
$tree = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
$iidAcc = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
[void][W.U]::AccessibleObjectFromWindow($tree.hwnd, [uint32]4294967292, [ref]$iidAcc, [ref]$acc)
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }} acc={5}" -f $tree.hwnd, $tree.rect.Left, $tree.rect.Top, ($tree.rect.Right-$tree.rect.Left), ($tree.rect.Bottom-$tree.rect.Top), $acc.GetType().Name)

[void][W.U]::SetForegroundWindow((Get-AutoShopMainWindow $proc))
Start-Sleep -Milliseconds 400

function Read-Sel {
  $id = $null
  try { $id = $acc.accSelection } catch { $id = $null }
  if ($null -eq $id -or $id -isnot [int]) { return [pscustomobject]@{ Id=$null; Name=''; State=''; X=0;Y=0;W=0;H=0 } }
  $n = ''; $s = -1; $x=0;$y=0;$w=0;$h=0
  try { $n = [string]$acc.accName([int]$id) } catch { }
  try { $s = [int]$acc.accState([int]$id) } catch { }
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$id) } catch { }
  return [pscustomobject]@{ Id=[int]$id; Name=$n; State=(Dec $s); Raw=$s; X=$x;Y=$y;W=$w;H=$h }
}

Write-Output ''
Write-Output '--- A) accSelect with NO mouse input (focus the tree by keyboard only) ---'
try { $acc.accSelect(3, [int]$acc.accSelection); Start-Sleep -Milliseconds 200; Write-Output ("  accSelect(TAKEFOCUS|TAKESELECTION) on current selection => ok, sel={0}" -f (Read-Sel).Name) }
catch { Write-Output ("  accSelect ERR {0}" -f $_.Exception.Message) }

Write-Output ''
Write-Output '--- B) click the top row of the tree, then walk DOWN and read the selection ---'
Click ($tree.rect.Left + 40) ($tree.rect.Top + 10)
Start-Sleep -Milliseconds 400
[void](Assert-NoDialog)
Send '^({HOME})' 600
Write-Output ("  after click+Ctrl+Home: {0}" -f ((Read-Sel) | ForEach-Object { "id=$($_.Id) name='$($_.Name)' state=$($_.State) rect=$($_.X),$($_.Y),$($_.W),$($_.H)" }))

Write-Output ''
Write-Output ("{0,4} {1,-42} {2,-40} {3}" -f 'step','name','state','rect')
$prev = ''
for ($i = 1; $i -le $Steps; $i++) {
  $s = Read-Sel
  Write-Output ("{0,4} {1,-42} {2,-40} {3}" -f $i, $s.Name, $s.State, "$($s.X),$($s.Y),$($s.W),$($s.H)")
  if ($ExpandWalk -and $s.State -like '*collapsed*') {
    Send '{RIGHT}' 300
    [void](Assert-NoDialog)
    $s2 = Read-Sel
    Write-Output ("      expanded -> {0} state={1}" -f $s2.Name, $s2.State)
  }
  if ($s.Name -eq $prev -and $i -gt 1) { Write-Output '  (selection did not advance - stopping)'; break }
  $prev = $s.Name
  Send '{DOWN}' 90
}
[void](Assert-NoDialog)
Write-Output ''
Write-Output 'done.'

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }
