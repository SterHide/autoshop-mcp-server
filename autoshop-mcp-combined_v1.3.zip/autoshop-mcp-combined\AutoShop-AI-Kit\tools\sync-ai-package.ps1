# Sync the CURRENT skills/tools/MCP into the existing desktop AI package, and drop the OLD-MCP leftovers.
#
# WHY A SCRIPT: the package is a deliverable that will be re-synced after every SKILL update. Doing it by
# hand means (a) stale tool copies silently survive, (b) the 11 tools that hardcode this machine's paths
# get shipped broken, (c) the old-MCP route creeps back in.
#
# Layout of the target package:
#   <Pkg>\skills\<name>\SKILL.md          4 skills
#   <Pkg>\tools\*.ps1                     the AutoShop scripts (paths must be portable)
#   <Pkg>\mcp\autoshop\server.mjs         the thin AutoShop MCP (this session's work)
#   <Pkg>\mcp\dsh-computer-use-win\       the generic desktop-automation MCP (left alone here)
#   <Pkg>\AGENTS-AutoShop-rules.md        rules extracted from ~/.dsh/AGENTS.md  (Chinese file name)
#   <Pkg>\install guide (Chinese name)    the install guide
#
# KEEP PURE ASCII in this file (a BOM-less .ps1 is read as ANSI by PowerShell 5.1).
param(
  [string]$ToolsDir  = (Join-Path $env:TEMP 'autoshop-tools'),
  [string]$McpDir    = (Join-Path $env:TEMP 'autoshop-mcp-autoshop'),
  [string]$SkillsDir = 'C:\Users\Administrator\.dsh\skills',
  [string]$AgentsMd  = 'C:\Users\Administrator\.dsh\AGENTS.md',
  [string]$TextsJson = (Join-Path $env:TEMP 'autoshop-_design\kit-texts.json'),
  [string]$Pkg       = 'C:\Users\Administrator\Desktop\DSH-AutoShop-AI-Package',
  [switch]$WhatIf
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)

# skills to ship (the 4 the package already advertises)
$skills = @('autoshop-uia', 'windows-desktop-automation', 'weinview-ebpro', 'dsh-memory-and-skills')

# one-off / debug leftovers of THIS machine, plus the maintenance scripts themselves: no value
# downstream, and some of them CALL the old MCP (autoshop-mcp-server, an HTTP MCP on port 18711)
$dropTools = @(
  'build-ai-kit.ps1', 'sync-ai-package.ps1',   # builders: only meaningful on the source machine
  '_apply-portability-patches.ps1', '_fix-five-bootstrap.ps1', '_probe-toolbar.ps1', '_test-setclip.ps1',
  'enc-probe.ps1', 'enc-match-probe.ps1', 'hub-client.ps1', 'wake.ps1',
  'autoshop-mcp-call.ps1',        # HTTP caller for the OLD MCP
  'autoshop-verify.ps1',          # "verification harness for autoshop-mcp-server fixes"
  'autoshop-wait-project.ps1'     # polls the OLD MCP until a project path shows up
)
# stale copies that must not survive the sync -- ONLY the ones tied to the OLD MCP plus litter.
# The measurement/probe tools MUST stay: they are how offsets get re-measured on another machine.
$stalePatterns = @(
  'autoshop-mcp-call.ps1',
  'autoshop-verify.ps1',
  'autoshop-wait-project.ps1',
  'last-shot.txt'
)

function Convert-ToPortable([string]$path) {
  $t = [System.IO.File]::ReadAllText($path, $utf8)
  $o = $t
  $t = [regex]::Replace($t, "'D:\\DeepseekHarness\\tools\\([^']+)'", "(Join-Path `$PSScriptRoot '`$1')")
  $t = [regex]::Replace($t, "'D:\\DeepseekHarness\\([^']*)'",       "(Join-Path `$env:TEMP 'autoshop-`$1')")
  $t = $t -replace "\`$Tools = \(Join-Path \`$env:TEMP 'autoshop-tools'\)", '$Tools = $PSScriptRoot'
  if ($t -ne $o) { [System.IO.File]::WriteAllBytes($path, $utf8.GetBytes($t)); return $true }
  return $false
}

# ---------------------------------------------------------------- 1) skills
$texts = [System.IO.File]::ReadAllText($TextsJson, $utf8) | ConvertFrom-Json
foreach ($s in $skills) {
  $srcSkill = Join-Path (Join-Path $SkillsDir $s) 'SKILL.md'
  if (-not (Test-Path $srcSkill)) { Write-Output ("  SKIP skill (missing): " + $s); continue }
  $dstDir = Join-Path (Join-Path $Pkg 'skills') $s
  if (-not $WhatIf) { [void](New-Item -ItemType Directory -Force -Path $dstDir) }
  $dst = Join-Path $dstDir 'SKILL.md'
  $t = [System.IO.File]::ReadAllText($srcSkill, $utf8)
  $note = ''
  if ($s -eq 'autoshop-uia') {
    $before = $t.Length
    # the package must not carry the old-MCP route: cut section 12, cut 40.6, rewrite the one bullet
    $t = [regex]::Replace($t, '(?s)\r?\n## 12\..*?(?=\r?\n## 13\.)', "`r`n")
    $t = [regex]::Replace($t, '(?s)\r?\n### 40\.6 .*$', "`r`n")
    $t = [regex]::Replace($t, '(?m)^- CLI.*autoshop-agent.*$', $texts.indexNote)
    $note = ("  (old-MCP section removed: {0} -> {1} chars)" -f $before, $t.Length)
  }
  Write-Output ("  skill  {0,-28} {1} chars{2}" -f $s, $t.Length, $note)
  if (-not $WhatIf) { [System.IO.File]::WriteAllBytes($dst, $utf8.GetBytes($t)) }
}

# ---------------------------------------------------------------- 2) tools (REPLACE, not merge)
# ★ The target's *.ps1 are wiped first: a plain "copy over" leaves whatever the PREVIOUS package build
#   put there (measured: enc-probe/hub-client/wake survived from the 08:40 build because the copy loop
#   only skips them -- it never deletes). Non-.ps1 files (docs) are left alone.
$dstTools = Join-Path $Pkg 'tools'
if (-not $WhatIf) { [void](New-Item -ItemType Directory -Force -Path $dstTools) }
$removed = New-Object System.Collections.ArrayList
foreach ($old in (Get-ChildItem "$dstTools\*.ps1" -ErrorAction SilentlyContinue)) {
  [void]$removed.Add($old.Name)
  if (-not $WhatIf) { Remove-Item $old.FullName -Force }
}
foreach ($pat in $stalePatterns) {
  $p = Join-Path $dstTools $pat
  if (Test-Path $p) { [void]$removed.Add($pat); if (-not $WhatIf) { Remove-Item $p -Force } }
}
$copied = 0; $fixed = 0
foreach ($f in (Get-ChildItem "$ToolsDir\*.ps1" | Sort-Object Name)) {
  if ($dropTools -contains $f.Name) { continue }
  $dst = Join-Path $dstTools $f.Name
  if (-not $WhatIf) {
    [System.IO.File]::WriteAllBytes($dst, [System.IO.File]::ReadAllBytes($f.FullName))
    if (Convert-ToPortable $dst) { $fixed++ }
  }
  $copied++
}

# ---------------------------------------------------------------- 3) the thin AutoShop MCP
$dstMcp = Join-Path (Join-Path $Pkg 'mcp') 'autoshop'
if (-not $WhatIf) { [void](New-Item -ItemType Directory -Force -Path $dstMcp) }
foreach ($n in 'server.mjs', 'mcp-invoke.ps1') {
  $src = Join-Path $McpDir $n
  if (-not (Test-Path $src)) { throw ('missing ' + $src) }
  if (-not $WhatIf) { [System.IO.File]::WriteAllBytes((Join-Path $dstMcp $n), [System.IO.File]::ReadAllBytes($src)) }
}
if (-not $WhatIf) {
  # default tools dir for THIS layout: <Pkg>\mcp\autoshop\ -> <Pkg>\tools
  $sp = Join-Path $dstMcp 'server.mjs'
  $t = [System.IO.File]::ReadAllText($sp, $utf8)
  $t = $t.Replace("process.env.AUTOSHOP_TOOLS_DIR || join(HERE, '..', 'tools')",
                  "process.env.AUTOSHOP_TOOLS_DIR || join(HERE, '..', '..', 'tools')")
  [System.IO.File]::WriteAllBytes($sp, $utf8.GetBytes($t))
}

# ---------------------------------------------------------------- 4) rules doc = current AGENTS.md
# NOTE: the file name is built from char codes on purpose -- a Chinese literal here would be read as ANSI
# out of this BOM-less .ps1 and would create a file with a MOJIBAKE name next to the real one (measured).
$rulesName = 'AGENTS-AutoShop' + [string][char]0x89C4 + [string][char]0x5219 + '.md'
if (Test-Path $AgentsMd) {
  Write-Output ('  rules  ' + $rulesName + '  <- ' + $AgentsMd)
  if (-not $WhatIf) {
    [System.IO.File]::WriteAllBytes((Join-Path $Pkg $rulesName), [System.IO.File]::ReadAllBytes($AgentsMd))
  }
}

Write-Output ''
Write-Output ("skills synced: {0}   tools copied: {1} (portable-fixed {2})   stale removed: {3}" -f $skills.Count, $copied, $fixed, $removed.Count)
if ($removed.Count -gt 0) { Write-Output ('  removed: ' + ($removed -join ', ')) }
