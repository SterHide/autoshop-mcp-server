# rctx.ps1 - Real mouse right-click on AutoShop tree node (replaces broken Shift+F10).
#
# WHY: In headless/remote sessions, Shift+F10 synthetic right-click is REFUSED by MFC's
# self-drawn menu (GetForegroundWindow()=0 scenario). The fix is a REAL mouse_event
# RIGHTDOWN/UP at the node's rect center, which MFC accepts.
#
# Atomic sequence: focus+topmost -> MSAA select node -> real mouse right-click -> wait for
# Afx menu popup -> click menu item at (offsetX, offsetY) -> capture dialog if any.
#
# KEEP PURE ASCII. Chinese node names arrive via -Node parameter.
param(
  [Parameter(Mandatory=$true)][string]$Node,
  [int]$OffsetX = 70,
  [int]$OffsetY = 18,
  [int]$ExpectedMenuW = 0,
  [int]$ExpectedMenuH = 0,
  [string]$CaptureOut = '',
  [string]$MainShotOut = '',
  [int]$NodeY = -1
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('R.U' -as [type])) {
Add-Type -Namespace R -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint flags);
[DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
[DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

$LD = 0x02; $LU = 0x04; $RD = 0x0008; $RU = 0x0010
$HWND_TOPMOST = [IntPtr](-1); $HWND_NOTOPMOST = [IntPtr](-2)
$SWP_NOMOVE = 0x0002; $SWP_NOSIZE = 0x0001; $SWP_SHOWWINDOW = 0x0040

function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][R.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function TxtOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 512;[void][R.U]::GetWindowTextW($h,$b,512);$b.ToString()}
function RectOf([IntPtr]$h){$r=New-Object R.U+RECT;[void][R.U]::GetWindowRect($h,[ref]$r);return $r}
function SavePng([IntPtr]$hwnd,[int]$w,[int]$h,[string]$path){
  Add-Type -AssemblyName System.Drawing
  $hs=[R.U]::GetDC([IntPtr]::Zero);$hm=[R.U]::CreateCompatibleDC($hs);$hb=[R.U]::CreateCompatibleBitmap($hs,$w,$h)
  $ho=[R.U]::SelectObject($hm,$hb);$ok=[R.U]::PrintWindow($hwnd,$hm,2);if(-not $ok){$ok=[R.U]::PrintWindow($hwnd,$hm,0)}
  $img=[System.Drawing.Image]::FromHbitmap($hb);$img.Save($path,[System.Drawing.Imaging.ImageFormat]::Png);$img.Dispose()
  [void][R.U]::SelectObject($hm,$ho);[void][R.U]::DeleteObject($hb);[void][R.U]::DeleteDC($hm);[void][R.U]::ReleaseDC([IntPtr]::Zero,$hs)
}
function ClickRaw([int]$x,[int]$y){
  [void][R.U]::SetCursorPos($x,$y);Start-Sleep -Milliseconds 150
  [R.U]::mouse_event($LD,0,0,0,0);Start-Sleep -Milliseconds 80
  [R.U]::mouse_event($LU,0,0,0,0)
}
function RightClickRaw([int]$x,[int]$y){
  [void][R.U]::SetCursorPos($x,$y);Start-Sleep -Milliseconds 200
  [R.U]::mouse_event($RD,0,0,0,0);Start-Sleep -Milliseconds 100
  [R.U]::mouse_event($RU,0,0,0,0)
}

# --- 1. Locate AutoShop main window and force it to foreground + topmost ----------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
Write-Output ("main hwnd={0}  pid={1}  title='{2}'" -f $main, $proc.Id, (TxtOf $main))

# ShowWindow SW_RESTORE
if ([R.U]::IsIconic($main)) { [void][R.U]::ShowWindow($main, 9); Start-Sleep -Milliseconds 300 }
# BringWindowToTop + SetForegroundWindow + HWND_TOPMOST
$fg = [R.U]::GetForegroundWindow()
$fgThread = [R.U]::GetWindowThreadProcessId($fg, [IntPtr]::Zero)
$myThread = [R.U]::GetCurrentThreadId()
$attached = $false
if ($fgThread -ne 0 -and $fgThread -ne $myThread) { $attached = [R.U]::AttachThreadInput($myThread, $fgThread, $true) }
[void][R.U]::SetWindowPos($main, [IntPtr]::Zero, 0, 0, 0, 0, 0x0003)
[void][R.U]::SetForegroundWindow($main)
[void][R.U]::SetWindowPos($main, $HWND_TOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_SHOWWINDOW))
[void][R.U]::BringWindowToTop($main)
if ($attached) { [R.U]::AttachThreadInput($myThread, $fgThread, $false) }
Start-Sleep -Milliseconds 500

# Poll for foreground (up to 20 x 150ms)
$fgOk = $false
for ($i = 1; $i -le 20; $i++) {
  if ([R.U]::GetForegroundWindow() -eq $main) { $fgOk = $true; break }
  Start-Sleep -Milliseconds 150
}
if (-not $fgOk) {
  Write-Output 'FAIL: AutoShop never became foreground - aborting (clicks would go nowhere)'
  exit 1
}
Write-Output 'ok: AutoShop is foreground + topmost'

# Park cursor off the toolbar
[void][R.U]::SetCursorPos(10, 10); Start-Sleep -Milliseconds 300

# --- 2. Find the project tree ----------------------------------------------------------------
$trees = New-Object System.Collections.ArrayList
$cb = [R.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq 'SysTreeView32' -and [R.U]::IsWindowVisible($h)){[void]$trees.Add($h)};return $true }
[void][R.U]::EnumChildWindows($main,$cb,[IntPtr]::Zero)
if ($trees.Count -eq 0) { throw 'no visible SysTreeView32' }
$tree = $trees | Sort-Object { (RectOf $_).Left } | Select-Object -First 1
$treeRect = RectOf $tree
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $tree, $treeRect.Left, $treeRect.Top, ($treeRect.Right-$treeRect.Left), ($treeRect.Bottom-$treeRect.Top))

# --- 3. MSAA: select node by name -------------------------------------------------------------
$iid=[guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:accObj=$null
[void][R.U]::AccessibleObjectFromWindow($tree,[uint32]4294967292,[ref]$iid,[ref]$script:accObj)
$count = [int]$script:accObj.accChildCount
$maxId = $count + 3000

# Sweep for the target name
$targetId = -1; $targetName = ''
for ($i=1; $i -le $maxId; $i++) {
  $n = ''
  try { $n = [string]$script:accObj.accName($i) } catch { continue }
  if ($n -eq $Node) { $targetId = $i; $targetName = $n; break }
}
if ($targetId -lt 0) { throw ("node not found: '{0}'" -f $Node) }
Write-Output ("target: id={0} '{1}'" -f $targetId, $targetName)

# accSelect
for ($try=1; $try -le 3; $try++) {
  try { $script:accObj.accSelect(3, [int]$targetId) } catch { Write-Output ("  accSelect try {0} threw" -f $try) }
  Start-Sleep -Milliseconds 350
  $selId = -1; try { $selId = [int]$script:accObj.accSelection } catch {}
  $selName = ''; try { $selName = [string]$script:accObj.accName([int]$selId) } catch {}
  Write-Output ("  try {0}: selection = {1}|{2}" -f $try, $selId, $selName)
  if ($selId -eq $targetId) { break }
}
if ([int]$script:accObj.accSelection -ne $targetId) { throw ("could not select '{0}'" -f $Node) }

# Get the node's rect: use tree center X (the selected node is always visible after accSelect)
# and either the -NodeY override or a middle-of-tree Y fallback
$nodeX = [int](($treeRect.Left + $treeRect.Right) / 2)
if ($NodeY -ge 0) {
  $nodeY = $NodeY
} else {
  $nodeY = [int]($treeRect.Top + ($treeRect.Bottom - $treeRect.Top) * 0.4)
}

Write-Output ("right-click at ({0},{1})" -f $nodeX, $nodeY)

# --- 4. Real mouse right-click -----------------------------------------------------------------
# Record top-level windows before
$beforeWins = New-Object System.Collections.ArrayList
$cbTop = [R.U+EnumProc]{ param($h,$p) if([R.U]::IsWindowVisible($h)){[void]$beforeWins.Add($h)};return $true }
[void][R.U]::EnumWindows($cbTop,[IntPtr]::Zero)
$beforeIds = @($beforeWins)

RightClickRaw $nodeX $nodeY
Start-Sleep -Milliseconds 1500

# --- 5. Detect the Afx menu popup (broad: any new top-level window, not just Afx:*) --------------
$menuHwnd = [IntPtr]::Zero
$menuRect = $null
for ($i = 1; $i -le 6; $i++) {
  $newWins = New-Object System.Collections.ArrayList
  $cbNew = [R.U+EnumProc]{ param($h,$p)
    if([R.U]::IsWindowVisible($h) -and $beforeIds -notcontains $h) {
      $cls = ClsOf $h
      $r = RectOf $h
      $w = $r.Right - $r.Left
      $ht = $r.Bottom - $r.Top
      # Small window (< 600x400), not the main window, not a tooltip
      if ($w -lt 600 -and $ht -lt 400 -and $w -gt 50 -and $ht -gt 20 -and $cls -ne 'tooltips_class32' -and $cls -notlike 'SysShadow*') {
        [void]$newWins.Add([pscustomobject]@{Hwnd=$h;Cls=$cls;X=$r.Left;Y=$r.Top;W=$w;H=$ht;Text=(TxtOf $h)})
      }
    }
    return $true
  }
  [void][R.U]::EnumWindows($cbNew,[IntPtr]::Zero)
  if ($newWins.Count -gt 0) {
    # Pick the one most likely to be a context menu (Afx:* class preferred)
    $menu = $newWins | Where-Object { $_.Cls -like 'Afx:*' } | Select-Object -First 1
    if ($null -eq $menu) { $menu = $newWins[0] }
    $menuHwnd = $menu.Hwnd
    $menuRect = [pscustomobject]@{X=$menu.X;Y=$menu.Y;W=$menu.W;H=$menu.H}
    break
  }
  Start-Sleep -Milliseconds 500
}

# Diagnostics: list ALL new windows seen
Write-Output '--- all new windows after right-click (diagnostic) ---'
$diagWins = New-Object System.Collections.ArrayList
$cbDiag = [R.U+EnumProc]{ param($h,$p)
  if([R.U]::IsWindowVisible($h) -and $beforeIds -notcontains $h) {
    $cls = ClsOf $h; $r = RectOf $h; $t = TxtOf $h
    [void]$diagWins.Add([pscustomobject]@{Hwnd=$h;Cls=$cls;X=$r.Left;Y=$r.Top;W=($r.Right-$r.Left);H=($r.Bottom-$r.Top);Text=$t})
  }
  return $true
}
[void][R.U]::EnumWindows($cbDiag,[IntPtr]::Zero)
foreach ($w in $diagWins) {
  Write-Output ("  class='{0}' {1}x{2} at {3},{4} text='{5}'" -f $w.Cls,$w.W,$w.H,$w.X,$w.Y,$w.Text)
}

if ($menuHwnd -eq [IntPtr]::Zero) {
  Write-Output 'FAIL: no Afx menu popup detected after right-click'
  # Park cursor
  [void][R.U]::SetCursorPos(10, 10)
  # Restore topmost
  [void][R.U]::SetWindowPos($main, $HWND_NOTOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE))
  exit 1
}

Write-Output ("menu: {0}x{1} at {2},{3}" -f $menuRect.W, $menuRect.H, $menuRect.X, $menuRect.Y)

# Optional: capture menu
if ($CaptureOut) { SavePng $menuHwnd $menuRect.W $menuRect.H $CaptureOut; Write-Output ("  captured -> {0}" -f $CaptureOut) }

# --- 6. Click menu item at offset ----------------------------------------------------------------
$clickX = $menuRect.X + $OffsetX
$clickY = $menuRect.Y + $OffsetY
Write-Output ("clicking menu item at ({0},{1}) [offset +{2},+{3}]" -f $clickX, $clickY, $OffsetX, $OffsetY)
ClickRaw $clickX $clickY
Start-Sleep -Milliseconds 1800

# --- 7. Report dialogs and new windows -----------------------------------------------------------
Write-Output '--- windows after click ---'
$afterWins = New-Object System.Collections.ArrayList
$cbAfter = [R.U+EnumProc]{ param($h,$p) if([R.U]::IsWindowVisible($h)){[void]$afterWins.Add($h)};return $true }
[void][R.U]::EnumWindows($cbAfter,[IntPtr]::Zero)
foreach ($h in @($afterWins | Where-Object { $beforeIds -notcontains $_ })) {
  $cls = ClsOf $h; $t = TxtOf $h; $r = RectOf $h
  Write-Output ("  '{0}' {1}x{2} at {3},{4} class='{5}'" -f $t, ($r.Right-$r.Left), ($r.Bottom-$r.Top), $r.Left, $r.Top, $cls)
}

# Dialogs specifically
$dlgs = New-Object System.Collections.ArrayList
$cbDlg = [R.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq '#32770' -and [R.U]::IsWindowVisible($h)){[void]$dlgs.Add($h)};return $true }
[void][R.U]::EnumWindows($cbDlg,[IntPtr]::Zero)
foreach ($d in $dlgs) {
  $dr = RectOf $d
  Write-Output ("  DIALOG '{0}' {{ {1},{2} {3}x{4} }}" -f (TxtOf $d), $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))
  $kids=New-Object System.Collections.ArrayList
  $cb10=[R.U+EnumProc]{ param($h,$p3) if([R.U]::IsWindowVisible($h)){[void]$kids.Add($h)};return $true }
  [void][R.U]::EnumChildWindows($d,$cb10,[IntPtr]::Zero)
  foreach ($k in $kids) { $kt=TxtOf $k; if($kt){ $kr=RectOf $k; Write-Output ("      {0,-20} '{{ {1},{2} {3}x{4} }}' text='{5}'" -f (ClsOf $k), $kr.Left,$kr.Top,($kr.Right-$kr.Left),($kr.Bottom-$kr.Top),$kt) } }
}

# --- 8. Cleanup: park cursor + restore topmost ----------------------------------------------------
[void][R.U]::SetCursorPos(10, 10)
[void][R.U]::SetWindowPos($main, $HWND_NOTOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE))
if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }

if ($MainShotOut) { $mr=RectOf $main; SavePng $main ($mr.Right-$mr.Left) ($mr.Bottom-$mr.Top) $MainShotOut; Write-Output ("  main captured -> {0}" -f $MainShotOut) }

Write-Output 'DONE'
