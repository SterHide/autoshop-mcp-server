# Write ST source back INTO an AutoShop block editor -- the reverse of the read path.
#
# ★ 2026-09-19 MEASURED FACTS (this is what actually works on AutoShop V4.11.0.5 / LiteST):
#   * the block view must be OPEN first; its caption may carry a modification marker, i.e.
#     'SBR_UN_14_真空吸 *' -- so match the title with -like, not -eq.
#   * **UIA ValuePattern is NOT supported** by this Scintilla (TryGetCurrentPattern -> False), so the
#     two UIA channels below only exist as a formality; they throw on a null pattern.
#   * **WM_SETTEXT with the RAW form WORKS** (verified: 1379-char Chinese body written, read back
#     identical, saved, and identical again after closing + reopening the block from disk).
#   * the raw form is: take the intended UTF-8 bytes and pair them into UTF-16 code units. That is
#     what the control stores, and what a WM_GETTEXT read-back returns, so the read decoder is the
#     inverse: expand every char into 2 LE bytes, then decode that run as UTF-8 -- and this must be
#     applied to MULTI-BYTE content too (the old "if any char > 0xFF then it is already text" guard
#     was wrong: a Chinese byte pair such as U+9CE7 is > 0xFF and got misjudged as plain text).
#   * AutoShop stores the block body inside a BINARY/packed .ST container -- the saved file does NOT
#     contain the text as plain ASCII/GBK/UTF-16, so "can I grep my code out of the .ST file" is
#     NOT a valid verification. The valid check is: save, close the view, reopen the block, read it.
#
# Channels tried, in order:
#   1. WM_SETTEXT with the raw form   -- measured working, no mouse, no focus needed
#   2. WM_SETTEXT plain
#   3. UIA ValuePattern (raw then plain) -- kept for other builds where the provider supports it
#
# SAFETY: this script does NOT save. Closing the view without saving discards the change.
#
# KEEP PURE ASCII (the text to write arrives via a parameter or a file).
param(
  [Parameter(Mandatory=$true)][string]$Block,
  [Parameter(Mandatory=$true)][string]$TextFile,   # UTF-8 file holding the full new body
  [ValidateSet('Try','WmRaw','WmPlain','UiaRaw','UiaPlain')][string]$Channel = 'Try',
  [int]$OpenWaitMs = 900
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageStr(IntPtr h, uint msg, IntPtr w, string l);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageSb(IntPtr h, uint msg, IntPtr w, System.Text.StringBuilder l);
[DllImport("user32.dll", EntryPoint="SendMessageW")] public static extern IntPtr SendMessageInt(IntPtr h, uint msg, IntPtr w, IntPtr l);
'@
}
$WM_SETTEXT = 0x000C
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetWindowTextW($h, $sb, 256); $sb.ToString() }

# --- encodings ---------------------------------------------------------------------------------
# raw form: UTF-8 bytes paired into UTF-16 code units (what the provider reads back)
function To-RawForm([string]$text) {
  $b = [System.Text.Encoding]::UTF8.GetBytes($text)
  $sb = New-Object System.Text.StringBuilder
  for ($i = 0; $i -lt $b.Length; $i += 2) {
    $lo = [int]$b[$i]
    $hi = if ($i + 1 -lt $b.Length) { [int]$b[$i + 1] } else { 0 }
    [void]$sb.Append([char]($lo -bor ($hi -shl 8)))
  }
  return $sb.ToString()
}
# inverse: raw form -> proper text (same rule as the read path).
# NOTE: this must run for MULTI-BYTE content too -- the old guard "if any char is > 0xFF assume it is
# already plain text" wrongly returned the mojibake for any Chinese body (a byte pair like U+9CE7 is
# > 0xFF), which made every verification fail while the write had actually succeeded.
function From-RawForm([string]$raw) {
  if ([string]::IsNullOrEmpty($raw)) { return $raw }
  $bytes = New-Object byte[] ($raw.Length * 2)
  for ($i = 0; $i -lt $raw.Length; $i++) {
    $u = [int][char]$raw[$i]
    $bytes[2*$i] = [byte]($u -band 0xFF); $bytes[2*$i+1] = [byte](($u -shr 8) -band 0xFF)
  }
  $n = 0; while ($n -lt $bytes.Length -and $bytes[$n] -ne 0) { $n++ }
  try { return (New-Object System.Text.UTF8Encoding($false,$true)).GetString($bytes, 0, $n) } catch { return $raw }
}

# --- locate the block view ---------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
[void][W.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 400

# the caption of a MODIFIED block carries a trailing ' *' -> match with -like, not -eq
$mc = [IntPtr]::Zero
$cb = [W.U+EnumProc]{ param($h,$p) $t=(TxtOf $h).TrimEnd(' ','*'); if ($t -eq $Block) { $script:mcHit = $h; return $false }; return $true }
[void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
$mc = $script:mcHit
if ($null -eq $mc -or $mc -eq [IntPtr]::Zero) { throw ("no open block view titled '{0}'" -f $Block) }
$sc = [IntPtr]::Zero
$cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Scintilla') { $script:scHit = $h; return $false }; return $true }
[void][W.U]::EnumChildWindows($mc, $cb2, [IntPtr]::Zero)
$sc = $script:scHit
if ($null -eq $sc -or $sc -eq [IntPtr]::Zero) { throw 'no Scintilla control inside the block view' }
Write-Output ("block='{0}'  view hwnd={1}  Scintilla hwnd={2}" -f $Block, $mc, $sc)

# --- read the current text ---------------------------------------------------------------------
# The UIA element is ONLY needed by the UiaRaw/UiaPlain channels, and this build does not support
# ValuePattern at all -- so a UIA miss must NOT abort the run.
# ★ 2026-09-20 measured: in an FB view (FB04_TON) the descent frame -> block -> Scintilla came back
#   EMPTY while the Win32 child (found by class name) was perfectly good, and the old `throw` killed a
#   write channel that would have worked. Only the Win32 handle is required.
$edit = $null
try {
  $AE = [System.Windows.Automation.AutomationElement]
  $root = $AE::FromHandle($main)
  $AEc = $AE
  $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
    (New-Object System.Windows.Automation.PropertyCondition($AEc::NameProperty, $Block)))
  if ($null -ne $child) {
    $edit = $child.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
      (New-Object System.Windows.Automation.PropertyCondition($AEc::ClassNameProperty, 'Scintilla')))
  }
} catch { Write-Output ("  UIA lookup threw (non-fatal): {0}" -f $_.Exception.Message) }
if ($null -eq $edit) {
  Write-Output '  UIA could not reach the block Scintilla - the two UIA channels will be skipped (they are unusable on this build anyway).'
}
$vp = $null
$vpOk = $false
if ($null -ne $edit) { try { $vpOk = $edit.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp) } catch { $vpOk = $false } }
Write-Output ("UIA element found = {0};  ValuePattern supported = {1}  (measured: NOT supported on V4.11.0.5; WM_SETTEXT is the working channel)" -f ($null -ne $edit), $vpOk)
function ReadNow {
  # Win32 WM_GETTEXT is the read channel that always works; UIA ValuePattern is only a bonus.
  $len = [int][W.U]::SendMessageInt($sc, 0x000E, [IntPtr]::Zero, [IntPtr]::Zero)
  $cap = [Math]::Max(256, $len + 512)
  $sb = New-Object System.Text.StringBuilder $cap
  [void][W.U]::SendMessageSb($sc, 0x000D, [IntPtr]$cap, $sb)
  return (From-RawForm $sb.ToString())
}
$before = ReadNow
Write-Output ("--- BEFORE ({0} chars) ---" -f $before.Length)
Write-Output $before

$want = [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8)
# normalise line endings for comparison (ST files use CRLF; Scintilla may report either)
function Norm([string]$t) { return ($t -replace "`r`n","`n").TrimEnd("`n","`r"," ","`t") }
$wantN = Norm $want

# --- try the channels --------------------------------------------------------------------------
$channels = if ($Channel -eq 'Try') { @('WmRaw','WmPlain','UiaRaw','UiaPlain') } else { @($Channel) }
foreach ($ch in $channels) {
  Write-Output ''
  Write-Output ("=== channel {0} ===" -f $ch)
  try {
    switch ($ch) {
      'WmRaw'     { [void][W.U]::SendMessageStr($sc, $WM_SETTEXT, [IntPtr]::Zero, (To-RawForm $want)) }
      'WmPlain'   { [void][W.U]::SendMessageStr($sc, $WM_SETTEXT, [IntPtr]::Zero, $want) }
      'UiaRaw'    { if ($vpOk) { ([System.Windows.Automation.ValuePattern]$vp).SetValue((To-RawForm $want)) } else { throw 'this build does not support UIA ValuePattern' } }
      'UiaPlain'  { if ($vpOk) { ([System.Windows.Automation.ValuePattern]$vp).SetValue($want) } else { throw 'this build does not support UIA ValuePattern' } }
    }
    Start-Sleep -Milliseconds 700
    $after = ReadNow
    $match = ((Norm $after) -eq $wantN)
    Write-Output ("  read-back {0} chars   MATCHES={1}" -f $after.Length, $match)
    if ($match) {
      Write-Output ("  *** CHANNEL '{0}' WORKS (verified by read-back) ***" -f $ch)
      Write-Output ("  (the block is now MODIFIED; closing WITHOUT saving discards it)")
      exit 0
    } else {
      if ($after.Length -gt 0) { Write-Output ("  first 60 chars: {0}" -f $after.Substring(0, [Math]::Min(60, $after.Length))) }
    }
  } catch { Write-Output ("  channel threw: {0}" -f $_.Exception.Message) }
}
Write-Output ''
Write-Output 'NO CHANNEL VERIFIED'
exit 1
