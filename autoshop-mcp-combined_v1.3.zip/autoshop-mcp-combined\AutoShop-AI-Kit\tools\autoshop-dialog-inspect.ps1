# Inspect a modal dialog: full recursive child tree + WHICH control currently holds the keyboard focus.
#
# Why focus matters: the proven way to drive the "save as" dialog is to rely on its filename field
# already having focus, type the full target path and press Enter -- that avoids depending on the
# dialog's geometry (its height changes between 600 and 209 px). But that only works if an Edit
# really does have focus, so read it instead of assuming.
#
# KEEP PURE ASCII.
param(
  [string]$TitleLike = '',       # substring of the dialog caption; empty = any visible #32770
  [int]$MaxLevels = 6
)

$ErrorActionPreference = 'Stop'
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint tid, ref GUITHREADINFO gti);
[StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
[StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
  public uint cbSize; public uint flags; public IntPtr hwndActive; public IntPtr hwndFocus;
  public IntPtr hwndCapture; public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret;
  public RECT rcCaret; }
'@
}
$GW_CHILD = 5; $GW_HWNDNEXT = 2

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }

function Dump([IntPtr]$h, [int]$level) {
  $r = RectOf $h
  $vis = if ([W.U]::IsWindowVisible($h)) { '' } else { ' HIDDEN' }
  Write-Output ("{0}hwnd={1,-8} {2,-24} rect={{ {3},{4} {5}x{6} }}{7} text='{8}'" -f `
    ('  ' * $level), $h, (ClsOf $h), $r.Left, $r.Top, ($r.Right-$r.Left), ($r.Bottom-$r.Top), $vis, (TxtOf $h))
  if ($level -ge $MaxLevels) { return }
  $k = [W.U]::GetWindow($h, $GW_CHILD)
  while ($k -ne [IntPtr]::Zero) { Dump $k ($level + 1); $k = [W.U]::GetWindow($k, $GW_HWNDNEXT) }
}

# --- find the dialog -------------------------------------------------------------------------
$dlgs = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) {
    if (-not $TitleLike -or (TxtOf $h) -like "*$TitleLike*") { [void]$dlgs.Add($h) }
  }
  return $true }
[void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
Write-Output ("visible dialogs matching '*{0}*': {1}" -f $TitleLike, $dlgs.Count)
if ($dlgs.Count -eq 0) { Write-Output 'nothing to inspect.'; exit 0 }

$procId = (Get-Process -Name AutoShop  | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1).Id
foreach ($d in $dlgs) {
  $dr = RectOf $d
  Write-Output ''
  Write-Output ("=== dialog hwnd={0} '{1}' rect={{ {2},{3} {4}x{5} }} ===" -f $d, (TxtOf $d), $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))
  Dump $d 0

  # --- focused control -----------------------------------------------------------------
  # GetGUIThreadInfo reports the focus of a GUI thread even across processes, which GetFocus cannot.
  $tid = [W.U]::GetWindowThreadProcessId($d, [IntPtr]::Zero)
  $gti = New-Object W.U+GUITHREADINFO
  $gti.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($gti)
  $ok = [W.U]::GetGUIThreadInfo($tid, [ref]$gti)
  Write-Output ''
  Write-Output ("  thread {0}: GetGUIThreadInfo ok={1}" -f $tid, $ok)
  if ($ok) {
    $fh = $gti.hwndFocus
    if ($fh -eq [IntPtr]::Zero) { Write-Output '  hwndFocus = (none)' }
    else {
      $fr = RectOf $fh
      Write-Output ("  hwndFocus  = {0}  class='{1}'  rect={{ {2},{3} {4}x{5} }}  text='{6}'" -f $fh, (ClsOf $fh), $fr.Left, $fr.Top, ($fr.Right-$fr.Left), ($fr.Bottom-$fr.Top), (TxtOf $fh))
    }
    Write-Output ("  hwndActive = {0}  class='{1}'" -f $gti.hwndActive, (ClsOf $gti.hwndActive))
  }
}

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }