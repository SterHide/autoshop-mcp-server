# Dump the window / UIA structure around a target window inside AutoShop.
# Used for UI discovery: find the pane, list control or button that a task needs, instead of
# guessing coordinates. Menus and toolbars are often missing from UIA, so both views are printed:
#   * Win32 child-window tree (class + rect + caption)  -> always complete
#   * UIA descendants (ControlType + ClassName + Name + AutomationId) -> gives the semantic handles
#
# KEEP PURE ASCII. Chinese comes in via parameters.
param(
  [string]$TitleLike = '',      # substring of a window caption to target
  [int]$MaxLevels = 4,
  [switch]$Uia,
  [switch]$MainFrame            # target the AutoShop main frame instead of a title match
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationTypes
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
# GW_CHILD = 5, GW_HWNDNEXT = 2. Enumerating with GetWindow (not EnumChildWindows, which is
# recursive and would re-print every descendant at every level) keeps the tree readable.
$GW_CHILD = 5; $GW_HWNDNEXT = 2
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }

function DumpWin([IntPtr]$h, [int]$level, [int]$maxLevels) {
  $r = RectOf $h
  $vis = if ([W.U]::IsWindowVisible($h)) { '' } else { ' HIDDEN' }
  Write-Output ("{0}hwnd={1,-8} {2,-26} rect={{ {3},{4} {5}x{6} }}{7} text='{8}'" -f `
    ('  ' * $level), $h, (ClsOf $h), $r.Left, $r.Top, ($r.Right-$r.Left), ($r.Bottom-$r.Top), $vis, (TxtOf $h))
  if ($level -ge $maxLevels) { return }
  $k = [W.U]::GetWindow($h, $GW_CHILD)
  while ($k -ne [IntPtr]::Zero) {
    DumpWin $k ($level + 1) $maxLevels
    $k = [W.U]::GetWindow($k, $GW_HWNDNEXT)
  }
}

# --- locate the target ----------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
$target = $main
if (-not $MainFrame) {
  if (-not $TitleLike) { throw 'pass -TitleLike or -MainFrame' }
  $found = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((TxtOf $h) -like "*$TitleLike*") { $script:found = $h; return $false }
    return $true }
  [void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
  $found = $script:found
  if ($null -eq $found -or $found -eq [IntPtr]::Zero) { throw ("no window matching '*" + $TitleLike + "*' under the AutoShop frame") }
  $target = $found
}
Write-Output ("target hwnd={0} class='{1}' text='{2}'" -f $target, (ClsOf $target), (TxtOf $target))
$tr = RectOf $target
Write-Output ("  rect={{ {0},{1} {2}x{3} }}" -f $tr.Left, $tr.Top, ($tr.Right-$tr.Left), ($tr.Bottom-$tr.Top))
Write-Output ''
Write-Output '=== Win32 descendant windows ==='
DumpWin $target 0 $MaxLevels

if ($Uia) {
  Write-Output ''
  Write-Output '=== UIA descendants ==='
  $root = [System.Windows.Automation.AutomationElement]::FromHandle($target)
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
  Write-Output ("count = {0}" -f $all.Count)
  $i = 0
  foreach ($e in $all) {
    $i++
    if ($i -gt 120) { Write-Output '  ... (truncated)'; break }
    $r = $e.Current.BoundingRectangle
    Write-Output ("  {0,-24} class='{1,-22}' id='{2,-8}' rect={3},{4},{5},{6} name='{7}'" -f `
      $e.Current.ControlType.ProgrammaticName, $e.Current.ClassName, $e.Current.AutomationId, `
      [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height, $e.Current.Name)
  }
}

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }