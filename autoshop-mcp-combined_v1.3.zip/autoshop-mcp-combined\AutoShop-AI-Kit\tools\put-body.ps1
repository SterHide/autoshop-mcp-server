# put-body.ps1 -- write an ST body into an AutoShop block, save it for real, then VERIFY by read-back.
#
# WHY EVERY STEP RUNS IN ITS OWN CHILD PROCESS:
#   Several of these tools define .NET helper types with the SAME name -- autoshop-write-block.ps1 and
#   autoshop-extract-blocks2.ps1 both do `Add-Type -Namespace W -Name U`. Chaining them inside one
#   process therefore dies at the verification step with "The type name 'W.U' already exists", i.e.
#   exactly the step that proves the write landed. Isolating each tool in its own powershell.exe also
#   stops one tool's leftover state (tree focus, open menus) from leaking into the next.
#
# The read-back is the only acceptable proof: AutoShop stores a body inside a packed container, so
# "the file grew" is not evidence and neither is the editor's title.
#
# PURE ASCII. Chinese arrives via parameters / files.
param(
  [Parameter(Mandatory=$true)][string]$Block,
  [Parameter(Mandatory=$true)][string]$StFile,
  [string]$FbDir = 'FB',
  [string]$MdPath = ''      # proof file of the read-back; programs and FB/FC use different layouts
)
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'prelude.ps1')
$T    = $PSScriptRoot
$ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Run-Tool([string]$script, [string[]]$toolArgs) {
  & $ps51 -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $T $script) @toolArgs 2>&1
}

# 1) UTF-8 without BOM (the write channel pairs UTF-8 bytes into UTF-16 code units)
$txt   = [System.IO.File]::ReadAllText($StFile, [System.Text.Encoding]::UTF8)
$plain = Join-Path $env:TEMP ($Block + '.nobom.st')
[System.IO.File]::WriteAllBytes($plain, (New-Object System.Text.UTF8Encoding($false)).GetBytes($txt))
Write-Output ('body: ' + $txt.Length + ' chars -> ' + $plain)

[void](Focus-AutoShopMain)

Write-Output '--- 1) open the block view ---'
Run-Tool 'autoshop-open-node.ps1' @('-Node', $Block) | ForEach-Object { Write-Output ('  ' + $_) }

Write-Output '--- 2) write the body ---'
Run-Tool 'autoshop-write-block.ps1' @('-Block', $Block, '-TextFile', $plain) |
  ForEach-Object { if ($_ -match 'channel|MATCHES|WORKS|FAIL|read-back') { Write-Output ('  ' + $_) } }

Write-Output '--- 3) save ---'
Park-Cursor
[void](Focus-AutoShopMain)
$r = Save-AutoShop
Write-Output ('  before: ' + $r.Before)
Write-Output ('  after : ' + $r.After)

Write-Output '--- 4) close every view so the next read comes from disk ---'
Run-Tool 'autoshop-close-all-blocks.ps1' @() | ForEach-Object { Write-Output ('  ' + $_) }
Start-Sleep -Milliseconds 800

Write-Output '--- 5) read back and diff ---'
$vargs = @('-Block', $Block, '-StFile', $plain, '-FbDir', $FbDir)
if ($MdPath) { $vargs += @('-MdPath', $MdPath) }
Run-Tool 'verify-block.ps1' $vargs | ForEach-Object { Write-Output ('  ' + $_) }
