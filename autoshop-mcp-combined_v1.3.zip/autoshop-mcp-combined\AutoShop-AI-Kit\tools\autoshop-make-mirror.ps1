# Build the local mirror skeleton for an AutoShop project.
# Source of truth for the tree = folder.txt (AutoShop's own project index), NOT guesses.
# KEEP THIS FILE PURE ASCII (PowerShell 5.1 reads BOM-less files as ANSI).
#
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-make-mirror.ps1 `
#          -ProjectDir "C:\...\PLC" -MirrorDir "C:\Users\Administrator\Desktop\PLC_mirror"
param(
  [Parameter(Mandatory = $true)][string]$ProjectDir,
  [Parameter(Mandatory = $true)][string]$MirrorDir,
  # Folder names are passed in (Chinese names come from the command line, so this file stays ASCII)
  [string]$VarsDir = 'global_vars',
  [string]$StructsDir = 'structs',
  [string]$GlobalsDir = 'variables',
  [string]$ProgDir = 'program',
  [string]$FbDir = 'fb',
  [string]$FcDir = 'fc'
)

$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($false)

function Write-Utf8([string]$path, [string]$text) {
  $dir = Split-Path -Parent $path
  if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
  [System.IO.File]::WriteAllText($path, $text, $U8)
}

$folderTxt = Join-Path $ProjectDir 'folder.txt'
if (-not (Test-Path -LiteralPath $folderTxt)) { Write-Output "ABORT: no folder.txt in $ProjectDir"; exit 1 }
$lines = [System.IO.File]::ReadAllLines($folderTxt, [System.Text.Encoding]::UTF8)

# section roots
$sectionRoot = @{ 'PROG' = "$ProgDir\$ProgDir"; 'FB' = "$ProgDir\$FbDir"; 'FC' = "$ProgDir\$FcDir" }
$sectionKind = @{ 'PROG' = 'program'; 'FB' = 'function_block'; 'FC' = 'function' }
$madeDirs = New-Object System.Collections.ArrayList
$madeFiles = New-Object System.Collections.ArrayList
$section = $null
$stack = @{}   # depth -> folder name

function New-Dir([string]$rel) {
  $full = Join-Path $MirrorDir $rel
  if (-not (Test-Path -LiteralPath $full)) { [void](New-Item -ItemType Directory -Path $full -Force); [void]$script:madeDirs.Add($rel) }
  return $full
}

foreach ($raw in $lines) {
  if ([string]::IsNullOrWhiteSpace($raw)) { continue }
  $tabs = 0
  while ($tabs -lt $raw.Length -and $raw[$tabs] -eq "`t") { $tabs++ }
  $body = $raw.Substring($tabs).Trim()
  if ($body -eq '') { continue }

  if ($body -eq 'PROG' -or $body -eq 'FB' -or $body -eq 'FC') { $section = $body; $stack = @{}; continue }
  if ($body -eq 'ROOT') { $stack = @{ 0 = '' }; continue }
  if ($null -eq $section) { continue }

  if ($body -like 'FOLDER*') {
    $name = $body.Substring(6).Trim()
    $parentRel = $sectionRoot[$section]
    for ($d = 1; $d -lt $tabs; $d++) { if ($stack.ContainsKey($d) -and $stack[$d]) { $parentRel = Join-Path $parentRel $stack[$d] } }
    $stack[$tabs] = $name
    [void](New-Dir (Join-Path $parentRel $name))
    continue
  }

  if ($body -like 'FILE*') {
    $file = $body.Substring(4).Trim()
    $parentRel = $sectionRoot[$section]
    for ($d = 1; $d -lt $tabs; $d++) { if ($stack.ContainsKey($d) -and $stack[$d]) { $parentRel = Join-Path $parentRel $stack[$d] } }
    $base = [System.IO.Path]::GetFileNameWithoutExtension($file)
    $ext = [System.IO.Path]::GetExtension($file).TrimStart('.').ToUpper()
    $lang = if ($ext -eq 'LD') { 'LD' } elseif ($ext -eq 'ST') { 'ST' } elseif ($ext -eq 'FB') { 'FB' } elseif ($ext -eq 'FC') { 'FC' } else { 'UNKNOWN' }

    if ($section -eq 'FB' -or $section -eq 'FC') {
      # one folder per FB / FC, holding its md program + csv variables
      $self = New-Dir (Join-Path $parentRel $base)
      [void](Write-Utf8 (Join-Path $self "$base.md") @"
---
project: $(Split-Path -Leaf $ProjectDir)
kind: $($sectionKind[$section])
block: $base
language: $lang
source: $ProjectDir\$file
status: TODO
---

<!-- Program body not extracted yet. LD/FB/FC are proprietary binary containers;
     the body must be pulled from the AutoShop editor via the clipboard. -->
"@)
      [void](Write-Utf8 (Join-Path $self "$base.csv") "name,dataType,initialValue,comment`r`n")
      [void]$madeFiles.Add((Join-Path $self "$base.md"))
    } else {
      # NOTE: New-Dir returns the FULL path - must use it, a relative join would write outside the mirror
      $parentFull = New-Dir $parentRel
      $md = Join-Path $parentFull "$base.md"
      [void](Write-Utf8 $md @"
---
project: $(Split-Path -Leaf $ProjectDir)
kind: program
block: $base
language: $lang
source: $ProjectDir\$file
status: $(if ($lang -eq 'LD') { 'SKIPPED_LD' } else { 'TODO' })
---

<!-- $(if ($lang -eq 'LD') { 'Ladder block - intentionally not mirrored (decision: ST only).' } else { 'ST body not extracted yet - pull from the AutoShop ST editor via clipboard.' }) -->
"@)
      [void]$madeFiles.Add($md)
    }
  }
}

# --- global variables -------------------------------------------------------
[void](New-Dir "$VarsDir\$StructsDir")
[void](New-Dir "$VarsDir\$GlobalsDir")

# GVL_*.csv (AutoShop writes these on disk, UTF-16LE, tab separated) -> mirror csv
Get-ChildItem -LiteralPath $ProjectDir -File -Filter 'GVL_*.csv' -ErrorAction SilentlyContinue | ForEach-Object {
  $out = Join-Path (Join-Path $MirrorDir "$VarsDir\$GlobalsDir") $_.Name
  [System.IO.File]::Copy($_.FullName, $out, $true)
  [void]$madeFiles.Add($out)
}

# structs: one csv placeholder per .stru (contents are plaintext inside a binary container - TBD)
Get-ChildItem -LiteralPath $ProjectDir -File -Filter '*.stru' -ErrorAction SilentlyContinue | ForEach-Object {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($_.Name)
  $out = Join-Path (Join-Path $MirrorDir "$VarsDir\$StructsDir") "$base.csv"
  [void](Write-Utf8 $out "name,dataType,initialValue,comment`r`n")
  [void]$madeFiles.Add($out)
}

Write-Output ("mirror   : {0}" -f $MirrorDir)
Write-Output ("dirs     : {0}" -f $madeDirs.Count)
Write-Output ("files    : {0}" -f $madeFiles.Count)
