# Capture the AutoShop ST editor region from the real screen and save a zoomed PNG for inspection.
# Uses CopyFromScreen (not PrintWindow) because PrintWindow renders the Scintilla control blank.
# Sets DPI awareness first so the captured bitmap matches UIA/screen coordinates 1:1.
#
# Usage:  powershell -ExecutionPolicy Bypass -File shot-editor.ps1 [-Out <png>] [-Zoom 2]
param(
  [string]$Out = (Join-Path $env:TEMP 'autoshop-autoshop-editor-zoom.png'),
  [int]$Zoom = 2,
  [int]$X = 160, [int]$Y = 500, [int]$W = 830, [int]$H = 690
)

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
if (-not ('Dpi.Helper' -as [type])) {
Add-Type -Namespace Dpi -Name Helper -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
'@
}
[void][Dpi.Helper]::SetProcessDPIAware()

$bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
if ($null -eq $bounds) { $bounds = New-Object System.Drawing.Rectangle 0, 0, 1920, 1200 }
$full = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
$gFull = [System.Drawing.Graphics]::FromImage($full)
$gFull.CopyFromScreen($bounds.X, $bounds.Y, 0, 0, (New-Object System.Drawing.Size $bounds.Width, $bounds.Height))
$gFull.Dispose()

Write-Output "screen=$($bounds.Width)x$($bounds.Height)  crop=($X,$Y) ${W}x${H}  zoom=${Zoom}x"

# Clamp the crop to the captured image.
$cw = [Math]::Min($W, $full.Width - $X)
$ch = [Math]::Min($H, $full.Height - $Y)

$bmp = New-Object System.Drawing.Bitmap ($cw * $Zoom), ($ch * $Zoom)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($full,
  (New-Object System.Drawing.Rectangle 0, 0, ($cw * $Zoom), ($ch * $Zoom)),
  (New-Object System.Drawing.Rectangle $X, $Y, $cw, $ch),
  [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
$full.Dispose()
Write-Output "saved $Out  ($((Get-Item $Out).Length) bytes)"
