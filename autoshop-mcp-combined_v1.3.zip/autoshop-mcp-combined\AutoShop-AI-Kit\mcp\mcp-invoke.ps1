# One-shot runner used by the autoshop MCP server: read a JSON spec, call ONE tool script, print its output.
#
# WHY THIS EXISTS
#   * The MCP server must not build a PowerShell command line by hand: Chinese tool names and quoted
#     arguments would have to survive several layers of quoting, and a BOM-less .ps1 cannot carry
#     Chinese literals at all (PowerShell 5.1 reads it as ANSI -> mojibake; this silently broke the
#     import tool once). So ALL arguments travel in a UTF-8 JSON file, never on a command line.
#   * The child sets its OWN console encoding to UTF-8, so the MCP server can read clean text back.
#   * ONE script per process: several tools define the same .NET helper type (W.U) and the second one
#     would silently skip its own Add-Type and then fail on a missing method.
#
# This file is PURE ASCII on purpose.
param(
  [Parameter(Mandatory=$true)][string]$SpecFile,
  [Parameter(Mandatory=$true)][string]$ScriptDir
)
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

if (-not (Test-Path -LiteralPath $SpecFile)) { Write-Output ("ERROR: no spec file: " + $SpecFile); exit 2 }
$utf8 = New-Object System.Text.UTF8Encoding($false)
$spec = [System.IO.File]::ReadAllText($SpecFile, $utf8) | ConvertFrom-Json

$name = [string]$spec.script
if ([string]::IsNullOrWhiteSpace($name)) { Write-Output 'ERROR: spec has no "script"'; exit 2 }
$script = Join-Path $ScriptDir $name
if (-not (Test-Path -LiteralPath $script)) { Write-Output ("ERROR: no such script in " + $ScriptDir + " : " + $name); exit 2 }

$ht = @{}
if ($null -ne $spec.params) {
  foreach ($p in $spec.params.PSObject.Properties) {
    $v = $p.Value
    if ($null -eq $v) { continue }
    if ($v -is [bool]) { $ht[$p.Name] = [bool]$v }
    else { $ht[$p.Name] = [string]$v }
  }
}
Write-Output ("### " + $name)
& $script @ht 2>&1 | ForEach-Object { $_ }
$code = $LASTEXITCODE
if ($null -eq $code) { $code = 0 }
Write-Output ("### exit=" + $code)
exit $code
