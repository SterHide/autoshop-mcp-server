# Right-click at a coordinate and READ the resulting context menu -- without taking a screenshot.
#
# WHY NO SCREENSHOT: launching a capture steals focus and the popup menu closes before it is
# captured (documented pitfall). Classic Win32 menus are however exposed to UI Automation as
# Menu / MenuItem elements under the DESKTOP root, so the items can be enumerated semantically.
# Two independent channels are printed: UIA MenuItems, and the raw '#32768' menu window.
#
# Usage: point it at a cell of the target grid, read the item list, then either
#   -ClickText '<item>'  to click that item, or
#   (default) press ESC to dismiss.
#
# KEEP PURE ASCII. Chinese item text arrives as a parameter.
param(
  [Parameter(Mandatory=$true)][int]$X,
  [Parameter(Mandatory=$true)][int]$Y,
  [string]$ClickText = '',
  [int]$SettleMs = 700,
  [string]$CaptureOut = '',      # PrintWindow the popup to this PNG (no focus change, so the menu stays open)
  [string]$Mnemonic = '',        # after the menu opens, send this mnemonic key (e.g. 'x' for an item marked (X))
  [string]$ClickXY = '',         # after the menu opens, click this ABSOLUTE point "x,y" (computed from the capture)
  [switch]$NoWarmup,             # skip the warm-up left click. REQUIRED for GVL/变量表 grids: a left
                                 # click there puts a cell into edit mode and raises a ComboLBox,
                                 # after which the right-click stops opening the context menu.
  [switch]$KeepOpen
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$RD = 0x0008; $RU = 0x0010; $LD = 0x02; $LU = 0x04
$GW_CHILD = 5; $GW_HWNDNEXT = 2
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function ClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
[void][W.U]::SetForegroundWindow((Get-AutoShopMainWindow $proc))
Start-Sleep -Milliseconds 400
Write-Output ("target point ({0},{1})   foreground = {2}   (AutoShop main = {3})" -f $X, $Y, ([W.U]::GetForegroundWindow()), (Get-AutoShopMainWindow $proc))

# Snapshot every visible top-level window, so ANY popup can be found by set difference -- that
# avoids assuming the popup's class is '#32768' (an owner-drawn or custom menu will not be).
function SnapWindows {
  $list = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ([W.U]::IsWindowVisible($h)) {
      $r = RectOf $h
      [void]$list.Add([pscustomobject]@{ Hwnd=$h; Cls=(ClsOf $h); X=$r.Left; Y=$r.Top; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top); Text=(TxtOf $h) })
    }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $list }
$before = SnapWindows
Write-Output ("top-level windows before: {0}" -f $before.Count)

# Warm-up: the first click on a non-focused control can be eaten by activation.
# BUT on a GVL/变量表 grid a left click starts editing the cell (a ComboLBox pops up) and the
# following right-click then fails to open the menu -- so -NoWarmup must be used there.
if ($NoWarmup) {
  Write-Output 'warm-up left click SKIPPED (-NoWarmup)'
  [System.Windows.Forms.SendKeys]::SendWait('{ESC}')   # cancel any cell edit already in progress
  Start-Sleep -Milliseconds 250
} else {
  ClickRaw $X $Y
  Start-Sleep -Milliseconds 350
  Write-Output 'warm-up left click done'
}
[void][W.U]::SetCursorPos($X, $Y); Start-Sleep -Milliseconds 200
[W.U]::mouse_event($RD,0,0,0,0); Start-Sleep -Milliseconds 90
[W.U]::mouse_event($RU,0,0,0,0)
Start-Sleep -Milliseconds $SettleMs

$after = SnapWindows
$beforeIds = @($before | ForEach-Object { $_.Hwnd })
$new = @($after | Where-Object { $beforeIds -notcontains $_.Hwnd })
# The warm-up left click can raise a small TOOLTIP, which also counts as "new". Order by area
# descending and treat the LARGEST as the menu: taking $new[0] once grabbed an 82x26 tooltip and
# produced a blank 301-byte capture.
$new = @($new | Sort-Object { -($_.W * $_.H) })
Write-Output ''
Write-Output ("=== NEW top-level windows after the right-click: {0} ===" -f $new.Count)
foreach ($w in $new) {
  Write-Output ("   hwnd={0,-8} class='{1,-24}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f $w.Hwnd, $w.Cls, $w.X, $w.Y, $w.W, $w.H, $w.Text)
  # MFC feature-pack popups (CMFCPopupMenu) are owner-drawn: no UIA items, no #32768 class.
  # Dump their child windows anyway -- if the items happen to be child windows, this reads them
  # directly instead of falling back to OCR.
  $k = [W.U]::GetWindow($w.Hwnd, $GW_CHILD)
  $n = 0
  while ($k -ne [IntPtr]::Zero -and $n -lt 80) {
    $kr = RectOf $k
    Write-Output ("        child hwnd={0,-8} class='{1,-22}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f `
      $k, (ClsOf $k), $kr.Left, $kr.Top, ($kr.Right-$kr.Left), ($kr.Bottom-$kr.Top), (TxtOf $k))
    $k = [W.U]::GetWindow($k, $GW_HWNDNEXT); $n++
  }
  if ($n -eq 0) { Write-Output '        (no child windows -> owner-drawn; read it with PrintWindow + OCR)' }
  else { Write-Output ("        {0} child window(s)" -f $n) }
}
if ($new.Count -eq 0) { Write-Output '   (nothing appeared -> the right-click did not open a menu here)' }

# --- optional: render the popup to a PNG with PrintWindow ------------------------------------
# PrintWindow draws the window into a memory DC WITHOUT activating it, so unlike a screen grab it
# does not steal focus and the popup stays open. That matters because the popup has to remain open
# for the follow-up click.
if ($CaptureOut -and $new.Count -gt 0) {
  Add-Type -AssemblyName System.Drawing
  $w = $new[0]
  Write-Output ''
  Write-Output ("=== PrintWindow capture of hwnd={0} -> {1} ===" -f $w.Hwnd, $CaptureOut)
  $hdcScreen = [W.U]::GetDC([IntPtr]::Zero)
  $hdcMem = [W.U]::CreateCompatibleDC($hdcScreen)
  $hBmp = [W.U]::CreateCompatibleBitmap($hdcScreen, $w.W, $w.H)
  $hOld = [W.U]::SelectObject($hdcMem, $hBmp)
  # PW_RENDERFULLCONTENT (2) is required for composited / DirectComposition content
  $ok = [W.U]::PrintWindow($w.Hwnd, $hdcMem, 2)
  if (-not $ok) { $ok = [W.U]::PrintWindow($w.Hwnd, $hdcMem, 0) }
  $img = [System.Drawing.Image]::FromHbitmap($hBmp)
  $img.Save($CaptureOut, [System.Drawing.Imaging.ImageFormat]::Png)
  $img.Dispose()
  [void][W.U]::SelectObject($hdcMem, $hOld)
  [void][W.U]::DeleteObject($hBmp); [void][W.U]::DeleteDC($hdcMem); [void][W.U]::ReleaseDC([IntPtr]::Zero, $hdcScreen)
  Write-Output ("   PrintWindow ok={0}  saved {1} ({2} bytes)" -f $ok, $CaptureOut, (Get-Item -LiteralPath $CaptureOut).Length)
  Write-Output ("   popup origin = ({0},{1}), size = {2}x{3}" -f $w.X, $w.Y, $w.W, $w.H)
  Write-Output '   -> read the PNG, then compute the absolute click point as: popup origin + offset inside the image'
}

# --- channel 1: classic popup-menu windows ---------------------------------------------------
Write-Output ''
Write-Output '=== channel 1: visible #32768 menu windows ==='
$menus = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq '#32768' -and [W.U]::IsWindowVisible($h)) { [void]$menus.Add($h) }
  return $true }
[void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
Write-Output ("menu windows found: {0}" -f $menus.Count)
foreach ($m in $menus) {
  $r = RectOf $m
  Write-Output ("   hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $m, $r.Left, $r.Top, ($r.Right-$r.Left), ($r.Bottom-$r.Top))
}

# --- channel 2: UIA menu items under the desktop ---------------------------------------------
Write-Output ''
Write-Output '=== channel 2: UIA MenuItems ==='
$items = New-Object System.Collections.ArrayList
try {
  $desk = [System.Windows.Automation.AutomationElement]::RootElement
  $AE = [System.Windows.Automation.AutomationElement]
  $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::MenuItem)
  $found = $desk.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
  foreach ($e in $found) {
    $r = $e.Current.BoundingRectangle
    [void]$items.Add([pscustomobject]@{ Name=$e.Current.Name; X=[int]($r.X + $r.Width/2); Y=[int]($r.Y + $r.Height/2); W=[int]$r.Width })
  }
} catch { Write-Output ("  UIA failed: {0}" -f $_.Exception.Message) }
Write-Output ("menu items found: {0}" -f $items.Count)
$i = 0
foreach ($it in $items) {
  $i++
  Write-Output ("  [{0,2}] '{1}'  centre=({2},{3})  w={4}" -f $i, $it.Name, $it.X, $it.Y, $it.W)
}

# --- act -------------------------------------------------------------------------------------
Write-Output ''
if ($Mnemonic) {
  # An MFC popup menu item marked "(X)" can be invoked by its mnemonic letter. That beats clicking
  # a computed pixel: no row can be missed and no neighbouring item can be hit by accident.
  Write-Output ("sending mnemonic key '{0}'" -f $Mnemonic)
  [System.Windows.Forms.SendKeys]::SendWait($Mnemonic)
  Start-Sleep -Milliseconds 1500
  $menuGone = @($new | Where-Object { [W.U]::IsWindowVisible($_.Hwnd) }).Count -eq 0
  Write-Output ("  popup closed after the mnemonic: {0}" -f $menuGone)
  $after2 = SnapWindows
  $afterIds = @($after | ForEach-Object { $_.Hwnd })
  $new2 = @($after2 | Where-Object { $afterIds -notcontains $_.Hwnd })
  Write-Output ("  NEW windows after '{0}': {1}" -f $Mnemonic, $new2.Count)
  foreach ($w in $new2) {
    Write-Output ("     hwnd={0,-8} class='{1,-24}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f $w.Hwnd, $w.Cls, $w.X, $w.Y, $w.W, $w.H, $w.Text)
    $k = [W.U]::GetWindow($w.Hwnd, $GW_CHILD)
    while ($k -ne [IntPtr]::Zero) {
      $t = TxtOf $k
      $kr = RectOf $k
      if ($t -or (ClsOf $k) -match 'Edit|Button|ComboBox|Static') {
        Write-Output ("        child {0,-8} class='{1,-20}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f $k, (ClsOf $k), $kr.Left, $kr.Top, ($kr.Right-$kr.Left), ($kr.Bottom-$kr.Top), $t)
      }
      $k = [W.U]::GetWindow($k, $GW_HWNDNEXT)
    }
  }
} elseif ($ClickXY) {
  # Mnemonics do not reach an MFC toolbar-style popup (verified: sending 'x' left the popup open).
  # So the item is clicked at an absolute point derived from the PrintWindow capture:
  #     absolute = popup origin + offset measured inside the image
  # The capture is 1:1 with the popup window, so image coordinates ARE window offsets.
  $parts = $ClickXY.Split(',')
  $px = [int]$parts[0].Trim(); $py = [int]$parts[1].Trim()
  Write-Output ("clicking the menu item at absolute ({0},{1})" -f $px, $py)
  ClickRaw $px $py
  Start-Sleep -Milliseconds 1500
  $menuGone = @($new | Where-Object { [W.U]::IsWindowVisible($_.Hwnd) }).Count -eq 0
  Write-Output ("  popup closed after the click: {0}" -f $menuGone)
  $after2 = SnapWindows
  $afterIds = @($after | ForEach-Object { $_.Hwnd })
  $new2 = @($after2 | Where-Object { $afterIds -notcontains $_.Hwnd })
  Write-Output ("  NEW windows after the click: {0}" -f $new2.Count)
  foreach ($w in $new2) {
    Write-Output ("     hwnd={0,-8} class='{1,-24}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f $w.Hwnd, $w.Cls, $w.X, $w.Y, $w.W, $w.H, $w.Text)
    $k = [W.U]::GetWindow($w.Hwnd, $GW_CHILD)
    while ($k -ne [IntPtr]::Zero) {
      $t = TxtOf $k; $kr = RectOf $k
      if ($t -or (ClsOf $k) -match 'Edit|Button|ComboBox|Static|List') {
        Write-Output ("        child {0,-8} class='{1,-20}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f $k, (ClsOf $k), $kr.Left, $kr.Top, ($kr.Right-$kr.Left), ($kr.Bottom-$kr.Top), $t)
      }
      $k = [W.U]::GetWindow($k, $GW_HWNDNEXT)
    }
  }
} elseif ($ClickText) {
  $hit = $items | Where-Object { $_.Name -eq $ClickText } | Select-Object -First 1
  if ($null -eq $hit) { $hit = $items | Where-Object { $_.Name -like "*$ClickText*" } | Select-Object -First 1 }
  if ($null -eq $hit) {
    Write-Output ("TARGET NOT FOUND: '{0}' is not among the menu items above" -f $ClickText)
    [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
  } else {
    Write-Output ("clicking '{0}' at ({1},{2})" -f $hit.Name, $hit.X, $hit.Y)
    ClickRaw $hit.X $hit.Y
    Start-Sleep -Milliseconds 900
  }
} elseif ($KeepOpen) {
  Write-Output 'menu left OPEN (as requested)'
} else {
  Write-Output 'dismissing the menu with ESC'
  [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
  Start-Sleep -Milliseconds 400
}

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }