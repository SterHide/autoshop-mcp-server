# Add a STRUCT-typed variable to a variable table by CSV: build -> import -> confirm -> save -> verify.
#
# All Chinese strings (variable name, struct name, paths) come in as PARAMETERS: a .ps1 with Chinese
# literals is read as ANSI by PowerShell 5.1 and the parser breaks. This file stays pure ASCII.
#
# Row format (10 fields, verified byte-identical against a UI-created sample):
#   <seq>,<Var>,<Struct>,,,,,,,
#   ,<Var>.<member>,<type>,,<init>,,,<comment>,,
# with init = OFF for BOOL, 0 for INT/DINT, empty otherwise.
param(
  [Parameter(Mandatory=$true)][string]$VarName,
  [Parameter(Mandatory=$true)][string]$StructName,
  [Parameter(Mandatory=$true)][string]$MembersCsv,
  [Parameter(Mandatory=$true)][string]$BaselineCsv,
  [Parameter(Mandatory=$true)][string]$OutCsv,
  [Parameter(Mandatory=$true)][string]$ProjectDir,
  [Parameter(Mandatory=$true)][string]$MirrorDir,
  [string]$View = '',
  [string]$E = (Join-Path $PSScriptRoot 'autoshop-extract-blocks2.ps1'),
  [string]$Imp = (Join-Path $PSScriptRoot 'autoshop-import-vartable.ps1'),
  [string]$Open = (Join-Path $PSScriptRoot 'autoshop-open-node.ps1'),
  [string]$VerifyDir = '',
  [int]$MenuOffsetY = 394,
  [int]$ImportOffsetY = 420,
  [int]$ExpectedMenuH = 632
)
$ErrorActionPreference = 'Stop'
$gbk = [System.Text.Encoding]::GetEncoding('GB2312')
$u8bom = New-Object System.Text.UTF8Encoding($true)

# --- 1) read the baseline export ---------------------------------------------------------------
$lines = @($gbk.GetString([System.IO.File]::ReadAllBytes($BaselineCsv)) -split "`r`n|`n")
$nonEmpty = @($lines | Where-Object { $_ -ne '' })
if ($nonEmpty.Count -eq 0) { throw ('baseline is empty: ' + $BaselineCsv) }
$max = 0
foreach ($l in $nonEmpty) { if ($l -match '^(\d+),') { $n = [int]$Matches[1]; if ($n -gt $max) { $max = $n } } }
Write-Output ("baseline: {0} non-empty rows, max seq = {1}" -f $nonEmpty.Count, $max)
Write-Output ("already contains '{0}'? {1}" -f $VarName, (@($nonEmpty | Where-Object { $_ -match ([regex]::Escape($VarName)) }).Count))

# --- 2) build the import file ------------------------------------------------------------------
$out = New-Object System.Collections.Generic.List[string]
foreach ($l in $lines) { $out.Add($l) }
$out.Add(('{0},{1},{2},,,,,,,' -f ($max + 1), $VarName, $StructName))
$members = @($u8bom.GetString([System.IO.File]::ReadAllBytes($MembersCsv)) -split "`r`n|`n" | Where-Object { $_ -ne '' } | Select-Object -Skip 1)
foreach ($m in $members) {
  $p = $m -split ','
  $nm = $p[0]; $ty = $p[1]
  $cm = (($p[2..($p.Count - 1)]) -join ',') -replace '^"|"$', ''
  if ($ty -eq 'BOOL') { $init = 'OFF' } elseif ($ty -match '^(INT|DINT)$') { $init = '0' } else { $init = '' }
  $out.Add((",{0}.{1},{2},,{3},,,{4},," -f $VarName, $nm, $ty, $init, $cm))
}
[System.IO.File]::WriteAllText($OutCsv, ($out -join "`r`n"), $gbk)
Write-Output ("import file: {0}  ({1} rows = baseline + parent + {2} members)" -f $OutCsv, $out.Count, $members.Count)

# --- 3) import ---------------------------------------------------------------------------------
if (-not $View) { $View = [System.IO.Path]::GetFileNameWithoutExtension($BaselineCsv) }
Write-Output ("opening '{0}' with the no-scan opener" -f $View)
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $Open -Node $View 2>&1 | ForEach-Object { Write-Output ('  [open] ' + $_) }
Start-Sleep -Milliseconds 1000
Write-Output ('importing into ' + $View)
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $Imp -View $View -CsvPath $OutCsv -ImportOffsetY $ImportOffsetY -ExpectedMenuH $ExpectedMenuH -ConfirmImport 2>&1 |
  Select-String -Pattern 'import prompt|clicking|clipboard|NO file|STALL|pressing|Save button|pass |dismissed|Ctrl\+S' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Start-Sleep -Milliseconds 1500

# --- 4) verify ---------------------------------------------------------------------------------
if (-not $VerifyDir) { $VerifyDir = Join-Path (Split-Path -Parent $OutCsv) 'verify' }
New-Item -ItemType Directory -Force -Path $VerifyDir | Out-Null
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $E -ProjectDir $ProjectDir -MirrorDir $MirrorDir `
  -TableNames $View -TableOutDir $VerifyDir -ExpandFolded -Limit 1 -Redo -MenuOffsetY $MenuOffsetY -ExpectedMenuH $ExpectedMenuH *> (Join-Path $VerifyDir 'log.txt')
$vPath = Join-Path $VerifyDir ($View + '.csv')
$t = $gbk.GetString([System.IO.File]::ReadAllBytes($vPath))
$vRows = @($t -split "`r`n|`n" | Where-Object { $_ -ne '' })
$hits = @($vRows | Where-Object { $_ -match ([regex]::Escape($VarName)) })
Write-Output ("verify: {0} rows (baseline {1}); rows with '{2}' = {3}" -f $vRows.Count, $nonEmpty.Count, $VarName, $hits.Count)
$expect = $members.Count + 1
if ($hits.Count -eq $expect) { Write-Output 'RESULT: OK - the struct variable is in the table' } else { Write-Output ('RESULT: MISSING - expected {0} rows for the new variable' -f $expect) }
Get-ChildItem -LiteralPath $ProjectDir -File | Where-Object { $_.Name -match '\.hcp$|\.gvt$' } |
  Sort-Object LastWriteTime -Descending | Select-Object -First 4 |
  ForEach-Object { Write-Output ('  {0,-22} {1,9} bytes  {2}' -f $_.Name, $_.Length, $_.LastWriteTime.ToString('HH:mm:ss')) }
