# Shared Win32 probe for the vendor IDE bridges. Invoke with -File so no string escaping is needed.
#
#   -Action scan  -PidFilter N            top-level windows of a process
#   -Action frames -Class NAME [-PidFilter N]   top-level windows matching a window class
#   -Action menu  -Hwnd N                 full native menu tree (returns menu:null when GetMenu is NULL)
#   -Action children -Hwnd N              child controls: class, text, dialog id, visibility
#   -Action click -Hwnd N                 BM_CLICK on a child button
#   -Action probe -Hwnd N -CommandId M    PostMessage WM_COMMAND (diagnostic)
#
# Why menu matters: a native Win32 menu can be read and driven by command id. Codejock XTP and
# Qt Ribbon command bars return NULL from GetMenu, so those apps need accelerators or UIA instead.
param(
  [Parameter(Mandatory = $true)][ValidateSet('scan', 'frames', 'menu', 'children', 'click', 'probe')][string]$Action,
  [string]$Class = '',
  [int]$PidFilter = 0,
  [long]$Hwnd = 0,
  [int]$CommandId = 0
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public class WinProbe
{
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll")] public static extern int GetClassName(IntPtr hWnd, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")] public static extern IntPtr GetMenu(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetMenuItemCount(IntPtr hMenu);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetMenuString(IntPtr hMenu, uint idItem, StringBuilder s, int maxBuf, uint uFlags);
    [DllImport("user32.dll")] public static extern IntPtr GetSubMenu(IntPtr hMenu, int pos);
    [DllImport("user32.dll")] public static extern uint GetMenuItemID(IntPtr hMenu, int pos);
    [DllImport("user32.dll")] public static extern uint GetMenuState(IntPtr hMenu, uint idItem, uint uFlags);

    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr hWnd);

    [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    const uint MF_BYPOSITION = 0x0400;
    const uint MF_BYCOMMAND = 0x0000;
    const uint MF_SEPARATOR = 0x0800;
    const uint MF_POPUP = 0x0010;
    const uint MF_GRAYED = 0x0001;
    const uint MF_CHECKED = 0x0008;

    static string Title(IntPtr h)
    {
        var t = new StringBuilder(1024);
        GetWindowText(h, t, 1024);
        return t.ToString();
    }
    static string ClassName(IntPtr h)
    {
        var c = new StringBuilder(256);
        GetClassName(h, c, 256);
        return c.ToString();
    }

    static object WalkMenu(IntPtr hMenu, int depth)
    {
        var items = new List<object>();
        int count = GetMenuItemCount(hMenu);
        for (int i = 0; i < count; i++)
        {
            var sb = new StringBuilder(512);
            GetMenuString(hMenu, (uint)i, sb, 512, MF_BYPOSITION);
            uint state = GetMenuState(hMenu, (uint)i, MF_BYPOSITION);
            uint id = GetMenuItemID(hMenu, i);
            var node = new Dictionary<string, object>();
            node["pos"] = i;
            node["text"] = sb.ToString();
            node["id"] = id;
            node["separator"] = (state & MF_SEPARATOR) != 0;
            node["popup"] = (state & MF_POPUP) != 0;
            node["grayed"] = (state & MF_GRAYED) != 0;
            node["checked"] = (state & MF_CHECKED) != 0;
            if ((state & MF_POPUP) != 0)
            {
                IntPtr sub = GetSubMenu(hMenu, i);
                if (sub != IntPtr.Zero && depth < 6) node["children"] = WalkMenu(sub, depth + 1);
            }
            items.Add(node);
        }
        return items;
    }

    public static object ReadMenu(long hwnd)
    {
        IntPtr h = GetMenu((IntPtr)hwnd);
        var frame = new Dictionary<string, object>();
        frame["hwnd"] = hwnd;
        frame["cls"] = ClassName((IntPtr)hwnd);
        frame["title"] = Title((IntPtr)hwnd);
        if (h == IntPtr.Zero)
        {
            frame["menu"] = null;
            frame["menuKind"] = "NO_NATIVE_MENU_BAR";
            return frame;
        }
        frame["menu"] = WalkMenu(h, 0);
        frame["menuKind"] = "WIN32_NATIVE";
        return frame;
    }

    public static List<object> Top(int pidFilter, string className)
    {
        var results = new List<object>();
        EnumWindows((h, l) =>
        {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            if (pidFilter != 0 && pid != (uint)pidFilter) return true;
            var cls = ClassName(h);
            if (!string.IsNullOrEmpty(className) && cls != className) return true;
            results.Add(new { hwnd = (long)h, pid = pid, cls = cls, title = Title(h), visible = IsWindowVisible(h) });
            return true;
        }, IntPtr.Zero);
        return results;
    }

    public static List<object> Children(long hwnd)
    {
        var results = new List<object>();
        EnumChildWindows((IntPtr)hwnd, (h, l) =>
        {
            results.Add(new
            {
                hwnd = (long)h,
                cls = ClassName(h),
                text = Title(h),
                dlgId = GetDlgCtrlID(h),
                visible = IsWindowVisible(h)
            });
            return true;
        }, IntPtr.Zero);
        return results;
    }

    // BM_CLICK = 0x00F5
    public static void ClickButton(long hwnd)
    {
        SendMessage((IntPtr)hwnd, 0x00F5, IntPtr.Zero, IntPtr.Zero);
    }

    // WM_COMMAND = 0x0111
    public static void PostCommand(long hWnd, int commandId)
    {
        PostMessage((IntPtr)hWnd, 0x0111, (IntPtr)commandId, IntPtr.Zero);
    }
}
'@

switch ($Action) {
  'scan' {
    if ($PidFilter -eq 0) { throw 'scan needs -PidFilter' }
    [pscustomobject]@{ windows = [WinProbe]::Top($PidFilter, '') } | ConvertTo-Json -Depth 6 -Compress
  }
  'frames' {
    if (-not $Class) { throw 'frames needs -Class' }
    [pscustomobject]@{ windows = [WinProbe]::Top($PidFilter, $Class) } | ConvertTo-Json -Depth 6 -Compress
  }
  'menu' {
    if ($Hwnd -eq 0) { throw 'menu needs -Hwnd' }
    [WinProbe]::ReadMenu($Hwnd) | ConvertTo-Json -Depth 8 -Compress
  }
  'children' {
    if ($Hwnd -eq 0) { throw 'children needs -Hwnd' }
    [pscustomobject]@{ children = [WinProbe]::Children($Hwnd) } | ConvertTo-Json -Depth 4 -Compress
  }
  'click' {
    if ($Hwnd -eq 0) { throw 'click needs -Hwnd' }
    [WinProbe]::ClickButton($Hwnd)
    [pscustomobject]@{ clicked = $true; hwnd = $Hwnd } | ConvertTo-Json -Compress
  }
  'probe' {
    if ($Hwnd -eq 0 -or $CommandId -eq 0) { throw 'probe needs -Hwnd and -CommandId' }
    [WinProbe]::PostCommand($Hwnd, $CommandId)
    [pscustomobject]@{ posted = $true; hwnd = $Hwnd; commandId = $CommandId } | ConvertTo-Json -Compress
  }
}
