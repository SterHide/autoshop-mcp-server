# Is the project-tree text clipped, and if so, widen the pane.
#
# WHY: the tree pane is only ~198px wide and block names sit at indent x=127/150/173, so long
# program names can run past the pane edge and be cut off on screen. Reported symptom: blocks open
# nothing on double-click, and consecutive nodes report impossible rects (y=918 then y=178).
#
# Objective checks (no eyeballing, no OCR):
#   1. WS_HSCROLL on the tree control + GetScrollInfo(SB_HORZ): nMax > nPage means the content is
#      wider than the viewport, i.e. something IS clipped.
#   2. Clipping signature from MSAA: for each indent level, count how many nodes share the SAME
#      right edge (x+w). A pile-up on one right edge == those rows are cut at the pane boundary.
#   3. Window hierarchy around the tree: parent chain + siblings, to locate the splitter bar.
# Then, with -Widen, drag the splitter to the right and re-verify.
#
# KEEP PURE ASCII. Chinese paths arrive as command-line parameters, never as source literals
# (PS 5.1 reads a BOM-less .ps1 as ANSI, so a Chinese literal becomes mojibake).
param(
  [Parameter(Mandatory=$true)][string]$ProjectDir,
  [switch]$Widen,
  [int]$WidenPx = 160
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
[StructLayout(LayoutKind.Sequential)] public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin; public int nMax; public int nPage; public int nPos; public int nTrackPos; }
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$WS_HSCROLL = 0x00100000; $WS_VSCROLL = 0x00200000
$SB_HORZ = 0; $SB_VERT = 1; $SIF_ALL = 0x17
$LD = 0x02; $LU = 0x04
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function ScrollInfoOf([IntPtr]$h, [int]$bar) {
  $si = New-Object W.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = $SIF_ALL
  $ok = [W.U]::GetScrollInfo($h, $bar, [ref]$si)
  return [pscustomobject]@{ Ok=$ok; Min=$si.nMin; Max=$si.nMax; Page=$si.nPage; Pos=$si.nPos; Track=$si.nTrackPos } }
function ClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }
function AssertNoDialog([string]$where) {
  $d = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$d.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  foreach ($x in $d) {
    $kids = New-Object System.Collections.ArrayList
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($x, $cb2, [IntPtr]::Zero)
    Write-Output ("   [dialog] ({0}) '{1}' buttons=[{2}]" -f $where, (TxtOf $x), (($kids | ForEach-Object { TxtOf $_ }) -join '/'))
    $pressed = $false
    foreach ($b in $kids) {
      $t = TxtOf $b
      if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) { $r = RectOf $b; ClickRaw ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2)); $pressed = $true; break } }
    if (-not $pressed) { [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Start-Sleep -Milliseconds 400 }
    Start-Sleep -Milliseconds 300 } }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
Write-Output ("main hwnd={0}" -f $main)

$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { [void]$trees.Add($h) }
  return $true }
[void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
$tree = $trees | Sort-Object { (RectOf $_).Left } | Select-Object -First 1
$tr = RectOf $tree
$cr = New-Object W.U+RECT; [void][W.U]::GetClientRect($tree, [ref]$cr)
Write-Output ("project tree hwnd={0}" -f $tree)
Write-Output ("  window rect = {{ {0},{1} {2}x{3} }}" -f $tr.Left, $tr.Top, ($tr.Right-$tr.Left), ($tr.Bottom-$tr.Top))
Write-Output ("  client rect = {{ 0,0 {0}x{1} }}  (client is smaller by the frame + scrollbars)" -f $cr.Right, $cr.Bottom)

# --- 1) scrollbar evidence -------------------------------------------------------------------
$style = [W.U]::GetWindowLong($tree, -16)   # GWL_STYLE
Write-Output ''
Write-Output '=== 1) scrollbar evidence ==='
Write-Output ("  WS_HSCROLL={0}  WS_VSCROLL={1}" -f [bool]($style -band $WS_HSCROLL), [bool]($style -band $WS_VSCROLL))
$h = ScrollInfoOf $tree $SB_HORZ
$v = ScrollInfoOf $tree $SB_VERT
Write-Output ("  SB_HORZ: ok={0} min={1} max={2} page={3} pos={4}  -> content width {5} px, viewport {6} px, OVERFLOW {7} px" -f `
  $h.Ok, $h.Min, $h.Max, $h.Page, $h.Pos, ($h.Max - $h.Min), $h.Page, [Math]::Max(0, ($h.Max - $h.Min + 1) - $h.Page))
Write-Output ("  SB_VERT: ok={0} min={1} max={2} page={3} pos={4}  -> {5} rows total, {6} rows visible" -f `
  $v.Ok, $v.Min, $v.Max, $v.Page, $v.Pos, ($v.Max - $v.Min + 1), $v.Page)
$clipped = (($h.Max - $h.Min + 1) - $h.Page) -gt 0
Write-Output ("  VERDICT: content is{0} wider than the pane -> names ARE clipped" -f $(if ($clipped) { '' } else { ' NOT' }))

# --- 2) clipping signature from MSAA ---------------------------------------------------------
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
[void][W.U]::AccessibleObjectFromWindow($tree, [uint32]4294967292, [ref]$iid, [ref]$acc)
Write-Output ''
Write-Output '=== 2) MSAA: per-indent right edge (x+w) -- a pile-up on one edge == clipped rows ==='
$ids = @($acc.accSelection) + @()
$rows = New-Object System.Collections.ArrayList
for ($i = 1; $i -le 400; $i++) {
  $nm = $null; $st = $null
  try { $nm = [string]$acc.accName([int]$i) } catch { continue }
  try { $st = [int]$acc.accState([int]$i) } catch { continue }
  if ([string]::IsNullOrEmpty($nm)) { continue }
  $x=0;$y=0;$w=0;$hh=0
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$hh,[int]$i) } catch { continue }
  if ($w -le 0) { continue }
  [void]$rows.Add([pscustomobject]@{ Id=$i; Name=$nm; X=$x; Y=$y; W=$w; R=($x+$w) }) }
Write-Output ("  nodes with a rect: {0}" -f $rows.Count)
$byIndent = $rows | Group-Object X | Sort-Object { [int]$_.Name }
foreach ($g in $byIndent) {
  $edges = $g.Group | Group-Object R | Sort-Object { -$_.Count }
  $top = $edges | Select-Object -First 1
  Write-Output ("  indent x={0,4}  nodes={1,3}  most common right edge={2} x{3}   max right edge={4}" -f `
    $g.Name, $g.Count, $top.Name, $top.Count, (($g.Group | Measure-Object R -Maximum).Maximum))
}
if ($rows.Count) {
  $paneRight = $tr.Right
  $at = @($rows | Where-Object { $_.R -ge ($paneRight - 6) })
  Write-Output ("  rows whose text reaches the pane edge ({0} +-6): {1}" -f $paneRight, $at.Count)
  foreach ($r in ($at | Select-Object -First 12)) { Write-Output ("     '{0}'  x={1} w={2} right={3}" -f $r.Name, $r.X, $r.W, $r.R) }
}

# --- 3) window hierarchy: locate the splitter ------------------------------------------------
Write-Output ''
Write-Output '=== 3) window hierarchy around the tree (to find the splitter) ==='
$cur = $tree
for ($d = 0; $d -lt 5; $d++) {
  $p = [W.U]::GetParent($cur)
  if ($p -eq [IntPtr]::Zero) { break }
  $pr = RectOf $p
  Write-Output ("  level {0}: parent hwnd={1} class='{2}' rect={{ {3},{4} {5}x{6} }} text='{7}'" -f `
    $d, $p, (ClsOf $p), $pr.Left, $pr.Top, ($pr.Right-$pr.Left), ($pr.Bottom-$pr.Top), (TxtOf $p))
  Write-Output ('    siblings:')
  $kids = New-Object System.Collections.ArrayList
  $cb2 = [W.U+EnumProc]{ param($h,$p2) if ([W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
  [void][W.U]::EnumChildWindows($p, $cb2, [IntPtr]::Zero)
  foreach ($k in $kids) {
    $kr = RectOf $k
    Write-Output ("      hwnd={0,-8} class='{1,-24}' rect={{ {2},{3} {4}x{5} }} text='{6}'" -f `
      $k, (ClsOf $k), $kr.Left, $kr.Top, ($kr.Right-$kr.Left), ($kr.Bottom-$kr.Top), (TxtOf $k)) }
  $cur = $p
}

# --- 4) optional: widen by dragging the splitter ---------------------------------------------
if ($Widen) {
  Write-Output ''
  Write-Output ("=== 4) widening the pane by dragging the splitter {0}px right ===" -f $WidenPx)
  # the splitter sits immediately right of the tree's right edge
  $sx = $tr.Right + 2
  $sy = [int](($tr.Top + $tr.Bottom) / 2)
  [void][W.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 400
  Write-Output ("  grabbing splitter at ({0},{1})" -f $sx, $sy)
  [void][W.U]::SetCursorPos($sx, $sy); Start-Sleep -Milliseconds 250
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 250
  $steps = 12
  for ($i = 1; $i -le $steps; $i++) {
    [void][W.U]::SetCursorPos(($sx + [int]($WidenPx * $i / $steps)), $sy)
    Start-Sleep -Milliseconds 70 }
  [W.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 600
  [void](AssertNoDialog 'after splitter drag')
  $tr2 = RectOf $tree
  Write-Output ("  tree rect after drag = {{ {0},{1} {2}x{3} }}  (was {4}px wide -> now {5}px)" -f `
    $tr2.Left, $tr2.Top, ($tr2.Right-$tr2.Left), ($tr2.Bottom-$tr2.Top), ($tr.Right-$tr.Left), ($tr2.Right-$tr2.Left))
  $h2 = ScrollInfoOf $tree $SB_HORZ
  Write-Output ("  SB_HORZ after drag: max={0} page={1} -> overflow {2} px" -f `
    $h2.Max, $h2.Page, [Math]::Max(0, ($h2.Max - $h2.Min + 1) - $h2.Page))
  if (($tr2.Right - $tr2.Left) -gt ($tr.Right - $tr.Left)) {
    Write-Output '  pane WIDENED. Re-run the extractor: names should now render fully.'
  } else {
    Write-Output '  pane width unchanged -- the drag missed the splitter. Try -WidenPx or locate the gripper by hand.'
  }
} else {
  Write-Output ''
  Write-Output '  (re-run with -Widen to drag the splitter right)'
}
[void](AssertNoDialog 'final')

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }