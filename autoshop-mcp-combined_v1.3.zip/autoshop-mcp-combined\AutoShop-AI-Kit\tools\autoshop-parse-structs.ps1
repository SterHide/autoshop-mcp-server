# Parse AutoShop .stru (struct definition) containers into CSV.
#
# Why: structs are NOT covered by AutoShop's "export as HMI variables" (variables only), and the
# autoshop-mcp-server has no .stru in its variable-table whitelist. The only source is the .stru
# file itself -- it is an "AutoShop" binary container, but member names/types/comments are stored
# as length-prefixed GBK strings (verified readable).
#
# KEEP THIS FILE PURE ASCII.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-parse-structs.ps1 `
#       -ProjectDir "C:\...\ST框架" -OutDir "C:\...\镜像\全局变量\结构体" [-Sample 2]
param(
  [Parameter(Mandatory = $true)][string]$ProjectDir,
  [Parameter(Mandatory = $true)][string]$OutDir,
  [int]$Sample = 0
)

$ErrorActionPreference = 'Stop'
$U8 = New-Object System.Text.UTF8Encoding($true)   # BOM: Excel-friendly
$GBK = [System.Text.Encoding]::GetEncoding(936)

# Inovance ST short type prefixes -> full type (best effort)
$TypeMap = @{
  'b' = 'BOOL'; 'i' = 'INT'; 'di' = 'DINT'; 'r' = 'REAL'; 'w' = 'WORD'; 'dw' = 'DWORD'
  'ui' = 'UINT'; 'udi' = 'UDINT'; 's' = 'STRING'; 't' = 'TIME'; 'dt' = 'DT'; 'l' = 'LREAL'
  'e' = 'ENUM'; 'x' = 'BOOL'
}

function Parse-Struct([string]$path) {
  $bytes = [System.IO.File]::ReadAllBytes($path)
  $text = $GBK.GetString($bytes)
  # control bytes act as token separators in this container
  $tokens = ($text -split '[\x00-\x08\x0B\x0C\x0E-\x1F]+') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }

  $name = $null
  $rows = New-Object System.Collections.ArrayList
  $pendingType = $null

  foreach ($tok in $tokens) {
    if ($null -eq $name) {
      # the struct name is the first token ending with '@' (may contain CJK)
      if ($tok -match '^(.+)@$') { $name = $Matches[1] }
      continue
    }
    # a declared type token, e.g. STRING<30> / BOOL / INT
    if ($tok -match '^(STRING<\d+>|STRING|BOOL|BYTE|INT|DINT|UINT|UDINT|WORD|DWORD|REAL|LREAL|TIME|DATE|DT)$') {
      $pendingType = $tok
      continue
    }
    # member record: optional lowercase type prefix + Chinese name [+ inline comment]
    # nested type reference (ends with @) is not a member
    if ($tok -match '@$') { continue }
    # member record: type prefix (longest-first) + name starting with CJK or uppercase, optional comment
    if ($tok -match '^(udi|udu|dw|di|ui|st|dt|lr|b|i|r|w|s|t|l|e|x)([^\x00-\x7F].*|[A-Z].*)$') {
      $prefix = $Matches[1]; $rest = $Matches[2]
      $member = $rest; $comment = $null
      if ($rest -match '^(\S+)\s+(.*)$') { $member = $Matches[1]; $comment = $Matches[2] }
      $type = $pendingType; $pendingType = $null
      if (-not $type) { $type = if ($TypeMap.ContainsKey($prefix)) { $TypeMap[$prefix] } else { $prefix } }
      $fullName = "$prefix$member"
      if ($comment) { $comment = $comment.Trim() }
      [void]$rows.Add([pscustomobject]@{ name = $fullName; dataType = $type; comment = $comment })
    }
  }
  return [pscustomobject]@{ struct = $name; rows = $rows }
}

if (-not (Test-Path -LiteralPath $OutDir)) { [void](New-Item -ItemType Directory -Path $OutDir -Force) }

$files = Get-ChildItem -LiteralPath $ProjectDir -File -Filter '*.stru'
if ($Sample -gt 0) { $files = $files | Select-Object -First $Sample }
$totalRows = 0
foreach ($f in $files) {
  $r = Parse-Struct $f.FullName
  $base = [System.IO.Path]::GetFileNameWithoutExtension($f.Name)
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.AppendLine('name,dataType,comment')
  foreach ($row in $r.rows) {
    $c = if ($row.comment) { '"' + ($row.comment -replace '"', '""') + '"' } else { '' }
    [void]$sb.AppendLine(('{0},{1},{2}' -f $row.name, $row.dataType, $c))
  }
  [System.IO.File]::WriteAllText((Join-Path $OutDir "$base.csv"), $sb.ToString(), $U8)
  $totalRows += $r.rows.Count
  if ($Sample -gt 0) {
    Write-Output ("=== {0}  (struct={1}, {2} members) ===" -f $base, $r.struct, $r.rows.Count)
    Get-Content -LiteralPath (Join-Path $OutDir "$base.csv") -Encoding UTF8 | Select-Object -First 30 | ForEach-Object { "  " + $_ }
    Write-Output ''
  }
}
Write-Output ("structs parsed: {0}   member rows: {1}" -f $files.Count, $totalRows)
