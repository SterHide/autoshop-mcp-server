﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Probe: can we READ AutoShop project-tree node names without opening anything?
#
# WHY: double-clicking a "program block" row pops a modal "program block properties" dialog that
# freezes the UI, so we must know what a row IS before clicking it.
#
# Channels tried, cheapest first:
#   A) Enumerate every SysTreeView32 in the main window and ask WM_GETTEXT -> in comctl32 the
#      tree answers with the text of the CURRENTLY SELECTED item (USER32 marshals WM_GETTEXT
#      across processes, so this works even though TVM_GETITEM does not).
#   B) MSAA: oleacc!AccessibleObjectFromWindow(hwnd, OBJID_CLIENT, IID_IDispatch) and then
#      late-bind accChildCount / accName(i) / accRole(i) / accLocation(i).
#      (Evidence from another project: this tree was reachable under MSAA.)
#
# KEEP THIS FILE PURE ASCII (PS 5.1 reads BOM-less .ps1 as ANSI).
param(
  [int]$TreeX = 100, [int]$TreeY = 400,
  [int]$MaxNodes = 300
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }


if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageStr(IntPtr h, uint msg, IntPtr wp, System.Text.StringBuilder lp);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

$LD = 0x02; $LU = 0x04
$WM_GETTEXT = 0x000D
# NB: PS parses 0xFFFFFFFC as Int32 -4, which then fails to marshal into a UInt32 parameter.
$OBJID_CLIENT = [uint32]4294967292

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LU,0,0,0,0)
}

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$hwnd = (Get-AutoShopMainWindow $proc)
Write-Output ("main hwnd = {0}  title = {1}" -f $hwnd, $proc.MainWindowTitle)

# --- A) every SysTreeView32 under the main window -------------------------------------------
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') {
    $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
    [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r })
  }
  return $true
}
[void][W.U]::EnumChildWindows($hwnd, $cb, [IntPtr]::Zero)
Write-Output ("SysTreeView32 found: {0}" -f $trees.Count)
foreach ($t in $trees) {
  Write-Output ("  hwnd={0}  rect={{ {1},{2} {3}x{4} }}" -f $t.hwnd, $t.rect.Left, $t.rect.Top, ($t.rect.Right-$t.rect.Left), ($t.rect.Bottom-$t.rect.Top))
}
if ($trees.Count -eq 0) { Write-Output 'NO TREE CONTROL - stop.'; return }

$tree = $trees[0].hwnd
$tr = $trees[0].rect

# --- B) WM_GETTEXT on the tree, before and after selecting a row -----------------------------
[void][W.U]::SetForegroundWindow($hwnd); Start-Sleep -Milliseconds 400
Click $TreeX $TreeY; Start-Sleep -Milliseconds 400

function TreeText {
  $sb = New-Object System.Text.StringBuilder 512
  [void][W.U]::SendMessageStr($tree, $WM_GETTEXT, [IntPtr]512, $sb)
  return $sb.ToString()
}
$t0 = TreeText
Write-Output ("WM_GETTEXT (as clicked)     = '{0}'" -f $t0)
[System.Windows.Forms.SendKeys]::SendWait('^({HOME})'); Start-Sleep -Milliseconds 400
$t1 = TreeText
Write-Output ("WM_GETTEXT (after Ctrl+Home)= '{0}'" -f $t1)
[System.Windows.Forms.SendKeys]::SendWait('{DOWN}'); Start-Sleep -Milliseconds 250
$t2 = TreeText
Write-Output ("WM_GETTEXT (after Down)     = '{0}'" -f $t2)
Write-Output 'A) WM_GETTEXT verdict: usable if the two strings above differ and look like node names.'

# --- C) MSAA --------------------------------------------------------------------------------
Write-Output ''
Write-Output 'C) MSAA (oleacc AccessibleObjectFromWindow, IID_IDispatch) ...'
$iidDispatch = [guid]'00020400-0000-0000-C000-000000000046'
$acc = $null
try {
  $hr = [W.U]::AccessibleObjectFromWindow($tree, $OBJID_CLIENT, [ref]$iidDispatch, [ref]$acc)
  Write-Output ("   hr = 0x{0:X8}   acc = {1}" -f $hr, $(if ($null -eq $acc) { '<null>' } else { $acc.GetType().FullName }))
} catch {
  Write-Output ("   AccessibleObjectFromWindow threw: {0}" -f $_.Exception.Message)
  $acc = $null
}

if ($null -ne $acc) {
  $cc = $null
  try { $cc = $acc.accChildCount } catch { Write-Output ("   accChildCount failed: {0}" -f $_.Exception.Message) }
  Write-Output ("   accChildCount = {0}" -f $cc)
  if ($null -ne $cc) {
    $n = [int]$cc
    if ($n -gt $MaxNodes) { $n = $MaxNodes }
    for ($i = 1; $i -le $n; $i++) {
      $name = $null; $role = $null; $loc = $null; $val = $null
      try { $name = $acc.accName($i) } catch { $name = "<ERR $($_.Exception.Message)>" }
      try { $role = $acc.accRole($i) } catch { $role = '?' }
      try { $val  = $acc.accValue($i) } catch { $val = '?' }
      try {
        $l = $acc.accLocation(0,0,0,0,$i)   # byref out params do not survive PS late binding
        $loc = $l
      } catch { $loc = '' }
      Write-Output ("   [{0,3}] role={1,-4} name='{2}' val='{3}' loc={4}" -f $i, $role, $name, $val, $loc)
    }
  }
  Write-Output 'C) MSAA verdict: usable if names above look like the project tree rows.'
}

[void][W.U]::SetForegroundWindow($hwnd)
Write-Output ''
Write-Output 'done.'
