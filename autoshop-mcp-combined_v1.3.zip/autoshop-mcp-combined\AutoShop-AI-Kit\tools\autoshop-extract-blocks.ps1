# DEPRECATED (superseded twice over): blind coordinate clicks + clipboard fallback, and it also walks the tree with arrow keys. Use autoshop-extract-blocks2.ps1 (name-addressed, no walking).
# ############################################################################################
# DEPRECATED -- USE autoshop-extract-blocks2.ps1 INSTEAD.
#
# Superseded because this version has two defects that produced CORRUPT output:
#   1. Blind page-stepping: it clicked guessed row coordinates and only learned what it had
#      opened by reading the MDI title, so double-clicking a folder popped the modal
#      "program block properties" dialog and froze the UI.
#   2. The clipboard fallback (click editor -> Ctrl+A -> Ctrl+C) is actively harmful: all MDI
#      children share one rectangle, so it silently copies the WRONG block, and dialog text can
#      land in the clipboard. A previous run of this script wrote the 180-character
#      "open window count exceeded" DIALOG TEXT into INT_001.md, front-matter and all, so the
#      garbage looked exactly like a successful extraction.
# v2 identifies every row through MSAA before clicking (name + fold state + real rect), checks
# for modal dialogs after every interaction, and reads text only through the UIA / WM_GETTEXT
# channels (never the clipboard).
# ############################################################################################
#
# Sweep the AutoShop project tree and extract every ST block body into the mirror.
#
# WHY THE UI: .ST/.FB/.FC containers and even STTemp/*.st are encrypted ("****AS*****"), so block
# bodies only exist inside the running editor. Channel: open block -> Ctrl+A / Ctrl+C -> clipboard.
#
# HOW IT NAVIGATES (deliberately dumb, order-independent):
#   select the tree -> Ctrl+Home -> then repeatedly: Down, Enter, read the main-window title.
#   If the title reads "... - [NAME]" and NAME is one of the blocks listed in folder.txt, that block
#   just got opened in the editor, so copy it out and store it under its own name.
#   The tree is assumed expanded; order does not matter because the block identity comes from the
#   title, not from the row position. At the end the script reports which expected blocks are still
#   missing (those are the ones hidden inside a collapsed folder).
#
# SAFETY: a long run of rows that open no block aborts the sweep (so it can never spam Enter into a
# modal dialog forever). -Write is required to touch files; default is a dry run.
#
# KEEP THIS FILE PURE ASCII.  Run with -STA (clipboard):
#   powershell -STA -NoProfile -ExecutionPolicy Bypass -File autoshop-extract-blocks.ps1 ^
#       -ProjectDir "C:\...\ST妗嗘灦" -MirrorDir "C:\...\ST妗嗘灦_鏈湴宸ョ▼" -Write
param(
  [Parameter(Mandatory = $true)][string]$ProjectDir,
  [Parameter(Mandatory = $true)][string]$MirrorDir,
  [int]$MaxRows = 320,                 # sweep budget
  [int]$Limit = 0,                     # 0 = all; else stop after N blocks
  [int]$StallAbort = 60,               # abort after this many consecutive non-block rows
  [switch]$Write,
  [int]$TreeX = 100, [int]$TreeY = 400,
  [int]$EditorX = 618, [int]$EditorY = 540,
  [int]$OpenWaitMs = 700, [int]$CopyWaitMs = 500,
  [string]$ProgDir = 'program', [string]$FbDir = 'fb', [string]$FcDir = 'fc'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string title);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$U8 = New-Object System.Text.UTF8Encoding($false)
$LD = 0x02; $LU = 0x04

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }

# Dismiss ANY visible dialog by READING its buttons with Win32 (UIA exposes nothing on these MFC
# dialogs and OCR cannot read the small captions). Always press No/Cancel -- never Yes/OK, so a
# stray dialog can never trigger a save or a destructive action.
function Dismiss-BlockPropDialog {
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  $hit = $false
  foreach ($d in $dlgs) {
    $kids = New-Object System.Collections.ArrayList
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d, $cb2, [IntPtr]::Zero)
    foreach ($b in $kids) {
      $t = TxtOf $b
      $cancelTxt = [string][char]0x53D6 + [string][char]0x6D88     # Cancel (char codes: a BOM-less .ps1 cannot carry Chinese literals)
      if ($t -like ('*' + $cancelTxt + '*')) {
        $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$r)
        Click ([int](($r.Left + $r.Right) / 2)) ([int](($r.Top + $r.Bottom) / 2))
        Start-Sleep -Milliseconds 500
        Write-Output ("   dialog '{0}' -> No/Cancel" -f (TxtOf $d))
        $hit = $true
        break
      }
    }
  }
  return $hit
}

function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LU,0,0,0,0)
}
function Send([string]$k, [int]$w = 150) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function Title { (Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1).MainWindowTitle }

# Read a block's source straight out of UIA instead of the clipboard.
# Why: after opening a block from the tree the keyboard focus stays on the TREE, and clicking the
# editor to move focus activates whichever MDI child happens to be on top (all MDI children share
# the same rectangle) -- that silently copies the WRONG block. The Scintilla control exposes the
# whole document through UIA, so we read it from the MDI child that is NAMED after the block.
try {
  Add-Type -AssemblyName UIAutomationClient  -ErrorAction Stop
  Add-Type -AssemblyName UIAutomationTypes   -ErrorAction Stop
  $script:UiaOk = $true
} catch { $script:UiaOk = $false }

function Read-BlockText([IntPtr]$hwnd, [string]$block) {
  if (-not $script:UiaOk) { return $null }
  try {
    $root = [System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
    if ($null -eq $root) { return $null }
    $byName = New-Object System.Windows.Automation.PropertyCondition(
      [System.Windows.Automation.AutomationElement]::NameProperty, $block)
    $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $byName)
    if ($null -eq $child) {
      # a modified block's MDI child is titled "<block> *"
      $byName2 = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::NameProperty, "$block *")
      $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $byName2)
    }
    if ($null -eq $child) { return $null }
    $byClass = New-Object System.Windows.Automation.PropertyCondition(
      [System.Windows.Automation.AutomationElement]::ClassNameProperty, 'Scintilla')
    $edit = $child.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $byClass)
    if ($null -eq $edit) { return $null }
    $vp = $null
    $t = $null
    if ($edit.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp)) {
      $t = ([System.Windows.Automation.ValuePattern]$vp).Current.Value
    }
    if (-not $t -or $t.Length -eq 0) { $t = $edit.Current.Name }
    if (-not $t) { return $null }
    # The Scintilla provider hands back the raw file bytes reinterpreted as UTF-16 code units
    # (e.g. "//" arrives as U+2F2F). Split every char back into 2 bytes and decode as UTF-8 --
    # verified: decoding as GBK yields the classic double-mojibake (澶嶄綅 -> 婢跺秳缍?.
    $bytes = New-Object byte[] ($t.Length * 2)
    for ($i = 0; $i -lt $t.Length; $i++) {
      $u = [int][char]$t[$i]
      $bytes[2 * $i] = [byte]($u -band 0xFF)
      $bytes[2 * $i + 1] = [byte](($u -shr 8) -band 0xFF)
    }
    return [System.Text.Encoding]::UTF8.GetString($bytes).TrimEnd([char]0)
  } catch { return $null }
}
function ActiveBlock {
  $t = Title
  if ($t -match '-\s*\[([^\]]+)\]\s*$') { return ($Matches[1] -replace '\s*\*$','').Trim() }
  return $null
}

# --- expected blocks from folder.txt (order == tree order), plus their mirror targets ---------
$lines = [System.IO.File]::ReadAllLines((Join-Path $ProjectDir 'folder.txt'), [System.Text.Encoding]::UTF8)
$map = @{}            # blockName -> @{ path=...; kind=...; lang=...; src=... }
$order = New-Object System.Collections.ArrayList
$section = $null; $stack = @{}
foreach ($raw in $lines) {
  if ([string]::IsNullOrWhiteSpace($raw)) { continue }
  $tabs = 0; while ($tabs -lt $raw.Length -and $raw[$tabs] -eq "`t") { $tabs++ }
  $body = $raw.Substring($tabs).Trim(); if ($body -eq '') { continue }
  if ($body -eq 'PROG' -or $body -eq 'FB' -or $body -eq 'FC') { $section = $body; $stack = @{0=''}; continue }
  if ($body -eq 'ROOT') { continue }
  if ($null -eq $section) { continue }
  if ($body -like 'FOLDER*') {
    $parent = ''; for ($d=1; $d -lt $tabs; $d++) { if ($stack.ContainsKey($d) -and $stack[$d]) { $parent = if ($parent) { Join-Path $parent $stack[$d] } else { $stack[$d] } } }
    $stack[$tabs] = $body.Substring(6).Trim()
    $stack[$tabs + 1] = ''      # reset deeper levels
    # remember the folder chain for this depth
    $stack["rel$tabs"] = if ($parent) { Join-Path $parent $stack[$tabs] } else { $stack[$tabs] }
    continue
  }
  $file = $body.Substring(4).Trim()
  $rel = ''; for ($d=1; $d -lt $tabs; $d++) { if ($stack.ContainsKey("rel$d") -and $stack["rel$d"]) { $rel = $stack["rel$d"] } }
  $base = [System.IO.Path]::GetFileNameWithoutExtension($file)
  $lang = [System.IO.Path]::GetExtension($file).TrimStart('.').ToUpper()
  $kind = if ($section -eq 'PROG') { 'program' } elseif ($section -eq 'FB') { 'function_block' } else { 'function' }
  $root = switch ($section) { 'PROG' { "$ProgDir\$ProgDir" } 'FB' { "$ProgDir\$FbDir" } 'FC' { "$ProgDir\$FcDir" } }
  $dir = if ($rel) { Join-Path $root $rel } else { $root }
  $md = if ($section -eq 'PROG') { Join-Path (Join-Path $MirrorDir $dir) "$base.md" }
        else { Join-Path (Join-Path (Join-Path $MirrorDir $dir) $base) "$base.md" }
  $map[$base] = @{ path = $md; kind = $kind; lang = $lang; src = $file }
  [void]$order.Add($base)
}
Write-Output ("expected blocks: {0}  (PROG/FB/FC from folder.txt)" -f $map.Count)

# --- drive ---------------------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$hwnd = (Get-AutoShopMainWindow $proc)
[void][W.U]::ShowWindow($hwnd, 9); [void][W.U]::SetForegroundWindow($hwnd); Start-Sleep -Milliseconds 500
Click $TreeX $TreeY                       # focus the tree pane
Start-Sleep -Milliseconds 300
Send '^({HOME})' 500                      # top of the tree
# Expand every folder: walking with RIGHT (expand, no-op on leaves) + DOWN traverses the tree in
# DFS order and unfolds it as it goes. Keyboard only -- double-clicking is what opens dialogs.
Write-Output 'expanding tree folders (RIGHT+DOWN sweep) ...'
for ($i = 0; $i -lt 400; $i++) { Send '{RIGHT}' 35; Send '{DOWN}' 35 }
Send '^({HOME})' 600                      # back to the top for the extraction pass
Write-Output 'tree expanded.'

$done = @{}; $count = 0
$rowH = 20; $topY = 160; $rowsPerPage = 36; $pages = 12
for ($page = 0; $page -lt $pages; $page++) {
  if ($count -ge $map.Count) { break }
  if ($Limit -gt 0 -and $count -ge $Limit) { break }
  for ($i = 0; $i -lt $rowsPerPage; $i++) {
    if ($Limit -gt 0 -and $count -ge $Limit) { break }
    $y = $topY + $rowH * $i
    Click $TreeX $y
    Start-Sleep -Milliseconds 60
    Click $TreeX $y
    Start-Sleep -Milliseconds $OpenWaitMs
    if (Dismiss-BlockPropDialog) { continue }        # "program block" node -> cancelled, skip row
    $b = ActiveBlock
    if (-not $b) { continue }
    if (-not $map.ContainsKey($b)) { continue }      # a folder / variable view / struct - not our target
    if ($done.ContainsKey($b)) { continue }          # already grabbed in an earlier page
    $src = Read-BlockText $hwnd $b
    $via = 'UIA'
    if (-not $src -or $src.Length -lt 2) {
      # Fallback via clipboard, guarded by a sentinel: a stale clipboard from the previous block
      # must never be mistaken for this block's source (that silently writes the wrong body).
      $via = 'clipboard'
      $sentinel = "DSH-SENTINEL-$([guid]::NewGuid().ToString('N'))"
      try { Set-Clipboard -Value $sentinel } catch { Write-Output ("SKIP {0,-28} : clipboard busy" -f $b); continue }
      Click $EditorX $EditorY
      Start-Sleep -Milliseconds 250
      Send '^a' 250
      Send '^c' $CopyWaitMs
      $clip = $null
      try { $clip = Get-Clipboard -Raw } catch { $clip = $null }
      if ($null -eq $clip -or $clip -eq $sentinel) { Write-Output ("SKIP {0,-28} : UIA read failed and the copy produced nothing" -f $b); continue }
      $src = $clip
    }
    $info = $map[$b]
    $body = @"
---
project: $(Split-Path -Leaf $ProjectDir)
kind: $($info.kind)
block: $b
language: $($info.lang)
source: $ProjectDir\$($info.src)
chars: $($src.Length)
lines: $(($src -split "`n").Count)
status: EXTRACTED
---

``````$($info.lang.ToLower())
$src
``````
"@
    if ($Write) {
      $d = Split-Path -Parent $info.path
      if (-not (Test-Path -LiteralPath $d)) { [void](New-Item -ItemType Directory -Path $d -Force) }
      [System.IO.File]::WriteAllText($info.path, $body, $U8)
      Write-Output ("OK   {0,-30} {1,6} chars" -f $b, $src.Length)
    } else {
      Write-Output ("DRY  {0,-30} {1,6} chars  | {2}" -f $b, $src.Length, (($src -split "`n")[0]))
    }
    # Close the block window immediately: leaving dozens open hits AutoShop's open-window limit
    # ("open window count exceeded"), which freezes the whole UI. Ctrl+F4 closes the MDI child.
    Send '^{F4}' 350
    [void](Dismiss-BlockPropDialog)
    $done[$b] = $true; $count++
  }
  if ($Limit -gt 0 -and $count -ge $Limit) { break }
  # advance the view one page: walk the selection down (the tree scrolls to follow it)
  for ($k = 0; $k -lt $rowsPerPage; $k++) { Send '{DOWN}' 60 }
  Start-Sleep -Milliseconds 300
}

$missing = $order | Where-Object { -not $done.ContainsKey($_) }
Write-Output ''
Write-Output ("extracted: {0} / {1}" -f $count, $map.Count)
if ($missing.Count -gt 0) {
  Write-Output ("missing ({0}) - likely inside collapsed folders:" -f $missing.Count)
  $missing | Select-Object -First 25 | ForEach-Object { Write-Output ("  - {0}" -f $_) }
}
if (-not $Write) { Write-Output 'DRY RUN - add -Write to write files.' }
