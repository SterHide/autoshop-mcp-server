# Shared AutoShop helpers, dot-sourced by the other tools (portability patches, skill 17.4/17.6).
# PURE ASCII ON PURPOSE.
#
# Why Get-AutoShopMainWindow exists (field report, skill 17.4):
#   .NET's Process.MainWindowHandle is "the first VISIBLE, OWNER-LESS top-level window of the process".
#   Park the mouse over AutoShop's toolbar (e.g. after clicking Save) and Windows shows a tooltip plus a
#   top-level SysShadow window (~90x27, visible, owner-less) -- MainWindowHandle then returns THAT, so every
#   script reports "main window is minimized or off-screen rect={176,180 180x54}" while AutoShop looks fine.
#   So find the main window by IDENTITY instead: the largest visible top-level window of the process whose
#   class starts with 'Afx:' and whose title contains 'AutoShop'.
#
# Why Park-Cursor exists: clicking the toolbar leaves the mouse on it -> tooltip -> the trap above.
# Park it on empty desktop instead (just inside the taskbar-free area, far from the window).

if (-not ('SH' -as [type])) {
  Add-Type -Namespace SH -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, ref int pid);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

function Get-AutoShopWindowText([IntPtr]$h) {
  $b = New-Object System.Text.StringBuilder 512; [void][SH.U]::GetWindowTextW($h, $b, 512); return $b.ToString()
}
function Get-AutoShopWindowClass([IntPtr]$h) {
  $b = New-Object System.Text.StringBuilder 256; [void][SH.U]::GetClassNameW($h, $b, 256); return $b.ToString().Trim()
}

# The robust main window. If the process is gone -> [IntPtr]::Zero. Falls back to MainWindowHandle only
# when the identity search finds nothing (older/short-lived states).
function Get-AutoShopMainWindow($Process) {
  $p = $Process
  if ($null -eq $p) { $p = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Select-Object -First 1 }
  if ($null -eq $p) { return [IntPtr]::Zero }
  $script:__shBest = [IntPtr]::Zero
  $script:__shArea = 0
  $script:__shPid = $p.Id
  $cb = [SH.U+EnumProc]{
    param($h, $x)
    if (-not [SH.U]::IsWindowVisible($h)) { return $true }
    $owner = [IntPtr]::Zero
    $wpid = 0
    [void][SH.U]::GetWindowThreadProcessId($h, [ref]$wpid)
    if ($wpid -ne $script:__shPid) { return $true }
    $cls = Get-AutoShopWindowClass $h
    $txt = Get-AutoShopWindowText $h
    if ($cls -notlike 'Afx:*') { return $true }
    if ($txt -notlike '*AutoShop*') { return $true }
    $r = New-Object SH.U+RECT; [void][SH.U]::GetWindowRect($h, [ref]$r)
    $area = ($r.Right - $r.Left) * ($r.Bottom - $r.Top)
    if ($area -gt $script:__shArea) { $script:__shArea = $area; $script:__shBest = $h }
    return $true
  }
  [void][SH.U]::EnumWindows($cb, [IntPtr]::Zero)
  if ($script:__shBest -ne [IntPtr]::Zero) { return $script:__shBest }
  return $p.MainWindowHandle
}

# Move the mouse off the app so no tooltip/SysShadow appears (see the note at the top).
function Park-Cursor([int]$X = 1900, [int]$Y = 1000) {
  try { [void][SH.U]::SetCursorPos($X, $Y) } catch { }
}
