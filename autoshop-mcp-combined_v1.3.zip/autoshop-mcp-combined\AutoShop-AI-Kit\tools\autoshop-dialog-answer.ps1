# List the visible modal dialogs of AutoShop and press ONE of their buttons (dialog-safe: no clicks,
# no foreground grab -- the button is driven with BM_CLICK).
#
# WHY WM_COMMAND AND NOT BM_CLICK: BM_CLICK is documented to work only while its dialog box is
# ACTIVE, and it silently does nothing otherwise -- measured on the "确认删除文件？" box, where
# BM_CLICK left the very same hwnd still up, while WM_COMMAND with the button's own control id
# (read with GetWindowLong(GWL_ID)) closed it immediately. The button is identified by POSITION, not
# by its Chinese caption, so this file stays pure ASCII: in AutoShop's dialogs the affirmative button
# (确定 / 是) is always the LEFT one and 取消 / 否 is the right one.
#
# Examples:
#   powershell -File autoshop-dialog-answer.ps1 -List              # just show what is up
#   powershell -File autoshop-dialog-answer.ps1 -Button OK         # press the left button
#   powershell -File autoshop-dialog-answer.ps1 -Button Cancel     # press the right button
param(
  [ValidateSet('OK','Cancel','None')][string]$Button = 'None',
  [switch]$List,
  [int]$Index = 0,          # which visible dialog to act on (0 = the first)
  [int]$WaitMs = 2000
)

$ErrorActionPreference = 'Stop'
if (-not ('G.U' -as [type])) {
if (-not ('G.U' -as [type])) {
Add-Type -Namespace G -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int idx);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, System.Text.StringBuilder lp);
[DllImport("user32.dll", EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
}
function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][G.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function WinTxt([IntPtr]$h){$b=New-Object System.Text.StringBuilder 512;[void][G.U]::SendMessageW($h,0x000D,[IntPtr]512,$b);$b.ToString()}
function RectOf([IntPtr]$h){$r=New-Object G.U+RECT;[void][G.U]::GetWindowRect($h,[ref]$r);return $r}
function VisibleDialogs {
  $l=New-Object System.Collections.ArrayList
  $cb=[G.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq '#32770' -and [G.U]::IsWindowVisible($h)){[void]$l.Add($h)};return $true }
  [void][G.U]::EnumWindows($cb,[IntPtr]::Zero); return $l }

$dl = @(VisibleDialogs)
Write-Output ("visible #32770 dialogs: {0}" -f $dl.Count)
$i = 0
foreach ($d in $dl) {
  $r = RectOf $d
  Write-Output ("  [{0}] hwnd={1} title='{2}' {{ {3},{4} {5}x{6} }} enabled={7}" -f $i,$d,(WinTxt $d),$r.Left,$r.Top,($r.Right-$r.Left),($r.Bottom-$r.Top),[G.U]::IsWindowEnabled($d))
  $kids = New-Object System.Collections.ArrayList
  $cb2 = [G.U+EnumProc]{ param($h,$p) [void]$kids.Add($h); return $true }
  [void][G.U]::EnumChildWindows($d,$cb2,[IntPtr]::Zero)
  foreach ($k in $kids) {
    $c = ClsOf $k
    if ($c -eq 'Button' -or $c -eq 'Static' -or $c -eq 'Edit') {
      $kr = RectOf $k
      Write-Output ("        {0,-8} '{{ {1},{2} {3}x{4} }}' text='{5}'" -f $c,$kr.Left,$kr.Top,($kr.Right-$kr.Left),($kr.Bottom-$kr.Top),(WinTxt $k))
    }
  }
  $i++
}

if ($List -or $Button -eq 'None') { exit 0 }
if ($dl.Count -eq 0) { throw 'no visible dialog to answer' }
if ($Index -ge $dl.Count) { throw ("-Index {0} out of range ({1} dialogs)" -f $Index,$dl.Count) }
$dlg = $dl[$Index]

$kids = New-Object System.Collections.ArrayList
$cb3 = [G.U+EnumProc]{ param ($h,$p) if((ClsOf $h) -eq 'Button'){[void]$kids.Add($h)}; return $true }
[void][G.U]::EnumChildWindows($dlg,$cb3,[IntPtr]::Zero)
if ($kids.Count -eq 0) { throw 'the dialog has no Button' }
$sorted = @($kids | Sort-Object { (RectOf $_).Left })
if ($Button -eq 'OK')     { $target = $sorted[0] }
else                      { $target = $sorted[$sorted.Count-1] }
$tr = RectOf $target
$btnId = [G.U]::GetWindowLong($target,-12)          # GWL_ID
Write-Output ("pressing the {0} button (x={1}, control id={2})" -f $Button,$tr.Left,$btnId)

# attempt 1: WM_COMMAND + BN_CLICKED (works even when the dialog is not the active window)
[void][G.U]::SendMessageW($dlg,0x0111,[IntPtr]$btnId,$target)     # WM_COMMAND, wParam=MAKELONG(id,BN_CLICKED)
Start-Sleep -Milliseconds $WaitMs
if ((@(VisibleDialogs)).Count -eq 0) { Write-Output '  closed via WM_COMMAND'; exit 0 }

# attempt 2: BM_CLICK (only effective while the dialog is active)
Write-Output '  still up - trying BM_CLICK'
[void][G.U]::SendMessageW($target,0x00F5,[IntPtr]::Zero,[IntPtr]::Zero)
Start-Sleep -Milliseconds $WaitMs
if ((@(VisibleDialogs)).Count -eq 0) { Write-Output '  closed via BM_CLICK'; exit 0 }

# attempt 3: a real mouse click on the button centre
Write-Output '  still up - trying a real mouse click'
[void][G.U]::SetCursorPos([int](($tr.Left+$tr.Right)/2),[int](($tr.Top+$tr.Bottom)/2))
Start-Sleep -Milliseconds 200
[G.U]::mouse_event(0x02,0,0,0,0)
Start-Sleep -Milliseconds 80
[G.U]::mouse_event(0x04,0,0,0,0)
Start-Sleep -Milliseconds $WaitMs

$dl2 = @(VisibleDialogs)
Write-Output ("dialogs still up after the press: {0}" -f $dl2.Count)
foreach ($d in $dl2) { Write-Output ("  still: title='{0}'" -f (WinTxt $d)) }
