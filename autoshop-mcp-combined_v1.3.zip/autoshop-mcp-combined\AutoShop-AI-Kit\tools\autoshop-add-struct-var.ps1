# Append a STRUCT-typed variable (parent row + every member row) to a variable table and import it.
#
# This is the ONE command for "add UN_stXXX : ST_XXX to a GVL", distilled from the 2026-09-20 session.
# Every trap found that day is baked in here:
#   * the export ends with a BLANK LINE -- appending after it makes the importer stop at the blank line
#     and silently drop the whole block (8 failed attempts). We strip trailing blanks FIRST.
#   * every row needs exactly 10 fields; the initial value sits in field 5:
#       <seq>,<Var>,<Struct>,,,,,,,                 (parent)
#       ,<Var>.<member>,<type>,<init>,,,<comment>,, (member; BOOL->OFF, INT/DINT->0, STRING->empty)
#   * the struct DESIGN file is 3 columns (name,dataType,comment) UTF-8-BOM, while the table export is
#     GB2312 -- mixing them up produced rows whose "name" was actually a type. Both are forced here.
#   * dismiss the success box BEFORE clicking Save (a Save click while the modal is up is swallowed).
#   * match dialog buttons by TEXT/position, never by id (id 2 is OK in one box and Cancel in another).
#
# Chinese (variable name, struct name, paths) is passed in as PARAMETERS -- a Chinese literal inside a
# .ps1 is read as ANSI by PowerShell 5.1 and breaks the parser. KEEP THIS FILE PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$Table,          # e.g. GVL_UN层  (view title / table name)
  [Parameter(Mandatory=$true)][string]$VarName,        # e.g. UN_st真空吸
  [Parameter(Mandatory=$true)][string]$StructName,     # e.g. ST_真空吸
  [Parameter(Mandatory=$true)][string]$StructDesign,   # 3-col design CSV (UTF-8 BOM): name,dataType,comment
  [Parameter(Mandatory=$true)][string]$TableDir,       # directory of the table's CSV inside the mirror
  [Parameter(Mandatory=$true)][string]$ProjectDir,
  [Parameter(Mandatory=$true)][string]$MirrorDir,
  [string]$DropVars = '',                              # comma-separated variable names to REMOVE first
  [int]$MenuOffsetY = 394,                             # export row offset (GVL: 394; FB/FC grid: 430)
  [int]$ImportOffsetY = 420,                           # import row offset (GVL: 420; FB/FC grid: 456)
  [int]$ExpectedMenuH = 632,                           # GVL 632; FB/FC grid 512; FB-instance 476
  [switch]$NoSave
)
$ErrorActionPreference = 'Stop'
$Tools = $PSScriptRoot
$gbk   = [System.Text.Encoding]::GetEncoding('GB2312')
$u8bom = New-Object System.Text.UTF8Encoding($true)
$View  = $Table
$csvPath = Join-Path $TableDir ($Table + '.csv')

Write-Output ('=== 1/4 refresh the table from AutoShop (the baseline must be current) ===')
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Tools 'autoshop-extract-blocks2.ps1') `
  -ProjectDir $ProjectDir -MirrorDir $MirrorDir -TableNames $Table -TableOutDir $TableDir -ExpandFolded `
  -Limit 1 -Redo -MenuOffsetY $MenuOffsetY -ExpectedMenuH $ExpectedMenuH | Select-String 'VAR |failed \(' |
  ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }

Write-Output '=== 2/4 build the import file ==='
$lines = New-Object System.Collections.Generic.List[string]
foreach ($l in ($gbk.GetString([System.IO.File]::ReadAllBytes($csvPath)) -split "`r`n|`n")) { [void]$lines.Add($l) }
$stripped = 0
while ($lines.Count -gt 0 -and $lines[$lines.Count-1] -eq '') { $lines.RemoveAt($lines.Count-1); $stripped++ }

# drop the variables we are replacing (so a re-run does not duplicate them)
$drops = @()
if ($DropVars -ne '') { $drops = @($DropVars -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }
# the variable itself is always replaced
$allDrops = @($drops + $VarName) | Sort-Object -Unique
$kept = New-Object System.Collections.Generic.List[string]
$dropped = 0
foreach ($l in $lines) {
  $f = $l -split ','
  $v = if ($f.Count -gt 1) { $f[1] } else { '' }
  $hit = $false
  foreach ($d in $allDrops) { if ($v -eq $d -or $v.StartsWith($d + '.')) { $hit = $true; break } }
  if ($hit) { $dropped++; continue }
  [void]$kept.Add($l)
}
$max = 0
foreach ($l in $kept) { if ($l -match '^(\d+),') { $n = [int]$Matches[1]; if ($n -gt $max) { $max = $n } } }
Write-Output ("  baseline {0} rows; stripped {1} trailing blank line(s); removed {2} row(s) of [{3}]; max seq {4}" -f `
  $lines.Count, $stripped, $dropped, ($allDrops -join '/'), $max)

$design = @($u8bom.GetString([System.IO.File]::ReadAllBytes($StructDesign)) -split "`r`n|`n" | Where-Object { $_ -ne '' })
[void]$kept.Add(('{0},{1},{2},,,,,,,' -f ($max + 1), $VarName, $StructName))
$n = 0
foreach ($r in ($design | Select-Object -Skip 1)) {
  $p = $r -split ','
  if ($p.Count -lt 2) { continue }
  $nm = $p[0]; $ty = $p[1]
  $cm = if ($p.Count -ge 3) { ((($p[2..($p.Count-1)]) -join ',') -replace '^"|"$','') } else { '' }
  $init = if ($ty -eq 'BOOL') { 'OFF' } elseif ($ty -match '^(INT|DINT)$') { '0' } else { '' }
  [void]$kept.Add((",{0}.{1},{2},,{3},,,{4},," -f $VarName, $nm, $ty, $init, $cm)); $n++
}
$outPath = Join-Path $TableDir ($Table + '_with_' + $VarName + '.csv')
[System.IO.File]::WriteAllText($outPath, (($kept -join "`r`n") + "`r`n"), $gbk)
Write-Output ("  wrote {0}  (parent row seq {1} + {2} member rows)" -f $outPath, ($max + 1), $n)

# the blank-line rule is the whole ballgame -- prove it before importing
$chk = @($gbk.GetString([System.IO.File]::ReadAllBytes($outPath)) -split "`r`n|`n")
$idx = -1
for ($k = 0; $k -lt $chk.Count; $k++) { if ($chk[$k] -match ('^{0},' -f ($max + 1))) { $idx = $k; break } }
if ($idx -le 0) { throw 'could not locate the new parent row in the file' }
if ($chk[$idx-1] -eq '') { throw 'ABORT: the new block would sit under a BLANK LINE (the importer stops there)' }
Write-Output ("  new block starts at line {0}; the line above is [{1}] -- not blank OK" -f $idx, $chk[$idx-1])

Write-Output '=== 3/4 open the view and import ==='
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Tools 'autoshop-open-node.ps1') -Node $View 2>&1 |
  Select-String 'hitTest|title' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Start-Sleep -Milliseconds 900
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Tools 'autoshop-import-vartable.ps1') `
  -View $View -CsvPath $outPath -ImportOffsetY $ImportOffsetY -ExpectedMenuH $ExpectedMenuH -ConfirmImport -NoSave 2>&1 |
  Select-String 'import prompt|clipboard|NO file|STALL' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Start-Sleep -Milliseconds 1000

Write-Output '=== 4/4 dismiss the success box, then save ==='
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Tools 'confirm-then-save.ps1') -ProjectDir $ProjectDir @(if ($NoSave) { '-NoSave' } else { @() }) 2>&1 |
  Select-String 'pressed|dismissed|clicking Save|dialogs left|hcp|gvt' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
