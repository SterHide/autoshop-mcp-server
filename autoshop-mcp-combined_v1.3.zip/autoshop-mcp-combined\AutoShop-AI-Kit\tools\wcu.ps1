param([Parameter(Mandatory=$true)][string]$Action)
# Thin wrapper around the dsh-computer-use-win engine.
# - Reads its JSON args from STDIN (avoids argument-quoting mangling).
# - NEVER prints the inline base64 screenshot payload (it floods stdout).
$engine = "C:\Users\Administrator\.dsh\profiles\desktop\node_modules\dsh-computer-use-win\scripts\windows-uia.ps1"
$ps51   = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

$Json = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($Json)) { $Json = '{}' }

$raw = $Json | & $ps51 -NoProfile -ExecutionPolicy Bypass -File $engine -Action $Action 2>&1 | Out-String
try { $o = $raw | ConvertFrom-Json } catch {
  Write-Output "PARSE_FAIL: $($raw.Substring(0,[Math]::Min(800,$raw.Length)))"; exit 1
}

function Strip-LongStrings($obj) {
  if ($null -eq $obj) { return }
  if ($obj -is [System.Management.Automation.PSCustomObject]) {
    foreach ($p in @($obj.PSObject.Properties)) {
      if ($p.Value -is [string] -and $p.Value.Length -gt 160) {
        $len = $p.Value.Length
        $obj.PSObject.Properties.Remove($p.Name)
        $obj | Add-Member -NotePropertyName ("$($p.Name)_omittedChars") -NotePropertyValue $len -Force
      } else { Strip-LongStrings $p.Value }
    }
  } elseif ($obj -is [System.Collections.IEnumerable] -and $obj -isnot [string]) {
    foreach ($i in $obj) { Strip-LongStrings $i }
  }
}
Strip-LongStrings $o
$o | ConvertTo-Json -Depth 8
