# OCR a PNG/JPEG file on disk using the Windows built-in Windows.Media.Ocr engine.
#
# WHY THIS EXISTS
#   The computer-use engine's `ocr` action can only capture a live window / the desktop.
#   A transient popup (context menu) that vanishes as soon as the mouse moves can therefore
#   not be read reliably, and this agent cannot view images directly either.
#   With this script, a screenshot saved to disk (e.g. via Win+Shift+S) can be read as text.
#
# USAGE
#   powershell -NoProfile -ExecutionPolicy Bypass -File ocr-file.ps1 -Path <png> [-Words] [-MaxWidth 0]
#     -Words      also print every word with its pixel bounding box (x,y,w,h)
#     -MaxWidth   downscale before OCR if the image is wider than this (0 = no downscale)
param(
  [Parameter(Mandatory = $true)][string]$Path,
  [switch]$Words,
  [int]$MaxWidth = 0
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $Path)) { Write-Output "FILE NOT FOUND: $Path"; exit 1 }

# --- load WinRT projections -------------------------------------------------
Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null
[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
[Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType = WindowsRuntime] | Out-Null

# --- generic IAsyncOperation<T> awaiter ------------------------------------
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

function Await($op, $type) {
  $netTask = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}

# --- optional downscale -----------------------------------------------------
$work = $Path
if ($MaxWidth -gt 0) {
  Add-Type -AssemblyName System.Drawing | Out-Null
  $img = [System.Drawing.Image]::FromFile($Path)
  if ($img.Width -gt $MaxWidth) {
    $h = [int]($img.Height * $MaxWidth / $img.Width)
    $bmp = New-Object System.Drawing.Bitmap $MaxWidth, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.DrawImage($img, 0, 0, $MaxWidth, $h)
    $g.Dispose()
    $work = Join-Path $env:TEMP ("ocr-file-" + [guid]::NewGuid().ToString('N') + ".png")
    $bmp.Save($work, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Output "note: downscaled $($img.Width)x$($img.Height) -> ${MaxWidth}x${h}"
  }
  $img.Dispose()
}

# --- OCR --------------------------------------------------------------------
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($work)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { Write-Output "no OCR engine for user profile languages"; exit 2 }

$result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

Write-Output "=== OCR TEXT ($($result.Lines.Count) lines) ==="
Write-Output $result.Text

if ($Words) {
  Write-Output ""
  Write-Output "=== WORDS (x,y,w,h) ==="
  foreach ($line in $result.Lines) {
    foreach ($w in $line.Words) {
      $r = $w.BoundingRect
      Write-Output ("  {0,-14} {1,5} {2,5} {3,4} {4,4}" -f $w.Text, [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height)
    }
  }
}

$stream.Dispose()
