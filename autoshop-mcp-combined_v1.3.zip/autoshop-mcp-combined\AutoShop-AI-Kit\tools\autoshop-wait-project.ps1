# Poll the autoshop-mcp-server until the open AutoShop window reports a project path,
# i.e. until autoshop_detect_open_instances returns selected_instance.projectPath.
# This is exactly the condition the MCP needs before any project-level tool can auto-locate the project.
param(
  [int]$TimeoutSeconds = 150,
  [int]$IntervalSeconds = 5,
  [int]$Port = 18711
)

Add-Type -AssemblyName System.Net.Http
$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromSeconds(20)
$body = '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"autoshop_detect_open_instances","arguments":{"response_format":"json"}}}'
$deadline = (Get-Date).AddSeconds($TimeoutSeconds)

while ((Get-Date) -lt $deadline) {
  try {
    $request = New-Object System.Net.Http.HttpRequestMessage ([System.Net.Http.HttpMethod]::Post), "http://127.0.0.1:$Port/mcp"
    [void]$request.Headers.Add('Accept', 'application/json, text/event-stream')
    $request.Content = New-Object System.Net.Http.StringContent ($body, [Text.Encoding]::UTF8, 'application/json')
    $response = $client.SendAsync($request).Result
    $text = $response.Content.ReadAsStringAsync().Result
    $obj = $text | ConvertFrom-Json
    $instance = $obj.result.structuredContent.selected_instance

    if ($instance.projectPath) {
      Write-Output "PROJECT DETECTED at $(Get-Date -Format 'HH:mm:ss')"
      Write-Output ($instance | ConvertTo-Json -Depth 6)
      exit 0
    }
    Write-Output "$(Get-Date -Format 'HH:mm:ss')  still no project - title: '$($instance.mainWindowTitle)'"
  }
  catch {
    Write-Output "$(Get-Date -Format 'HH:mm:ss')  request failed: $($_.Exception.Message)"
  }
  Start-Sleep -Seconds $IntervalSeconds
}

Write-Output "TIMED OUT after ${TimeoutSeconds}s - no project path in the AutoShop window title yet."
exit 1
