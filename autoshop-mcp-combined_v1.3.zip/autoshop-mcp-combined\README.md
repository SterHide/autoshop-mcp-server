# autoshop-mcp-combined

把两个汇川 AutoShop MCP 聚合成**一个** MCP 服务器（stdio），共 41 个工具：

| 前缀 | 后端 | 能力 |
|---|---|---|
| `kit_` | AutoShop-AI-Kit（UI 自动化 + 已并入的桥功能） | 工程树、开关节点视图、读写 ST 源码、保存、表格导入导出、新建/删除块（14）+ 进程探活标题解析、离线读 folder.txt 程序树与 CSV 符号表、对话框扫描/按 hwnd 精确点按钮（5），共 19 工具 |
| `r_` | autoshop-mcp-server v1.5.1（只读解读） | LD/FB 二进制源码提取、块/项目解读、调用图、符号搜索、LD→ST 生成（22 工具） |

聚合方式：FastMCP 4.x `ProxyProvider` + 多后端 `MCPConfig`，零自研桥接代码，启动时自动连接两个后端并发现全部工具，工具名自动加 `kit_` / `r_` 前缀防冲突。原 plc-bridges 桥的 5 个工具已直接并入 Kit 的 `server.mjs`（成为 `kit_autoshop_status` 等），不再有独立 `b_` 后端。

## 目录结构

```
autoshop-mcp-combined/
├── proxy.py                  # 聚合入口（相对路径解析，解压即用）
├── requirements.txt          # Python 依赖（fastmcp==4.1.8）
├── mcp-config.example.json   # MCP 客户端注册样例
├── register-combined.ps1     # 写 Codex config.toml：默认 dry run，-Apply 前自动备份
├── verify-combined.ps1       # 自检入口（起 proxy → 列工具 → 跑只读调用）
├── verify-combined.py        # 自检本体，UTF-8 输出，--call / --call-file 传参
├── verify-calls.example.json # 只读调用清单样例（指向副本工程）
├── AutoShop-AI-Kit/
│   ├── mcp/server.mjs        # Kit MCP 服务器（Node）：14 个 UI 自动化工具 + 5 个并入的原桥工具
│   ├── tools/*.ps1           # UI 自动化脚本（已打多实例过滤补丁）+ winprobe.ps1 / uia-dump.ps1 探针
│   ├── SKILL.md / AUTOSHOP_操作要点.md / README.md
└── autoshop-mcp-server/
    ├── dist/                 # 解读版编译产物（可直接运行）
    ├── src/ docs/ examples/ manifest/
    └── package.json / package-lock.json / tsconfig.json
```

## 依赖与安装

1. **Node.js 18+**（两个后端都是 Node 程序）
2. **Python 3.10+**，安装聚合层依赖：
   ```
   pip install -r requirements.txt
   ```
3. **恢复解读版依赖**（本包不含 node_modules，约 52 MB）：
   ```
   cd autoshop-mcp-server
   npm install
   ```
   dist 运行需要 @modelcontextprotocol/sdk、express、zod 等依赖，`npm install` 后无需再 `tsc`。
   **这一步不能省**：少了 node_modules，`r_` 后端起不来。

## 环境变量

| 变量 | 作用 | 默认 |
|---|---|---|
| `AUTOSHOP_MCP_NODE` | 两个后端的 Node 解释器 | PATH 里的 `node` |
| `AUTOSHOP_EXE` | AutoShop 主程序（`kit_autoshop_project_open` 启动工程用） | `D:\app\major\INOVANCE\AutoShop\AutoShop.exe` |
| `AUTOSHOP_TOOLS_DIR` | Kit 的 ps1 目录 | 包内 `AutoShop-AI-Kit\tools` |
| `AUTOSHOP_TITLE_FILTER` | 多实例时按标题锁定目标实例 | 未设（兜底排除无盘符标题） |
| `AUTOSHOP_COMBINED_BACKENDS` | 只启用部分后端 `kit,r` | 两个全开 |

**别用 `AUTOSHOP_COMBINED_BACKENDS` 裁到只剩一个后端**：FastMCP 只在多后端时才加前缀，单后端时工具名变成裸的 `autoshop_status`，脚本和 SOP 里的名字会全部对不上。它只用来排障定位是哪个后端坏了。

## 注册到 MCP 客户端（mcp.json）

```json
{
  "mcpServers": {
    "autoshop": {
      "command": "C:\\path\\to\\python.exe",
      "args": ["D:\\AI\\MCP\\autoshop-mcp-combined\\proxy.py"],
      "cwd": "D:\\AI\\MCP\\autoshop-mcp-combined"
    }
  }
}
```

- `proxy.py` 内部用**相对自身的路径**找后端，解压到任意目录均可运行。
- Node 不在 PATH 时，设置环境变量 `AUTOSHOP_MCP_NODE` 指向 node.exe 完整路径。
- 配置后需在客户端的连接器管理页对新条目点“信任”才会启用。

### Codex 桌面版

```
pwsh -File register-combined.ps1          # 先看 dry run
pwsh -File register-combined.ps1 -Apply   # 备份 config.toml.bak-autoshop-combined-<stamp> 后写入
```

它把 `[mcp_servers.autoshop]` 换成指向 `proxy.py`，并删掉旧的 `autoshop` 块（含 `[mcp_servers.autoshop.env]` 子表）。python 依次试包内 `.venv`、PATH、`.workbuddy`，**只认能 `import fastmcp` 的那个**。写完要重启 Codex。

一个名字只能有一个入口。要是 `plc-bridges\register-bridges.ps1` 又把 `autoshop` 写回单桥，合并就白做了——那边已加闸，默认不碰 `autoshop`，除非显式 `-WithAutoshop`。

## 多 AutoShop 实例注意事项（Kit 工具）

Kit 的 ps1 脚本通过窗口标题选择 AutoShop 实例，已打补丁：

- 设置 `AUTOSHOP_TITLE_FILTER`（如 `DAA-副本`）→ 只匹配标题含该串的实例；
- 未设置时兜底：标题**不含盘符路径**（`*:\*`）的视为临时工程/活动工程实例。

在 MCP 配置的 `env` 里加 `"AUTOSHOP_TITLE_FILTER": "工程名"` 即可，多个实例同时打开时强烈建议设置。

推荐做法：先调 `kit_autoshop_status` 列出全部 AutoShop 实例（pid + 工程目录 + 当前程序），确认目标工程后再把工程名填进 `AUTOSHOP_TITLE_FILTER`，避免 Kit 选错实例。

## 并入的原桥工具（现为 kit_ 前缀）

- `kit_autoshop_status`：探活/列实例，从窗口标题解析 version/projectDir/currentProgram，只读。
- `kit_autoshop_project_inspect`：不开 IDE 离线读工程（folder.txt 程序树 + CSV 符号表 UTF-16LE/GBK 自适应 + 加密源清单）；`.LD/.ST` 正文为厂商家密文，不解密。
- `kit_autoshop_bridge_dialog_scan` + `kit_autoshop_bridge_dialog_click`：标准 Win32 对话框（确认删除、报错框）用 scan 拿按钮 hwnd 后精确点击，比像素偏移安全。
- AutoShop 主程序不在默认路径时：在 MCP 配置 `env` 加 `"AUTOSHOP_EXE": "C:\\...\\AutoShop.exe"`。

## 版本快照信息

- AutoShop-AI-Kit tools：2026-11-13 已打 `AUTOSHOP_TITLE_FILTER` 补丁版（备份 tools_bak_20261113 未包含在包内）；含 winprobe.ps1 / uia-dump.ps1（原桥的 Win32 探针，并入工具依赖）
- autoshop-mcp-server：v1.5.1，dist 已预编译（TypeScript 源码一并附带）
- FastMCP：4.1.8（4.x 已移除 `as_proxy`，须用 `add_provider(ProxyProvider(...))` 写法）
- 原 plc-bridges/autoshop-mcp 桥：已并入 Kit server.mjs（单文件、零依赖、AutoShop V4.12.0.0 实测通过），独立后端已删除

## 快速自检

```
pwsh -File verify-combined.ps1 -Python <带 fastmcp 的 python>
```

默认只跑离线只读调用（`r_autoshop_scan_project` + `kit_autoshop_project_inspect`，指向副本工程），不动 AutoShop 界面。加 `-Calls <json>` 换调用清单，加 `-Backends kit` 单独查某个后端。

本机 2026-11-13 实测：`TOTAL=41 kit=19 r=22`；`r_autoshop_scan_project` 出 5 个程序（4 LD + 1 ST）/1 功能块/8 变量表；`kit_autoshop_project_inspect` 出 12 节点树、`变量表.csv` 83 个符号、17 个加密正文，中文节点名正常。

`kit_*` 工具要连着 AutoShop 才能验，需干净桌面：关掉所有 AutoShop → 开副本工程 → `kit_autoshop_preflight`（先不带 fix）→ `kit_autoshop_tree`。Kit 的像素偏移是在 4.11.0.5 / 4.12.0.2 标定的，本机 4.12.0.0 **尚未复验**，别一上来就写。
