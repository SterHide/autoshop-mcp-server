# Press a button in a visible top-level dialog (#32770) by matching its TITLE and the BUTTON TEXT.
#
# WHY: BM_CLICK does nothing on a dialog that is not active, and SendKeys/ESC goes to whatever window
# has the foreground - which is often NOT the dialog (e.g. the DSH window). WM_COMMAND with the
# button's control id (GetWindowLong(hwnd,-12)) works regardless of activation state; that is the
# channel already used by autoshop-dialog-answer.ps1 / autoshop-close-all-blocks.ps1.
#
# Usage:
#   ... -File press-dialog-button.ps1 -List                                  # list dialogs + buttons
#   ... -File press-dialog-button.ps1 -Title '另存为' -ButtonText '取消'      # cancel a Save-As box
#   ... -File press-dialog-button.ps1 -Title 'AutoShop' -ButtonText '确定'
# KEEP PURE ASCII.
param(
  [string]$Title = '',
  [string]$ButtonText = '',
  [switch]$List
)
$ErrorActionPreference = 'Stop'
if (-not ('PB.U' -as [type])) {
Add-Type -Namespace PB -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int idx);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
'@
}
function ClsOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 256; [void][PB.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 512; [void][PB.U]::GetWindowTextW($h,$b,512); $b.ToString() }

$dialogs = New-Object System.Collections.ArrayList
$cb = [PB.U+EnumProc]{
  param($h,$x)
  if ([PB.U]::IsWindowVisible($h) -and (ClsOf $h) -eq '#32770') { [void]$dialogs.Add($h) }
  return $true
}
[void][PB.U]::EnumWindows($cb, [IntPtr]::Zero)

if ($dialogs.Count -eq 0) { Write-Output 'no visible #32770 dialogs'; exit 0 }

$picked = [IntPtr]::Zero
foreach ($d in $dialogs) {
  $t = TxtOf $d
  $isMatch = $false
  if ($Title) { if ($t -like "*$Title*") { $isMatch = $true } } else { $isMatch = $true }
  if ($List) { Write-Output ("dialog hwnd={0} title='{1}'{2}" -f $d, $t, $(if($isMatch){'  <== match'}else{''})) }
  if ($isMatch -and $picked -eq [IntPtr]::Zero) { $picked = $d }

  $btns = New-Object System.Collections.ArrayList
  $cb2 = [PB.U+EnumProc]{
    param($h,$x)
    if ((ClsOf $h) -eq 'Button') { [void]$btns.Add([pscustomobject]@{H=$h; Id=[PB.U]::GetWindowLong($h,-12); T=(TxtOf $h)}) }
    return $true
  }
  [void][PB.U]::EnumChildWindows($d, $cb2, [IntPtr]::Zero)
  foreach ($b in $btns) { if ($List) { Write-Output ("    Button id={0,-6} text='{1}'" -f $b.Id, $b.T) } }

  if (-not $List -and $isMatch -and $ButtonText) {
    $hit = $btns | Where-Object { $_.T -like "*$ButtonText*" } | Select-Object -First 1
    if ($hit) {
      Write-Output ("pressing '{0}' (id={1}) in dialog '{2}' via WM_COMMAND" -f $hit.T, $hit.Id, $t)
      [void][PB.U]::SendMessageW($d, 0x0111, [IntPtr]$hit.Id, [IntPtr]$hit.H)
      Start-Sleep -Milliseconds 800
      Write-Output ("dialog still visible: {0}" -f [PB.U]::IsWindowVisible($d))
      exit 0
    } else {
      Write-Output ("no button matching '{0}' in dialog '{1}'" -f $ButtonText, $t)
    }
  }
}
if (-not $List -and $picked -eq [IntPtr]::Zero) { Write-Output ("no dialog matching title '{0}'" -f $Title) }
