<#
.SYNOPSIS
  Create a NEW temporary project in Inovance AutoShop, driven by UI Automation.

.DESCRIPTION
  Why the menu clicks are mouse clicks
  ------------------------------------
  AutoShop is a classic MFC app whose menu bar is NOT exposed through UI Automation
  (the whole control tree is ~36 nodes and holds no menu items), and SendKeys
  accelerators (Alt+F) do not reach it either. So the File menu -> New Project pair
  has to be two real mouse clicks at points derived from the window frame.
  Measured on AutoShop V4.11.0.5, 1920x1200 @100% DPI, Win10 1903,
  with the UIA window box at (883,118):
      "File(F)" menu item        click (926,161) => window-relative (+43,+43)
      "New Project(N)" item      click (1000,190) => window-relative (+117,+72)
  The menu bar is ~22px tall, so roughly +/-10px of drift is tolerated.

  Why everything else keys off AutomationId
  -----------------------------------------
  The New Project dialog is a plain Win32 #32770 and is UIA-addressable, BUT its
  owner-drawn controls are all reported as ControlType.Pane and support ZERO UIA
  patterns: FindAll by ControlType returns 0 rows and SelectionItemPattern throws
  "Unsupported Pattern". Only AutomationId is stable. Measured ids:
      1380 = New Project radio    1145 = Temporary Project radio
      1052 = project-name edit    1056 = save-path edit
      1045 = series/model combo   1046 = editor combo
         1 = OK button               2 = Cancel button
  So selection falls back to a mouse click on the element's bounding box, and the
  result is verified indirectly: in Temporary Project mode the project-name edit
  (1052) must become DISABLED.

  The dialog is an OWNED CHILD of the AutoShop frame, not a top-level window, so it
  must be reached by descending from the main window - never by windowTitle.

  Safety
  ------
  The script proceeds only if the dialog it finds actually CONTAINS radio 1145. If a
  different dialog appears (e.g. a "save current project?" prompt) it STOPS without
  clicking anything.

  This source is pure ASCII on purpose: the Chinese UI strings are built from code
  points, so the file needs no BOM and cannot be mangled by PowerShell 5.1 reading
  a BOM-less file as ANSI.

.PARAMETER DryRun
  Do everything up to (but not including) pressing OK, verify the dialog state, then
  press Cancel.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-new-temp-project.ps1 -DryRun
  powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-new-temp-project.ps1
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$DryRun,
    [int]$MenuDx = 43,
    [int]$MenuDy = 43,
    [int]$ItemDx = 117,
    [int]$ItemDy = 72,
    [int]$DialogWaitMs = 8000
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName UIAutomationClient
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class WcuMouse {
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    private const uint LEFTDOWN = 0x0002, LEFTUP = 0x0004;
    public static void Click(int x, int y) {
        SetCursorPos(x, y);
        System.Threading.Thread.Sleep(70);
        mouse_event(LEFTDOWN, 0, 0, 0, IntPtr.Zero);
        System.Threading.Thread.Sleep(50);
        mouse_event(LEFTUP, 0, 0, 0, IntPtr.Zero);
    }
}
"@

# --- Chinese UI strings built from code points, so this file stays pure ASCII ---
# U+4E34 U+65F6 U+5DE5 U+7A0B = "lin shi gong cheng" (Temporary Project)
$S_TEMP_PROJECT = -join ([char]0x4E34, [char]0x65F6, [char]0x5DE5, [char]0x7A0B)
# U+786E U+5B9A = OK          U+53D6 U+6D88 = Cancel
$S_OK     = -join ([char]0x786E, [char]0x5B9A)
$S_CANCEL = -join ([char]0x53D6, [char]0x6D88)

# UIA -> Win32 scale factor (recomputed once from main window geometry below).
# This script process is DPI-unaware: Win32 rects and SetCursorPos share the
# virtualized LOGICAL coordinate system, while UIA BoundingRectangle reports
# PHYSICAL pixels (measured ratio 1.75 on a 175% display). Never mix them.
$script:ScaleX = 1.0
$script:ScaleY = 1.0

$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
function P($prop, $val) { New-Object System.Windows.Automation.PropertyCondition($prop, $val) }

function Get-MainWindow {
    $p = Get-Process -Name AutoShop -ErrorAction SilentlyContinue |
         Where-Object { (Get-AutoShopMainWindow $_) -ne 0 } | Select-Object -First 1
    if (-not $p) { throw 'AutoShop is not running (no process with a main window).' }
    return $AE::FromHandle((Get-AutoShopMainWindow $p))
}

function Get-NewProjectDialog($main) {
    foreach ($d in $main.FindAll($TS::Descendants, (P $AE::ClassNameProperty '#32770'))) {
        if ($d.FindFirst($TS::Descendants, (P $AE::AutomationIdProperty '1145'))) { return $d }
    }
    return $null
}

function Get-ById($scope, $id) {
    return $scope.FindFirst($TS::Descendants, (P $AE::AutomationIdProperty $id))
}

# Activate an element: prefer a semantic pattern, fall back to a real mouse click.
function Invoke-Element($el, $label) {
    $pat = $null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$pat)) {
        if (-not $pat.Current.IsSelected) { $pat.Select() }
        return 'SelectionItemPattern'
    }
    $pat = $null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$pat)) {
        $pat.Invoke()
        return 'InvokePattern'
    }
    $b = $el.Current.BoundingRectangle
    if ($b.Width -le 0 -or $b.Height -le 0) { throw "$label has no pattern and no usable bounding box." }
    # UIA rect = PHYSICAL pixels, SetCursorPos = LOGICAL pixels -> divide by measured scale.
    $cx = [int](($b.X + $b.Width / 2) / $script:ScaleX)
    $cy = [int](($b.Y + $b.Height / 2) / $script:ScaleY)
    [WcuMouse]::Click($cx, $cy)
    return 'mouse-click'
}

# ---------- 1. find + activate ----------
$main = Get-MainWindow
$hw = [IntPtr]$main.Current.NativeWindowHandle
[void][WcuMouse]::SetForegroundWindow($hw)
Start-Sleep -Milliseconds 600

# Menu clicks MUST use the Win32 LOGICAL rect (same coordinate system as SetCursorPos).
# UIA BoundingRectangle is PHYSICAL; the UIA/Win32 width ratio gives the live scale.
$ur = $main.Current.BoundingRectangle
$wr = New-Object SH.U+RECT
[void][SH.U]::GetWindowRect($hw, [ref]$wr)
$rx = $wr.Left; $ry = $wr.Top
$sw = $wr.Right - $wr.Left; $sh = $wr.Bottom - $wr.Top
if ($sw -gt 0 -and $sh -gt 0 -and $ur.Width -gt 0) { $script:ScaleX = [double]$ur.Width / $sw; $script:ScaleY = [double]$ur.Height / $sh }
Write-Host ("AutoShop : {0}" -f $main.Current.Name)
Write-Host ("window   : x={0} y={1} w={2} h={3} (win32 logical)  uia/win32 = {4:F2},{5:F2}" -f $rx, $ry, $sw, $sh, $script:ScaleX, $script:ScaleY)

# ---------- 2. File(F) -> New Project(N) ----------
[WcuMouse]::Click(($rx + $MenuDx), ($ry + $MenuDy))
Start-Sleep -Milliseconds 1200
[WcuMouse]::Click(($rx + $ItemDx), ($ry + $ItemDy))

# ---------- 3. wait for the right dialog, touch nothing else ----------
$dlg = $null
$deadline = (Get-Date).AddMilliseconds($DialogWaitMs)
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 400
    $dlg = Get-NewProjectDialog $main
    if ($dlg) { break }
}
if (-not $dlg) {
    throw 'The new-project dialog did not appear. Either the menu clicks missed (tune -MenuDx/-MenuDy/-ItemDx/-ItemDy) or a DIFFERENT dialog is open. Nothing was clicked.'
}
Write-Host ("dialog   : '{0}'" -f $dlg.Current.Name)

# ---------- 4. select the Temporary Project radio ----------
$radio = Get-ById $dlg '1145'
if (-not $radio) { throw 'Dialog found, but radio 1145 is missing.' }
if ($radio.Current.Name -ne $S_TEMP_PROJECT) {
    throw ("AutomationId 1145 is not the expected radio - got '{0}'. Aborting." -f $radio.Current.Name)
}
$how = Invoke-Element $radio 'temporary-project radio'
Start-Sleep -Milliseconds 900
Write-Host ("radio    : '{0}' selected via {1}" -f $S_TEMP_PROJECT, $how)

# ---------- 5. verify: project-name edit (1052) must now be disabled ----------
$editName = Get-ById $dlg '1052'
if ($editName) {
    if ($editName.Current.IsEnabled) {
        throw 'The project-name edit is still enabled, so Temporary Project is NOT active. Aborting before pressing anything.'
    }
    Write-Host ("verify   : project-name edit disabled -> '{0}' mode confirmed" -f $S_TEMP_PROJECT)
} else {
    Write-Warning 'Could not read the project-name edit to verify; continuing.'
}

# ---------- 6. confirm (or cancel under -DryRun) ----------
$btnId    = if ($DryRun) { '2' } else { '1' }
$btnLabel = if ($DryRun) { $S_CANCEL } else { $S_OK }
$btn = Get-ById $dlg $btnId
if (-not $btn -or $btn.Current.Name -ne $btnLabel) {
    throw ("Could not find the expected dialog button (AutomationId {0})." -f $btnId)
}
Write-Host ("press    : '{0}'{1}" -f $btnLabel, $(if ($DryRun) { '  (-DryRun: no project created)' } else { '' }))
[void](Invoke-Element $btn 'dialog button')
Start-Sleep -Seconds 3

# ---------- 7. report ----------
$titleAfter = (Get-MainWindow).Current.Name
Write-Host ("result   : {0}" -f $titleAfter)
if ($DryRun) {
    Write-Host 'DRY RUN OK - recipe verified, nothing was created.'
} elseif ($titleAfter -like "*$S_TEMP_PROJECT*") {
    Write-Host ("OK - '{0}' created and open." -f $S_TEMP_PROJECT)
} else {
    Write-Warning ("Confirmed, but the title lacks '{0}'. Check AutoShop by hand." -f $S_TEMP_PROJECT)
}
