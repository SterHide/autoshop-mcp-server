# prelude.ps1 -- shared helpers for driving AutoShop on THIS machine (AutoShop V4.12.0.2).
#
# WHY THIS EXISTS (measured 2026-09-20, cost a full round):
#   When the mouse is left hovering over AutoShop's toolbar, Windows pops a tooltip plus a
#   top-level class 'SysShadow' window (visible, unowned, ~90x27). .NET's Process.MainWindowHandle
#   is documented as "the first visible top-level window that has no owner", so it returns THAT
#   SHADOW instead of the real frame. Every AutoShop script that resolves its target through
#   Get-Process ... .MainWindowHandle then fails with nonsense ("main window is minimized or
#   off-screen (rect={ 176,180 180x54 })") even though the app is perfectly healthy.
#   Park the cursor on neutral ground and MainWindowHandle snaps back to the real frame.
#
# Get-AutoShopMain resolves the frame by IDENTITY instead of by that heuristic:
#   biggest visible top-level window of the AutoShop process whose class starts with 'Afx:' and
#   whose title contains 'AutoShop'. That is stable regardless of tooltips/menus/shadows.
#
# KEEP PURE ASCII.
Add-Type -AssemblyName System.Windows.Forms

if (-not ('PL.W' -as [type])) {
Add-Type -Namespace PL -Name W -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

function Get-AutoShopProcess {
  $p = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($null -eq $p) { throw 'AutoShop is not running' }
  return $p
}

function Get-AutoShopMain {
  $p = Get-AutoShopProcess
  $pid0 = [int]$p.Id
  $best = $null; $bestArea = 0
  $cb = [PL.W+EnumProc]{ param($h,$x)
    $q = 0; [void][PL.W]::GetWindowThreadProcessId($h, [ref]$q)
    if ([int]$q -eq $script:pid0 -and [PL.W]::IsWindowVisible($h)) {
      $cn = New-Object System.Text.StringBuilder 256; [void][PL.W]::GetClassNameW($h,$cn,256)
      $tt = New-Object System.Text.StringBuilder 512; [void][PL.W]::GetWindowTextW($h,$tt,512)
      if ($cn.ToString() -like 'Afx:*' -and $tt.ToString() -like '*AutoShop*') {
        $r = New-Object PL.W+RECT; [void][PL.W]::GetWindowRect($h,[ref]$r)
        $area = ($r.Right-$r.Left)*($r.Bottom-$r.Top)
        if ($area -gt $script:bestArea) {
          $script:bestArea = $area
          $script:best = [pscustomobject]@{ Hwnd=$h; Title=$tt.ToString(); X=$r.Left; Y=$r.Top; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top) }
        }
      }
    }
    return $true }
  $script:pid0 = $pid0
  [void][PL.W]::EnumWindows($cb, [IntPtr]::Zero)
  if ($null -eq $script:best) { throw 'no AutoShop main frame found (Afx:* with an AutoShop title)' }
  return $script:best
}

# Park the cursor somewhere harmless so tooltips/shadows disappear. It must be OUTSIDE the frame:
# parking inside it (e.g. the bottom-right corner) just raises a tooltip for whatever control is
# there, which recreates the very SysShadow problem this helper exists to avoid.
function Park-Cursor {
  $m = Get-AutoShopMain
  $sx = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
  $sy = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height
  $x = [Math]::Min([int]($m.X + $m.W + 60), $sx - 10)
  $y = [Math]::Min([int]($m.Y + $m.H + 60), $sy - 10)
  [void][PL.W]::SetCursorPos($x, $y)
  Start-Sleep -Milliseconds 500
}

# Park, then make the real frame the foreground window. Returns the frame object.
function Focus-AutoShopMain {
  Park-Cursor
  $m = Get-AutoShopMain
  for ($i = 0; $i -lt 6; $i++) {
    [void][PL.W]::SetForegroundWindow($m.Hwnd)
    Start-Sleep -Milliseconds 350
    if ([PL.W]::GetForegroundWindow() -eq $m.Hwnd) { break }
  }
  return $m
}

# Ctrl+S into the (assumed foreground) AutoShop, then report whether the ' *' modified marker cleared.
# The title is read from the IDENTITY-resolved frame, never from Process.MainWindowTitle (which lies
# whenever a tooltip shadow is on screen).
function Save-AutoShop {
  $before = (Get-AutoShopMain).Title
  [System.Windows.Forms.SendKeys]::SendWait('^s')
  Start-Sleep -Milliseconds 1200
  $after = (Get-AutoShopMain).Title
  return [pscustomobject]@{ Before=$before; After=$after; MarkerCleared=($before -ne $after -and $after -notlike '*`**') }
}
