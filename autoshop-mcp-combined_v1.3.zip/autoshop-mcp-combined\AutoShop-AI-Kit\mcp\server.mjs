#!/usr/bin/env node
// Thin MCP server that exposes the AutoShop UI-automation PowerShell scripts as MCP tools.
//
// WHY A THIN WRAPPER (and not a rewrite):
//   * The verified logic already lives in D:\AI\MCP\AutoShop-AI-Kit\tools\*.ps1 (MSAA + Win32 driving the real
//     AutoShop UI). Rewriting it in Node would throw away every measured offset and judgement rule.
//   * Wrapping it means ANY MCP client can drive AutoShop -- the client only needs to call tools, it
//     does not need a shell, and it does not need to read a 250 KB SKILL.md to know the menu offsets.
//   * The offsets that took hours to measure (per-view import offsets, per-node context-menu offsets)
//     are baked in HERE, so a model cannot get them wrong.
//
// DISCIPLINE BAKED IN (this is the real value):
//   * every import ends with autoshop-save-until-clean (dismiss the box -> press Save -> verify the
//     dirty marker cleared) because a Save whose click was swallowed by a modal box looks like success
//   * every tool call runs in its OWN powershell process (several scripts share the .NET type W.U and
//     would otherwise silently skip their own Add-Pe and then fail on a missing method)
//   * arguments travel in a UTF-8 JSON file, never on a command line (Chinese + quoting + ANSI)
//
// stdio transport, newline-delimited JSON-RPC 2.0, ZERO npm dependencies.
// Nothing but JSON-RPC may be written to stdout; diagnostics go to stderr.

import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtempSync, writeFileSync, rmSync, existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const TOOLS_DIR = process.env.AUTOSHOP_TOOLS_DIR || join(HERE, '..', 'tools');
const POWERSHELL = process.env.AUTOSHOP_POWERSHELL ||
  join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
const PROTOCOL = '2024-11-05';

// ---------------------------------------------------------------- per-view offsets (measured)
// Import row offsets / popup heights, measured on AutoShop V4.11.0.5. NEVER guess these.
const IMPORT_PRESET = {
  fb:     { ImportOffsetY: 456, ExpectedMenuH: 512 },   // FB / FC variable table
  struct: { ImportOffsetY: 386, ExpectedMenuH: 442 },   // struct editor
  gvl:    { ImportOffsetY: 409, ExpectedMenuH: 632 },   // global variable table
  fbi:    { ImportOffsetY: 409, ExpectedMenuH: 476 },   // FB-instance table
};

// Context-menu offsets for creating a node, per parent node type (measured).
const CREATE_PRESET = {
  fb:         { Node: '功能块(FB)', ClickOffsetY: 18, ExpectedMenuH: 168, dialog: true,  bare: true  },
  struct:     { Node: '结构体',     ClickOffsetY: 18, ExpectedMenuH: 64,  dialog: true,  bare: false },
  gvl:        { Node: '全局变量',   ClickOffsetY: 18, ExpectedMenuH: 64,  dialog: false, bare: false },
  subprogram: { Node: '程序块',     ClickOffsetY: 72, ExpectedMenuH: 116, dialog: true,  bare: true  },
};

function step(script, params) { return { script, params: params || {} }; }

// ---------------------------------------------------------------- tools
const TOOLS = [
  {
    name: 'autoshop_preflight',
    description: 'AutoShop 开工自检：窗体位置/尺寸、左栏宽度、折叠状态、已开视图数、是否有模态框。任何一批操作前后都该跑。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        fix:  { type: 'boolean', description: '自动修复（归位窗体、把左栏拖回 346px、展开所有文件夹）' },
        deep: { type: 'boolean', description: '连折叠状态一起查并全部展开' },
        widen_pane: { type: 'boolean', description: '已废弃（保留以兼容旧调用）' },
        keep_views: { type: 'boolean', description: '不关闭开着的块视图（默认 true —— 关视图可能丢未保存的改动）' },
      },
    },
    build: (p) => [step('autoshop-preflight.ps1', {
      Fix: !!p.fix, Deep: !!p.deep, WidenPane: !!p.widen_pane, KeepViews: p.keep_views !== false,
    })],
  },
  {
    name: 'autoshop_tree',
    description: '读 AutoShop 工程树的全部节点（id + 名称，MSAA 名字索引）。用来确认某节点是否已建好。',
    readOnly: true,
    schema: { type: 'object', properties: {} },
    build: () => [step('autoshop-node-menu.ps1', { ListNodes: true })],
  },
  {
    name: 'autoshop_open_node',
    description: '按名字选中并打开一个工程树节点（块/变量表/结构体都会打开对应视图）。',
    schema: { type: 'object', properties: { node: { type: 'string', description: '节点名，如 FB_气缸 / GVL_SYS / SBR_气缸' } }, required: ['node'] },
    build: (p) => [step('autoshop-open-node.ps1', { Node: p.node })],
  },
  {
    name: 'autoshop_read_block',
    description: '只读回读块正文（不改动、不保存）。给 diff 就与本地文件逐字符比对并给 IDENTICAL/DIFF。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        block: { type: 'string' },
        diff: { type: 'string', description: '本地 .st/.md 路径，逐字符比对' },
        out_file: { type: 'string', description: '把读到的正文写到这个文件' },
        max_show: { type: 'integer', description: '顺带回显前 N 行' },
      },
      required: ['block'],
    },
    build: (p) => [step('autoshop-read-block.ps1', { Block: p.block, Diff: p.diff || '', OutFile: p.out_file || '', MaxShow: p.max_show || 0 })],
  },
  {
    name: 'autoshop_write_block',
    description: '把一段正文写进已打开的块编辑器（WM_SETTEXT，自动回读校验 MATCHES）。★写完必须调 autoshop_save。',
    schema: {
      type: 'object',
      properties: { block: { type: 'string' }, text_file: { type: 'string', description: 'UTF-8 正文文件（纯代码，无 md 围栏）' } },
      required: ['block', 'text_file'],
    },
    build: (p) => [step('autoshop-write-block.ps1', { Block: p.block, TextFile: p.text_file })],
  },
  {
    name: 'autoshop_save',
    description: '保存：先按掉弹窗（成功框是模态的，不按掉会吞掉保存点击）→ 再按工具栏保存 → 复读标题看 ` *` 是否消失，没消失就再点。这是唯一可信的保存验证。',
    schema: { type: 'object', properties: { max_rounds: { type: 'integer' } } },
    build: (p) => [step('autoshop-save-until-clean.ps1', { MaxRounds: p.max_rounds || 6 })],
  },
  {
    name: 'autoshop_close_all',
    description: '关闭所有块视图（.stru/.gvt/.FB 等只在关视图时真正落盘）。★先保存再关。',
    schema: { type: 'object', properties: {} },
    build: () => [step('autoshop-close-all-blocks.ps1', {})],
  },
  {
    name: 'autoshop_create_node',
    description: '新建工程树节点：fb（功能块）/ struct（结构体）/ gvl（全局变量表，会自动改名）/ subprogram（子程序，AutoShop 自动加 SBR_ 前缀）。菜单位置已内置，不用记偏移。',
    schema: {
      type: 'object',
      properties: {
        kind: { type: 'string', enum: ['fb', 'struct', 'gvl', 'subprogram'] },
        name: { type: 'string', description: '名称（子程序与 FB 给裸名，AutoShop 自己加前缀的只加 SBR_）' },
      },
      required: ['kind'],
    },
    build: (p) => {
      const c = CREATE_PRESET[p.kind];
      if (!c) throw new Error('unknown kind: ' + p.kind + ' (use fb|struct|gvl|subprogram)');
      const steps = [step('autoshop-node-menu.ps1', { Node: c.Node, ClickOffsetY: c.ClickOffsetY, ExpectedMenuH: c.ExpectedMenuH })];
      if (c.dialog) {
        if (!p.name) throw new Error('name is required for kind=' + p.kind);
        steps.push(step('autoshop-fill-newdialog.ps1', { Name: p.name }));
      } else if (p.name) {
        // a new GVL table is created as 变量表_1 and opened: rename it (two-step: menu item, then inline edit)
        steps.push(step('autoshop-node-menu.ps1', { Match: '变量表_', ClickOffsetY: 96, ExpectedMenuH: 168 }));
        steps.push(step('autoshop-rename-inline.ps1', { NewName: p.name }));
      }
      return steps;
    },
  },
  {
    name: 'autoshop_import_table',
    description: '导入整张表（结构体成员 / GVL 变量 / FB 变量表 / 功能块实例）——整表替换。preset 决定该视图的导入偏移（fb/gvl/struct/fbi，已内置）。默认：先开视图 → 导入 → 保存并验星号。',
    schema: {
      type: 'object',
      properties: {
        view: { type: 'string', description: '已打开视图名，如 ST_气缸 / GVL_SYS / FB_气缸 / 功能块实例' },
        csv: { type: 'string', description: '整表 CSV（GBK，全量，含表头）' },
        preset: { type: 'string', enum: ['fb', 'gvl', 'struct', 'fbi'] },
        open: { type: 'boolean', description: '导入前先按名字打开该表（默认 true）' },
        confirm: { type: 'boolean', description: '自动确认「当前表格将被清空且不支持撤销恢复」（默认 true）' },
        save: { type: 'boolean', description: '导入后自动保存并验星号（默认 true）' },
      },
      required: ['view', 'csv', 'preset'],
    },
    build: (p) => {
      const pre = IMPORT_PRESET[p.preset];
      if (!pre) throw new Error('unknown preset: ' + p.preset + ' (use fb|gvl|struct|fbi)');
      const steps = [];
      if (p.open !== false) steps.push(step('autoshop-open-node.ps1', { Node: p.view }));
      steps.push(step('autoshop-import-vartable.ps1', {
        View: p.view, CsvPath: p.csv, ConfirmImport: p.confirm !== false,
        ImportOffsetY: pre.ImportOffsetY, ExpectedMenuH: pre.ExpectedMenuH,
      }));
      if (p.save !== false) steps.push(step('autoshop-save-until-clean.ps1', {}));
      return steps;
    },
  },
  {
    name: 'autoshop_check_block',
    description: '五条铁律自查：ST 基本结构、局部变量声明、全局变量存在、调用的 FB 已实例化、TON/TRIG 实例存在。',
    readOnly: true,
    schema: {
      type: 'object',
      properties: {
        mirror_dir: { type: 'string', description: '镜像根目录' },
        block: { type: 'string' },
        body_file: { type: 'string', description: '.md（围栏正文）或纯 .st' },
        inst_name: { type: 'string' }, fb_type: { type: 'string' },
        table_dir: { type: 'string', description: '镜像内放 GVL csv 的目录，如 变量表' },
        fbi_path: { type: 'string', description: '功能块实例 csv 的完整路径' },
      },
      required: ['mirror_dir', 'block'],
    },
    build: (p) => [step('autoshop-check-block.ps1', {
      MirrorDir: p.mirror_dir, Block: p.block, BodyFile: p.body_file || '',
      InstName: p.inst_name || '', FbType: p.fb_type || '',
      TableDir: p.table_dir || '', FbiPath: p.fbi_path || '',
    })],
  },
  {
    name: 'autoshop_make_tables',
    description: '由一个 UTF-8 规格文件生成全部 AutoShop 表（GBK 导入表 + UTF-8 设计稿）。改设计只改规格文件，不要手写 CSV。',
    schema: { type: 'object', properties: { spec: { type: 'string' }, mirror: { type: 'string' } }, required: ['spec', 'mirror'] },
    build: (p) => [step('make-cylinder-tables.ps1', { Spec: p.spec, Mirror: p.mirror })],
  },
  {
    name: 'autoshop_md_to_st',
    description: '从镜像 .md 里抽出围栏正文成纯 .st（写入通道要文件）。兼容单反引号的畸形围栏。',
    schema: { type: 'object', properties: { md: { type: 'string' }, out: { type: 'string' } }, required: ['md', 'out'] },
    build: (p) => [step('md-to-st.ps1', { Md: p.md, Out: p.out })],
  },
  {
    name: 'autoshop_set_pane',
    description: '把工程树左栏拖到指定像素宽度（修「左栏过宽」）。默认 346px。',
    schema: { type: 'object', properties: { width: { type: 'integer' } } },
    build: (p) => [step('autoshop-set-pane.ps1', { Width: p.width || 346 })],
  },
  {
    name: 'autoshop_dialogs',
    description: '列出当前所有模态弹窗及其按钮；action=ok/cancel 时按文字（确定/是 / 否/取消）回答，认不出的框不动它。',
    schema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'ok', 'cancel'] } } },
    build: (p) => {
      const a = p.action || 'list';
      const map = { list: 'None', ok: 'OK', cancel: 'Cancel' };
      return [step('autoshop-dialog-answer.ps1', { Button: map[a] || 'None', List: a === 'list' })];
    },
  },
];

// ---------------------------------------------------------------- native tools (merged from the plc-bridges autoshop bridge)
// Read-only / process-level channels that do NOT touch the editor and need no preflight:
//   * autoshop_status          -- list instances, parse the title into version/projectDir/currentProgram
//   * autoshop_project_open    -- launch AutoShop with a .hcp (refuses while another instance is up)
//   * autoshop_project_inspect -- read folder.txt tree + *.csv symbol tables without opening the IDE
//   * autoshop_bridge_dialog_scan / autoshop_bridge_dialog_click -- enumerate #32770 dialogs with
//     button hwds and click one by hwnd (precise; complements autoshop_dialogs which answers by text).
// The Win32 probes they shell out to (winprobe.ps1, uia-dump.ps1) live in TOOLS_DIR.
const runExt = promisify(execFile);
const BRIDGE_EXE = process.env.AUTOSHOP_EXE || 'D:\\app\\major\\INOVANCE\\AutoShop\\AutoShop.exe';
const gbkDec = new TextDecoder('gbk');
const utf8StrictDec = new TextDecoder('utf-8', { fatal: true });

const PSFILE = (script, args, timeout = 30000) => runExt('powershell.exe',
  ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, ...args],
  { windowsHide: true, maxBuffer: 32 * 1024 * 1024, timeout });

const PSINLINE = (body) => runExt('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
  // trailing exit 0: powershell.exe -Command returns 1 on non-terminating errors (e.g. Get-Process
  // on a name that is not running) even when stdout is perfectly good.
  '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;' + body + '; exit 0'],
  { windowsHide: true, maxBuffer: 16 * 1024 * 1024, timeout: 30000 });

const WinProbe = (action, kv = {}) => PSFILE(join(TOOLS_DIR, 'winprobe.ps1'), [
  '-Action', action,
  ...Object.entries(kv).flatMap(([k, v]) => ['-' + k, String(v)]),
]);

const UiaProbe = (action, hwnd) => PSFILE(join(TOOLS_DIR, 'uia-dump.ps1'), ['-Action', action, '-Hwnd', String(hwnd)]);

async function bridgeProcesses(name) {
  const { stdout } = await PSINLINE(
    `$ErrorActionPreference='SilentlyContinue';Get-Process -Name '${name}' | ForEach-Object { ` +
    `[pscustomobject]@{ pid=$_.Id; mainHwnd=[long]$_.MainWindowHandle; title=$_.MainWindowTitle; ` +
    `responding=$_.Responding; start=$_.StartTime.ToString('s') } } | ConvertTo-Json -Compress`);
  const one = JSON.parse(stdout || 'null');
  return Array.isArray(one) ? one : one ? [one] : [];
}

async function bridgeTopWindows(pid) {
  const { stdout } = await WinProbe('scan', { PidFilter: pid });
  return (JSON.parse(stdout || '{}').windows) || [];
}

async function bridgeDialogs(pid) {
  const wins = (await bridgeTopWindows(pid)).filter((w) => w.cls === '#32770');
  const out = [];
  for (const w of wins) {
    const { stdout } = await WinProbe('children', { Hwnd: w.hwnd });
    const kids = (JSON.parse(stdout || '{}').children) || [];
    out.push({
      hwnd: w.hwnd,
      visible: w.visible,
      title: w.title,
      texts: kids.filter((k) => k.cls === 'Static' && k.text).map((k) => k.text),
      buttons: kids.filter((k) => k.cls === 'Button').map((k) => ({ hwnd: k.hwnd, dlgId: k.dlgId, text: k.text, visible: k.visible })),
      inputs: kids.filter((k) => k.cls.includes('Edit') || k.cls.includes('Combo')).map((k) => ({ hwnd: k.hwnd, dlgId: k.dlgId, cls: k.cls, text: k.text })),
    });
  }
  return out;
}

async function bridgeBestTitle(mainHwnd, caption) {
  if (mainHwnd) {
    try {
      const { stdout } = await UiaProbe('name', mainHwnd);
      const u = JSON.parse(stdout || '{}');
      if (u.name) return { title: u.name, source: 'uia', cls: u.class };
    } catch { /* fall back to the caption */ }
  }
  return { title: caption ?? null, source: 'caption' };
}

function bridgeParseTitle(title) {
  // "AutoShop V4.12.0.0  <project folder> - [MAIN]"
  const out = { raw: title, version: null, projectDir: null, currentProgram: null };
  if (!title) return out;
  const vm = title.match(/AutoShop\s+V([\d.]+)/i);
  if (vm) out.version = vm[1];
  const tail = title.match(/\[(.*?)\]\s*$/);
  if (tail) out.currentProgram = tail[1];
  const mid = title.match(/V[\d.]+\s+(.+?)\s+-\s+\[/);
  if (mid) out.projectDir = mid[1];
  return out;
}

async function bridgeStatus() {
  const procs = await bridgeProcesses('AutoShop');
  const frames = [];
  for (const p of procs) {
    const t = await bridgeBestTitle(p.mainHwnd, p.title);
    frames.push({ pid: p.pid, mainHwnd: p.mainHwnd, responding: p.responding, started: p.start, titleSource: t.source, title: t.title, parsed: bridgeParseTitle(t.title) });
  }
  return { ok: true, value: { autoShopExe: BRIDGE_EXE, frames } };
}

function bridgeReadTextSmart(buf) {
  if (buf[0] === 0xff && buf[1] === 0xfe) return buf.toString('utf16le').replace(/^\uFEFF/, '');
  if (buf[0] === 0xef && buf[1] === 0xbb) return buf.toString('utf8').replace(/^\uFEFF/, '');
  try { return utf8StrictDec.decode(buf); } catch { return gbkDec.decode(buf); }
}

function bridgeParseFolderTxt(text) {
  const sections = [];
  let current = null;
  for (const raw of text.split(/\r?\n/)) {
    if (!raw) continue;
    const indent = (raw.match(/^\t+/) || [''])[0].length;
    const line = raw.trim();
    if (indent === 0 && (line === 'PROG' || line === 'VAR' || line === 'ROOT')) {
      if (line === 'ROOT') continue;
      current = { section: line, nodes: [] };
      sections.push(current);
      continue;
    }
    if (!current) continue;
    const parts = line.split('\t');
    const kind = parts[0];
    const name = parts.slice(1).join('\t');
    if (kind === 'FILE' || kind === 'FOLDER' || kind === 'STRUROOT' || kind === 'ENUMROOT') {
      current.nodes.push({ depth: indent, kind, name });
    }
  }
  return sections;
}

function bridgeParseCsvTable(text) {
  const rows = text.split(/\r?\n/).map((l) => l.split('\t'));
  const meta = {};
  for (const r of rows) if (r.length === 2 && !r[0].startsWith('_')) meta[r[0]] = r[1];
  const headerIdx = rows.findIndex((r) => r[0] === 'FullName');
  const header = headerIdx >= 0 ? rows[headerIdx] : [];
  const body = headerIdx >= 0 ? rows.slice(headerIdx + 1).filter((r) => r[0] && !r[0].startsWith('_')) : [];
  return { meta, header, symbolCount: body.length, sample: body.slice(0, 12).map((r) => r.map((c) => c.trim())) };
}

function bridgeStatSyncSafe(p) { try { return statSync(p).isFile(); } catch { return false; } }
function bridgeReadHeader(p) {
  try {
    const b = readFileSync(p).subarray(0, 48);
    return { magic: gbkDec.decode(b.subarray(0, 9)), versions: (gbkDec.decode(b.subarray(20, 32)).match(/[\d.]{3,}/g) || []).slice(0, 2) };
  } catch { return null; }
}

// name -> { schema, readOnly, fn(args) -> {ok, value} | {ok:false, code, error} }
const NATIVE = {
  autoshop_status: {
    description: '列出所有 AutoShop 进程：pid、主窗口句柄、解析出的 版本/工程目录/当前打开程序。只读。调其它工具前先用它确认目标实例（配合 AUTOSHOP_TITLE_FILTER）。',
    schema: { type: 'object', properties: {} },
    fn: async () => bridgeStatus(),
  },
  autoshop_project_open: {
    description: '用 .hcp 路径启动 AutoShop 打开工程；已有实例运行时拒绝启动（这几家 IDE 带文件二次打开不可靠）。工程是一个文件夹，只拷 .hcp 打不开。',
    schema: { type: 'object', properties: { projectPath: { type: 'string' } }, required: ['projectPath'] },
    fn: async (args) => {
      const projectPath = args?.projectPath;
      if (!projectPath || !/\.hcp$/i.test(projectPath)) return { ok: false, code: 'bad_path', error: 'projectPath must end in .hcp' };
      if (!existsSync(projectPath)) return { ok: false, code: 'not_found', error: projectPath };
      const dir = join(projectPath, '..');
      const procs = await bridgeProcesses('AutoShop');
      const st0 = await bridgeStatus();
      const already = st0.value.frames.filter((f) => f.parsed.projectDir && f.parsed.projectDir.toLowerCase() === dir.toLowerCase());
      if (already.length) {
        return { ok: true, value: { action: 'already-open', launched: false, frame: already[0].parsed, note: 'Already loaded in a running AutoShop; nothing launched.' } };
      }
      if (procs.length > 0) {
        return { ok: false, code: 'instance_exists', runningInstances: procs.length, pids: procs.map((p) => p.pid),
          error: 'An instance is already running. AutoShop does not reliably open a project from the command line while another instance is up. Close it first, or open the file through its own UI.' };
      }
      const child = spawn(BRIDGE_EXE, [`"${projectPath}"`], { cwd: join(BRIDGE_EXE, '..'), detached: true, stdio: 'ignore', windowsHide: false });
      child.unref();
      await new Promise((r) => setTimeout(r, 20000));
      const st = await bridgeStatus();
      const ds = await bridgeDialogs(st.value.frames[0]?.pid ?? 0);
      return { ok: st.value.frames.length > 0, value: {
        action: 'launched', launched: true,
        frames: st.value.frames.map((f) => f.parsed),
        dialogs: ds.map((d) => ({ texts: d.texts, buttons: d.buttons.map((b) => b.text) })),
        note: 'AutoShop needs the whole project folder, not just the .hcp; a missing sidecar raises an error dialog and the app quits.',
      } };
    },
  },
  autoshop_project_inspect: {
    description: '不开 IDE 直接读工程文件夹：folder.txt 程序树、全部 *.csv 符号表（FullName 行）、加密 .LD/.ST 清单。绝不写入工程目录。',
    schema: { type: 'object', properties: { projectPath: { type: 'string' } }, required: ['projectPath'] },
    fn: async (args) => {
      const projectPath = args?.projectPath;
      const dir = bridgeStatSyncSafe(projectPath) ? join(projectPath, '..') : projectPath;
      if (!dir || !existsSync(dir)) return { ok: false, code: 'not_found', error: projectPath };
      const files = [];
      const walk = (d, rel) => {
        for (const e of readdirSync(d, { withFileTypes: true })) {
          const abs = join(d, e.name);
          const r = rel ? join(rel, e.name) : e.name;
          if (e.isDirectory()) walk(abs, r);
          else { const st = statSync(abs); files.push({ name: r, size: st.size, mtime: st.mtime.toISOString() }); }
        }
      };
      walk(dir, '');
      const out = { ok: true, projectDir: dir, entryFiles: [], tree: [], symbolTables: [], encryptedSources: [], notes: [] };
      for (const f of files) {
        const ext = extname(f.name).toLowerCase();
        if (ext === '.hcp' || ext === '.hcpp') out.entryFiles.push(f);
        if (ext === '.ld' || ext === '.st' || ext === '.gvt' || ext === '.enum' || ext === '.stru' || ext === '.fbi' || ext === '.gdt' || ext === '.fb' || ext === '.fc' || ext === '.flib') {
          out.encryptedSources.push({ name: f.name, size: f.size, mtime: f.mtime, header: bridgeReadHeader(join(dir, f.name)) });
        }
      }
      const ft = join(dir, 'folder.txt');
      if (existsSync(ft)) out.tree = bridgeParseFolderTxt(bridgeReadTextSmart(readFileSync(ft)));
      else out.notes.push('no folder.txt in this folder: pass the folder that contains it, or the matching .hcp');
      for (const f of files.filter((x) => extname(x.name).toLowerCase() === '.csv')) {
        try { out.symbolTables.push({ name: f.name, size: f.size, ...bridgeParseCsvTable(bridgeReadTextSmart(readFileSync(join(dir, f.name)))) }); }
        catch (e) { out.notes.push(`could not parse ${f.name}: ${e.message}`); }
      }
      out.notes.push('program bodies (.LD/.ST/.gvt/...) carry the "AutoShop" magic and an encrypted body; this tool reads structure and symbol tables only');
      out.notes.push('nothing is written to the project folder');
      return { ok: true, value: out };
    },
  },
  autoshop_bridge_dialog_scan: {
    description: '扫描 AutoShop 的标准 Win32 对话框（#32770）：文本、按钮 hwnd+dlgId、编辑框。确认/报错框先扫后点。',
    schema: { type: 'object', properties: { pid: { type: 'integer' } } },
    fn: async (args) => {
      const pid = Number(args?.pid) || (await bridgeProcesses('AutoShop'))[0]?.pid;
      if (!pid) return { ok: false, code: 'no_process', error: 'AutoShop is not running and no pid was given' };
      const ds = await bridgeDialogs(pid);
      const wins = await bridgeTopWindows(pid);
      return { ok: true, value: { pid, dialogs: ds, topLevels: wins.filter((w) => w.visible).map((w) => ({ hwnd: w.hwnd, cls: w.cls, title: w.title })) } };
    },
  },
  autoshop_bridge_dialog_click: {
    description: '按 hwnd 精确点击一个对话框按钮（hwnd 来自 autoshop_bridge_dialog_scan），点后回报新标题。比像素偏移安全。',
    schema: { type: 'object', properties: { hwnd: { type: 'integer' } }, required: ['hwnd'] },
    fn: async (args) => {
      const hwnd = Number(args?.hwnd);
      if (!Number.isInteger(hwnd) || hwnd <= 0) return { ok: false, code: 'bad_args', error: 'hwnd must be a positive integer (from autoshop_bridge_dialog_scan buttons)' };
      const { stdout } = await WinProbe('click', { Hwnd: hwnd });
      const clicked = JSON.parse(stdout || '{}');
      await new Promise((r) => setTimeout(r, 1000));
      const st = await bridgeStatus();
      return { ok: true, value: { clicked, frames: st.value.frames.map((f) => f.parsed) } };
    },
  },
};

// ---------------------------------------------------------------- runner
// ★ ONCE PER SESSION (user rule, 2026-09-20: "软件打开一次控制 autoshop 判断一次"):
//   every time AutoShop is (re)started it comes back MAXIMISED and with a ~198px tree pane, and
//   offset-based actions then land wrong. Instead of hoping the caller remembers, the server runs the
//   preflight itself before the FIRST tool call of the process.
//   -KeepViews is deliberate: closing block views can discard unsaved edits (WM_CLOSE raises a save
//   prompt and the preflight answers No/Cancel by design), so an automatic pass must never close them.
//   If the pass fails (AutoShop not up yet) it is simply retried on the next call.
let sessionReady = false;
async function ensureSessionPreflight() {
  if (sessionReady) return '';
  const r = await runPowershell(step('autoshop-preflight.ps1', { Fix: true, Deep: true, KeepViews: true }));
  if (r.code === 0) sessionReady = true;
  const head = '### [session start] AutoShop normalised once (window geometry + pane 346px + expand folders; views NOT closed)\n';
  const tail = r.code === 0
    ? ''
    : '\n(NOTE: this startup pass did not succeed - is AutoShop running? It will be retried on the next call.)';
  return head + (r.out || '').trim() + (r.err ? '\n[stderr] ' + r.err.trim() : '') + tail + '\n\n';
}

function runPowershell(spec) {
  return new Promise((resolve) => {
    const dir = mkdtempSync(join(tmpdir(), 'autoshop-mcp-'));
    const specFile = join(dir, 'spec.json');
    try {
      writeFileSync(specFile, JSON.stringify(spec), 'utf8');
      const args = ['-STA', '-NoProfile', '-ExecutionPolicy', 'Bypass',
        '-File', join(HERE, 'mcp-invoke.ps1'),
        '-SpecFile', specFile, '-ScriptDir', TOOLS_DIR];
      const child = spawn(POWERSHELL, args, { windowsHide: true });
      let out = '', err = '';
      child.stdout.setEncoding('utf8');
      child.stderr.setEncoding('utf8');
      child.stdout.on('data', (d) => { out += d; });
      child.stderr.on('data', (d) => { err += d; });
      child.on('error', (e) => { cleanup(); resolve({ code: -1, out, err: err + String(e && e.message || e) }); });
      child.on('close', (code) => { cleanup(); resolve({ code: code === null ? -1 : code, out, err }); });
      function cleanup() { try { rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ } }
    } catch (e) {
      try { rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
      resolve({ code: -1, out: '', err: String(e && e.message || e) });
    }
  });
}

async function callTool(name, args) {
  // Native in-process tools (merged bridge): no PowerShell steps, no preflight needed.
  const nat = NATIVE[name];
  if (nat) {
    try {
      const r = await nat.fn(args || {});
      return { text: JSON.stringify(r.ok ? r.value : r), isError: !r.ok };
    } catch (e) { return { text: String(e && e.message || e), isError: true }; }
  }
  const tool = TOOLS.find((t) => t.name === name);
  if (!tool) return { text: 'unknown tool: ' + name, isError: true };
  let steps;
  try { steps = tool.build(args || {}); }
  catch (e) { return { text: String(e && e.message || e), isError: true }; }

  // ★ ONCE PER SESSION (user rule 2026-09-20: "每次开始控制 AutoShop 就判断一次"):
  //   normalise the AutoShop window before the first real tool call. An explicit autoshop_preflight
  //   call IS that check, so it is not run twice.
  let pre = '';
  if (name !== 'autoshop_preflight') pre = await ensureSessionPreflight();

  const parts = [];
  let failed = false;
  for (let i = 0; i < steps.length; i++) {
    const r = await runPowershell(steps[i]);
    parts.push('--- step ' + (i + 1) + '/' + steps.length + ': ' + steps[i].script + ' (exit ' + r.code + ') ---');
    if (r.out) parts.push(r.out.replace(/\s+$/, ''));
    if (r.err) parts.push('[stderr]\n' + r.err.replace(/\s+$/, ''));
    if (r.code !== 0) { failed = true; break; }   // a failed step invalidates the rest (dependencies)
  }
  return { text: pre + parts.join('\n'), isError: failed };
}

// ---------------------------------------------------------------- JSON-RPC over stdio
function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n'); }

function handle(msg) {
  const { id, method, params } = msg;
  const isNotification = (id === undefined || id === null);

  if (method === 'initialize') {
    send({ jsonrpc: '2.0', id, result: {
      protocolVersion: PROTOCOL,
      capabilities: { tools: {} },
      serverInfo: { name: 'autoshop-uia', version: '1.0.0' },
    } });
    return;
  }
  if (method === 'notifications/initialized' || method === 'initialized') return;
  if (method === 'ping') { if (!isNotification) send({ jsonrpc: '2.0', id, result: {} }); return; }
  if (method === 'tools/list') {
    send({ jsonrpc: '2.0', id, result: { tools: [
      ...TOOLS.map((t) => ({
        name: t.name,
        description: t.description,
        inputSchema: t.schema,
        annotations: { readOnlyHint: !!t.readOnly },
      })),
      ...Object.entries(NATIVE).map(([n, nat]) => ({
        name: n,
        description: nat.description,
        inputSchema: nat.schema,
        annotations: { readOnlyHint: (n === 'autoshop_status' || n === 'autoshop_project_inspect' || n === 'autoshop_bridge_dialog_scan') },
      })),
    ] } });
    return;
  }
  if (method === 'tools/call') {
    const name = params && params.name;
    const args = (params && params.arguments) || {};
    // ★ SERIALIZE every tool call. These tools drive ONE real AutoShop window with the mouse, the
    //   keyboard, MSAA selection and modal dialogs -- two of them running at once fight over focus and
    //   destroy each other's work. Measured: firing open_node + read_block + close_all together made
    //   read_block run BEFORE open_node finished ("no open block view titled 'FB_气缸'"). A client is
    //   allowed to send calls in parallel, so the SERVER must be the one that queues them.
    pending++;
    queue = queue.then(() => callTool(name, args)).then((r) => {
      send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: r.text }], isError: r.isError } });
    }).catch((e) => {
      send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: String(e && e.message || e) }], isError: true } });
    }).finally(() => {
      pending--;
      if (stdinEnded && pending === 0) process.exit(0);
    });
    return;
  }
  if (!isNotification) {
    send({ jsonrpc: '2.0', id, error: { code: -32601, message: 'method not found: ' + method } });
  }
}

let buf = '';
// ★ 2026-09-20: a piped stdin (tests, `echo | server`) closes long before a tool call finishes. Exiting
// on 'end' alone truncated in-flight calls and the response was lost, so exit only when stdin has ended
// AND nothing is pending.
let stdinEnded = false;
let pending = 0;
let queue = Promise.resolve();   // serializes tool calls: only ONE may touch AutoShop at a time
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buf += chunk;
  let idx;
  while ((idx = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, idx).trim();
    buf = buf.slice(idx + 1);
    if (!line) continue;
    let msg;
    try { msg = JSON.parse(line); }
    catch { process.stderr.write('autoshop-mcp: bad JSON line, ignored\n'); continue; }
    try { handle(msg); }
    catch (e) { process.stderr.write('autoshop-mcp: handler error: ' + String(e && e.message || e) + '\n'); }
  }
});
process.stdin.on('end', () => { stdinEnded = true; if (pending === 0) process.exit(0); });
process.stderr.write('autoshop-mcp: ready (tools dir ' + TOOLS_DIR + ')\n');
