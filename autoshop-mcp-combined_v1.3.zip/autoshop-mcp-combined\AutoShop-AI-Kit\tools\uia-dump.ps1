# UI Automation tree dump for one window handle.
#   -Hwnd N          window to inspect
#   -MaxNodes N      stop after N elements (default 400)
#   -Depth N         how deep to walk (default 6)
#   -Action dump     full tree (default) | name -> just the accessible Name, which for some
#                    Qt apps carries the live document title that GetWindowText does not return
#
# Why this matters: Codejock XTP, Qt Ribbon and MFC command bars all return NULL from GetMenu,
# so UIA is the remaining way to discover what an agent can actually invoke. The pattern list is
# the payload: Invoke means it can be pressed, ExpandCollapse means a menu can be opened,
# Value means text can be set.
param(
  [Parameter(Mandatory = $true)][long]$Hwnd,
  [int]$MaxNodes = 400,
  [int]$Depth = 6,
  [ValidateSet('dump', 'name')][string]$Action = 'dump'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$AE = [System.Windows.Automation.AutomationElement]
# TreeWalker's ctor is not public; use the prebuilt view walkers.
$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker

$root = $AE::FromHandle([IntPtr]$Hwnd)
if ($null -eq $root) { throw "no UIA element for hwnd $Hwnd" }

if ($Action -eq 'name') {
  [pscustomobject]@{ hwnd = $Hwnd; class = $root.Current.ClassName; name = $root.Current.Name } |
    ConvertTo-Json -Depth 2 -Compress
  return
}

$script:count = 0
$script:out = New-Object System.Collections.Generic.List[object]

function Describe($el, $depth) {
  if ($script:count -ge $MaxNodes -or $depth -gt $Depth) { return }
  $script:count += 1
  $patterns = @()
  foreach ($p in $el.GetSupportedPatterns()) { $patterns += ($p.ProgrammaticName -replace '^PatternIdentifiers\.Pattern$', '') }
  $script:out.Add([pscustomobject]@{
    depth        = $depth
    name         = $el.Current.Name
    type         = ($el.Current.ControlType.ProgrammaticName -replace '^ControlType\.', '')
    class        = $el.Current.ClassName
    automationId = $el.Current.AutomationId
    enabled      = $el.Current.IsEnabled
    offscreen    = $el.Current.IsOffscreen
    patterns     = ($patterns -join ',')
  })
  $child = $walker.GetFirstChild($el)
  while ($null -ne $child) {
    Describe $child ($depth + 1)
    $child = $walker.GetNextSibling($child)
  }
}

Describe $root 0
[pscustomobject]@{
  hwnd      = $Hwnd
  rootName  = $root.Current.Name
  rootClass = $root.Current.ClassName
  total     = $script:count
  truncated = ($script:count -ge $MaxNodes)
  elements  = $script:out
} | ConvertTo-Json -Depth 4 -Compress
