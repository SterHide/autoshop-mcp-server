# Export ONE open FB/FC block's variable table to a CSV, end to end.
#
# Flow (all verified against FB01_总线轴控制):
#   1. the block's MDI child contains a visible VSFlexGrid8N = the variable table
#   2. right-click inside that grid -> an MFC toolbar-style popup menu appears
#        (class 'Afx:...' with an 'Afx:ToolBar...' child -- NOT '#32768', so UIA exposes no
#         MenuItems and the mnemonic key does not reach it either; both were tried and failed)
#   3. click the '导出(X)' row at a FIXED offset inside the popup
#   4. the '另存为' dialog appears; its filename Edit already has focus, so paste the full target
#      path and press Enter (its height varies between 600 and 209 px, so geometry is avoided)
#   5. Windows asks '确认另存为' ("<file> already exists - replace?") and THAT one needs 是(&Y)
#
# ---------------------------------------------------------------- the one narrow exception -----
# Everywhere else this project presses only No/Cancel. The single exception is the Windows
# overwrite prompt '确认另存为', matched by its EXACT caption AND the presence of BOTH a 是(&Y) and
# a 否(&N) button. Replacing our own placeholder CSV is precisely the intent here, and matching it
# this narrowly means no other dialog can ever be confirmed by accident.
# ------------------------------------------------------------------------------------------------
#
# Self-checks before anything irreversible happens:
#   * the popup height must match the known 导出 layout, otherwise the click point is NOT trusted
#   * the dialog that follows must be '另存为'; an '打开' dialog would mean the wrong row was hit
#
# KEEP PURE ASCII. Chinese arrives via parameters.
param(
  [string]$Block = '',
  [string]$CsvPath = '',
  [switch]$Cleanup,             # just dismiss every visible dialog safely, then exit
  [int]$MenuOffsetY = 430,      # '导出(X)' row centre, measured inside the popup capture
  [int]$MenuOffsetX = 100,
  [int]$ExpectedMenuH = 512,
  [int]$MenuHTolerance = 60
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint tid, ref GUITHREADINFO gti);
[StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
[StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
  public uint cbSize; public uint flags; public IntPtr hwndActive; public IntPtr hwndFocus;
  public IntPtr hwndCapture; public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret;
  public RECT rcCaret; }
'@
}
# Non-ASCII captions built from char codes (this file must stay pure ASCII).
$S_NO      = [string][char]0x5426                                        # No
$S_CANCEL  = [string][char]0x53D6 + [string][char]0x6D88                  # Cancel
$S_YES     = [string][char]0x662F                                        # Yes
$S_SAVEAS  = [string][char]0x53E6 + [string][char]0x5B58 + [string][char]0x4E3A          # Save As
$S_CONFIRM = [string][char]0x786E + [string][char]0x8BA4 + $S_SAVEAS                     # Confirm Save As
$S_OPEN    = [string][char]0x6253 + [string][char]0x5F00                                 # Open
$LD = 0x02; $LU = 0x04; $RD = 0x08; $RU = 0x10

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString().Trim() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function Send([string]$k, [int]$w = 180) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function ClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LU,0,0,0,0) }
function RClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($RD,0,0,0,0); Start-Sleep -Milliseconds 80
  [W.U]::mouse_event($RU,0,0,0,0) }

function TopWindows {
  $l = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ([W.U]::IsWindowVisible($h)) { $r = RectOf $h
      [void]$l.Add([pscustomobject]@{ Hwnd=$h; Cls=(ClsOf $h); X=$r.Left; Y=$r.Top; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top); Text=(TxtOf $h) }) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $l }
function Dialogs {
  $d = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$d.Add($h) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $d }
function Buttons([IntPtr]$dlg) {
  $k = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$k.Add($h) }
    return $true }
  [void][W.U]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $k }
function PressButton([IntPtr]$btn) {
  $r = RectOf $btn
  ClickRaw ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2))
  Start-Sleep -Milliseconds 500 }

# No / Cancel only. Returns $true if it pressed something.
function DismissSafe([IntPtr]$dlg) {
  foreach ($b in (Buttons $dlg)) {
    $t = TxtOf $b
    if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) {
      Write-Output ("   press '{0}' on '{1}'" -f $t, (TxtOf $dlg)); PressButton $b; return $true } }
  Send '{ESC}' 450
  Write-Output ("   press ESC on '{0}' (no No/Cancel button)" -f (TxtOf $dlg))
  return $true }

function CleanupAll {
  $n = 0
  for ($i = 0; $i -lt 8; $i++) {
    $d = Dialogs
    if ($d.Count -eq 0) { break }
    foreach ($x in $d) { [void](DismissSafe $x); $n++ }
    Start-Sleep -Milliseconds 500 }
  return $n }

if ($Cleanup) {
  Write-Output ("dialogs dismissed: {0}" -f (CleanupAll))
  exit 0
}
if (-not $Block -or -not $CsvPath) { throw 'pass -Block and -CsvPath (or -Cleanup)' }

# --- locate the block view and its variable-table grid ----------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
[void][W.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 400
$pre = CleanupAll
if ($pre) { Write-Output ("pre-flight dialogs dismissed: {0}" -f $pre) }

$mc = [IntPtr]::Zero
$cb = [W.U+EnumProc]{ param($h,$p) if ((TxtOf $h) -eq $Block) { $script:mcHit = $h; return $false }; return $true }
[void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
$mc = $script:mcHit
if ($null -eq $mc -or $mc -eq [IntPtr]::Zero) { throw ("no open block view titled '{0}' - open it first" -f $Block) }
$mcr = RectOf $mc
Write-Output ("block view '{0}' hwnd={1} rect={{ {2},{3} {4}x{5} }}" -f $Block, $mc, $mcr.Left, $mcr.Top, ($mcr.Right-$mcr.Left), ($mcr.Bottom-$mcr.Top))

# the variable table is the VISIBLE VSFlexGrid8N inside that MDI child
$grids = New-Object System.Collections.ArrayList
$cb2 = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -like 'VSFlexGrid*' -and [W.U]::IsWindowVisible($h)) {
    $r = RectOf $h
    if (($r.Right - $r.Left) -gt 50) { [void]$grids.Add([pscustomobject]@{ Hwnd=$h; R=$r }) } }
  return $true }
[void][W.U]::EnumChildWindows($mc, $cb2, [IntPtr]::Zero)
Write-Output ("visible grids inside the block: {0}" -f $grids.Count)
foreach ($g in $grids) { Write-Output ("   hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $g.Hwnd, $g.R.Left, $g.R.Top, ($g.R.Right-$g.R.Left), ($g.R.Bottom-$g.R.Top)) }
if ($grids.Count -eq 0) { throw 'no visible variable-table grid found in this block view' }
$grid = $grids[0]

# --- open the context menu ---------------------------------------------------------------------
$gx = [int](($grid.R.Left + $grid.R.Right) / 2)
$gy = $grid.R.Top + 60
if ($gy -gt ($grid.R.Bottom - 10)) { $gy = [int](($grid.R.Top + $grid.R.Bottom) / 2) }
$before = TopWindows
$beforeIds = @($before | ForEach-Object { $_.Hwnd })
Write-Output ("right-clicking the variable table at ({0},{1})" -f $gx, $gy)
ClickRaw $gx $gy            # warm-up: the first click can be eaten by activation
Start-Sleep -Milliseconds 350
RClickRaw $gx $gy
Start-Sleep -Milliseconds 1300
$after = TopWindows
$popup = @($after | Where-Object { $beforeIds -notcontains $_.Hwnd })
if ($popup.Count -eq 0) { throw 'no popup menu appeared - the variable table may not have focus, or the pane is laid out differently' }
$p = $popup[0]
Write-Output ("popup: hwnd={0} class='{1}' rect={{ {2},{3} {4}x{5} }}" -f $p.Hwnd, $p.Cls, $p.X, $p.Y, $p.W, $p.H)

# Refuse to click a layout we have not verified: the whole scheme rests on the menu having the
# same item list, so its height is a cheap invariant to check.
if ([Math]::Abs($p.H - $ExpectedMenuH) -gt $MenuHTolerance) {
  Send '{ESC}' 400
  throw ("popup height {0}px differs from the verified layout ({1} +-{2}) - NOT clicking; re-measure the offset from a capture" -f $p.H, $ExpectedMenuH, $MenuHTolerance)
}

$ix = $p.X + $MenuOffsetX
$iy = $p.Y + $MenuOffsetY
Write-Output ("clicking the export row at ({0},{1})  [popup origin + {2},{3}]" -f $ix, $iy, $MenuOffsetX, $MenuOffsetY)
ClickRaw $ix $iy
Start-Sleep -Milliseconds 1600

# --- the dialog that follows must be 'Save As' -------------------------------------------------
$dlg = [IntPtr]::Zero
foreach ($d in (Dialogs)) { if ((TxtOf $d) -eq $S_SAVEAS) { $dlg = $d; break } }
if ($dlg -eq [IntPtr]::Zero) {
  $titles = ((Dialogs) | ForEach-Object { TxtOf $_ }) -join '/'
  [void](CleanupAll)
  throw ("expected a '{0}' dialog, got [{1}] - the wrong menu row was probably clicked" -f $S_SAVEAS, $titles)
}
$dr = RectOf $dlg
Write-Output ("'{0}' dialog hwnd={1} rect={{ {2},{3} {4}x{5} }}" -f (TxtOf $dlg), $dlg, $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))

# --- paste the target path and commit ---------------------------------------------------------
$tid = [W.U]::GetWindowThreadProcessId($dlg, [IntPtr]::Zero)
$gti = New-Object W.U+GUITHREADINFO
$gti.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($gti)
[void][W.U]::GetGUIThreadInfo($tid, [ref]$gti)
$focusCls = if ($gti.hwndFocus -ne [IntPtr]::Zero) { ClsOf $gti.hwndFocus } else { '' }
Write-Output ("focused control class = '{0}'" -f $focusCls)

$set = $false
$ErrorActionPreference = 'Continue'
for ($i = 0; $i -lt 6 -and -not $set; $i++) {
  try { [System.Windows.Forms.Clipboard]::SetText($CsvPath); $set = $true } catch { Start-Sleep -Milliseconds 250 } }
$ErrorActionPreference = 'Stop'
if (-not $set) { [void](CleanupAll); throw 'could not place the path on the clipboard' }
Write-Output ("clipboard <- '{0}'" -f $CsvPath)
Send '^a' 220
Send '^v' 450
Send '{ENTER}' 200
Start-Sleep -Milliseconds 1600

# --- the overwrite prompt is the ONLY place 是(&Y) may be pressed ------------------------------
$replaced = $false
for ($round = 0; $round -lt 6; $round++) {
  $open = Dialogs
  if ($open.Count -eq 0) { break }
  $handled = $false
  foreach ($d in $open) {
    $t = TxtOf $d
    $btns = Buttons $d
    $caps = @($btns | ForEach-Object { TxtOf $_ })
    $hasYes = @($caps | Where-Object { $_.Contains($S_YES) }).Count -gt 0
    $hasNo  = @($caps | Where-Object { $_.Contains($S_NO) }).Count -gt 0
    if ($t -eq $S_CONFIRM -and $hasYes -and $hasNo) {
      Write-Output ("   '{0}' detected (exact caption + Yes&No buttons) -> this is the overwrite prompt, pressing '{1}'" -f $t, ($caps | Where-Object { $_.Contains($S_YES) } | Select-Object -First 1))
      $yes = $btns | Where-Object { (TxtOf $_).Contains($S_YES) } | Select-Object -First 1
      PressButton $yes
      $replaced = $true
      $handled = $true
    } else {
      [void](DismissSafe $d)
      $handled = $true
    }
  }
  if (-not $handled) { break }
  Start-Sleep -Milliseconds 700
}

$left = Dialogs
Write-Output ("dialogs remaining: {0}" -f $left.Count)
foreach ($d in $left) { Write-Output ("   STILL OPEN: '{0}'" -f (TxtOf $d)) }
if ($replaced) { Write-Output 'overwrite prompt: confirmed (file replaced)' }

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }