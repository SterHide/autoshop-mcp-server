# Put AutoShop back in the foreground -- as a LIBRARY that other scripts dot-source.
#
# WHY: every AutoShop automation script has to force AutoShop to the front in order to click, and
# afterwards the terminal / DSH window usually owns the focus again -- so the app looks "occupied"
# and the user cannot operate it. User's standing instruction: ALWAYS hand the foreground back to
# AutoShop when the work is done.
#
# WHY DOT-SOURCE AND NOT A CHILD PROCESS: spawning `powershell.exe -File autoshop-focus.ps1` was
# tried first and DID NOT WORK -- the focus stayed on the terminal. Windows only grants
# SetForegroundWindow to a process that owns (or recently received) the foreground; a fresh
# grandchild process does not qualify, so the call is silently refused. Dot-sourcing runs the code
# in the SAME process that did the clicking, which is the one Windows will allow.
#
# Usage, as the LAST thing in a script:
#     if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }
# Running it directly also works:
#     powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-focus.ps1
#
# KEEP PURE ASCII.
param([switch]$Quiet)

# Enable-Types is guarded: dot-sourcing several times must not throw "type already exists".
if (-not ('F.U' -as [type])) {
  Add-Type -Namespace F -Name U -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint flags);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
[DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
'@
}
function TxtOfWin([IntPtr]$h) { $b = New-Object System.Text.StringBuilder 256; [void][F.U]::GetWindowTextW($h, $b, 256); $b.ToString() }

# ★ 2026-09-20 FIX: Focus-AutoShop calls Get-AutoShopMainWindow(), which lives in autoshop-shared.ps1.
# Callers that dot-source THIS file alone (e.g. autoshop-close-all-blocks.ps1) died with
# "Get-AutoShopMainWindow is not recognized" -- which aborted the whole close pass. Load the shared
# helper here so this file is self-sufficient, and fall back to a plain Win32 lookup if it is missing.
if (-not (Get-Command Get-AutoShopMainWindow -ErrorAction SilentlyContinue)) {
  $__sh = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
  if (Test-Path -LiteralPath $__sh) { . $__sh }
}
if (-not (Get-Command Get-AutoShopMainWindow -ErrorAction SilentlyContinue)) {
  function Get-AutoShopMainWindow([object]$proc) {
    # minimal fallback: biggest visible Afx:* window of that process (same rule as shared.ps1)
    if ($null -eq $proc) { return [IntPtr]::Zero }
    return [IntPtr]$proc.MainWindowHandle
  }
  if (-not $Quiet) { Write-Output '  NOTE: autoshop-shared.ps1 not found - using the MainWindowHandle fallback for focus.' }
}

function Focus-AutoShop {
  param([switch]$Quiet)
  $proc = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($null -eq $proc) { if (-not $Quiet) { Write-Output 'AutoShop is not running - nothing to focus.' }; return $false }
  $main = (Get-AutoShopMainWindow $proc)
  if ($main -eq [IntPtr]::Zero) { if (-not $Quiet) { Write-Output 'AutoShop has no main window - nothing to focus.' }; return $false }
  # SW_RESTORE first: a minimized window cannot be foregrounded by SetForegroundWindow alone.
  if ([F.U]::IsIconic($main)) { [void][F.U]::ShowWindow($main, 9) }
  [void][F.U]::SetWindowPos($main, [IntPtr]::Zero, 0, 0, 0, 0, 0x0003)   # HWND_TOP, SWP_NOMOVE|SWP_NOSIZE
  [void][F.U]::BringWindowToTop($main)

  # A plain SetForegroundWindow is NOT reliable here -- it was observed to be silently refused, with
  # the focus staying on the terminal. Windows only lets a process take the foreground if it owns
  # the foreground, received the last input, or no lock is active, and a background console process
  # qualifies for none of those. Standard fix: attach THIS thread's input to the current foreground
  # thread, which makes the call legitimate, then detach.
  $fg = [F.U]::GetForegroundWindow()
  $fgThread = [F.U]::GetWindowThreadProcessId($fg, [IntPtr]::Zero)
  $myThread = [F.U]::GetCurrentThreadId()
  $attached = $false
  if ($fgThread -ne 0 -and $fgThread -ne $myThread) { $attached = [F.U]::AttachThreadInput($myThread, $fgThread, $true) }
  [void][F.U]::SetForegroundWindow($main)
  [void][F.U]::BringWindowToTop($main)
  if ($attached) { [void][F.U]::AttachThreadInput($myThread, $fgThread, $false) }
  Start-Sleep -Milliseconds 300

  # Still not foreground? Pulse to TOPMOST and back. That reliably raises the window above every
  # other window even when the focus grab is refused, so one click on it finishes the job.
  if ([F.U]::GetForegroundWindow() -ne $main) {
    [void][F.U]::SetWindowPos($main, [IntPtr](-1), 0, 0, 0, 0, 0x0003)   # HWND_TOPMOST
    Start-Sleep -Milliseconds 150
    [void][F.U]::SetWindowPos($main, [IntPtr](-2), 0, 0, 0, 0, 0x0003)   # HWND_NOTOPMOST
    [void][F.U]::SetForegroundWindow($main)
    Start-Sleep -Milliseconds 300
  }

  $ok = ([F.U]::GetForegroundWindow() -eq $main)
  if (-not $Quiet) {
    if ($ok) { Write-Output 'AutoShop is now the foreground window - the user can operate it.' }
    else {
      Write-Output ("AutoShop raised above every other window, but the keyboard focus is '{0}'." -f (TxtOfWin ([F.U]::GetForegroundWindow())))
      Write-Output '  (Windows refused the focus grab; one click on AutoShop completes it.)'
    }
  }
  return $ok
}

# Run directly (not dot-sourced) -> do the focus now.
if ($MyInvocation.InvocationName -ne '.') { [void](Focus-AutoShop -Quiet:$Quiet) }
