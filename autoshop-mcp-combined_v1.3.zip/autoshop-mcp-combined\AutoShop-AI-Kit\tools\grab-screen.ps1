# Grab a screenshot (from the clipboard, or the newest file in the Windows screenshot folder),
# save it to disk, then OCR it. Designed for capturing transient popups (context menus) that
# vanish as soon as the mouse moves: the user presses PrintScreen (keyboard only, no mouse
# movement), and this script turns that into text.
#
# MUST be run with -STA (clipboard access requires a single-threaded apartment):
#   powershell -STA -NoProfile -ExecutionPolicy Bypass -File grab-screen.ps1 -Out <png> [-Words]
param(
  [string]$Out = (Join-Path $env:TEMP 'autoshop-shot.png'),
  [switch]$Words,
  [int]$MaxAgeSeconds = 600
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms | Out-Null
Add-Type -AssemblyName System.Drawing | Out-Null

function Save-ClipboardImage($target) {
  try {
    $img = [System.Windows.Forms.Clipboard]::GetImage()
  } catch { return $false }
  if ($null -eq $img) { return $false }
  $bmp = New-Object System.Drawing.Bitmap $img.Width, $img.Height
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.DrawImage($img, 0, 0, $img.Width, $img.Height)
  $g.Dispose()
  $bmp.Save($target, [System.Drawing.Imaging.ImageFormat]::Png)
  Write-Output "source: clipboard image  ($($img.Width)x$($img.Height))"
  $bmp.Dispose(); $img.Dispose()
  return $true
}

function Save-NewestScreenshot($target, $maxAgeSeconds) {
  $dirs = @(
    "$env:USERPROFILE\Pictures\Screenshots",
    "$env:USERPROFILE\Pictures\屏幕截图",
    "$env:USERPROFILE\OneDrive\图片\屏幕截图"
  )
  $cut = (Get-Date).AddSeconds(-$maxAgeSeconds)
  $best = $null
  foreach ($d in $dirs) {
    if (-not (Test-Path -LiteralPath $d)) { continue }
    $f = Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue |
      Where-Object { $_.LastWriteTime -gt $cut } |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($f -and (-not $best -or $f.LastWriteTime -gt $best.LastWriteTime)) { $best = $f }
  }
  if (-not $best) { return $false }
  Copy-Item -LiteralPath $best.FullName -Destination $target -Force
  Write-Output "source: file $($best.FullName)  ($($best.LastWriteTime.ToString('HH:mm:ss')))"
  return $true
}

$ok = Save-ClipboardImage $Out
if (-not $ok) { $ok = Save-NewestScreenshot $Out $MaxAgeSeconds }

if (-not $ok) {
  Write-Output "NO IMAGE: clipboard has no image and no recent screenshot file was found."
  Write-Output "  -> press PrintScreen (whole screen) or Win+PrintScreen (saves a file), then retry."
  exit 1
}

Write-Output "saved: $Out  ($([math]::Round((Get-Item -LiteralPath $Out).Length/1KB))KB)"
Write-Output ""

$args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'ocr-file.ps1'), '-Path', $Out)
if ($Words) { $args += '-Words' }
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" @args
