# Rename an EXISTING struct-typed variable inside a variable-table CSV (parent row + all its member rows).
#
# Why: creating a NEW struct variable by import is silently dropped by AutoShop (measured 7x, 2026-09-20).
# Renaming an EXISTING one may take a different code path (it is a modification, not an insertion), so it
# is worth trying -- and it is what the user asked for ("为什么你测试不能再 CSV 改为 UN_st真空吸").
#
# Only the VARIABLE-NAME column (field index 1) is touched, and only for exact matches:
#   <seq>,<Old>            -> <seq>,<New>
#   ,<Old>.<member>,T,..   -> ,<New>.<member>,T,..
# Other names that merely CONTAIN the old name (e.g. UN_b测试2) are left alone.
#
# Chinese strings come in as PARAMETERS (a .ps1 with Chinese literals is read as ANSI by PS 5.1).
# KEEP PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$OldName,
  [Parameter(Mandatory=$true)][string]$NewName,
  [Parameter(Mandatory=$true)][string]$BaselineCsv,
  [Parameter(Mandatory=$true)][string]$OutCsv,
  [Parameter(Mandatory=$true)][string]$ProjectDir,
  [Parameter(Mandatory=$true)][string]$MirrorDir,
  [string]$View = '',
  [string]$VerifyDir = '',
  [string]$E = (Join-Path $PSScriptRoot 'autoshop-extract-blocks2.ps1'),
  [string]$Imp = (Join-Path $PSScriptRoot 'autoshop-import-vartable.ps1'),
  [string]$Open = (Join-Path $PSScriptRoot 'autoshop-open-node.ps1'),
  [string]$Wait = (Join-Path $PSScriptRoot 'autoshop-wait-dialog.ps1'),
  [string]$SaveTool = (Join-Path $PSScriptRoot 'confirm-then-save.ps1'),
  [int]$MenuOffsetY = 394,
  [int]$ImportOffsetY = 420,
  [int]$ExpectedMenuH = 632
)
$ErrorActionPreference = 'Stop'
$gbk = [System.Text.Encoding]::GetEncoding('GB2312')
$lines = @($gbk.GetString([System.IO.File]::ReadAllBytes($BaselineCsv)) -split "`r`n|`n")
$nonEmpty = @($lines | Where-Object { $_ -ne '' })
if ($nonEmpty.Count -eq 0) { throw 'baseline is empty' }

$changed = 0
$out = New-Object System.Collections.Generic.List[string]
foreach ($l in $lines) {
  if ($l -eq '') { $out.Add($l); continue }
  $f = $l -split ','
  if ($f.Count -lt 3) { $out.Add($l); continue }
  $v = $f[1]
  if ($v -eq $OldName) {
    $f[1] = $NewName; $changed++
    $out.Add(($f -join ','))
  } elseif ($v.StartsWith($OldName + '.')) {
    $f[1] = $NewName + $v.Substring($OldName.Length); $changed++
    $out.Add(($f -join ','))
  } else {
    $out.Add($l)
  }
}
Write-Output ("rename in CSV: '{0}' -> '{1}'   rows changed = {2}   (baseline {3} non-empty rows)" -f $OldName, $NewName, $changed, $nonEmpty.Count)
if ($changed -eq 0) { throw ('nothing matched: is the variable really named ' + $OldName + ' ?') }
[System.IO.File]::WriteAllText($OutCsv, ($out -join "`r`n"), $gbk)
Write-Output ('import file: ' + $OutCsv)
foreach ($l in @($out | Where-Object { $_ -match ([regex]::Escape($NewName)) } | Select-Object -First 3)) { Write-Output ('  sample: ' + $l) }

if (-not $View) { $View = [System.IO.Path]::GetFileNameWithoutExtension($BaselineCsv) }
if (-not $VerifyDir) { $VerifyDir = Join-Path (Split-Path -Parent $OutCsv) 'verify' }

Write-Output '--- opening the view ---'
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $Open -Node $View 2>&1 | Select-String -Pattern 'hitTest|title' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Start-Sleep -Milliseconds 800
Write-Output '--- importing (no auto-save) ---'
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $Imp -View $View -CsvPath $OutCsv -ImportOffsetY $ImportOffsetY -ExpectedMenuH $ExpectedMenuH -ConfirmImport -NoSave 2>&1 |
  Select-String -Pattern 'import prompt|clipboard|NO file|STALL' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Start-Sleep -Milliseconds 800
Write-Output '--- dismissing the success box (with proof) ---'
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $Wait 2>&1 | Select-String -Pattern 'found|pressing|CLOSED|CRASH' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }
Write-Output '--- saving via the toolbar button ---'
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $SaveTool -ProjectDir $ProjectDir 2>&1 | Select-String -Pattern 'dismissed|clicking Save|dialogs left|gvt|hcp' | ForEach-Object { Write-Output ('  ' + $_.Line.Trim()) }

Write-Output '--- verify by re-export ---'
New-Item -ItemType Directory -Force -Path $VerifyDir | Out-Null
& powershell -STA -NoProfile -ExecutionPolicy Bypass -File $E -ProjectDir $ProjectDir -MirrorDir $MirrorDir `
  -TableNames $View -TableOutDir $VerifyDir -ExpandFolded -Limit 1 -Redo -MenuOffsetY $MenuOffsetY -ExpectedMenuH $ExpectedMenuH *> (Join-Path $VerifyDir 'log.txt')
$t = $gbk.GetString([System.IO.File]::ReadAllBytes((Join-Path $VerifyDir ($View + '.csv'))))
$vRows = @($t -split "`r`n|`n" | Where-Object { $_ -ne '' })
$newHits = @($vRows | Where-Object { $_ -match ([regex]::Escape($NewName)) })
$oldHits = @($vRows | Where-Object { ($_ -split ',')[1] -eq $OldName -or ($_ -split ',')[1].StartsWith($OldName + '.') })
Write-Output ("verify: {0} rows (baseline {1}); '{2}' rows = {3}; '{4}' rows = {5}" -f $vRows.Count, $nonEmpty.Count, $NewName, $newHits.Count, $OldName, $oldHits.Count)
if ($newHits.Count -eq $changed -and $oldHits.Count -eq 0) { Write-Output 'RESULT: OK - the rename took' } else { Write-Output 'RESULT: the rename did NOT take' }
