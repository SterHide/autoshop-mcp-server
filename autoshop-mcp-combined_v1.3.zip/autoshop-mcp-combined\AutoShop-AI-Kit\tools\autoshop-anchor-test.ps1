﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Controlled test: is accSelect(id) a RELIABLE way to select a tree node?
#
# Why this matters: a real extraction run drifted at step 42 -- the selection jumped from
# 'SBR_UN鍘嗗彶OEE' to the unrelated '鏁版嵁璁板綍' (a node far down the tree), the tree auto-scrolled
# there, and the walk died. The prime suspect is accSelect(): the MSAA child-id space of this
# control is demonstrably unstable (the same node answers on different ids before/after scrolling,
# and accChildCount reports 188 while real ids run past 230).
#
# Method (read-only, no block is ever opened):
#   1. walk DOWN with the keyboard and record the authoritative (id -> name) mapping as we go
#   2. afterwards, for a sample of those ids, call accSelect(3, id) and re-read the name
#   3. PASS  = selection round-trips to the same id AND accName still yields the recorded name
#      FAIL  = the id now resolves to a DIFFERENT node  => accSelect is unsafe for re-anchoring
#   4. restore the tree to the top before exiting (a previous probe left it scrolled to the bottom)
#
# KEEP PURE ASCII. Run with -STA.
param([int]$Steps = 25, [int]$Samples = 6)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000;
         selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88
$LD = 0x02; $LU = 0x04
$WM_CLOSE = 0x0010

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function RawClick([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }
function Dialogs {
  $d = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$d.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero); return $d }
# every click is followed by a dialog check; only No / Cancel is ever pressed
function AssertNoDialog([string]$where) {
  foreach ($d in (Dialogs)) {
    $kids = New-Object System.Collections.ArrayList
    $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d, $cb, [IntPtr]::Zero)
    Write-Output ("   [dialog] '{0}' buttons=[{1}]" -f (TxtOf $d), (($kids | ForEach-Object { TxtOf $_ }) -join '/'))
    $done = $false
    foreach ($b in $kids) {
      $t = TxtOf $b
      if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) {
        $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$r)
        RawClick ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2)); $done = $true; break } }
    if (-not $done) { Send '{ESC}' 400 }
    Start-Sleep -Milliseconds 350
  } }
function ClickChecked([int]$x, [int]$y, [string]$where) { RawClick $x $y; Start-Sleep -Milliseconds 160; AssertNoDialog $where }

function CloseStale([IntPtr]$mainHwnd) {
  $mdi = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'MDIClient') { $script:mdiT = $h }; return $true }
  [void][W.U]::EnumChildWindows($mainHwnd, $cb, [IntPtr]::Zero); $mdi = $script:mdiT
  if ($mdi -eq [IntPtr]::Zero) { return 0 }
  $n = 0
  for ($i = 0; $i -lt 80; $i++) {
    # NB: initialise the holder first -- if no visible child exists the callback never runs and an
    # unset variable arrives as $null, which TxtOf(IntPtr) then rejects.
    $script:kidT = [IntPtr]::Zero
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { $script:kidT = $h; return $false }; return $true }
    [void][W.U]::EnumChildWindows($mdi, $cb2, [IntPtr]::Zero); $k = $script:kidT
    if ($null -eq $k -or $k -eq [IntPtr]::Zero) { break }
    Write-Output ("   [stale] closing '{0}'" -f (TxtOf $k))
    [void][W.U]::SendMessageW($k, $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 320; AssertNoDialog 'closing stale'; $n++ }
  return $n }

# --- setup -----------------------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$script:MainHwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows($script:MainHwnd, $cb, [IntPtr]::Zero)
$tree = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:acc = $null
$hr = [W.U]::AccessibleObjectFromWindow($tree.hwnd, [uint32]4294967292, [ref]$iid, [ref]$script:acc)
if ($hr -ne 0) { throw ("AccessibleObjectFromWindow hr=0x{0:X8}" -f $hr) }
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $tree.hwnd, $tree.rect.Left, $tree.rect.Top, ($tree.rect.Right-$tree.rect.Left), ($tree.rect.Bottom-$tree.rect.Top))

[void][W.U]::SetForegroundWindow($script:MainHwnd); Start-Sleep -Milliseconds 350
AssertNoDialog 'pre-flight' | Out-Null
Write-Output ("stale windows closed: {0}" -f (CloseStale $script:MainHwnd))

function ReadSel {
  $id = $null
  try { $id = $script:acc.accSelection } catch { }
  $o = [pscustomobject]@{ Id=$null; Name=''; State=-1; X=0; Y=0; W=0; H=0 }
  if ($null -eq $id -or $id -isnot [int]) { return $o }
  try { $o.Name  = [string]$script:acc.accName([int]$id) } catch { }
  try { $o.State = [int]$script:acc.accState([int]$id) } catch { }
  $x=0;$y=0;$w=0;$h=0
  try { $script:acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$id) } catch { }
  $o.X=$x; $o.Y=$y; $o.W=$w; $o.H=$h; $o.Id=[int]$id
  return $o }

function NameOfId([int]$id) { try { return [string]$script:acc.accName([int]$id) } catch { return '<ERR>' } }

# --- 1. authoritative mapping by keyboard walk ------------------------------------------------
ClickChecked ($tree.rect.Left + 40) ($tree.rect.Top + 10) 'focus tree'
Send '^({HOME})' 600
$rootName = Split-Path -Leaf 'C:\Users\Administrator\Desktop\ST妗嗘灦'
$s = ReadSel
if ($s.Name -notlike "$rootName*") {
  Write-Output ("  Ctrl+Home did not reach the root (at '{0}') - walking UP" -f $s.Name)
  $prev = $s.Name
  for ($i = 0; $i -lt 400; $i++) { Send '{UP}' 35; $s = ReadSel; if ($s.Name -eq $prev) { break }; $prev = $s.Name }
}
Write-Output ("walk starts at id={0} name='{1}'" -f $s.Id, $s.Name)

Write-Output ''
Write-Output '--- step 1: keyboard walk, recording id -> name ---'
$map = New-Object System.Collections.ArrayList
$prev = $null
for ($i = 1; $i -le $Steps; $i++) {
  $s = ReadSel
  if ($s.Id -and $s.Name -and $s.Name -ne $prev) {
    [void]$map.Add([pscustomobject]@{ Id=$s.Id; Name=$s.Name; Y=$s.Y })
    Write-Output ("  step {0,3}  id={1,4}  y={2,5}  '{3}'" -f $i, $s.Id, $s.Y, $s.Name)
  }
  $prev = $s.Name
  Send '{DOWN}' 90
}
Write-Output ("recorded {0} nodes" -f $map.Count)

# --- 2. select each sampled id programmatically and re-read the name --------------------------
Write-Output ''
Write-Output '--- step 2: accSelect(3, id) then re-read ---'
$pass = 0; $fail = 0
$idx = @()
if ($map.Count -gt 0) {
  for ($k = 0; $k -lt $Samples; $k++) { $idx += [int]($k * ($map.Count - 1) / [Math]::Max(1, $Samples - 1)) }
  $idx = $idx | Select-Object -Unique
}
foreach ($i in $idx) {
  $rec = $map[$i]
  $selOk = $true
  try { $script:acc.accSelect(3, [int]$rec.Id) } catch { $selOk = $false }
  Start-Sleep -Milliseconds 220
  $after = ReadSel
  $nameNow = NameOfId $rec.Id
  $sameId   = ($after.Id -eq $rec.Id)
  $sameName = ($nameNow -eq $rec.Name)
  $focused  = ($after.State -ge 0 -and ($after.State -band $ST.focused))
  $verdict = if ($sameId -and $sameName) { 'PASS' } else { 'FAIL' }
  if ($verdict -eq 'PASS') { $pass++ } else { $fail++ }
  Write-Output ("  {0}  id={1,4} expected='{2}' now='{3}' selIdAfter={4} focused={5} selOk={6}" -f `
    $verdict, $rec.Id, $rec.Name, $nameNow, $after.Id, $focused, $selOk)
}

Write-Output ''
Write-Output ("accSelect verdict: PASS={0}  FAIL={1}" -f $pass, $fail)
if ($fail -gt 0) {
  Write-Output '*** accSelect resolves ids UNSTABLY -> do NOT use it for re-anchoring.'
  Write-Output '*** Re-anchor with a real click on the row rect instead (verified by the FOCUSED bit + name).'
} else {
  Write-Output 'accSelect round-trips correctly on this sample -> safe to use for re-anchoring.'
}

# --- 3. restore: leave the tree at the top ---------------------------------------------------
Send '^({HOME})' 600
AssertNoDialog 'restore'
$end = ReadSel
Write-Output ''
Write-Output ("restored: tree left at id={0} name='{1}' (was scrolled by this test; put back to the top)" -f $end.Id, $end.Name)

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }
