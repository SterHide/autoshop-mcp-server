# Extract the fenced source block from a mirror .md into a plain UTF-8 (no BOM) .st file.
#
# WHY: the write channel (autoshop-write-block.ps1) takes a FILE, and the mirror .md holds
# front-matter + a fenced code block. Doing this inline kept breaking on quoting, so it is a file.
#
# Accepts fences tagged ```st / ```fb / untagged, and ALSO the single-backtick typo (`st ... `) that
# one hand-written .md shipped with -- a one-character fence is easy to miss and made the extractor
# return "no fence" while the file looked fine.
#
# KEEP PURE ASCII (paths and names arrive via parameters).
param(
  [Parameter(Mandatory=$true)][string]$Md,
  [Parameter(Mandatory=$true)][string]$Out,
  [switch]$Quiet
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Md)) { throw ("no such .md: " + $Md) }
$txt = [System.IO.File]::ReadAllText($Md, [System.Text.Encoding]::UTF8)
$bt  = [string][char]96
$f3  = $bt + $bt + $bt

$body = $null
$kind = ''
# 1) triple-backtick fence
$m = [regex]::Match($txt, '(?s)' + [regex]::Escape($f3) + '[A-Za-z]*[ \t]*\r?\n(.*?)\r?\n' + [regex]::Escape($f3))
if ($m.Success) { $body = $m.Groups[1].Value; $kind = 'triple-backtick fence' }
# 2) single-backtick fence (the typo variant): a line that is exactly `st (or `fb)
if ($null -eq $body) {
  $m2 = [regex]::Match($txt, '(?s)' + [regex]::Escape($bt) + '(st|fb|ST|FB)[ \t]*\r?\n(.*?)\r?\n' + [regex]::Escape($bt) + '[ \t]*(\r?\n|$)')
  if ($m2.Success) { $body = $m2.Groups[2].Value; $kind = 'single-backtick fence (non-standard)' }
}
if ($null -eq $body) { throw ('no fenced source block found in ' + $Md) }

$body = ($body -replace "`r`n", "`n")
$dir = Split-Path -Parent $Out
if ($dir -and -not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Force -Path $dir) }
[System.IO.File]::WriteAllBytes($Out, (New-Object System.Text.UTF8Encoding($false)).GetBytes($body))

if (-not $Quiet) {
  $lines = @($body -split "`n")
  Write-Output ("extracted from {0}" -f $Md)
  Write-Output ("  fence style : {0}" -f $kind)
  Write-Output ("  chars={0}  lines={1}  bytes={2} -> {3}" -f $body.Length, $lines.Count, (Get-Item -LiteralPath $Out).Length, $Out)
  Write-Output ("  first line  : {0}" -f $lines[0])
  Write-Output ("  last  line  : {0}" -f $lines[$lines.Count-1])
}
