# AutoShop PRE-FLIGHT. Run this BEFORE any UI operation on AutoShop. Always.
#
# WHY THIS EXISTS (both failures were silent and cost hours):
#
#   1) TREE PANE WIDTH. The project tree pane is a resizable docked pane. When it is merely "a bit
#      narrow", long node names do not fit and Windows adds a HORIZONTAL SCROLLBAR along the bottom
#      of the control. Rows near the bottom then have their rect OVERLAPPING that scrollbar, so a
#      click aimed at a row presses the scrollbar instead: the target never opens, and the tree
#      lurches to another scroll position. Measured on the stock pane: content 314px vs viewport
#      181px -> 133px overflow -> 8 blocks in a row failed to open, and consecutive nodes reported
#      impossible rects (y=918 then y=178, i.e. 740px apart).
#      The pane width is NOT stable: it was widened to 347px (overflow 0, everything worked) and
#      later came back at 198px (overflow 134px) on its own.
#      DECISIVE MEASURE: not the pixel width, but (GetScrollInfo SB_HORZ range) - page == 0.
#
#   ★ CORRECTION (2026-09-20, measured live on V4.11.0.5): that SCROLLINFO reading is BROKEN and must
#     never drive a drag. This build reports nPage = 0, so the formula collapses to
#     overflow = (nMax - nMin + 1) - 0 = range -- a number that does NOT depend on the pane width at
#     all. Measured proof: a drag widened the tree 446px -> 570px and the reported overflow stayed at
#     exactly 101px. Every earlier -Fix run therefore pushed the splitter further right, ended at
#     570px, and -- because AutoShop PERSISTS the pane width -- left a permanently half-screen-wide
#     tree (user: "左栏如果过宽你应该拉回去"). Therefore: when nPage = 0 the reading is declared
#     UNRELIABLE, it is NOT reported as a failure, and NO drag happens. Dragging now requires BOTH
#     -WidenPane AND a usable reading, and it drags itself back when it fails to improve the number.
#
#   2) MAIN WINDOW SIZE/POSITION. The verified absolute coordinates for the GVL/HMI variable export
#      flow assume the main window sits at (0,1) with size 1287x1144, NOT maximized. Maximizing or
#      moving the frame changes the internal layout AND moves every centred dialog, silently
#      invalidating all of those coordinates.
#
# Also reports: how many block views are open (must be 0-2; ~34 pops "open window count exceeded"
# and disables the whole UI) and whether a modal dialog is currently up.
#
# KEEP PURE ASCII. Chinese arrives only via command-line parameters.
param(
  [int]$BaseX = 0, [int]$BaseY = 1, [int]$BaseW = 1287, [int]$BaseH = 1144,
  [switch]$Fix,                 # normalise the window + close stale block views (never touches the pane)
  [switch]$Deep,                # ALSO check the tree's fold state and expand every folded folder
  [switch]$WidenPane,           # opt-in: allow a splitter drag, only when the overflow reading is usable
  [switch]$KeepViews,           # with -Fix: report open views but NEVER close them (no data loss)
  [int]$PaneMargin = 24,        # widen by (overflow + this) when -WidenPane actually drags
  [switch]$FitToScreen,         # PORTABILITY: shrink BaseW/BaseH so the window fits THIS screen
  [switch]$Quiet
)
# PORTABILITY (2026-09-20): 1287x1144 is the geometry the export flow was calibrated on. On a smaller or
# higher-DPI screen that window does not fit, and MoveWindow would leave part of it off-screen. With
# -FitToScreen the target is clamped to the actual work area and the geometry that is REALLY used gets
# printed, so every later step works from the measured numbers instead of the constants above.
$screenNote = ''
if ($FitToScreen) {
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    if ($BaseW -gt ($wa.Width - 8)) { $BaseW = $wa.Width - 8 }
    if ($BaseH -gt ($wa.Height - 8)) { $BaseH = $wa.Height - 8 }
    if ($BaseX + $BaseW -gt $wa.Right) { $BaseX = [Math]::Max(0, $wa.Right - $BaseW) }
    if ($BaseY + $BaseH -gt $wa.Bottom) { $BaseY = [Math]::Max(0, $wa.Bottom - $BaseH) }
    $screenNote = ('screen work area {0}x{1} at {2},{3} -> target geometry {4},{5} {6}x{7}' -f `
      $wa.Width, $wa.Height, $wa.X, $wa.Y, $BaseX, $BaseY, $BaseW, $BaseH)
  } catch { $screenNote = 'could not read the screen work area; keeping the default geometry' }
}

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
[DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool repaint);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
[StructLayout(LayoutKind.Sequential)] public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin; public int nMax; public int nPage; public int nPos; public int nTrackPos; }
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$WS_HSCROLL = 0x00100000; $SB_HORZ = 0; $SB_VERT = 1; $SIF_ALL = 0x17
$WM_CLOSE = 0x0010
$S_NO     = [string][char]0x5426
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88
$LD = 0x02; $LU = 0x04
$ST_COLLAPSED = 0x400; $ST_EXPANDED = 0x200; $ST_FOCUSED = 0x4
$script:problems = New-Object System.Collections.ArrayList

# --- tree helpers (MSAA) -- only used by the -Deep fold check --------------------------------
function Get-Acc([IntPtr]$h) {
  # NB: returning a __ComObject from a function mangles it (the caller gets a bare Int32), so the
  # out-object must land in a script-scope variable.
  $iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
  $script:accObj = $null
  $hr = [W.U]::AccessibleObjectFromWindow($h, [uint32]4294967292, [ref]$iid, [ref]$script:accObj)
  if ($hr -ne 0 -or $null -eq $script:accObj) { return $false }
  return $true
}
function Count-Folded([IntPtr]$treeHwnd) {
  $folded = New-Object System.Collections.ArrayList
  for ($i = 1; $i -le 400; $i++) {
    $nm = $null; $st = $null
    try { $nm = [string]$script:accObj.accName([int]$i) } catch { continue }
    if ([string]::IsNullOrEmpty($nm)) { continue }
    try { $st = [int]$script:accObj.accState([int]$i) } catch { continue }
    if ($st -band $ST_COLLAPSED) { [void]$folded.Add([pscustomobject]@{ Id=$i; Name=$nm }) }
  }
  return $folded
}

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); return $r }
function SInfo([IntPtr]$h, [int]$bar) {
  $si = New-Object W.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = $SIF_ALL
  if (-not [W.U]::GetScrollInfo($h, $bar, [ref]$si)) { return $null }
  return $si }
function ClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0) }
function Dismiss-Dialogs {
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }; return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  foreach ($d in $dlgs) {
    $kids = New-Object System.Collections.ArrayList
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.U]::EnumChildWindows($d, $cb2, [IntPtr]::Zero)
    Write-Output ("   [dialog] '{0}' buttons=[{1}]" -f (TxtOf $d), (($kids | ForEach-Object { TxtOf $_ }) -join '/'))
    $pressed = $false
    foreach ($b in $kids) {
      $t = TxtOf $b
      if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) { $r = RectOf $b; ClickRaw ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2)); $pressed = $true; break } }
    if (-not $pressed) { [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Start-Sleep -Milliseconds 400 }
    Start-Sleep -Milliseconds 300 } }

function Problem([string]$text) { [void]$script:problems.Add($text); Write-Output ("  FAIL  {0}" -f $text) }
function Ok([string]$text)      { Write-Output ("  ok    {0}" -f $text) }

# --- locate AutoShop -------------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction SilentlyContinue | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
if ($null -eq $proc) { Write-Output 'ABORT: AutoShop is not running.'; exit 2 }
$main = (Get-AutoShopMainWindow $proc)
Write-Output ('=== AutoShop pre-flight ===')
Write-Output ("main hwnd={0}  pid={1}" -f $main, $proc.Id)
Write-Output ("title: {0}" -f $proc.MainWindowTitle)
Write-Output ''

# --- check 1: main window geometry -----------------------------------------------------------
Write-Output '1) main window geometry (the export flow works relative to it)'
if ($screenNote -ne '') { Write-Output ('  ' + $screenNote) }
$mr = RectOf $main
$mw = $mr.Right - $mr.Left; $mh = $mr.Bottom - $mr.Top
$zoomed = [W.U]::IsZoomed($main)
Write-Output ("  actual : x={0} y={1} w={2} h={3}  maximized={4}" -f $mr.Left, $mr.Top, $mw, $mh, $zoomed)
Write-Output ("  baseline: x={0} y={1} w={2} h={3}  (not maximized)" -f $BaseX, $BaseY, $BaseW, $BaseH)
# PORTABILITY: the baseline is only a PREFERRED geometry. What later steps really need is a non-maximized,
# fully on-screen window + a wide-enough tree pane -- both measured live. Report the scale between the
# actual and baseline sizes so a different DPI / screen is visible in the log instead of silently wrong.
$geomScaleW = if ($BaseW -gt 0) { $mw / [double]$BaseW } else { 1.0 }
$geomScaleH = if ($BaseH -gt 0) { $mh / [double]$BaseH } else { 1.0 }
Write-Output ("  size ratio vs baseline: {0:N3} x {1:N2}" -f $geomScaleW, $geomScaleH)
$offScreen = ($mr.Left -lt -2000) -or ($mw -lt 400)
if ($offScreen) { Problem 'the window is minimized or off-screen (clicks would go nowhere)' }
$geomOk = (-not $zoomed) -and (-not $offScreen) -and $mr.Left -eq $BaseX -and $mr.Top -eq $BaseY -and $mw -eq $BaseW -and $mh -eq $BaseH
if ($geomOk) { Ok 'geometry matches the baseline' }
else {
  Problem ("geometry differs from the baseline (later steps still work: they use live element rects; the window must just be restored, not maximized and fully on-screen)")
  if ($Fix) {
    if ($zoomed) { [void][W.U]::SendMessageW($main, 0x0112, [IntPtr]0xF120, [IntPtr]::Zero); Start-Sleep -Milliseconds 500 }  # WM_SYSCOMMAND SC_RESTORE
    [void][W.U]::MoveWindow($main, $BaseX, $BaseY, $BaseW, $BaseH, $true); Start-Sleep -Milliseconds 700
    $mr = RectOf $main
    Write-Output ("  FIXED -> x={0} y={1} w={2} h={3}" -f $mr.Left, $mr.Top, ($mr.Right-$mr.Left), ($mr.Bottom-$mr.Top))
    Write-Output ("  (the geometry actually in use is the FIXED line above -- later scripts read it live, not from constants)")
    if (($mr.Right-$mr.Left) -eq $BaseW -and ($mr.Bottom-$mr.Top) -eq $BaseH) { Ok 'geometry normalized' } else { Problem 'geometry still differs after MoveWindow' }
  } else { Write-Output '  (re-run with -Fix to normalize; add -FitToScreen on a smaller/high-DPI screen)' }
}
Write-Output ''

# --- check 2: tree pane width / horizontal overflow ------------------------------------------
Write-Output '2) project tree pane width  <-- ADVISORY on this build (its SCROLLINFO reading is broken, see NOTE)'
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { [void]$trees.Add($h) }
  return $true }
[void][W.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
if ($trees.Count -eq 0) { Problem 'no SysTreeView32 found under the main window'; }
else {
  $tree = $trees | Sort-Object { (RectOf $_).Left } | Select-Object -First 1
  $tr = RectOf $tree
  $cr = New-Object W.U+RECT; [void][W.U]::GetClientRect($tree, [ref]$cr)
  Write-Output ("  tree hwnd={0} window={{ {1},{2} {3}x{4} }}  client={5}x{6}" -f $tree, $tr.Left, $tr.Top, ($tr.Right-$tr.Left), ($tr.Bottom-$tr.Top), $cr.Right, $cr.Bottom)
  $style = [W.U]::GetWindowLong($tree, -16)
  $hsi = SInfo $tree $SB_HORZ
  $vsi = SInfo $tree $SB_VERT
  $curW = $tr.Right - $tr.Left
  $page = if ($hsi) { [int]$hsi.nPage } else { -1 }
  $readable = ($null -ne $hsi -and $page -gt 0)
  $overflow = if ($readable) { [Math]::Max(0, ($hsi.nMax - $hsi.nMin + 1) - $page) } else { -1 }
  Write-Output ("  WS_HSCROLL={0}   SB_HORZ range={1} page={2}  -> range/page figure = {3}  [ADVISORY ONLY]" -f `
    [bool]($style -band $WS_HSCROLL), $(if ($hsi) { ($hsi.nMax - $hsi.nMin + 1) } else { 0 }), $page, $(if ($readable) { "$($overflow)px" } else { 'UNKNOWN' }))
  if ($vsi) { Write-Output ("  SB_VERT range={0} page={1} -> {2} rows, {3} visible" -f ($vsi.nMax-$vsi.nMin+1), $vsi.nPage, ($vsi.nMax-$vsi.nMin+1), $vsi.nPage) }

  # ---- THE DECISION: the pane's PIXEL width band. Never the SCROLLINFO figure above. -------------
  # USER RULE (2026-09-20): "drag the left pane FIRST, then expand all folders". So this rule has to be
  # UNCONDITIONAL: an earlier version nested it inside the "SCROLLINFO unreadable" branch, and on a run
  # where the figure WAS readable the pane was never normalised (measured: it stayed 199px and the
  # preflight kept failing). Pane = check 2, expand = check 5, so the order is guaranteed by structure.
  # It also has to run BEFORE the fold pass: on a narrow pane the tree is clipped and carries a bottom
  # horizontal scrollbar, which makes the expand clicks land wrong.
  $paneTarget = 346; $paneLow = 300; $paneHigh = 400
  $paneOk = ($curW -ge $paneLow -and $curW -le $paneHigh)
  if (-not $paneOk) {
    Problem ("tree pane is {0}px wide -> outside the sane band {1}..{2}px (PIXEL width; the SCROLLINFO figure is not used to decide)" -f $curW, $paneLow, $paneHigh)
    if ($Fix) {
      $sp = Join-Path $PSScriptRoot 'autoshop-set-pane.ps1'
      if (Test-Path -LiteralPath $sp) {
        # MUST run as a SEPARATE process: autoshop-set-pane.ps1 ends with `exit`, and an in-process call
        # would terminate THIS script right here -- skipping the fold pass that has to run afterwards.
        $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        Write-Output ("  FIX: dragging the pane to {0}px FIRST (the fold pass runs after this)" -f $paneTarget)
        & $psExe -NoProfile -ExecutionPolicy Bypass -File $sp -Width $paneTarget 2>&1 |
          ForEach-Object { Write-Output ('        ' + $_) }
        $trW = RectOf $tree
        Ok ("tree pane is {0}px wide now" -f ($trW.Right - $trW.Left))
      } else {
        Write-Output '  WARNING: autoshop-set-pane.ps1 not found next to this script - pane left as it is'
      }
    } else {
      Write-Output ('          fix it with: autoshop-set-pane.ps1 -Width ' + $paneTarget)
    }
  } else {
    Ok ("tree pane {0}px wide -> inside the sane band {1}..{2}px" -f $curW, $paneLow, $paneHigh)
  }
  if (-not $readable) {
    Write-Output  ('  NOTE: SB_HORZ page=0 -> the range/page figure is UNRELIABLE on this build and is ignored;')
    Write-Output  ('        the PIXEL band above is the only rule that may move the splitter.')
  } elseif ($overflow -gt 0) {
    Write-Output  ('  NOTE: the range/page figure says {0}px, but it is ADVISORY only -- inside the band the splitter' -f $overflow)
    Write-Output  ('        is not touched (trusting this number is what used to widen the pane for no reason).')
  }
}
Write-Output ''

# --- check 3: open block views ---------------------------------------------------------------
# NB: EnumChildWindows is RECURSIVE -- it returns every descendant, not just the direct children.
# Counting all of them reported ONE open block view as SEVEN (a block view contains an
# AfxMDIFrame90u, a #32770, two Buttons, a VSFlexGrid8N, an AfxFrameOrView90u and the Scintilla),
# so a single open view looked like a failure. Count only DIRECT children of the MDIClient.
Write-Output '3) open block views (must be 0-2; about 34 pops the window-limit dialog and disables the UI)'
$mdiCount = 0
function Get-MdiChildren([IntPtr]$mcl) {
  $res = New-Object System.Collections.ArrayList
  $cbx = [W.U+EnumProc]{ param($h,$p) if ([W.U]::GetParent($h) -eq $mcl) { [void]$res.Add($h) }; return $true }
  [void][W.U]::EnumChildWindows($mcl, $cbx, [IntPtr]::Zero)
  return $res
}
try {
  $mcl = [IntPtr]::Zero
  $cb2 = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'MDIClient') { $script:mcl = $h }; return $true }
  [void][W.U]::EnumChildWindows($main, $cb2, [IntPtr]::Zero)
  $mcl = $script:mcl
  if ($null -ne $mcl -and $mcl -ne [IntPtr]::Zero) {
    $mdiCount = @(Get-MdiChildren $mcl | Where-Object { [W.U]::IsWindowVisible($_) }).Count
  }
} catch { }
Write-Output ("  open block views: {0}" -f $mdiCount)
if ($mdiCount -le 2) { Ok 'within the safe range' }
else {
  Problem ("{0} block views are open" -f $mdiCount)
  if ($Fix -and $KeepViews) {
    # ★ -KeepViews: report only. Closing a view that has UNSAVED edits loses them (WM_CLOSE raises a
    #   "save?" prompt, and this script answers No/Cancel by design), so an AUTOMATIC startup pass must
    #   never close views. Used by the MCP server's once-per-session normalisation.
    Write-Output '  (-KeepViews: NOT closing them -- close them yourself after saving, or call autoshop_close_all)'
  } elseif ($Fix) {
    Write-Output '  FIX: closing them with WM_CLOSE'
    for ($i = 0; $i -lt 80; $i++) {
      $k = @(Get-MdiChildren $mcl | Where-Object { [W.U]::IsWindowVisible($_) })
      if ($k.Count -eq 0) { break }
      [void][W.U]::SendMessageW($k[0], $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
      Start-Sleep -Milliseconds 300; Dismiss-Dialogs }
    Ok 'stale block views closed'
  } else { Write-Output '  (re-run with -Fix, or use autoshop-close-all-blocks.ps1)' }
}
Write-Output ''

# --- check 4: modal dialog -------------------------------------------------------------------
Write-Output '4) modal dialog up?'
try {
  $root = [System.Windows.Automation.AutomationElement]::FromHandle($main)
  $en = $root.Current.IsEnabled
  Write-Output ("  main window IsEnabled = {0}" -f $en)
  if ($en) { Ok 'no modal dialog blocking (a modal makes every click and keypress silently fail)' }
  else {
    Problem 'the main window is DISABLED -> a modal dialog is up; every click/keypress is being swallowed'
    if ($Fix) { Dismiss-Dialogs; Ok 'dialogs dismissed (No/Cancel only)' }
  }
} catch { Write-Output ("  (could not read IsEnabled: {0})" -f $_.Exception.Message) }

# --- check 5 (-Deep): fold state ---------------------------------------------------------------
# A folded folder hides its children from ANY tree walk, so a target inside it is simply never
# visited -- and the log then says "not found / never reached", which looks like a completely
# different problem. First run of a session must therefore EXPAND EVERYTHING before hunting targets.
if ($Deep) {
  Write-Output ''
  Write-Output '5) tree fold state  <-- a folded folder hides its children from the walk entirely'
  if ($null -eq $tree -or $tree -eq [IntPtr]::Zero) {
    Problem 'no tree handle available - fold state unknown'
  } elseif (-not (Get-Acc $tree)) {
    Problem 'could not open the tree via MSAA - fold state unknown'
  } else {
    [void][W.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 350
    $pass = 0
    while ($pass -lt 6) {
      $folded = Count-Folded $tree
      if ($folded.Count -eq 0) { break }
      $pass++
      Write-Output ("  pass {0}: {1} folded folder(s): {2}" -f $pass, $folded.Count, `
        (($folded | Select-Object -First 10 | ForEach-Object { $_.Name }) -join ', '))
      if (-not $Fix) { break }
      foreach ($f in $folded) {
        # accSelect is mouse-free and verified reliable; RIGHT expands a collapsed folder.
        # RIGHT is only sent for folders whose MSAA state really says "collapsed".
        try { $script:accObj.accSelect(3, [int]$f.Id) } catch { }
        Start-Sleep -Milliseconds 160
        [System.Windows.Forms.SendKeys]::SendWait('{RIGHT}')
        Start-Sleep -Milliseconds 260
        Dismiss-Dialogs
      }
    }
    $left = Count-Folded $tree
    if ($left.Count -eq 0) { Ok 'every folder is expanded (no STATE_SYSTEM_COLLAPSED left)' }
    else {
      Problem ("{0} folder(s) still folded (e.g. {1})" -f $left.Count, (($left | Select-Object -First 5 | ForEach-Object { $_.Name }) -join ', '))
      if (-not $Fix) { Write-Output '  (re-run with -Fix to expand them)' }
    }
  }
}

# --- verdict ---------------------------------------------------------------------------------
Write-Output ''
if ($script:problems.Count -eq 0) {
  Write-Output '=== PRE-FLIGHT PASS - safe to operate AutoShop ==='
  exit 0
} elseif ($Fix) {
  # The problems above were collected BEFORE the fixes ran, so reporting FAIL here would be
  # misleading: the fixes were applied in place. Say so, and require a clean re-run to confirm.
  Write-Output ("=== FIXES APPLIED for {0} problem(s) ===" -f $script:problems.Count)
  foreach ($p in $script:problems) { Write-Output ("   * {0}" -f $p) }
  Write-Output '   -> re-run WITHOUT -Fix to confirm PRE-FLIGHT PASS.'
  exit 0
} else {
  Write-Output ("=== PRE-FLIGHT FAIL - {0} problem(s) ===" -f $script:problems.Count)
  foreach ($p in $script:problems) { Write-Output ("   * {0}" -f $p) }
  Write-Output '   -> re-run with -Fix, then re-run without -Fix to confirm PASS.'
  exit 1
}

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }