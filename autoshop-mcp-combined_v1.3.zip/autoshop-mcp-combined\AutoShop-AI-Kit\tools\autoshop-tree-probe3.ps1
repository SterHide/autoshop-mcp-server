﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Probe 3: are MSAA rects REAL (scroll-aware) or virtual, and can we read the SELECTED node?
#
# Two facts must be settled before any click is trusted:
#   1. Are accLocation rects screen-real for currently visible rows, or "virtual" positions of the
#      fully expanded tree?  Test: read node 1's rect, scroll the tree 30 rows, read it again.
#      * rect moves / goes off-box  => REAL, and coordinates can be used directly
#      * rect unchanged             => VIRTUAL, coordinates are useless, must derive y from the
#                                      visible row grid instead
#   2. Can we read WHICH node is selected (so keyboard navigation can be tied to a name)?
#
# KEEP PURE ASCII.
$ErrorActionPreference = 'Stop'
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

$LD = 0x02; $LU = 0x04
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LU,0,0,0,0)
}
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$hwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows($hwnd, $cb, [IntPtr]::Zero)
$t = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
Write-Output ("project tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $t.hwnd, $t.rect.Left, $t.rect.Top, ($t.rect.Right-$t.rect.Left), ($t.rect.Bottom-$t.rect.Top))

$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
[void][W.U]::AccessibleObjectFromWindow($t.hwnd, [uint32]4294967292, [ref]$iid, [ref]$acc)

function RectOf([int]$i) {
  $x=0;$y=0;$w=0;$h=0
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$i) } catch { }
  return "$x,$y,$w,$h"
}
function NameOf([int]$i) {
  try { return [string]$acc.accName([int]$i) } catch { return '<ERR>' }
}
# MSAA STATE_SYSTEM_* -- the collapse/expand bits are what tell us whether a folder's children
# are reachable right now, without ever double-clicking the folder (double-click = properties dialog).
$SB = @{ expanded=0x2000; collapsed=0x4000; selected=0x2; focused=0x4; invisible=0x8000; offscreen=0x10000; focusable=0x100000; haspopup=0x40000000 }
function StateOf([int]$i) {
  $s = $null
  try { $s = [int]$acc.accState([int]$i) } catch { return '<ERR>' }
  $f = New-Object System.Collections.ArrayList
  foreach ($k in @('expanded','collapsed','selected','focused','focusable','invisible','offscreen')) { if ($s -band $SB[$k]) { [void]$f.Add($k) } }
  $txt = if ($f.Count) { $f -join '+' } else { '-' }
  return ("0x{0:X8} {1}" -f $s, $txt)
}
function Dump([string]$tag, [int]$upto) {
  Write-Output ("--- {0} ---" -f $tag)
  for ($i = 1; $i -le $upto; $i++) {
    Write-Output ("  id={0,3} rect={1,-18} state={2,-34} name='{3}'" -f $i, (RectOf $i), (StateOf $i), (NameOf $i))
  }
}

[void][W.U]::SetForegroundWindow($hwnd); Start-Sleep -Milliseconds 400
Click 100 400; Start-Sleep -Milliseconds 400
Send '^({HOME})' 600
Write-Output ''
Write-Output ("accChildCount = {0}" -f $acc.accChildCount)
Dump 'AFTER Ctrl+Home (tree at top)' 14

# --- collapse / expand census over the WHOLE tree --------------------------------------------
# This is the "is this folder folded?" answer we need before deciding to click anything.
Write-Output ''
Write-Output '--- collapse/expand census (whole tree) ---'
$N = [int]$acc.accChildCount
$exp = 0; $col = 0; $none = 0; $err = 0; $zeroRect = 0
for ($i = 1; $i -le $N; $i++) {
  $s = $null
  try { $s = [int]$acc.accState([int]$i) } catch { $err++; continue }
  if     ($s -band $SB.expanded)  { $exp++ }
  elseif ($s -band $SB.collapsed) { $col++ }
  else                            { $none++ }
  $r = RectOf $i
  if ($r -like '0,0,0,0') { $zeroRect++ }
}
Write-Output ("  total={0}  expanded={1}  collapsed={2}  neither={3}  accState-errors={4}  rect=0,0,0,0 -> {5}" -f $N,$exp,$col,$none,$err,$zeroRect)
Write-Output '  if collapsed > 0 above, accState IS the fold indicator (good).'
Write-Output '  if neither == total, fall back to "rect 0,0,0,0 means hidden inside a folded folder".'

# --- selection readback ---------------------------------------------------------------------
Write-Output ''
Write-Output '--- selection readback right after Ctrl+Home ---'
foreach ($form in @(
    @{ l='accFocus';                    s={ $acc.accFocus } },
    @{ l='accSelection';                s={ $acc.accSelection } },
    @{ l='accFocus type';               s={ $acc.accFocus.GetType().FullName } },
    @{ l='accName(accSelection)';       s={ $acc.accName($acc.accSelection) } }
  )) {
  try { Write-Output ("  {0,-26} => '{1}'" -f $form.l, (& $form.s)) }
  catch { Write-Output ("  {0,-26} => ERR {1}" -f $form.l, $_.Exception.Message) }
}

# --- the decisive test: scroll and re-read ---------------------------------------------------
Send '{DOWN}' 150
Send '{DOWN}' 150
Send '{DOWN}' 150
Write-Output ''
Write-Output '--- selection readback after 3x Down ---'
foreach ($form in @(
    @{ l='accFocus';              s={ $acc.accFocus } },
    @{ l='accSelection';          s={ $acc.accSelection } },
    @{ l='accName(accSelection)'; s={ $acc.accName($acc.accSelection) } }
  )) {
  try { Write-Output ("  {0,-26} => '{1}'" -f $form.l, (& $form.s)) }
  catch { Write-Output ("  {0,-26} => ERR {1}" -f $form.l, $_.Exception.Message) }
}
Dump 'AFTER 3x Down (selection moved 3 rows, no scroll yet)' 8

# scroll far down so the top rows must leave the box
for ($k = 0; $k -lt 40; $k++) { Send '{DOWN}' 25 }
Start-Sleep -Milliseconds 300
Dump 'AFTER 40x Down (tree scrolled down)' 8
Write-Output ''
Write-Output '*** VERDICT: if node 1 rect changed between the first and last dump, MSAA rects are REAL.'
Write-Output '***          if node 1 still reads the same y, rects are VIRTUAL (do not use for clicking).'
[void][W.U]::SetForegroundWindow($hwnd)
