# Set AutoShop's project-tree pane to a chosen pixel width by dragging the splitter, then VERIFY.
#
# WHY THIS EXISTS (user, 2026-09-20): "左栏如果过宽你应该拉回去".
# autoshop-preflight.ps1 -Fix widens the pane by (reported overflow + margin) whenever its overflow
# check fails -- but that check is BOGUS: it reads SB_HORZ and gets page=0, so
#   overflow = (nMax-nMin+1) - 0 = range
# which does NOT depend on the pane width at all. Measured: widening 446px -> 570px left the number at
# exactly 101px. So -Fix kept pushing the splitter right, every run, and never succeeded -- and because
# AutoShop PERSISTS the pane width, the damage survived restarts. This script undoes it.
#
# The drag itself is accurate (asked for +125px, measured +124px), so a leftward drag is reliable.
#
# KEEP PURE ASCII. Requires the main window on-screen; refuses if it is minimized/off-screen.
param(
  [int]$Width = 346,          # target tree-pane width in pixels (346 = the width recorded as good)
  [int]$Tolerance = 6,        # accept when within this many px of the target
  [switch]$WhatIf
)
$ErrorActionPreference = 'Stop'
if (-not ('PW' -as [type])) {
  Add-Type -Namespace PW -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h){ $b=New-Object Text.StringBuilder 256; [void][PW.U]::GetClassNameW($h,$b,256); $b.ToString() }
function TxtOf([IntPtr]$h){ $b=New-Object Text.StringBuilder 512; [void][PW.U]::GetWindowTextW($h,$b,512); $b.ToString() }
function RectOf([IntPtr]$h){ $r=New-Object PW.U+RECT; [void][PW.U]::GetWindowRect($h,[ref]$r); return $r }
$LD=0x02; $LU=0x04

# resolve the main frame by IDENTITY (Process.MainWindowHandle lies when a tooltip shadow is on screen)
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$want = [int]$proc.Id
$best = [IntPtr]::Zero; $bestArea = 0
$cb = [PW.U+EnumProc]{ param($h,$x)
  $q=0; [void][PW.U]::GetWindowThreadProcessId($h,[ref]$q)
  if ([int]$q -eq $script:want -and [PW.U]::IsWindowVisible($h)) {
    $c = ClsOf $h
    if ($c -like 'Afx:*' -and (TxtOf $h) -like '*AutoShop*') {
      $r = RectOf $h; $a = ($r.Right-$r.Left)*($r.Bottom-$r.Top)
      if ($a -gt $script:bestArea) { $script:bestArea=$a; $script:best=$h }
    }
  }
  return $true }
$script:want = $want
[void][PW.U]::EnumWindows($cb,[IntPtr]::Zero)
$main = $script:best
if ($main -eq [IntPtr]::Zero) { throw 'AutoShop main frame not found' }
$mr = RectOf $main
Write-Output ("main hwnd={0} rect={{ {1},{2} {3}x{4} }}  title=[{5}]" -f $main,$mr.Left,$mr.Top,($mr.Right-$mr.Left),($mr.Bottom-$mr.Top),(TxtOf $main))
if ($mr.Left -lt -2000 -or ($mr.Right-$mr.Left) -lt 400) { throw 'main window is minimized or off-screen - restore it first' }

# leftmost SysTreeView32 = the project tree
$trees = New-Object System.Collections.ArrayList
$cb2 = [PW.U+EnumProc]{ param($h,$x) if ((ClsOf $h) -eq 'SysTreeView32') { [void]$script:trees.Add($h) }; return $true }
$script:trees = $trees
[void][PW.U]::EnumChildWindows($main,$cb2,[IntPtr]::Zero)
if ($trees.Count -eq 0) { throw 'no SysTreeView32 under the main window' }
$tree = @($trees | Sort-Object { (RectOf $_).Left } | Select-Object -First 1)[0]
$tr = RectOf $tree
$curW = $tr.Right - $tr.Left
$delta = $Width - $curW
Write-Output ("tree hwnd={0}  current width = {1}px  (left={2})  target = {3}px  -> need {4}px" -f $tree,$curW,$tr.Left,$Width,$delta)
if ([Math]::Abs($delta) -le $Tolerance) { Write-Output 'already within tolerance - nothing to drag'; exit 0 }
if ($WhatIf) { Write-Output '(-WhatIf: not dragging)'; exit 0 }

# the splitter sits just right of the tree's window rect; that is where preflight's drag grabbed it too
$gx = $tr.Right + 2
$gy = [int](($tr.Top + $tr.Bottom) / 2)
$tx = $gx + $delta
for ($i=1; $i -le 3; $i++) { [void][PW.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 250; if ([PW.U]::GetForegroundWindow() -eq $main) { break } }
[void][PW.U]::SetCursorPos($gx,$gy); Start-Sleep -Milliseconds 300
[PW.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 300
$steps = 16
for ($i=1; $i -le $steps; $i++) { [void][PW.U]::SetCursorPos(($gx + [int]($delta*$i/$steps)),$gy); Start-Sleep -Milliseconds 60 }
[PW.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 700

$tr2 = RectOf $tree
$newW = $tr2.Right - $tr2.Left
Write-Output ("after drag: width = {0}px  (was {1}px; asked for {2}px)" -f $newW,$curW,$Width)
if ([Math]::Abs($newW - $Width) -gt [Math]::Max($Tolerance, 12)) {
  # drag landed off target -> measure once more and correct with a second, smaller drag
  $d2 = $Width - $newW
  Write-Output ("  off target by {0}px -> correcting" -f $d2)
  $gx2 = $tr2.Right + 2
  [void][PW.U]::SetCursorPos($gx2,$gy); Start-Sleep -Milliseconds 250
  [PW.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 250
  for ($i=1; $i -le 12; $i++) { [void][PW.U]::SetCursorPos(($gx2 + [int]($d2*$i/12)),$gy); Start-Sleep -Milliseconds 60 }
  [PW.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 700
  $tr3 = RectOf $tree
  $newW = $tr3.Right - $tr3.Left
  Write-Output ("after correction: width = {0}px" -f $newW)
}
if ([Math]::Abs($newW - $Width) -le [Math]::Max($Tolerance,12)) { Write-Output 'RESULT: PASS (pane width is at target)' ; exit 0 }
Write-Output 'RESULT: OFF-TARGET (report the measured width above; the splitter may be docked differently)'
exit 1
