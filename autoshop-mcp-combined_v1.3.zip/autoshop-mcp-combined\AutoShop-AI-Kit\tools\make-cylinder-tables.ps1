# Build every AutoShop table file for a design from ONE UTF-8 spec file.
#
# WHY (user's rules, 2026-09-20):
#   * "变更只在本地做，你只需要导入到项目就可以" -- every table is authored HERE, in full, then
#     imported ONCE. Never export a baseline from AutoShop, never re-export to verify.
#   * Chinese literals inside a BOM-less .ps1 are read as ANSI by PowerShell 5.1 and become mojibake;
#     that silently broke the import tool's success-box dismissal. So this file is PURE ASCII: every
#     Chinese string (headers, row templates, dir names, comments) lives in the UTF-8 spec and is only
#     copied/spliced here -- decoded from UTF-8, re-encoded to GBK for AutoShop.
#
# Outputs per spec section:
#   #STRUCT <name>  -> <mirror>\<structdir>\<name>_import4.csv   (GBK, AutoShop import, 4 cols)
#                      <mirror>\<structdir>\<name>.csv          (UTF-8 BOM, human design copy)
#   #FB <name>      -> <mirror>\<fbdir>\<name>\<name>.csv       (GBK, FB/FC variable table)
#   #GVL <table>    -> <mirror>\<gvldir>\<table>.csv            (GBK, 9 cols)
#   #FBI ...        -> <mirror>\<fbidir>\<fbidir>.csv           (GBK, 6 cols)
#
# The FB's INOUT member rows are expanded from the struct it references, exactly the way AutoShop's
# own export does it, so the imported table matches a round-tripped one (verified in skill 30.5/30.6).
param(
  [Parameter(Mandatory=$true)][string]$Spec,
  [Parameter(Mandatory=$true)][string]$Mirror,
  [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$gbk  = [System.Text.Encoding]::GetEncoding(936)
$utf8 = New-Object System.Text.UTF8Encoding($false)
$bom  = New-Object System.Text.UTF8Encoding($true)

$lines = ([System.IO.File]::ReadAllText($Spec, $utf8)) -split "`r?`n"

$dirs = @{}; $headers = @{}; $tpl = @{}
$structs = @{}; $structOrder = New-Object System.Collections.ArrayList
$ton = New-Object System.Collections.ArrayList
$fbs = New-Object System.Collections.ArrayList; $curFb = $null
$gvl = New-Object System.Collections.ArrayList; $fbi = New-Object System.Collections.ArrayList
$cur = $null

foreach ($raw in $lines) {
  $l = $raw.TrimEnd()
  if ($l -eq '' -or $l.StartsWith('#' + ' ')) { continue }
  if ($l -match '^#(OUTDIR|HEADER|TPL)\s+(.+)$') {
    $kind = $Matches[1]; $rest = $Matches[2]
    if ($rest.StartsWith('[')) { continue }                        # allow a disabled/commented entry
    $p = $rest -split '\|', 2
    if ($kind -eq 'OUTDIR') { $dirs[$p[0].Trim()] = $p[1] }
    elseif ($kind -eq 'HEADER') { $headers[$p[0].Trim()] = $p[1] }
    else { $tpl[$p[0].Trim()] = $p[1] }
    $cur = $null; continue
  }
  if ($l -match '^#TONMEMBER\s+(.+)$') {
    $f = $Matches[1] -split '\|'
    [void]$ton.Add(@{ m=$f[0]; t=$f[1]; init=$f[2]; c=$(if ($f.Count -gt 3) { $f[3] } else { '' }) })
    $cur = $null; continue
  }
  if ($l -match '^#STRUCT\s+(.+)$') {
    $nm = $Matches[1].Trim()
    $structs[$nm] = New-Object System.Collections.ArrayList
    [void]$structOrder.Add($nm)
    $cur = @{ kind='struct'; name=$nm }; continue
  }
  if ($l -match '^#FB\s+(.+)$') {
    $nm = $Matches[1].Trim()
    $curFb = @{ name=$nm; rows=(New-Object System.Collections.ArrayList) }
    [void]$fbs.Add($curFb)
    $cur = @{ kind='fb' }; continue
  }
  if ($l -match '^#GVL\s+(.+)$') {
    $f = $Matches[1] -split '\|'
    [void]$gvl.Add(@{ table=$f[0]; var=$f[1]; type=$f[2]; c=$(if ($f.Count -gt 3) { $f[3] } else { '' }) })
    $cur = $null; continue
  }
  if ($l -match '^#FBI\s+(.+)$') {
    $f = $Matches[1] -split '\|'
    [void]$fbi.Add(@{ i=$f[0]; n=$f[1]; t=$f[2]; c=$(if ($f.Count -gt 3) { $f[3] } else { '' }) })
    $cur = $null; continue
  }
  if ($null -eq $cur) { continue }
  $f = $l -split '\|'
  if ($cur.kind -eq 'struct') {
    [void]$structs[$cur.name].Add(@{ m=$f[0]; t=$f[1]; c=$(if ($f.Count -gt 2) { $f[2] } else { '' }) })
  } elseif ($cur.kind -eq 'fb') {
    [void]$curFb.rows.Add(@{ kind=$f[0]; n=$f[1]; t=$f[2]; c=$(if ($f.Count -gt 3) { $f[3] } else { '' }) })
  }
}

# default value for the initial-value column, from the data type
function DefVal([string]$t) {
  if ($t -like 'BOOL*') { return 'OFF' }
  if ($t -like 'DINT*' -or $t -like 'INT*') { return '0' }
  return ''
}
function Fill([string]$tplStr, [hashtable]$v) {
  # Only replace the placeholders the caller actually supplied. A placeholder left out (e.g. {init} on a
  # struct row that has no scalar initial value) must vanish, never be printed literally.
  $s = $tplStr
  foreach ($k in $v.Keys) { $s = $s.Replace('{' + $k + '}', [string]$v[$k]) }
  $s = [regex]::Replace($s, '\{[A-Za-z0-9_]+\}', '')
  return $s
}
# Quote a comment when it carries a comma (or a quote) -- an unquoted comma silently shifts every
# later column, which is defect #3 on the import-problem list (skill section 32.5). AutoShop's own
# export quotes the same way: "(ET:=0, IN:=OFF, iRecordCount:=0..., PT:=0, Q:=OFF)".
# Pad a CSV row with empty trailing slots until it has exactly $target top-level fields.
# (Trailing empty slots are harmless to AutoShop; a missing comma is not.)
function Pad-Row([string]$row, [string]$headerRow) {
  $target = (Csv-FieldCount $headerRow)
  $cur = (Csv-FieldCount $row)
  if ($cur -lt $target) { return $row + (',' * ($target - $cur)) }
  return $row
}
function Pad-List([System.Collections.ArrayList]$list, [string]$headerRow) {
  $target = (Csv-FieldCount $headerRow)
  for ($j = 1; $j -lt $list.Count; $j++) {
    $cur = (Csv-FieldCount ([string]$list[$j]))
    if ($cur -lt $target) { $list[$j] = [string]$list[$j] + (',' * ($target - $cur)) }
  }
}
# Count top-level CSV fields (RFC-4180 quoting aware: commas inside "..." do not split).
function Csv-FieldCount([string]$s) {
  if ($null -eq $s -or $s -eq '') { return 0 }
  $n = 1
  $inQ = $false
  $i = 0
  while ($i -lt $s.Length) {
    $ch = $s[$i]
    if ($inQ) {
      if ($ch -eq '"') {
        if ($i + 1 -lt $s.Length -and $s[$i + 1] -eq '"') { $i++ }
        else { $inQ = $false }
      }
    } else {
      if ($ch -eq '"') { $inQ = $true }
      elseif ($ch -eq ',') { $n++ }
    }
    $i++
  }
  return $n
}
function Qc([string]$s) {
  # Quote a CSV field when it carries a comma, quote or newline. The spec file is the source of truth:
  # a comment there is EITHER bare (generator quotes it) OR already quoted (kept as-is, never doubled).
  if ($null -eq $s) { return '' }
  if ($s.StartsWith('"') -and $s.EndsWith('"') -and $s.Length -ge 2) { return $s }
  if ($s.Contains(',') -or $s.Contains('"') -or $s.Contains("`n")) { return '"' + $s.Replace('"', '""') + '"' }
  return $s
}
function Emit([string]$path, [string[]]$outLines, [bool]$asBom) {
  $d = Split-Path -Parent $path
  if ($d -and -not (Test-Path -LiteralPath $d)) { [void](New-Item -ItemType Directory -Force -Path $d) }
  # CSV field-count guard: every row (incl. the header) must have the same comma count as the header.
  # A mismatched row means a missing/extra comma in a template or spec line -- catch it HERE, before it
  # hits AutoShop as a silently shifted import.
  # Field-count guard with real CSV quoting awareness: a comma inside a quoted field is data, not a
  # separator, so a plain -split overcounts. Count fields the way a CSV parser does.
  $hc = (Csv-FieldCount $outLines[0])
  for ($j = 1; $j -lt $outLines.Count; $j++) {
    $rc = (Csv-FieldCount $outLines[$j])
    if ($rc -ne $hc) { throw ("CSV column mismatch in " + (Split-Path -Leaf $path) + " line " + ($j + 1) + ": " + $rc + " fields, header has " + $hc + " -> [" + $outLines[$j] + "]") }
  }
  $body = (($outLines -join "`r`n") + "`r`n")
  if ($DryRun) { Write-Output ("  [dry] " + $path + "  (" + $outLines.Count + " lines)"); return }
  $enc = $(if ($asBom) { $bom } else { $gbk })
  [System.IO.File]::WriteAllBytes($path, $enc.GetBytes($body))
  Write-Output ("  wrote {0}  ({1} lines, {2} bytes, {3})" -f $path, $outLines.Count, (Get-Item -LiteralPath $path).Length, $(if ($asBom) { 'UTF-8 BOM' } else { 'GBK' }))
}

# ---------------- structs ----------------
# (Join-Path with three positional args needs PS6+; join one at a time, and read hashtable keys into
#  plain variables first -- in argument mode `$h['k']` is ambiguous to the parser.)
$dirStruct = $dirs['struct']; $dirGvl = $dirs['gvl']; $dirFb = $dirs['fb']; $dirFbi = $dirs['fbi']
foreach ($nm in $structOrder) {
  $ms = $structs[$nm]
  $imp = New-Object System.Collections.ArrayList
  [void]$imp.Add($headers['struct4'])
  $i = 0
  foreach ($m in $ms) { $i++; [void]$imp.Add((Fill $tpl['struct_import'] @{ i=$i; m=$m.m; t=$m.t; c=(Qc $m.c) })) }
  Emit (Join-Path (Join-Path $Mirror $dirStruct) ($nm + '_import4.csv')) $imp $false
  $des = New-Object System.Collections.ArrayList
  [void]$des.Add($headers['struct3'])
  foreach ($m in $ms) { [void]$des.Add((Fill $tpl['struct_design'] @{ m=$m.m; t=$m.t; c=(Qc $m.c) })) }
  Emit (Join-Path (Join-Path $Mirror $dirStruct) ($nm + '.csv')) $des $true
}

# ---------------- FB variable tables (one per #FB section) ----------------
foreach ($theFb in $fbs) {
  $out = New-Object System.Collections.ArrayList
  [void]$out.Add($headers['fb9'])
  $i = 0
  foreach ($r in $theFb.rows) {
    switch ($r.kind) {
      'INOUT' {
        $i++
        [void]$out.Add((Fill $tpl['fb_struct_top'] @{ i=$i; kind=$r.kind; n=$r.n; t=$r.t; c=(Qc $r.c) }))
        if (-not $structs.ContainsKey($r.t)) { throw ("FB references struct '" + $r.t + "' which the spec does not define") }
        foreach ($m in $structs[$r.t]) {
          [void]$out.Add((Fill $tpl['fb_struct_member'] @{ parent=$r.n; m=$m.m; t=$m.t; c=(Qc $m.c); init=(DefVal $m.t) }))
        }
      }
      'IN'      { $i++; [void]$out.Add((Fill $tpl['fb_pin'] @{ i=$i; kind=$r.kind; n=$r.n; t=$r.t; c=(Qc $r.c) })) }
      'OUT'     { $i++; [void]$out.Add((Fill $tpl['fb_pin'] @{ i=$i; kind=$r.kind; n=$r.n; t=$r.t; c=(Qc $r.c) })) }
      'VAR'     {
        # generic local VAR: the TYPE comes from the spec (it used to be hardcoded INT) and the initial
        # value is derived from that type -- BOOL -> OFF, INT/DINT -> 0.
        $i++
        [void]$out.Add((Fill $tpl['fb_var'] @{ i=$i; n=$r.n; t=$r.t; c=(Qc $r.c); init=(DefVal $r.t) }))
      }
      'VARFB'   {
        # FB04_TON row + its member expansion, in AutoShop's own export shape (skill 11.9):
        #   top row   = 序号,VAR,<名>,FB04_TON,"(ET:=0, IN:=OFF, ...)",...,不保持,
        #   member row=  ,<名>.<成员>,<类型>,,,<初值>,,,   (initial value in col 5, no power-retention)
        $i++
        [void]$out.Add((Fill $tpl['fb_var_fb'] @{ i=$i; n=$r.n; t=$r.t; c=$r.c }))
        foreach ($m in $ton) {
          # AutoShop's export shape: the initial value (init) lives in the INITIAL-VALUE column (col 5);
          # the comment column stays empty -- a type note there was our invention and no AutoShop export has it.
          [void]$out.Add((Fill $tpl['ton_member'] @{ parent=$r.n; m=$m.m; t=$m.t; init=$m.init; c=$m.c }))
        }
      }
      default   { throw ("unknown FB row kind '" + $r.kind + "'") }
    }
  }
  $fbDirPath = Join-Path (Join-Path $Mirror $dirFb) $theFb.name
  Emit (Join-Path $fbDirPath ($theFb.name + '.csv')) $out $false
}

# ---------------- GVL tables ----------------
# ★ ONE CSV PER TABLE, holding EVERY variable of that table. The spec may carry several #GVL lines with
#   the same table name (a GVL table usually holds more than one struct variable); emitting one file per
#   LINE would overwrite the earlier variables -- and an import is a WHOLE-TABLE replace, so the file
#   must be the complete table.
$tblOrder = New-Object System.Collections.ArrayList
$tblVars = @{}
foreach ($g in $gvl) {
  if (-not $tblVars.ContainsKey($g.table)) {
    $tblVars[$g.table] = New-Object System.Collections.ArrayList
    [void]$tblOrder.Add($g.table)
  }
  [void]$tblVars[$g.table].Add($g)
}
function Is-PlainType([string]$t) {
  $tt = $t.Trim()
  return ($tt -match '^(BOOL|BYTE|WORD|DWORD|INT|DINT|SINT|USINT|UINT|UDINT|REAL|LREAL|TIME|DATE|TOD|DT|DTL|STRING|WSTRING|TIME_OF_DAY|DATE_AND_TIME)\b')
}
foreach ($tbl in $tblOrder) {
  $out = New-Object System.Collections.ArrayList
  [void]$out.Add($headers['gvl9'])
  $i = 0
  foreach ($g in $tblVars[$tbl]) {
    $i++
    $plain = Is-PlainType $g.type
    if (-not $plain -and -not $structs.ContainsKey($g.type)) { throw ("GVL references struct '" + $g.type + "' which the spec does not define") }
    if ($plain) {
      # scalar variable: top-level row only, default initial value derived from the type
      [void]$out.Add((Fill $tpl['gvl_top'] @{ i=$i; n=$g.var; t=$g.type; init=(DefVal $g.type); c=(Qc $g.c) }))
    } else {
      [void]$out.Add((Fill $tpl['gvl_top'] @{ i=$i; n=$g.var; t=$g.type; c=(Qc $g.c) }))
      foreach ($m in $structs[$g.type]) {
        [void]$out.Add((Fill $tpl['gvl_member'] @{ parent=$g.var; m=$m.m; t=$m.t; c=(Qc $m.c); init=(DefVal $m.t) }))
      }
    }
  }
  Pad-List $out ($headers['gvl9'])
  Emit (Join-Path (Join-Path $Mirror $dirGvl) ($tbl + '.csv')) $out $false
}

# ---------------- FB instances ----------------
if ($fbi.Count -gt 0) {
  $out = New-Object System.Collections.ArrayList
  [void]$out.Add($headers['fbi6'])
  foreach ($r in $fbi) { [void]$out.Add((Fill $tpl['fbi_top'] @{ i=$r.i; n=$r.n; t=$r.t; c=(Qc $r.c) })) }
  Emit (Join-Path (Join-Path $Mirror $dirFbi) ($dirFbi + '.csv')) $out $false
}

Write-Output ("spec rows: structs={0}  FB={1}  GVL={2}  FBI={3}" -f $structOrder.Count, $(if ($fb) { $fb.name } else { '-' }), $gvl.Count, $fbi.Count)
