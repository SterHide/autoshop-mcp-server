# Close every MDI child window of the AutoShop main frame.
#
# Why: each opened block is an MDI child; leaving them open hits AutoShop's window limit
# ("open window count exceeded"), which pops a modal dialog and freezes the UI. Closing them from
# code (WM_CLOSE) is deterministic -- no tab context menu, no OCR, no guessing.
# If a dialog appears while closing, its buttons are read with Win32 (EnumChildWindows) and
# "No"/"Cancel" is pressed -- never "Yes"/"OK".
#
# KEEP THIS FILE PURE ASCII.
param(
  [string]$MainClassLike = 'Afx:',   # AutoShop main frame
  [int]$MaxClose = 60
)

$ErrorActionPreference = 'Stop'
Add-Type -Namespace W -Name C -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
$WM_CLOSE = 0x0010
# Non-ASCII captions built from char codes: PS 5.1 reads a BOM-less .ps1 as ANSI, so a literal
# Chinese button caption would be mojibake and the match below would silently never fire.
$S_NO     = [string][char]0x5426                          # No
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88    # Cancel
$S_YES    = [string][char]0x662F                          # Yes - the authorized save prompt answer
$S_SAVE   = [string][char]0x4FDD + [string][char]0x5B58   # 'save' - marks the 'save your changes?' prompt

function ClassOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.C]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TextOf([IntPtr]$h)  { $sb = New-Object System.Text.StringBuilder 512; [void][W.C]::GetWindowTextW($h, $sb, 512); $sb.ToString() }

# Press No/Cancel on any dialog that pops up while closing -- EXCEPT the "save your changes?"
# prompt, which the user has explicitly authorized pressing YES on (2026-09-19):
#   "when a save prompt appears while closing a tab, just confirm it" / "default to confirming".
# The prompt is: #32770 AutoShop 339x169, buttons Yes(&Y)/No(&N)/Cancel,
# static text "save the changes to <x>?".  Its YES button is control id 6 (IDYES).
# KEEP THIS FILE PURE ASCII - the captions are matched via char codes above.
# Its YES button is control id 6 (IDYES).
# The button is pressed with WM_COMMAND + its control id, NOT with BM_CLICK: BM_CLICK
#   while the dialog is not the active window (measured -- the script reported a press and the box
#   stayed up).
function PressButtonById([IntPtr]$dlg, [IntPtr]$btn) {
  $id = [W.C]::GetWindowLong($btn, -12)          # GWL_ID
  [void][W.C]::SendMessageW($dlg, 0x0111, [IntPtr]$id, $btn)   # WM_COMMAND, BN_CLICKED
  Start-Sleep -Milliseconds 600
}
function StaticsOf([IntPtr]$dlg) {
  $txt = ''
  $cb = [W.C+EnumProc]{ param($h,$p) if ((ClassOf $h) -eq 'Static') { $script:stTxt += (TextOf $h) }; return $true }
  $script:stTxt = ''
  [void][W.C]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $script:stTxt
}
function DismissAnyDialog {
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.C+EnumProc]{ param($h,$p) if ((ClassOf $h) -eq '#32770' -and [W.C]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }; return $true }
  [void][W.C]::EnumWindows($cb, [IntPtr]::Zero)
  foreach ($d in $dlgs) {
    $kids = New-Object System.Collections.ArrayList
    $cb2 = [W.C+EnumProc]{ param($h,$p) if ((ClassOf $h) -eq 'Button' -and [W.C]::IsWindowVisible($h)) { [void]$kids.Add($h) }; return $true }
    [void][W.C]::EnumChildWindows($d, $cb2, [IntPtr]::Zero)
    # 1) save prompt -> press YES (authorized)
    if ((StaticsOf $d).Contains($S_SAVE)) {
      foreach ($b in $kids) {
        if ((TextOf $b).Contains($S_YES)) {
          Write-Output ("   dialog '{0}' is a SAVE prompt -> pressing YES (authorized)" -f (StaticsOf $d))
          PressButtonById $d $b
          break
        }
      }
      continue
    }
    # 2) anything else -> press No / Cancel
    foreach ($b in $kids) {
      $t = TextOf $b
      if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) {
        $r = New-Object W.C+RECT; [void][W.C]::GetWindowRect($b, [ref]$r)
        $cx = [int](($r.Left + $r.Right) / 2); $cy = [int](($r.Top + $r.Bottom) / 2)
        [void][W.C]::SetCursorPos($cx, $cy); Start-Sleep -Milliseconds 120
        [W.C]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 50; [W.C]::mouse_event(0x04,0,0,0,0)
        Write-Output ("   dialog '{0}' -> pressed '{1}' at ({2},{3})" -f (TextOf $d), $t, $cx, $cy)
        Start-Sleep -Milliseconds 400
        break
      }
    }
  }
}

# locate the AutoShop main frame
$main = [IntPtr]::Zero
$cb = [W.C+EnumProc]{ param($h,$p) if ((ClassOf $h) -like "$MainClassLike*" -and [W.C]::IsWindowVisible($h)) { $t = TextOf $h; if ($t -like 'AutoShop*') { if ($env:AUTOSHOP_TITLE_FILTER) { if ($t -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*')) { $script:main = $h } } else { if ($t -notlike '*:\*') { $script:main = $h } } } }; return $true }
[void][W.C]::EnumWindows($cb, [IntPtr]::Zero)
if ($main -eq [IntPtr]::Zero) { Write-Output 'ABORT: AutoShop main window not found.'; exit 1 }
Write-Output ("main hwnd={0}  '{1}'" -f $main, (TextOf $main))

# find the MDI client, then close its children one by one
$mdi = [IntPtr]::Zero
$cb2 = [W.C+EnumProc]{ param($h,$p) if ((ClassOf $h) -eq 'MDIClient') { $script:mdi = $h }; return $true }
[void][W.C]::EnumChildWindows($main, $cb2, [IntPtr]::Zero)
if ($mdi -eq [IntPtr]::Zero) { Write-Output 'ABORT: MDIClient not found.'; exit 1 }

$closed = 0
for ($i = 0; $i -lt $MaxClose; $i++) {
  $kid = [IntPtr]::Zero
  $cb3 = [W.C+EnumProc]{ param($h,$p) if ([W.C]::IsWindowVisible($h)) { $script:kid = $h; return $false }; return $true }
  [void][W.C]::EnumChildWindows($mdi, $cb3, [IntPtr]::Zero)
  if ($kid -eq [IntPtr]::Zero) { break }
  $name = TextOf $kid
  [void][W.C]::SendMessageW($kid, $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
  Start-Sleep -Milliseconds 350
  $closed++
  DismissAnyDialog
  if ($i -lt 5 -or $i % 10 -eq 0) { Write-Output ("  closed [{0}] '{1}'" -f $closed, $name) }
}
Write-Output ("MDI children closed: {0}" -f $closed)

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }
