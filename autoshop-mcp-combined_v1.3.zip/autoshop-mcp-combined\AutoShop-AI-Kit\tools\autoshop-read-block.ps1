# READ an AutoShop block's source text back out of its editor WITHOUT modifying it.
#
# WHY (2026-09-20): the only valid proof that a body landed is reading it back after save+close+reopen
# (the .FB/.ST containers are packed -- see autoshop-uia section 29). Until now the only reader was
# autoshop-write-block.ps1, which PRINTS the current text but then REWRITES it, i.e. "read by writing".
# This tool only reads: WM_GETTEXT on the Scintilla + the raw-form decode (UTF-8 bytes paired into
# UTF-16 code units). Nothing is written, nothing is saved, the view is left exactly as found.
#
# The block's view must already be open (use autoshop-open-node.ps1 -Node <name> first).
#
# KEEP PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$Block,
  [string]$OutFile = '',      # save the text here (UTF-8, no BOM)
  [string]$Diff    = '',      # compare against this file and report IDENTICAL / first differences
  [int]$MaxShow    = 0        # >0: also echo the first N lines
)
$ErrorActionPreference = 'Stop'
if (-not ('RB' -as [type])) {
Add-Type -Namespace RB -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageStr(IntPtr h, uint msg, IntPtr w, System.Text.StringBuilder l);
[DllImport("user32.dll", EntryPoint="SendMessageW")] public static extern IntPtr SendMessageInt(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h){ $b=New-Object Text.StringBuilder 256; [void][RB.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b=New-Object Text.StringBuilder 512; [void][RB.U]::GetWindowTextW($h,$b,512); $b.ToString() }

# the read channel returns the RAW form: each UTF-16 code unit carries two UTF-8 bytes (LE).
function From-RawForm([string]$raw) {
  if ([string]::IsNullOrEmpty($raw)) { return $raw }
  $bytes = New-Object byte[] ($raw.Length * 2)
  for ($i = 0; $i -lt $raw.Length; $i++) {
    $u = [int][char]$raw[$i]
    $bytes[2*$i] = [byte]($u -band 0xFF); $bytes[2*$i+1] = [byte](($u -shr 8) -band 0xFF)
  }
  $n = 0; while ($n -lt $bytes.Length -and $bytes[$n] -ne 0) { $n++ }
  try { return (New-Object System.Text.UTF8Encoding($false,$true)).GetString($bytes, 0, $n) } catch { return $raw }
}

# resolve the main frame by IDENTITY (never Process.MainWindowHandle: a tooltip shadow steals it).
# "Biggest visible Afx:* window whose title contains AutoShop, belonging to the AutoShop process".
function Get-MainFrame {
  $wanted = (Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1).Id
  $script:cands2 = New-Object System.Collections.ArrayList
  $script:wantPid = [int]$wanted
  $cbw = [RB.U+EnumProc]{ param($h,$x)
    $q = 0; [void][RB.U]::GetWindowThreadProcessId($h, [ref]$q)
    if ([int]$q -eq $script:wantPid -and [RB.U]::IsWindowVisible($h)) {
      $sb = New-Object Text.StringBuilder 256; [void][RB.U]::GetClassNameW($h,$sb,256)
      if ($sb.ToString() -like 'Afx:*' -and (TxtOf $h) -like '*AutoShop*') { [void]$script:cands2.Add($h) }
    }
    return $true }
  [void][RB.U]::EnumWindows($cbw, [IntPtr]::Zero)
  $best = [IntPtr]::Zero; $ba = 0
  foreach ($h in $script:cands2) {
    $r = New-Object RB.U+RECT; [void][RB.U]::GetWindowRect($h, [ref]$r)
    $a = ($r.Right - $r.Left) * ($r.Bottom - $r.Top)
    if ($a -gt $ba) { $ba = $a; $best = $h }
  }
  return $best
}
$main = Get-MainFrame
if ($main -eq [IntPtr]::Zero) { throw 'AutoShop main frame not found' }

$mc = [IntPtr]::Zero
$cb2 = [RB.U+EnumProc]{ param($h,$x) if ((TxtOf $h).TrimEnd(' ','*') -eq $script:Block) { $script:mcHit = $h; return $false }; return $true }
$script:Block = $Block
[void][RB.U]::EnumChildWindows($main, $cb2, [IntPtr]::Zero)
$mc = $script:mcHit
if ($null -eq $mc -or $mc -eq [IntPtr]::Zero) { throw ("no open block view titled '{0}'" -f $Block) }

$sc = [IntPtr]::Zero
$cb3 = [RB.U+EnumProc]{ param($h,$x) if ((ClsOf $h) -eq 'Scintilla') { $script:scHit = $h; return $false }; return $true }
[void][RB.U]::EnumChildWindows($mc, $cb3, [IntPtr]::Zero)
$sc = $script:scHit
if ($null -eq $sc -or $sc -eq [IntPtr]::Zero) { throw 'no Scintilla control inside the block view' }

$len = [int][RB.U]::SendMessageInt($sc, 0x000E, [IntPtr]::Zero, [IntPtr]::Zero)
$cap = [Math]::Max(256, $len + 512)
$sb = New-Object Text.StringBuilder $cap
[void][RB.U]::SendMessageStr($sc, 0x000D, [IntPtr]$cap, $sb)
$txt = From-RawForm $sb.ToString()
$norm = ($txt -replace "`r`n", "`n")
Write-Output ("block='{0}'  view hwnd={1}  Scintilla hwnd={2}" -f $Block, $mc, $sc)
Write-Output ("  editor text: {0} chars, {1} line(s)" -f $norm.Length, (@($norm -split "`n").Count))

if ($OutFile -ne '') {
  $d = Split-Path -Parent $OutFile
  if ($d -and -not (Test-Path -LiteralPath $d)) { [void](New-Item -ItemType Directory -Force -Path $d) }
  [System.IO.File]::WriteAllBytes($OutFile, (New-Object Text.UTF8Encoding($false)).GetBytes($norm))
  Write-Output ("  written to {0}" -f $OutFile)
}
if ($MaxShow -gt 0) {
  Write-Output '  --- first lines ---'
  $ls = @($norm -split "`n")
  for ($i = 0; $i -lt [Math]::Min($MaxShow, $ls.Count); $i++) { Write-Output ('  | ' + $ls[$i]) }
}
if ($Diff -ne '') {
  if (-not (Test-Path -LiteralPath $Diff)) { Write-Output ("  DIFF skipped: no such file {0}" -f $Diff); exit 0 }
  $want = ([System.IO.File]::ReadAllText($Diff, [System.Text.Encoding]::UTF8) -replace "`r`n", "`n").TrimEnd("`n","`r"," ","`t")
  $got  = $norm.TrimEnd("`n","`r"," ","`t")
  if ($want -ceq $got) { Write-Output '  RESULT: IDENTICAL to the local file (character-exact)'; exit 0 }
  $a = $want -split "`n"; $b = $got -split "`n"
  Write-Output ("  RESULT: DIFF  (local {0} chars / {1} lines vs editor {2} chars / {3} lines)" -f $want.Length,$a.Count,$got.Length,$b.Count)
  $shown = 0
  for ($k = 0; $k -lt [Math]::Max($a.Count, $b.Count); $k++) {
    $x = if ($k -lt $a.Count) { $a[$k] } else { '<none>' }
    $y = if ($k -lt $b.Count) { $b[$k] } else { '<none>' }
    if ($x -cne $y) { $shown++; if ($shown -le 8) { Write-Output ("   line {0}" -f ($k+1)); Write-Output ('     local : ' + $x); Write-Output ('     editor: ' + $y) } }
  }
  if ($shown -gt 8) { Write-Output ("   ... and {0} more differing line(s)" -f ($shown-8)) }
  exit 1
}
