# Export AutoShop global variables to CSV, one shot.
#
# Self-calibrating: the only machine-dependent value is the tree-node position of the
# "global variables" node. It is discovered objectively -- right-click a candidate row, click the
# menu item, and check whether a dialog titled (export-as-HMI-variables) appears. Everything else
# is derived from the dialog rectangles at run time, so a different machine / DPI / window
# position does not need code changes.
#
# Precondition: AutoShop is running with a project open. The window is normalized automatically
# to (0,0) 1287x1145 before driving anything.
#
# KEEP THIS FILE PURE ASCII: PowerShell 5.1 reads BOM-less files as ANSI, so Chinese literals
# in the source would turn into mojibake. Window titles are therefore built from char codes.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File autoshop-export-gvl.ps1 -Name my_gvl
#   ... -Recalibrate     # force re-discovery of the tree node
#   ... -DryRun          # normalize + report only, click nothing
param(
  [string]$Name = 'gvl_export',
  [switch]$Recalibrate,
  [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$CacheFile = Join-Path $PSScriptRoot 'autoshop-coords.json'
$WinW = 1287; $WinH = 1145

if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string cls, string title);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }


$LD = 0x02; $LU = 0x04; $RD = 0x08; $RU = 0x10
$SWP_NOZORDER = 0x0004; $SWP_NOACTIVATE = 0x0010

function Click([int]$x, [int]$y, [switch]$Right, [int]$Pause = 110) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds $Pause
  if ($Right) { [W.U]::mouse_event($RD,0,0,0,0); Start-Sleep -Milliseconds 60; [W.U]::mouse_event($RU,0,0,0,0) }
  else        { [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60; [W.U]::mouse_event($LU,0,0,0,0) }
}
function RectOf([IntPtr]$h) { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); $r }

# Titles built from char codes (see header note).
$T_EXPORT = (-join ([char]0x5BFC,[char]0x51FA,[char]0x4E3A)) + 'HMI' + (-join ([char]0x53D8,[char]0x91CF))   # export-as-HMI-variables
$T_SAVEAS = (-join ([char]0x53E6,[char]0x5B58,[char]0x4E3A))                                                # save-as
$T_APPTTL = 'AutoShop'

# --- bring AutoShop up and normalize its window -----------------------------
$proc = Get-Process AutoShop -ErrorAction SilentlyContinue | Where-Object { (-not $env:AUTOSHOP_TITLE_FILTER) -or ($_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*')) } | Select-Object -First 1
if (-not $proc -or (Get-AutoShopMainWindow $proc) -eq 0) { Write-Output 'ABORT: AutoShop not running.'; exit 1 }
$hwnd = (Get-AutoShopMainWindow $proc)
[void][W.U]::ShowWindow($hwnd, 9)
[void][W.U]::SetWindowPos($hwnd, [IntPtr]::Zero, 0, 0, $WinW, $WinH, $SWP_NOZORDER)
[void][W.U]::SetForegroundWindow($hwnd)
Start-Sleep -Milliseconds 500
Write-Output ("hwnd={0} foreground_ok={1} window={2}x{3}" -f $hwnd, ([W.U]::GetForegroundWindow() -eq $hwnd), $WinW, $WinH)
if ($DryRun) { Write-Output 'DryRun: normalized, nothing clicked.'; exit 0 }

# --- calibration (only the tree node needs it) ------------------------------
function Get-Coords {
  if ((Test-Path -LiteralPath $CacheFile) -and -not $Recalibrate) {
    $c = Get-Content -LiteralPath $CacheFile -Raw | ConvertFrom-Json
    Write-Output ("calibration: cached (nodeY={0})" -f $c.nodeY)
    return $c
  }
  Write-Output 'calibration: probing tree rows for the global-variables node ...'
  $nodeY = $null
  foreach ($y in 152,172,192,212,232,252,132) {
    # warm-up click (first click may only activate the window), then right-click, then menu item 2
    Click -x 100 -y $y
    Start-Sleep -Milliseconds 250
    Click -x 100 -y $y -Right
    Start-Sleep -Milliseconds 700
    Click -x 170 -y ($y + 36)
    Start-Sleep -Milliseconds 1200
    $dlg = [W.U]::FindWindow('#32770', $T_EXPORT)
    if ($dlg -ne [IntPtr]::Zero) {
      Write-Output ("calibration: node found at y={0}" -f $y)
      $nodeY = $y
      $dr = RectOf $dlg
      # offsets measured on the reference machine, relative to the dialog origin
      $coords = [pscustomobject]@{
        nodeX = 100; nodeY = $y
        dlgW = $dr.Right - $dr.Left; dlgH = $dr.Bottom - $dr.Top
        tickOffX = 42; tickOffY = 40      # "select all" checkbox
        expOffX = 131; expOffY = 397      # "export"
        canOffX = 201; canOffY = 398      # "cancel"
      }
      $coords | ConvertTo-Json | Set-Content -LiteralPath $CacheFile -Encoding UTF8
      Write-Output ("calibration: dialog {0}x{1}, cached -> {2}" -f $coords.dlgW, $coords.dlgH, $CacheFile)
      # close the dialog we just opened, leave AutoShop clean
      Click -x ($dr.Left + $coords.canOffX) -y ($dr.Top + $coords.canOffY)
      Start-Sleep -Milliseconds 600
      return $coords
    }
    # dismiss anything stray before the next candidate
    Click -x 600 -y 300
    Start-Sleep -Milliseconds 200
  }
  Write-Output 'ABORT: could not locate the global-variables node (no export dialog appeared).'
  exit 3
}

$c = Get-Coords
$nx = $c.nodeX; $ny = $c.nodeY

function Find-ExportDialog {
  for ($i = 0; $i -lt 20; $i++) {
    $d = [W.U]::FindWindow('#32770', $T_EXPORT)
    if ($d -ne [IntPtr]::Zero) { return $d }
    Start-Sleep -Milliseconds 150
  }
  return [IntPtr]::Zero
}

# --- run the export ---------------------------------------------------------
Click -x $nx -y $ny                                   # warm-up (may be swallowed by activation)
Start-Sleep -Milliseconds 300
Click -x $nx -y $ny -Right                            # 1) context menu on the node
Start-Sleep -Milliseconds 800
Click -x 170 -y ($ny + 36)                            # 2) "export as ..." (item 2)
$dlg = Find-ExportDialog
if ($dlg -eq [IntPtr]::Zero) { Write-Output 'ABORT: export dialog did not appear.'; exit 3 }
$dr = RectOf $dlg
Write-Output ("export dialog at ({0},{1}) {2}x{3}" -f $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))

Click -x ($dr.Left + $c.tickOffX) -y ($dr.Top + $c.tickOffY)     # 3) tick "select all"
Start-Sleep -Milliseconds 500
Click -x ($dr.Left + $c.expOffX)  -y ($dr.Top + $c.expOffY)      # 4) "export"
Start-Sleep -Milliseconds 1600

# 5) Save-As: filename box has focus -> rename via keyboard, Enter saves (no coordinates needed)
[System.Windows.Forms.SendKeys]::SendWait('^a'); Start-Sleep -Milliseconds 200
[System.Windows.Forms.SendKeys]::SendWait($Name); Start-Sleep -Milliseconds 250
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}'); Start-Sleep -Milliseconds 1800
# 6) success message box -> Enter hits its default button
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}'); Start-Sleep -Milliseconds 800

# --- verify -----------------------------------------------------------------
$desk = [Environment]::GetFolderPath('Desktop')
Write-Output ''
$ok = $true
foreach ($n in @("$Name.csv", "${Name}_new.csv")) {
  $f = Join-Path $desk $n
  if (Test-Path -LiteralPath $f) {
    $i = Get-Item -LiteralPath $f
    Write-Output ("OK   {0,-22} {1,9:N1} KB  {2}" -f $n, ($i.Length/1KB), $i.LastWriteTime.ToString('HH:mm:ss'))
  } else { $ok = $false; Write-Output ("MISS {0}" -f $n) }
}
if (-not $ok) { Write-Output 'FAILED - check AutoShop for a leftover dialog.'; exit 2 }
