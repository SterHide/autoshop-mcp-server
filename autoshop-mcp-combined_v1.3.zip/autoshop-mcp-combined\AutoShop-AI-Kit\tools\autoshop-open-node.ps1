# Open an AutoShop tree node WITHOUT scanning/walking the whole tree.
#
# WHY THIS EXISTS (user, 2026-09-20): "你每次找到变量表，双击后，左栏滚动条都会往下滚？
# 不是应该双击了就开始在变量表右键导出了么，为何左栏还会滚动下去"
# Cause: autoshop-jump.ps1 builds a ROW TABLE by paging through the tree ("scanning 187 rows
# (40 per page)") to compute a click Y -- that paging IS the visible scrolling.
# This script never walks rows:
#   1) one MSAA name sweep (accName over ids 1..N) -- pure reads, does NOT scroll
#   2) duplicate names -> smallest display row (needs the rect of each candidate only)
#   3) accSelect(3,id)      -- selects; the tree scrolls ONLY the target row into view
#   4) read accLocation(id) -- fresh, because the row is now realized
#   5) accHitTest(x,y)      -- verify it really is the target before clicking
#   6) double-click, then verify the MDI caption
#   7) restore the tree's original scroll position
# KEEP PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$Node,
  [int]$MaxId = 0,                 # default accChildCount + 3000
  [switch]$SelectOnly,             # select, do not double-click
  [switch]$KeepScroll              # do not restore the original scroll position
)

# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }
$ErrorActionPreference = 'Stop'
if (-not ('ON.U' -as [type])) {
Add-Type -Namespace ON -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
public struct RECT { public int Left, Top, Right, Bottom; }
public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin, nMax; public uint nPage; public int nPos, nTrackPos; }
'@
}
function ClsOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 256; [void][ON.U]::GetClassNameW($h,$b,256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h){ $b = New-Object System.Text.StringBuilder 512; [void][ON.U]::GetWindowTextW($h,$b,512); $b.ToString() }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
[void][ON.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 350

# --- the tree ---------------------------------------------------------------------------------
# There are SEVERAL SysTreeView32 windows in AutoShop (the project tree on the left AND the toolbox
# tree on the right). Picking "the first one found" grabbed the TOOLBOX tree -- the sweep then reported
# accName(1)='EtherCAT Devices' and every project node was missing. The engine's rule is the right one:
# collect them all and take the LEFTMOST (smallest rect.Left) = the project tree.
$trees = New-Object System.Collections.ArrayList
$cb = [ON.U+EnumProc]{
  param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') {
    $r = New-Object ON.U+RECT; [void][ON.U]::GetWindowRect($h, [ref]$r)
    [void]$trees.Add([pscustomobject]@{ hwnd = $h; rect = $r })
  }
  return $true
}
[void][ON.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
if ($trees.Count -eq 0) { throw 'no SysTreeView32 found' }
$treeInfo = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
$tree = $treeInfo.hwnd
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}  (of {5} SysTreeView32 candidates)" -f `
  $tree, $treeInfo.rect.Left, $treeInfo.rect.Top, ($treeInfo.rect.Right-$treeInfo.rect.Left), ($treeInfo.rect.Bottom-$treeInfo.rect.Top), $trees.Count)

$acc = $null
if (-not ('ON.A' -as [type])) {
  Add-Type -Namespace ON -Name A -MemberDefinition @'
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
'@
}
# OBJID_CLIENT = 0xFFFFFFFC: bind MSAA straight to THIS tree hwnd.
# NOTE: the marshalling signature matters -- the working engine declares "out object acc"; writing it as
# "ref object ppv" silently binds a DIFFERENT object (the sweep then reports ~1000 names that are not the
# tree's items and every lookup misses). Keep it identical to autoshop-extract-blocks2.ps1.
$iidAcc = [Guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$hrAcc = [ON.A]::AccessibleObjectFromWindow($tree, [uint32]4294967292, [ref]$iidAcc, [ref]$acc)
if ($hrAcc -ne 0 -or $null -eq $acc) { throw ("AccessibleObjectFromWindow failed hr=0x{0:X8}" -f $hrAcc) }
# PORTABILITY (field report from AutoShop V4.12, skill 17.2): on 4.12 the id space starts at 128 and
# accName(1) THROWS (E_INVALIDARG) instead of returning an empty string -- an unguarded probe kills the
# whole run before the sweep even starts. Probe several ids with try/catch, report the first that answers.
$msaaProbe = ''
foreach ($probeId in @(1, 2, 3, 128, 129, 130, 200, 300)) {
  try { $t = [string]$acc.accName([int]$probeId); if ($t) { $msaaProbe = ("accName({0})='{1}'" -f $probeId, $t); break } } catch { }
}
Write-Output ("MSAA live: " + $(if ($msaaProbe) { $msaaProbe } else { 'no id in 1..300 answered' }))

$count = [int]$acc.accChildCount
$maxId = $MaxId; if ($maxId -le 0) { $maxId = $count + 3000 }
$hits = New-Object System.Collections.ArrayList
$named = 0
for ($i = 1; $i -le $maxId; $i++) {
  $nm = ''
  try { $nm = [string]$acc.accName($i) } catch { continue }
  if ([string]::IsNullOrWhiteSpace($nm)) { continue }
  $named++
  if ($nm -eq $Node) { [void]$hits.Add($i) }
}
Write-Output ("name sweep: {0} named ids (swept 1..{1}); '{2}' -> {3} candidate(s)" -f $named, $maxId, $Node, $hits.Count)
if ($hits.Count -eq 0) { throw ("node '{0}' not found in the name sweep" -f $Node) }

# --- duplicate resolution: SMALLEST display row wins (row = nPos + (rect.top - treeTop)/20) -----
function Get-NPos {
  $si = New-Object ON.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = 0x17
  [void][ON.U]::GetScrollInfo($tree, 1, [ref]$si)
  return [int]$si.nPos
}
function RectOfId([int]$id) {
  $x=0;$y=0;$w=0;$h=0
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h, $id) } catch { }
  return [pscustomobject]@{ Id=$id; X=$x; Y=$y; W=$w; H=$h }
}
$tr = New-Object ON.U+RECT; [void][ON.U]::GetWindowRect($tree, [ref]$tr)
$chosen = $null
if ($hits.Count -eq 1) {
  $chosen = RectOfId $hits[0]
} else {
  $npos = Get-NPos
  $cands = @($hits | ForEach-Object { $r = RectOfId $_; $r | Add-Member -NotePropertyName Row -NotePropertyValue ($npos + [int](($r.Y - $tr.Top) / 20)) -PassThru })
  foreach ($c in $cands) { Write-Output ("  DUP id={0} x={1} row={2}" -f $c.Id, $c.X, $c.Row) }
  $chosen = @($cands | Sort-Object Row, @{Expression='X';Descending=$true} | Select-Object -First 1)[0]
  Write-Output ("  chosen id={0} (row {1}) -- the FIRST occurrence in the tree, per the user's rule" -f $chosen.Id, $chosen.Row)
}
Write-Output ("target id={0}" -f $chosen.Id)

# --- remember the scroll position, then select (this scrolls ONLY the target into view) --------
$nposBefore = Get-NPos
# accSelect only scrolls the row into view when the TREE has the focus; without it the target can stay
# unrealized (measured: accLocation returned y=-1712 and the hit-test came back empty). Grabbing focus
# with a click inside the tree pane is what the engine's jump tool does too.
[void][ON.U]::SetForegroundWindow($main); Start-Sleep -Milliseconds 200
$clickX = $treeInfo.rect.Left + 20
$clickY = $treeInfo.rect.Top + [int](($treeInfo.rect.Bottom - $treeInfo.rect.Top) / 2)
[void][ON.U]::SetCursorPos($clickX, $clickY); Start-Sleep -Milliseconds 120
[ON.U]::mouse_event(0x02,0,0,0,0); [ON.U]::mouse_event(0x04,0,0,0,0)
Start-Sleep -Milliseconds 300
try { $acc.accSelect(3, [int]$chosen.Id) } catch { }
Start-Sleep -Milliseconds 300
$fresh = RectOfId $chosen.Id
if ($fresh.H -le 0 -or $fresh.Y -lt $treeInfo.rect.Top -or $fresh.Y -gt $treeInfo.rect.Bottom) {
  # still not realized -> scroll by the row estimate (nPos + (y - treeTop)/20) the same way the jump tool does
  $est = Get-NPos + [int](($fresh.Y - $treeInfo.rect.Top) / 20)
  if ($est -lt 0) { $est = 0 }
  Write-Output ("  row not realized (rect y={0}); scrolling to the estimated row {1}" -f $fresh.Y, $est)
  if (-not ('ON.S' -as [type])) {
    Add-Type -Namespace ON -Name S -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
'@
  }
  for ($g = 1; $g -le 40; $g++) {
    $now = Get-NPos
    if ([Math]::Abs($now - $est) -le 1) { break }
    $cmd = if ($now -gt $est) { 0 } else { 1 }   # SB_LINEUP / SB_LINEDOWN
    [void][ON.S]::SendMessageW($tree, 0x0115, [IntPtr]$cmd, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 40
  }
  try { $acc.accSelect(3, [int]$chosen.Id) } catch { }
  Start-Sleep -Milliseconds 300
  $fresh = RectOfId $chosen.Id
}
if ($fresh.H -le 0) { throw 'the row did not realize after accSelect' }
$cx = $fresh.X + 40; $cy = $fresh.Y + [int]($fresh.H / 2)
$hit = ''
try {
  $h2 = $acc.accHitTest($cx, $cy)
  if ($h2 -is [int]) { $hit = [string]$acc.accName([int]$h2) } elseif ($null -ne $h2) { $hit = [string]$h2.accName(0) }
} catch { }
Write-Output ("  rect=({0},{1} {2}x{3}) click=({4},{5}) hitTest says '{6}'" -f $fresh.X,$fresh.Y,$fresh.W,$fresh.H,$cx,$cy,$hit)
if ($hit -ne $Node) { throw ("hit-test at the row centre says '{0}', expected '{1}' - refusing to click" -f $hit, $Node) }

if (-not $SelectOnly) {
  [void][ON.U]::SetCursorPos($cx, $cy); Start-Sleep -Milliseconds 120
  [ON.U]::mouse_event(0x02,0,0,0,0); [ON.U]::mouse_event(0x04,0,0,0,0)
  Start-Sleep -Milliseconds 90
  [ON.U]::mouse_event(0x02,0,0,0,0); [ON.U]::mouse_event(0x04,0,0,0,0)
  Start-Sleep -Milliseconds 900
  Write-Output ("  main window title: '{0}'" -f (TxtOf $main))
}

# --- restore the original scroll position ------------------------------------------------------
if (-not $KeepScroll) {
  $nposNow = Get-NPos
  if ($nposNow -ne $nposBefore) {
    # delta = rows; each WM_VSCROLL line scrolls one row
    $delta = $nposNow - $nposBefore
    $cmd = if ($delta -gt 0) { 0 } else { 1 }   # SB_LINEUP / SB_LINEDOWN
    if (-not ('ON.S' -as [type])) {
      Add-Type -Namespace ON -Name S -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
'@
    }
    for ($i = 0; $i -lt [Math]::Abs($delta); $i++) { [void][ON.S]::SendMessageW($tree, 0x0115, [IntPtr]$cmd, [IntPtr]::Zero) }
    Write-Output ("  scroll restored: {0} -> {1}" -f $nposNow, (Get-NPos))
  } else {
    Write-Output '  scroll unchanged'
  }
}
