# 把 Codex 里的 [mcp_servers.autoshop] 换成合并入口（proxy.py，41 个工具）。
# 一个名字只留一个入口：老桥（mcp-scaffold\autoshop-mcp）和三个 AutoShop 实现都收敛到这一个块，
# 否则 Codex 里会有两套工具同时驱动同一个 AutoShop 界面。
#   无参数   -> dry run，打印将要写入的块和会删掉的旧块
#   -Apply   -> 先备份 config.toml 到 config.toml.bak-autoshop-combined-<stamp>，再写入
#Requires -Version 7
param(
  [switch]$Apply,
  [string]$Python = '',
  [string]$Node = '',
  [string]$AutoShopExe = 'D:\app\major\INOVANCE\AutoShop\AutoShop.exe',
  [string]$ConfigPath = (Join-Path $HOME '.codex\config.toml')
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$proxy = Join-Path $PSScriptRoot 'proxy.py'
if (-not (Test-Path -LiteralPath $proxy)) { "missing proxy: $proxy"; exit 1 }
if (-not (Test-Path -LiteralPath $ConfigPath)) { "config not found: $ConfigPath"; exit 1 }

# python must be one that can import fastmcp; prefer the bundled .venv, then PATH, then workbuddy
if (-not $Python) {
  $candidates = @(
    (Join-Path $PSScriptRoot '.venv\Scripts\python.exe'),
    (Get-Command python.exe -EA SilentlyContinue).Source,
    (Join-Path $HOME '.workbuddy\binaries\python\envs\default\Scripts\python.exe')
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
  $Python = foreach ($c in $candidates) {
    & $c -c 'import fastmcp' 2>$null
    if ($LASTEXITCODE -eq 0) { $c; break }
  }
  if (-not $Python) { 'no python with fastmcp found - run: .venv\Scripts\pip install fastmcp==4.1.8'; exit 1 }
}
& $Python -c 'import fastmcp' 2>$null
if ($LASTEXITCODE -ne 0) { "fastmcp missing in $Python"; exit 1 }

if (-not $Node) { $Node = (Get-Command node.exe -EA SilentlyContinue).Source }
if (-not $Node) { 'node.exe not found - set -Node'; exit 1 }

$block = @"

[mcp_servers.autoshop]
command = '$Python'
args = ['$proxy']
startup_timeout_sec = 120

[mcp_servers.autoshop.env]
AUTOSHOP_MCP_NODE = '$Node'
AUTOSHOP_EXE = '$AutoShopExe'
"@

# Drop every existing block whose server name is "autoshop", including the [..autoshop.env] sub-table.
$kept = [System.Collections.Generic.List[string]]::new()
$dropped = [System.Collections.Generic.List[string]]::new()
$skip = $false
foreach ($line in (Get-Content -LiteralPath $ConfigPath -Encoding utf8)) {
  if ($line -match '^\s*\[mcp_servers\.([A-Za-z0-9_-]+)(\..*)?\]\s*$') { $skip = ($Matches[1] -eq 'autoshop') }
  elseif ($line -match '^\s*\[') { $skip = $false }
  if ($skip) { $dropped.Add($line) } else { $kept.Add($line) }
}
$newText = (($kept -join "`n").TrimEnd() + "`n" + $block)

"config : $ConfigPath"
"python : $Python"
"node   : $Node"
"autoshop exe : $AutoShopExe"
if (-not $Apply) {
  ''
  'DRY RUN - removing:'
  if ($dropped.Count) { $dropped | ForEach-Object { "  $_" } } else { '  (no existing autoshop block)' }
  'DRY RUN - appending:'
  $block -split "`n" | ForEach-Object { "  $_" }
  ''
  'Re-run with -Apply. Old file is copied to config.toml.bak-autoshop-combined-<stamp> first.'
  exit 0
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = "$ConfigPath.bak-autoshop-combined-$stamp"
Copy-Item -LiteralPath $ConfigPath -Destination $backup -Force
Set-Content -LiteralPath $ConfigPath -Value $newText -Encoding utf8 -NoNewline
"backup : $backup"
"written: $ConfigPath"
'Restart Codex - MCP servers load at process start, config changes are not hot-reloaded.'
