# Rename the inline tree edit box: focus it, select-all, paste the new name, press Enter.
# (AutoShop's node rename is an inline Edit control inside the tree, not a dialog.)
# Pure ASCII on purpose -- the new name arrives as a parameter.
param(
  [Parameter(Mandatory=$true)][string]$NewName,
  [int]$MaxTries = 12
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('RN.U' -as [type])) {
Add-Type -Namespace RN -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc cb, IntPtr x);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h) { $b = New-Object System.Text.StringBuilder 256; [void][RN.U]::GetClassNameW($h, $b, 256); $b.ToString().Trim() }
function TxtOf([IntPtr]$h) { $b = New-Object System.Text.StringBuilder 512; [void][RN.U]::GetWindowTextW($h, $b, 512); $b.ToString() }

$proc = Get-Process -Name AutoShop  | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
# the inline rename box is a small visible Edit inside the LEFT pane (x < 400), height ~20
$box = [IntPtr]::Zero
for ($t = 1; $t -le $MaxTries; $t++) {
  $cands = New-Object System.Collections.ArrayList
  $cb = [RN.U+EnumProc]{
    param($h, $x)
    if ((ClsOf $h) -eq 'Edit' -and [RN.U]::IsWindowVisible($h)) {
      $r = New-Object RN.U+RECT; [void][RN.U]::GetWindowRect($h, [ref]$r)
      $w = $r.Right - $r.Left; $hh = $r.Bottom - $r.Top
      if ($r.Left -lt 400 -and $hh -le 30 -and $w -ge 30) { [void]$cands.Add([pscustomobject]@{ H = $h; X = $r.Left; Y = $r.Top; W = $w; Hh = $hh }) }
    }
    return $true
  }
  [void][RN.U]::EnumChildWindows((Get-AutoShopMainWindow $proc), $cb, [IntPtr]::Zero)
  if ($cands.Count -gt 0) { $box = (@($cands | Sort-Object X | Select-Object -First 1)[0]).H; break }
  Start-Sleep -Milliseconds 250
}
if ($box -eq [IntPtr]::Zero) { throw 'no inline rename Edit box found in the left pane' }
Write-Output ('inline rename box found, current text = "' + (TxtOf $box) + '"')

[void][RN.U]::SetForegroundWindow((Get-AutoShopMainWindow $proc)); Start-Sleep -Milliseconds 300
[System.Windows.Forms.SendKeys]::SendWait('^a'); Start-Sleep -Milliseconds 200
[System.Windows.Forms.Clipboard]::SetText($NewName); Start-Sleep -Milliseconds 200
[System.Windows.Forms.SendKeys]::SendWait('^v'); Start-Sleep -Milliseconds 500
Write-Output ('after paste, box text = "' + (TxtOf $box) + '"')
[System.Windows.Forms.SendKeys]::SendWait('{ENTER}'); Start-Sleep -Milliseconds 900
Write-Output 'ENTER sent'
