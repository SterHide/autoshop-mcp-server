# 给合并入口建包内自带 .venv 并装 fastmcp（默认走清华镜像，直连 PyPI 这边经常卡住）。
#   -Index   换索引地址；-Force 时重建 venv
#Requires -Version 7
param(
  [string]$Index = 'https://pypi.tuna.tsinghua.edu.cn/simple',
  [string]$BasePython = '',
  [switch]$Force
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$venv = Join-Path $PSScriptRoot '.venv'
$venvPy = Join-Path $venv 'Scripts\python.exe'

if (-not (Test-Path -LiteralPath $venvPy)) {
  if (-not $BasePython) {
    $BasePython = (Get-Command python.exe -EA SilentlyContinue).Source
    if (-not $BasePython) { 'base python not found - pass -BasePython'; exit 1 }
  }
  "creating venv with $BasePython"
  & $BasePython -m venv $venv
  if ($LASTEXITCODE -ne 0) { 'venv creation failed'; exit 1 }
}

"installing fastmcp==4.1.8 from $Index"
& $venvPy -m pip install --disable-pip-version-check -i $Index fastmcp==4.1.8
if ($LASTEXITCODE -ne 0) { 'pip install failed'; exit 1 }

& $venvPy -c "import fastmcp, sys; print('venv ok:', sys.executable); print('fastmcp', fastmcp.__version__)"
