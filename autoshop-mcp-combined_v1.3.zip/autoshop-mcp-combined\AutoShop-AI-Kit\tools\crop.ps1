param(
  [Parameter(Mandatory=$true)][string]$Src,
  [Parameter(Mandatory=$true)][int]$X,
  [Parameter(Mandatory=$true)][int]$Y,
  [Parameter(Mandatory=$true)][int]$W,
  [Parameter(Mandatory=$true)][int]$H,
  [int]$Zoom = 4,
  [Parameter(Mandatory=$true)][string]$Out
)
Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile($Src)
try {
  $srcRect = New-Object System.Drawing.Rectangle $X, $Y, $W, $H
  $dstRect = New-Object System.Drawing.Rectangle 0, 0, ($W*$Zoom), ($H*$Zoom)
  $bmp = New-Object System.Drawing.Bitmap ($W*$Zoom), ($H*$Zoom)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  try {
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
    $g.DrawImage($img, $dstRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)
  } finally { $g.Dispose() }
  $bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
} finally { $img.Dispose() }
Write-Output "wrote $Out ($($W*$Zoom)x$($H*$Zoom)) crop of ($X,$Y ${W}x${H})"
