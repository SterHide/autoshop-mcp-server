# Find a toolbar button BY NAME (MSAA), instead of assuming a pixel offset.
#
# WHY (user, 2026-09-20): "你初始化窗体的时候应该要找找保存按钮的位置" -- the recorded offset (88,70) /
# toolbar-relative (88,42) was measured against ONE toolbar row; when AutoShop lays its toolbar out
# differently the click lands outside the 30px-tall toolbar and the save silently does nothing.
#
# Method: main window -> every visible 'Afx:ToolBar*' child -> bind MSAA (OBJID_CLIENT) -> sweep child ids
# (tolerant of the 4.12 id-space quirk: accName(1) may THROW, ids may start at 128) -> match a name ->
# return the button's SCREEN RECT so the caller can click its centre.
# PURE ASCII; the wanted label arrives as a parameter.
param(
  [string]$Label = '',
  [switch]$List,
  [switch]$Click,
  [int]$MaxId = 400
)
$ErrorActionPreference = 'Stop'
if (-not ('FB' -as [type])) {
  Add-Type -Namespace FB -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h) { $b = New-Object System.Text.StringBuilder 256; [void][FB.U]::GetClassNameW($h, $b, 256); $b.ToString().Trim() }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
# robust main window (see autoshop-shared.ps1 / skill 17.4)
$shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $shared) { . $shared }
$main = if (Get-Command Get-AutoShopMainWindow -ErrorAction SilentlyContinue) { Get-AutoShopMainWindow $proc } else { $proc.MainWindowHandle }

$tbs = New-Object System.Collections.ArrayList
$cb = [FB.U+EnumProc]{
  param($h, $x)
  if ([FB.U]::IsWindowVisible($h) -and (ClsOf $h) -like 'Afx:ToolBar*') {
    $r = New-Object FB.U+RECT; [void][FB.U]::GetWindowRect($h, [ref]$r)
    [void]$tbs.Add([pscustomobject]@{ H = $h; L = $r.Left; T = $r.Top; W = ($r.Right-$r.Left); Hh = ($r.Bottom-$r.Top) })
  }
  return $true
}
[void][FB.U]::EnumChildWindows($main, $cb, [IntPtr]::Zero)
Write-Output ("toolbars found: {0}" -f $tbs.Count)
$iid = [Guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$found = $null
foreach ($tb in (@($tbs | Sort-Object T, L))) {
  $acc = $null
  $hr = [FB.U]::AccessibleObjectFromWindow($tb.H, [uint32]4294967292, [ref]$iid, [ref]$acc)
  Write-Output ("  toolbar {{ {0},{1} {2}x{3} }}  MSAA hr={4}" -f $tb.L, $tb.T, $tb.W, $tb.Hh, $hr)
  if ($hr -ne 0 -or $null -eq $acc) { continue }
  for ($i = 1; $i -le $MaxId; $i++) {
    $nm = ''
    try { $nm = [string]$acc.accName([int]$i) } catch { continue }
    if ([string]::IsNullOrWhiteSpace($nm)) { continue }
    $x = 0; $y = 0; $w = 0; $h = 0
    try { $acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$i) } catch { continue }
    if ($h -le 0) { continue }
    if ($List) { Write-Output ("    id={0,-4} name='{1}' rect={{ {2},{3} {4}x{5} }}" -f $i, $nm, $x, $y, $w, $h) }
    if ($Label -ne '' -and $nm -like ('*' + $Label + '*')) {
      $found = [pscustomobject]@{ Id = $i; Name = $nm; X = $x; Y = $y; W = $w; H = $h; Tb = $tb }
      break
    }
  }
  if ($null -ne $found) { break }
}
if ($null -eq $found) { Write-Output ("button containing '{0}' NOT found by MSAA" -f $Label); exit 1 }
$cx = $found.X + [int]($found.W / 2); $cy = $found.Y + [int]($found.H / 2)
Write-Output ("FOUND '{0}' id={1} rect={{ {2},{3} {4}x{5} }} -> click centre ({6},{7})" -f $found.Name, $found.Id, $found.X, $found.Y, $found.W, $found.H, $cx, $cy)
if ($Click) {
  [void][FB.U]::SetCursorPos($cx, $cy); Start-Sleep -Milliseconds 150
  [FB.U]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 70; [FB.U]::mouse_event(0x04,0,0,0,0)
  Write-Output 'clicked'
}
