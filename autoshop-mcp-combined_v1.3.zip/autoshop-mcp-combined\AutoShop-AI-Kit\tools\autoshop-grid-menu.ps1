# Right-click inside an AutoShop grid, then click ONE item of the popup menu by a vertical offset.
#
# WHY THIS EXISTS: the grid's context menu (219x476 on the 功能块实例 / GVL views) is an MFC
# toolbar-style popup that UIA does not expose, so items must be clicked by offset. Doing that with
# a HARD-CODED absolute point is dangerous: AutoShop repositions the popup so it fits on screen
# (measured origins 455, 457, 468 for the same right-click point), and a stale assumption turned a
# "+271 (insert row)" click into "+282" -- which sits on the boundary to "+297 (delete row)".
# This script therefore reads the popup's own rect and computes the point from it every time.
#
# Measured offsets for the 功能块实例 / GVL grids (menu 219x476, pitch 26):
#   全选(A) +242 | 删除(D) +268 | 插入行(I) +271 | 删除行(L) +297 | 添加行(N) +323 |
#   批量添加(B) +349 | 导出(X) +383 | 导入(M) +409
#
# KEEP PURE ASCII.
param(
  [Parameter(Mandatory=$true)][int]$X,
  [Parameter(Mandatory=$true)][int]$Y,
  [Parameter(Mandatory=$true)][int]$ItemOffsetY,
  [int]$ItemOffsetX = 100,
  [int]$ExpectedMenuH = 0,          # if > 0, refuse to click unless the popup height is within +-20
  [string]$CaptureOut = '',         # PrintWindow the popup here before clicking
  [switch]$NoClick                  # only capture / report
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('GM.U' -as [type])) {
Add-Type -Namespace GM -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][GM.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function WR([IntPtr]$h){$r=New-Object GM.U+RECT;[void][GM.U]::GetWindowRect($h,[ref]$r);return $r}
function Popups {
  $l=New-Object System.Collections.ArrayList
  $cb=[GM.U+EnumProc]{ param($h,$p) if([GM.U]::IsWindowVisible($h)){ if((ClsOf $h) -like 'Afx:00400000:800:*'){ $r=WR $h; [void]$l.Add([pscustomobject]@{H=$h;X=$r.Left;Y=$r.Top;W=($r.Right-$r.Left);Hh=($r.Bottom-$r.Top)}) } }; return $true }
  [void][GM.U]::EnumWindows($cb,[IntPtr]::Zero); return @($l | Sort-Object { -($_.W*$_.Hh) }) }
function SavePng([IntPtr]$hwnd,[int]$w,[int]$h,[string]$path){
  $hs=[GM.U]::GetDC([IntPtr]::Zero);$hm=[GM.U]::CreateCompatibleDC($hs);$hb=[GM.U]::CreateCompatibleBitmap($hs,[Math]::Max(1,$w),[Math]::Max(1,$h))
  $ho=[GM.U]::SelectObject($hm,$hb);[void][GM.U]::PrintWindow($hwnd,$hm,2)
  $img=[System.Drawing.Image]::FromHbitmap($hb);$img.Save($path,[System.Drawing.Imaging.ImageFormat]::Png);$img.Dispose()
  [void][GM.U]::SelectObject($hm,$ho);[void][GM.U]::DeleteObject($hb);[void][GM.U]::DeleteDC($hm);[void][GM.U]::ReleaseDC([IntPtr]::Zero,$hs) }

$p = Get-Process -Name AutoShop  | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
[void][GM.U]::SetForegroundWindow((Get-AutoShopMainWindow $p)); Start-Sleep -Milliseconds 400

# a leftover popup would defeat the "new window" test -> dismiss nothing, just record what is up
$before = @(Popups | ForEach-Object { $_.H })
[void][GM.U]::SetCursorPos($X, $Y); Start-Sleep -Milliseconds 150
[GM.U]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 70; [GM.U]::mouse_event(0x04,0,0,0,0)
Start-Sleep -Milliseconds 900
$new = @(Popups | Where-Object { $before -notcontains $_.H })
if ($new.Count -eq 0) { throw 'right-click did not raise a grid popup menu' }
$m = $new[0]
Write-Output ("popup {0}x{1} at {2},{3}" -f $m.W,$m.Hh,$m.X,$m.Y)
if ($CaptureOut) { SavePng $m.H $m.W $m.Hh $CaptureOut; Write-Output ("captured -> {0}" -f $CaptureOut) }
if ($ExpectedMenuH -gt 0 -and [Math]::Abs($m.Hh - $ExpectedMenuH) -gt 20) {
  [System.Windows.Forms.SendKeys]::SendWait('{ESC}')
  throw ("popup height {0} != expected {1} - refusing to click" -f $m.Hh,$ExpectedMenuH)
}
if ($NoClick) { [System.Windows.Forms.SendKeys]::SendWait('{ESC}'); Write-Output 'no click requested'; exit 0 }
$cx = $m.X + $ItemOffsetX
$cy = $m.Y + $ItemOffsetY
Write-Output ("clicking popup + {0},{1} -> absolute {2},{3}" -f $ItemOffsetX,$ItemOffsetY,$cx,$cy)
[void][GM.U]::SetCursorPos($cx, $cy); Start-Sleep -Milliseconds 150
[GM.U]::mouse_event(0x02,0,0,0,0); Start-Sleep -Milliseconds 70; [GM.U]::mouse_event(0x04,0,0,0,0)
Start-Sleep -Milliseconds 900
$left = @(Popups | Where-Object { $_.H -eq $m.H }).Count
Write-Output ("popup closed after the click: {0}" -f ($left -eq 0))
