# FAST JUMP: go straight to a node in the AutoShop project tree, then CLICK it (or double-click to
# open the block) -- without walking the tree row by row.
#
# Strategy (all numbers measured on AutoShop V4.11.0.5, project tree hwnd 724296):
#   * the tree window is (9,148) 355x811, client 338x811, so the VERTICAL SCROLLBAR is
#     x = 347..364 (17px), y = 148..959; there is NO horizontal scrollbar while the pane is wide
#     enough (WS_HSCROLL is off -- see the pre-flight check).
#   * row height is exactly 20px and rows are 0-based, so with the scroll position nPos
#       screen_y(row) = treeTop + (row - nPos) * 20 + 10
#     (verified: a node selected at row 140 sits at y=908 with nPos=102)
#   * the scroll state comes from GetScrollInfo(SB_VERT): nMin/nMax/nPage/nPos, maxPos = nMax-nPage+1
#     (measured: nMax=187 nPage=40 -> maxPos=148, i.e. 188 rows with 40 visible)
#   * scrolling WITHOUT coordinates: WM_VSCROLL with SB_TOP/SB_PAGEDOWN/SB_LINEUP etc. -- verified
#     to move exactly as asked and re-read with GetScrollInfo.
#   * scrolling WITH the mouse (what the user asked for) also works and is exact:
#       click the track BELOW the thumb -> nPos +39      (= nPage-1, one page)
#       click the track ABOVE the thumb -> nPos -39
#       click the bottom arrow          -> nPos +1
#       click ON the thumb              -> NOTHING (so a thumb must always be avoided)
#     the thumb geometry is read with GetScrollBarInfo(OBJID_VSCROLL) instead of being guessed:
#       thumb_screen_y = trackTop + lineButton + round(nPos/maxPos * (trackH - thumbH))
#   * HOW THE TARGET ROW IS FOUND: accName(id) gives every node's name but the id is NOT the display
#     row, so the row is obtained by selecting the node once (accSelect) and reading where it landed:
#       row = nPos + (rect.y - treeTop)/20
#   * HOW THE CLICK IS PROVED CORRECT: accHitTest(x, y) returns the node under a screen point, so the
#     row is hit-tested BEFORE the click and, if asked, AFTER it. No blind clicking any more.
#
# KEEP PURE ASCII. Chinese node names arrive via parameters.
param(
  [string]$Node = '',                 # target node name (exact match), or use -Row
  [int]$Row = -1,                     # target display row (0-based), or use -Node
  [int]$Index = 0,                    # which match to use when the name occurs more than once
  [ValidateSet('Click','Select')][string]$Mode = 'Click',
  [switch]$DoubleClick,               # double-click the row (opens the block)
  [ValidateSet('Message','Mouse')][string]$ScrollBy = 'Message',
  [switch]$Scan,                      # page through the whole tree and print row -> name
  [switch]$ListSections,              # print the row of every section named in -SectionNames
  [string]$SectionNames = '',         # comma-separated node names, e.g. 'Program,FB,FC'
  [switch]$NoRestore,                 # do not scroll back to where we started
  [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('J.U' -as [type])) {
if (-not ('J.U' -as [type])) {
Add-Type -Namespace J -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, System.Text.StringBuilder lp);
[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
[DllImport("user32.dll")] public static extern bool GetScrollBarInfo(IntPtr h, int idObject, ref SCROLLBARINFO sbi);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
[StructLayout(LayoutKind.Sequential)] public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin; public int nMax; public int nPage; public int nPos; public int nTrackPos; }
[StructLayout(LayoutKind.Sequential)] public struct SCROLLBARINFO { public uint cbSize; public RECT rcScrollBar; public int dxyLineButton; public int xyThumbTop; public int xyThumbBottom; public int reserved; [MarshalAs(UnmanagedType.ByValArray, SizeConst=6)] public uint[] rgstate; }
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
}
function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][J.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function TxtOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 512;[void][J.U]::GetWindowTextW($h,$b,512);$b.ToString()}
function RectOf([IntPtr]$h){$r=New-Object J.U+RECT;[void][J.U]::GetWindowRect($h,[ref]$r);return $r}
function ClickRaw([int]$x,[int]$y){[void][J.U]::SetCursorPos($x,$y);Start-Sleep -Milliseconds 100;[J.U]::mouse_event(0x02,0,0,0,0);Start-Sleep -Milliseconds 50;[J.U]::mouse_event(0x04,0,0,0,0);Start-Sleep -Milliseconds 250}
function DblClickRaw([int]$x,[int]$y){[void][J.U]::SetCursorPos($x,$y);Start-Sleep -Milliseconds 100
  [J.U]::mouse_event(0x02,0,0,0,0);[J.U]::mouse_event(0x04,0,0,0,0)
  Start-Sleep -Milliseconds 60
  [J.U]::mouse_event(0x02,0,0,0,0);[J.U]::mouse_event(0x04,0,0,0,0)
  Start-Sleep -Milliseconds 1200}

$ROW_H = 20
$SB_VERT = 1
$WM_VSCROLL = 0x0115
$SB = @{ LINEUP=0; LINEDOWN=1; PAGEUP=2; PAGEDOWN=3; THUMBPOSITION=4; THUMBTRACK=5; TOP=6; BOTTOM=7; ENDSCROLL=8 }
# Focus-AutoShop is dot-sourced so the foreground can be handed back at the end (standing user rule).
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1') }

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [J.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq 'SysTreeView32' -and [J.U]::IsWindowVisible($h)){[void]$trees.Add($h)};return $true }
[void][J.U]::EnumChildWindows($main,$cb,[IntPtr]::Zero)
if ($trees.Count -eq 0) { throw 'no visible SysTreeView32' }
$tree = (@($trees) | Sort-Object { (RectOf $_).Left } | Select-Object -First 1)
$tree = [IntPtr]$tree
$wr = RectOf $tree
$cr = New-Object J.U+RECT; [void][J.U]::GetClientRect($tree,[ref]$cr)
$style = [J.U]::GetWindowLong($tree,-16)
$hasH = (($style -band 0x00100000) -ne 0)
Write-Output ("tree hwnd={0} rect={1},{2} {3}x{4}  client={5}x{6}  WS_HSCROLL={7}" -f $tree,$wr.Left,$wr.Top,($wr.Right-$wr.Left),($wr.Bottom-$wr.Top),($cr.Right-$cr.Left),($cr.Bottom-$cr.Top),$hasH)
if ($hasH) { Write-Output '  WARNING: WS_HSCROLL is on -> a horizontal scrollbar sits in the bottom band; do not click there (run the pre-flight -Fix).' }

function Get-Scroll {
  $si = New-Object J.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si); $si.fMask = 0x17
  [void][J.U]::GetScrollInfo($tree,$SB_VERT,[ref]$si)
  return [pscustomobject]@{ Min=$si.nMin; Max=$si.nMax; Page=$si.nPage; Pos=$si.nPos; MaxPos=($si.nMax-$si.nPage+1) }
}
function Get-Thumb {
  $sbi = New-Object J.U+SCROLLBARINFO
  $sbi.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($sbi); $sbi.rgstate = New-Object uint32[] 6
  if (-not [J.U]::GetScrollBarInfo($tree,-5,[ref]$sbi)) { return $null }   # OBJID_VSCROLL
  $r = $sbi.rcScrollBar
  if (($r.Right-$r.Left) -le 0) { return $null }
  return [pscustomobject]@{
    BarLeft=$r.Left; BarTop=$r.Top; BarW=($r.Right-$r.Left); BarH=($r.Bottom-$r.Top)
    Arrow=$sbi.dxyLineButton
    Top=($r.Top + $sbi.dxyLineButton + $sbi.xyThumbTop)
    Bottom=($r.Top + $sbi.dxyLineButton + $sbi.xyThumbBottom)
    X=[int](($r.Left+$r.Right)/2)
  }
}
function Scroll-To([int]$target) {
  # Scroll so that nPos == target, clamped. Default channel is WM_VSCROLL (no coordinates at all);
  # -ScrollBy Mouse uses the measured scrollbar geometry instead.
  $s = Get-Scroll
  $target = [Math]::Max($s.Min, [Math]::Min($s.MaxPos, $target))
  for ($i=1; $i -le 40; $i++) {
    $s = Get-Scroll
    if ($s.Pos -eq $target) { return $true }
    $delta = $target - $s.Pos
    if ($ScrollBy -eq 'Message') {
      if ($delta -ge $s.Page) { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.PAGEDOWN,[IntPtr]::Zero) }
      elseif ($delta -le (-$s.Page)) { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.PAGEUP,[IntPtr]::Zero) }
      elseif ($delta -gt 0) { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.LINEDOWN,[IntPtr]::Zero) }
      else { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.LINEUP,[IntPtr]::Zero) }
    } else {
      $th = Get-Thumb
      if ($null -eq $th) { throw 'no vertical scrollbar found' }
      if ($delta -gt 0) {
        # click the track BELOW the thumb; stay clear of the thumb and of the bottom arrow
        $y = [int](($th.Bottom + 12)); $lim = $th.BarTop + $th.BarH - $th.Arrow - 6
        if ($y -gt $lim) { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.LINEDOWN,[IntPtr]::Zero) }
        else { ClickRaw $th.X $y }
      } else {
        $y = [int](($th.Top - 12)); $lim = $th.BarTop + $th.Arrow + 6
        if ($y -lt $lim) { [void][J.U]::SendMessageW($tree,$WM_VSCROLL,[IntPtr]$SB.LINEUP,[IntPtr]::Zero) }
        else { ClickRaw $th.X $y }
      }
    }
    Start-Sleep -Milliseconds 120
  }
  Write-Output ("  WARNING: could not reach nPos={0} (stopped at {1})" -f $target,(Get-Scroll).Pos)
  return $false
}
function RowY([int]$row,[int]$nPos) { return [int]($wr.Top + ($row - $nPos) * $ROW_H + [int]($ROW_H/2)) }

# where the view was when we started, so it can be put back (standing user rule: restore what you move)
$script:startPos = (Get-Scroll).Pos

# --- MSAA -------------------------------------------------------------------------------------
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:acc = $null
[void][J.U]::AccessibleObjectFromWindow($tree,[uint32]4294967292,[ref]$iid,[ref]$script:acc)
$count = [int]$script:acc.accChildCount
$map = New-Object System.Collections.ArrayList
for ($i=1; $i -le ($count + 800); $i++) {
  $n = ''; try { $n = [string]$script:acc.accName($i) } catch { continue }
  if ([string]::IsNullOrWhiteSpace($n)) { continue }
  [void]$map.Add([pscustomobject]@{ Id=$i; Name=$n })
}
function HitName([int]$x,[int]$y) {
  $hit = $null
  try { $hit = $script:acc.accHitTest($x,$y) } catch { return '' }
  if ($null -eq $hit) { return '' }
  if ($hit -is [int]) { try { return [string]$script:acc.accName([int]$hit) } catch { return '' } }
  try { return [string]$hit.accName(0) } catch { return '' }
}
function Get-SelInfo {
  $id = $null; try { $id = $script:acc.accSelection } catch {}
  if ($id -isnot [int]) { return [pscustomobject]@{ Id=-1; Name=''; X=0; Y=0 } }
  $n=''; try { $n = [string]$script:acc.accName([int]$id) } catch {}
  $x=0;$y=0;$w=0;$h=0; try { $script:acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$id) } catch {}
  return [pscustomobject]@{ Id=[int]$id; Name=$n; X=$x; Y=$y }
}

# --- the whole-tree row table (optional) ------------------------------------------------------
if ($Scan -or $ListSections) {
  $start = (Get-Scroll).Pos
  $s = Get-Scroll
  Write-Output ("scanning {0} rows ({1} per page) ..." -f $s.Max,$s.Page)
  [void](Scroll-To 0)
  $table = New-Object System.Collections.ArrayList
  $seen = @{}
  # NB: the page step is nPage-1 (=39), NOT nPage -- PAGEDOWN overlaps by one row, which is why the
  # first version of this table had 199 entries for 188 rows. Dedupe by row number as well.
  $rPage = [int]$s.Page
  for ($page=0; $page -le [Math]::Ceiling($s.Max / [Math]::Max(1,$rPage-1)); $page++) {
    $now = Get-Scroll
    for ($i=0; $i -lt $now.Page; $i++) {
      $rr = $now.Pos + $i
      if ($rr -gt $s.Max) { break }
      if ($seen.ContainsKey($rr)) { continue }
      $y = RowY $rr $now.Pos
      $nm = HitName ($wr.Left + 60) $y
      if ([string]::IsNullOrWhiteSpace($nm)) { continue }
      $seen[$rr] = $true
      [void]$table.Add([pscustomobject]@{ Row=$rr; Name=$nm })
    }
    if ($now.Pos -ge $now.MaxPos) { break }
    [void](Scroll-To ($now.Pos + $now.Page))
  }
  Write-Output ("  row table built: {0} rows" -f $table.Count)
  if ($ListSections) {
    Write-Output '  --- section header rows (give the names with -SectionNames) ---'
    foreach ($sec in ($SectionNames -split ',' | Where-Object { $_.Trim() -ne '' })) {
      $nm = $sec.Trim()
      $h = @($table | Where-Object { $_.Name -eq $nm })
      if ($h.Count -eq 0) { Write-Output ("    {0,-16} <not found>" -f $nm); continue }
      Write-Output ("    {0,-16} header row {1}" -f $nm,$h[0].Row)
    }
  }
  if (-not $NoRestore) { [void](Scroll-To $start); Write-Output ("  scroll restored to {0}" -f $start) }
  if ($Scan) {
    foreach ($t in $table) {
      $ind = 0
      $mm = @($map | Where-Object { $_.Name -eq $t.Name })
      if ($mm.Count -gt 0) {
        $x=0;$y=0;$w=0;$h=0
        try { $script:acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$mm[0].Id) } catch {}
        if ($x -gt 0) { $ind = [int](($x - 58) / 23) }   # measured indent ladder: 58/81/104/127/150/173
      }
      Write-Output ("  row {0,4}  {1}{2}" -f $t.Row, ('  ' * $ind), $t.Name)
    }
  }
  if (-not $Node -and $Row -lt 0) { exit 0 }
}

# --- resolve the target -----------------------------------------------------------------------
$targetRow = $Row
if ($targetRow -lt 0) {
  if (-not $Node) { throw 'pass -Node NAME, -Row N, -Scan or -ListSections' }
  $hits = @($map | Where-Object { $_.Name -eq $Node })
  if ($hits.Count -eq 0) { throw ("node not found: '{0}'" -f $Node) }
  if ($hits.Count -gt 1) {
    Write-Output ("  {0} nodes named '{1}': {2}" -f $hits.Count,$Node, (($hits | ForEach-Object { $_.Id }) -join ','))
  }
  if ($Index -ge $hits.Count) { throw ("-Index {0} out of range ({1} matches)" -f $Index,$hits.Count) }
  $tid = [int]$hits[$Index].Id
  # select it once to learn its real display row (the id is NOT the row)
  try { $script:acc.accSelect(3,$tid) } catch {}
  Start-Sleep -Milliseconds 300
  $si = Get-SelInfo
  if ($si.Id -ne $tid) { throw ("could not select '{0}' (wanted id {1}, got id {2} '{3}')" -f $Node,$tid,$si.Id,$si.Name) }
  $sc = Get-Scroll
  $targetRow = $sc.Pos + [int](($si.Y - $wr.Top) / $ROW_H)
  Write-Output ("  '{0}' id={1} is at row {2} (nPos={3}, y={4})" -f $si.Name,$tid,$targetRow,$sc.Pos,$si.Y)
}

# --- scroll so the row sits comfortably in view -----------------------------------------------
if ($targetRow -ge 0) {
  $s = Get-Scroll
  $want = [Math]::Max($s.Min, [Math]::Min($s.MaxPos, $targetRow - [int]($s.Page/2)))
  $s = Get-Scroll
  $visible = ($targetRow -ge $s.Pos -and $targetRow -lt ($s.Pos + $s.Page))
  $yNow = RowY $targetRow $s.Pos
  $comfortable = ($visible -and $yNow -gt ($wr.Top + 60) -and $yNow -lt ($wr.Bottom - 60))
  if (-not $comfortable) {
    Write-Output ("  scrolling to page nPos={0} (was {1}) via {2}" -f $want,$s.Pos,$ScrollBy)
    [void](Scroll-To $want)
  } else {
    Write-Output ("  target row {0} is already comfortably visible at y={1}" -f $targetRow,$yNow)
  }
}

if ($Mode -eq 'Select') {
  Write-Output '  -Mode Select: selection already made with accSelect; no mouse click performed.'
} else {
  $sc = Get-Scroll
  $y = RowY $targetRow $sc.Pos
  $x = $wr.Left + 60
  if ($y -lt ($wr.Top + 10) -or $y -gt ($wr.Bottom - 10)) { throw ("row {0} is off-screen (y={1}) - refusing to click" -f $targetRow,$y) }
  $under = HitName $x $y
  Write-Output ("  row {0} -> y={1}  accHitTest says: '{2}'" -f $targetRow,$y,$under)
  if ($Node -and $under -ne $Node) {
    throw ("the row under y={0} is '{1}', not '{2}' - refusing to click (folders may be collapsed; run the pre-flight -Deep)" -f $y,$under,$Node)
  }
  if ($DoubleClick) { Write-Output '  double-clicking'; DblClickRaw $x $y } else { Write-Output '  clicking'; ClickRaw $x $y }
  Start-Sleep -Milliseconds 400
  $after = HitName $x $y
  $sel = Get-SelInfo
  Write-Output ("  after the click: row says '{0}', selection is id={1} '{2}'" -f $after,$sel.Id,$sel.Name)
  if ($Node -and $sel.Name -ne $Node) { Write-Output ("  WARNING: selection is not the target - re-check (folders collapsed? name repeated?)") }
  if ($DoubleClick) { Write-Output ("  main window title: '{0}'" -f (TxtOf $main)) }
}

if (-not $NoRestore -and -not $Scan) {
  # put the view back where it was found (the user's standing rule: restore what you moved)
  $cur = (Get-Scroll).Pos
  if ($script:startPos -ne $null -and $cur -ne $script:startPos) {
    [void](Scroll-To $script:startPos)
    Write-Output ("  scroll restored: {0} -> {1}" -f $cur,(Get-Scroll).Pos)
  }
}
if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
