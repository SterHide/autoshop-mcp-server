# ST block extractor v2 -- NAME-ADDRESSED via MSAA, dialog-checked on every action.
#
# 鈽?2026-09-19: THE KEYBOARD WALK IS GONE. Do not reintroduce it.
#   OLD-OLD: blind coordinate clicks -> read the MDI caption to find out what got opened.
#   OLD:     walk the tree with the DOWN key, asking MSAA what is selected at every row.
#            It worked, but it was slow (a re-walk per chunk), it needed "is this row on screen /
#            in the no-click band" checks, it needed stale-read re-reads to detect the end of the
#            tree, and it needed a DRIFT repair when the focus escaped after closing a view.
#   NEW:     ONE MSAA sweep builds a name -> id index, then every block is addressed BY NAME:
#              accSelect(3, id)   -> selects it (and scrolls it into view), no coordinates involved
#              Ctrl+O             -> opens that block's view (measured on program / FB / FC)
#              WM_CLOSE           -> closes it, verified
#            Measured facts that make this safe:
#              * accName(id) answers for EVERY id, but accChildCount (~188) is NOT the top of the id
#                space (real ids reach 600+) and ids are REASSIGNED on every tree change -> sweep
#                wide and re-sweep per run, never cache an id.
#              * Ctrl+Home is a no-op in this tree; accDoDefaultAction is not implemented
#                (DISP_E_MEMBERNOTFOUND) and a plain {ENTER} does not open a block. Ctrl+O is the
#                only keyboard opener.
#   Every action that can raise a dialog still goes through Assert-NoDialog, and dismissal always
#   presses No/Cancel (or ESC) -- NEVER Yes/OK.
#
# SAFETY: read-only against the project. Opens blocks, reads their text, closes them.
#   -Write is required to touch files; the default is a dry run.
#
# KEEP THIS FILE PURE ASCII. Run with -STA.
param(
  [Parameter(Mandatory=$true)][string]$ProjectDir,
  [Parameter(Mandatory=$true)][string]$MirrorDir,
  [switch]$Write,
  [int]$Limit = 0,                 # 0 = all blocks
  [int]$OpenWaitMs = 700,
  [switch]$ExpandFolded,           # expand every folded folder up front, BEFORE the name index
  # Deprecated no-ops (kept so old command lines do not break; the walk they belonged to is gone)
  [int]$MaxSteps = 0,
  [int]$StepWaitMs = 0,
  [switch]$Resume,
  [switch]$UseSkeleton = $true,    # resolve each block's target from the existing placeholder .md
  # NB: use a plain flag rather than a boolean parameter. `powershell.exe -File` cannot express
  # "-SkipDone:$false" (it arrives as the literal string "System.String" and binding fails), so a
  # default-on boolean is impossible to turn off from the command line. -Redo inverts it instead.
  [switch]$Redo,                   # re-extract blocks that already have a body
  [string]$ProbeBlock = '',        # stop right after diagnosing this one block
  [switch]$KeepOpen,               # with -ProbeBlock: leave the block view open for inspection
  [switch]$ExportVarTables,        # also export each FB/FC block's variable table next to its .md
  [switch]$VarTableOnly,           # ONLY do the variable-table export (leaves the .md files alone)
  [switch]$DumpRows,               # dump the whole name index (id / state / known-to-folder.txt) and go on
  [string]$OnlyBlock = '',         # restrict all work to this ONE block name (skip everything else)
  [switch]$FlatLayout,             # mirror root holds 绋嬪簭/FB/FC directly (see the note after param)
  # GVL / 鍙橀噺琛?mode: these nodes are NOT in folder.txt, so they need an explicit name list.
  # Comma-separated node names, and the directory their CSVs are written to.
  [string]$TableNames = '',
  [string]$TableOutDir = '',
  # Context-menu layout of the grid's right-click menu. Measured per VIEW TYPE:
  #   FB/FC view  -> 219x512 popup, '瀵煎嚭(X)' at +100,+430
  #   GVL/鍙橀噺琛?view -> taller popup, different offset (measure with autoshop-menu-probe.ps1)
  [int]$MenuOffsetX = 100,
  [int]$MenuOffsetY = 430,
  [int]$ExpectedMenuH = 512,
  [string]$PopupShot = '',     # on a layout mismatch, PrintWindow the unmeasured popup to this PNG
  [string]$ProgDir = '', [string]$FbDir = '', [string]$FcDir = ''
)
# (see -FlatLayout note below)
$SkipDone = -not $Redo
# -FlatLayout puts the branch folders directly under the mirror root, instead of the older nested
# scheme:
#   flat            : PROG -> <ProgDir>\<folder>\<name>.md    FB -> <FbDir>\<name>\<name>.md
#   nested (default): PROG -> 绋嬪簭\绋嬪簭\...                   FB -> 绋嬪簭\鍔熻兘鍧?FB)\<name>\...
$flat = [bool]$FlatLayout
if ($VarTableOnly) { $ExportVarTables = $true }
# GVL / 鍙橀噺琛?mode. These nodes (Global_閫氱敤, GVL_*, 鍔熻兘鍧楀疄渚? ...) are NOT in folder.txt, so they
# are targeted by an explicit name list and their CSVs go to an explicit directory.
$tableSet = @{}
foreach ($n in ($TableNames -split ',')) { $t = $n.Trim(); if ($t) { $tableSet[$t] = $true } }
$tableMode = ($tableSet.Count -gt 0)
if ($tableMode -and -not $TableOutDir) { throw '-TableNames requires -TableOutDir' }
# layout of the grid right-click menu, read by Export-VarTable (which runs at script scope)
$script:MenuOffsetX = $MenuOffsetX
$script:MenuOffsetY = $MenuOffsetY
$script:MenuH       = $ExpectedMenuH
$script:PopupShot   = $PopupShot

# Mirror folder names, built from char codes so this file stays pure ASCII: 绋嬪簭 / 鍔熻兘鍧?FB) / 鍑芥暟(FC)
$C_PROG = [string][char]0x7A0B + [string][char]0x5E8F
$C_FB   = [string][char]0x529F + [string][char]0x80FD + [string][char]0x5757 + '(' + [string][char]0x46 + [string][char]0x42 + ')'
$C_FC   = [string][char]0x51FD + [string][char]0x6570 + '(' + [string][char]0x46 + [string][char]0x43 + ')'
if (-not $ProgDir) { $ProgDir = $C_PROG }
if (-not $FbDir)   { $FbDir   = $C_FB }
if (-not $FcDir)   { $FcDir   = $C_FC }

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }


if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int hh, uint flags);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="SendMessageW")] public static extern IntPtr SendMessageBuf(IntPtr h, uint msg, IntPtr w, byte[] l);
[DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool GetScrollInfo(IntPtr h, int bar, ref SCROLLINFO si);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
[DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint tid, ref GUITHREADINFO gti);
[StructLayout(LayoutKind.Sequential)] public struct GUITHREADINFO {
  public uint cbSize; public uint flags; public IntPtr hwndActive; public IntPtr hwndFocus;
  public IntPtr hwndCapture; public IntPtr hwndMenuOwner; public IntPtr hwndMoveSize; public IntPtr hwndCaret;
  public RECT rcCaret; }
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
[StructLayout(LayoutKind.Sequential)] public struct SCROLLINFO { public uint cbSize; public uint fMask; public int nMin; public int nMax; public int nPage; public int nPos; public int nTrackPos; }
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
$WM_CLOSE = 0x0010
$SB_HORZ = 0; $SIF_ALL = 0x17

$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000;
         selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
$S_NO     = [string][char]0x5426                          # No
$S_CANCEL = [string][char]0x53D6 + [string][char]0x6D88    # Cancel
$S_YES    = [string][char]0x662F                          # Yes
$S_SAVE   = [string][char]0x4FDD + [string][char]0x5B58    # "save" - marks the save-changes prompt
                                                           # (user-authorized: answer it with YES)
$S_SAVEAS = [string][char]0x53E6 + [string][char]0x5B58 + [string][char]0x4E3A                       # Save As
$S_CONFSA = [string][char]0x786E + [string][char]0x8BA4 + $S_SAVEAS                                 # Confirm Save As
$RD = 0x08; $RU = 0x10
$LD = 0x02; $LU = 0x04
$U8 = New-Object System.Text.UTF8Encoding($false)
$script:DialogsSeen = 0

# Hand the foreground BACK to AutoShop. These scripts force AutoShop to the front in order to click,
# which means that for the duration of a batch the user cannot use the app -- and afterwards the
# terminal/DSH window tends to have the focus again, so the app looks "stuck". Leaving AutoShop in
# front makes the end state usable instead of ambiguous.
function Focus-AutoShop {
  [void][W.U]::ShowWindow($script:MainHwnd, 9)      # SW_RESTORE
  [void][W.U]::SetWindowPos($script:MainHwnd, [IntPtr]::Zero, 0,0,0,0, 0x0003)   # HWND_TOP, NOMOVE|NOSIZE
  [void][W.U]::BringWindowToTop($script:MainHwnd)
  [void][W.U]::SetForegroundWindow($script:MainHwnd)
  Start-Sleep -Milliseconds 300
}

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }
function MainTitle { (Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1).MainWindowTitle }
function ActiveBlock {
  $t = MainTitle
  if ($t -match '-\s*\[([^\]]+)\]\s*$') { return ($Matches[1] -replace '\s*\*$','').Trim() }
  return $null
}
function StateText([int]$s) {
  $f = New-Object System.Collections.ArrayList
  foreach ($k in @('selected','focused','expanded','collapsed','focusable','selectable','invisible','offscreen')) { if ($s -band $ST[$k]) { [void]$f.Add($k) } }
  if ($f.Count) { return ($f -join '+') } else { return '-' }
}

# --- every click is followed by a dialog check -----------------------------------------------
function Get-Dialogs {
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $dlgs
}
function Get-Buttons([IntPtr]$dlg) {
  $kids = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }
    return $true }
  [void][W.U]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $kids
}
function Test-SafeButton([string]$t) {
  if (-not $t) { return $false }
  if ($t.Contains($S_NO)) { return $true }
  if ($t.Contains($S_CANCEL)) { return $true }
  return $false
}
# Dismiss every visible modal dialog, preferring No then Cancel, then ESC as a last resort.
# ESC maps to Cancel in every MFC dialog, so it can never confirm anything either.
function Assert-NoDialog([string]$where = '') {
  $hit = 0
  foreach ($d in (Get-Dialogs)) {
    $title = TxtOf $d
    $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($d, [ref]$r)
    $btns = Get-Buttons $d
    $caps = ($btns | ForEach-Object { TxtOf $_ }) -join '/'
    $pressed = ''
    # 0) SAVE PROMPT FIRST -- and press YES on it (user-authorized, 2026-09-19):
    #    "when a save prompt appears while closing a tab, just confirm it".  Without this the code
    #    below would press No and silently DISCARD a modified table/block.
    #    The prompt is: buttons Yes(&Y)/No(&N)/Cancel + a static containing 'save'.
    #    Pressed through WM_COMMAND with the button's control id -- BM_CLICK does nothing while the
    #    dialog is not active (measured).
    $statTxt = ''
    $cbS = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'Static') { $script:stx += (TxtOf $h) }; return $true }
    $script:stx = ''
    [void][W.U]::EnumChildWindows($d, $cbS, [IntPtr]::Zero)
    $statTxt = $script:stx
    if ($statTxt.Contains($S_SAVE)) {
      foreach ($b in $btns) {
        if ((TxtOf $b).Contains($S_YES)) {
          $bid = [W.U]::GetWindowLong($b, -12)
          [void][W.U]::SendMessageW($d, 0x0111, [IntPtr]$bid, $b)
          $pressed = 'YES (authorized save prompt)'
          break
        }
      }
      if ($pressed) {
        Start-Sleep -Milliseconds 700
        $script:DialogsSeen++
        Write-Output ("   [dialog]{0} '{1}' SAVE PROMPT -> pressed YES{2}" -f `
          $(if ($where) { "($where)" } else { '' }), $title, $(if (@(Get-Dialogs | Where-Object { $_ -eq $d }).Count -gt 0) { '  !!! STILL OPEN' } else { '' }))
        $hit++
        continue
      }
    }
    foreach ($b in $btns) { if ((TxtOf $b).Contains($S_NO))    { $br = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$br); RawClick ([int](($br.Left+$br.Right)/2)) ([int](($br.Top+$br.Bottom)/2)); $pressed = TxtOf $b; break } }
    if (-not $pressed) { foreach ($b in $btns) { if ((TxtOf $b).Contains($S_CANCEL)) { $br = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$br); RawClick ([int](($br.Left+$br.Right)/2)) ([int](($br.Top+$br.Bottom)/2)); $pressed = TxtOf $b; break } } }
    if (-not $pressed) { Send '{ESC}' 400; $pressed = 'ESC' }
    Start-Sleep -Milliseconds 350
    $left = @(Get-Dialogs | Where-Object { $_ -eq $d }).Count
    $script:DialogsSeen++
    Write-Output ("   [dialog]{0} '{1}' {{ {2},{3} {4}x{5} }} buttons=[{6}] -> '{7}'{8}" -f `
      $(if ($where) { "($where)" } else { '' }), $title, $r.Left, $r.Top, ($r.Right-$r.Left), ($r.Bottom-$r.Top), $caps, $pressed, `
      $(if ($left -gt 0) { '  !!! STILL OPEN AFTER DISMISS' } else { '' }))
    $hit++
  }
  return $hit
}
# Raw input primitives -- no dialog logic, so Assert-NoDialog can use them without recursion.
function RawClick([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0)
}
function ClickChecked([int]$x, [int]$y, [string]$what = '') {
  RawClick $x $y
  Start-Sleep -Milliseconds 160
  [void](Assert-NoDialog $what)
}
function DoubleClickChecked([int]$x, [int]$y, [int]$waitMs, [string]$what = '') {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
  [W.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
  [W.U]::mouse_event($LU,0,0,0,0)
  Start-Sleep -Milliseconds $waitMs
  return (Assert-NoDialog $what)      # >0 means a dialog appeared => this row was NOT a block
}

# --- tree / MSAA ------------------------------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$script:MainHwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows($script:MainHwnd, $cb, [IntPtr]::Zero)
$tree = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
if ($null -eq $tree) { throw 'no SysTreeView32 found' }
# The out-object must stay in a plain script-scope variable: returning a __ComObject from a
# function yields a bare Int32 and every accName call then fails.
$iidAcc = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:acc = $null
$hrAcc = [W.U]::AccessibleObjectFromWindow($tree.hwnd, [uint32]4294967292, [ref]$iidAcc, [ref]$script:acc)
if ($hrAcc -ne 0 -or $null -eq $script:acc) { throw ("AccessibleObjectFromWindow failed hr=0x{0:X8}" -f $hrAcc) }
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $tree.hwnd, $tree.rect.Left, $tree.rect.Top, ($tree.rect.Right-$tree.rect.Left), ($tree.rect.Bottom-$tree.rect.Top))
# PORTABILITY (field report from AutoShop V4.12, skill 17.2): on 4.12 the id space starts at 128 and
# accName(1) THROWS (E_INVALIDARG) instead of returning an empty string -- an unguarded probe kills the
# whole run before the sweep even starts. Probe several ids with try/catch, report the first that answers.
$msaaProbe = ''
foreach ($probeId in @(1, 2, 3, 128, 129, 130, 200, 300)) {
  try { $t = [string]$script:acc.accName([int]$probeId); if ($t) { $msaaProbe = ("accName({0})='{1}'" -f $probeId, $t); break } } catch { }
}
Write-Output ("MSAA live: " + $(if ($msaaProbe) { $msaaProbe } else { 'no id in 1..300 answered' }))

# A narrow tree pane puts a HORIZONTAL SCROLLBAR along the bottom of the control, and rows near the
# bottom then have their rect overlapping that scrollbar. Clicking there presses the scrollbar
# instead of the row: the block never opens (observed as "title was ''") and the tree lurches to a
# different scroll position. Measured on the stock 198px pane: content 314px vs viewport 181px.
# Two defences: (a) never click a row whose rect reaches into the scrollbar band, (b) re-select the
# node and re-read its rect right before clicking, so the row is scrolled into view and the rect is
# fresh rather than cached.
function Get-HScrollOverflow {
  $si = New-Object W.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = $SIF_ALL
  if (-not [W.U]::GetScrollInfo($tree.hwnd, $SB_HORZ, [ref]$si)) { return 0 }
  return [Math]::Max(0, ($si.nMax - $si.nMin + 1) - [int]$si.nPage)
}
$hOverflow = Get-HScrollOverflow
if ($hOverflow -gt 0) {
  Write-Output ("WARNING: the tree pane is too narrow -- horizontal overflow {0}px." -f $hOverflow)
  Write-Output ("  Long names are clipped and a horizontal scrollbar sits at the bottom. The bottom")
  Write-Output ("  {0}px of the tree will be treated as a no-click zone." -f 20)
  Write-Output ("  To fix it for real, widen the pane: autoshop-pane-check.ps1 -ProjectDir <dir> -Widen -WidenPx 150")
} else {
  Write-Output 'tree pane width OK (no horizontal overflow).'
}
$clickableBottom = $tree.rect.Bottom - $(if ($hOverflow -gt 0) { 20 } else { 4 })

function Read-Sel {
  $id = $null
  try { $id = $script:acc.accSelection } catch { }
  $o = [pscustomobject]@{ Id=$null; Name=''; State=-1; Fold=''; X=0; Y=0; W=0; H=0 }
  if ($null -eq $id -or $id -isnot [int]) { return $o }
  try { $o.Name  = [string]$script:acc.accName([int]$id) } catch { }
  try { $o.State = [int]$script:acc.accState([int]$id) } catch { }
  # accLocation needs [ref] on PLAIN VARIABLES. Taking [ref] of a pscustomobject property is
  # rejected by PowerShell and the try/catch swallows it, leaving every rect 0,0,0,0 -- which
  # silently looks like "every node is off screen".
  $x = 0; $y = 0; $w = 0; $h = 0
  try { $script:acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$id) } catch { }
  $o.X = $x; $o.Y = $y; $o.W = $w; $o.H = $h
  $o.Id = [int]$id
  $o.Fold = StateText $o.State
  return $o
}

# Read the block body from the MDI child NAMED after the block, via UIA + Scintilla.
# Clicking the editor is NOT an option: all MDI children share one rectangle, so clicking activates
# whichever is on top and silently copies the wrong block.
try { Add-Type -AssemblyName UIAutomationClient -ErrorAction Stop; Add-Type -AssemblyName UIAutomationTypes -ErrorAction Stop; $script:UiaOk = $true }
catch { $script:UiaOk = $false; Write-Output 'WARNING: UIA not available - cannot read block text' }

# Decode what a Scintilla control hands back.
# Verified quirk: the UIA provider returns the document's raw BYTES reinterpreted as UTF-16 code
# units (little-endian pairs), so "//" arrives as U+2F2F and a Chinese character as two chars whose
# codes are both <= 0xFF. Repair = split each char into its 2 bytes and decode the byte run as UTF-8.
# Decoding as GBK instead yields the classic double mojibake.
# Discriminator (needed because some channels return already-correct text):
#   * any char > 0xFF              => already proper UTF-16 text, use as-is
#   * repaired bytes contain 0x00  => it was proper text all along, use as-is
$script:Utf8Strict = New-Object System.Text.UTF8Encoding($false, $true)
function Decode-ScintillaText([string]$t) {
  if ([string]::IsNullOrEmpty($t)) { return $t }
  foreach ($ch in $t.ToCharArray()) { if ([int]$ch -gt 0xFF) { return $t } }
  $bytes = New-Object byte[] ($t.Length * 2)
  for ($i = 0; $i -lt $t.Length; $i++) {
    $u = [int][char]$t[$i]
    $bytes[2*$i] = [byte]($u -band 0xFF)
    $bytes[2*$i+1] = [byte](($u -shr 8) -band 0xFF)
  }
  if ($bytes -contains [byte]0) { return $t }
  try { return $script:Utf8Strict.GetString($bytes).TrimEnd([char]0) }
  catch {
    # not valid UTF-8 -> probably an ANSI/GBK document; fall back to the system code page
    try { return [System.Text.Encoding]::GetEncoding(936).GetString($bytes).TrimEnd([char]0) } catch { return $t }
  }
}

# --- Win32 channel: WM_GETTEXT straight into the Scintilla window ----------------------------
# Independent of UIA. Needed because some blocks' Scintilla refuses ValuePattern (observed:
# SBR_001 and INT_001 report valueLen=-1 while MAIN and SBR_002 answer normally).
function Find-MdiChildByTitle([string]$title) {
  $mdi = [IntPtr]::Zero
  $script:mdiTmp = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'MDIClient') { $script:mdiTmp = $h }; return $true }
  [void][W.U]::EnumChildWindows($script:MainHwnd, $cb, [IntPtr]::Zero)
  $mdi = $script:mdiTmp
  if ($null -eq $mdi -or $mdi -eq [IntPtr]::Zero) { return [IntPtr]::Zero }
  $hit = [IntPtr]::Zero
  # EnumChildWindows walks the whole descendant tree, so the title test doubles as a recursive search
  $script:titleTmp = [IntPtr]::Zero
  $cb2 = [W.U+EnumProc]{ param($h,$p)
    $t = TxtOf $h
    if ($t -eq $title -or $t -eq "$title *") { $script:titleTmp = $h; return $false }
    return $true }
  [void][W.U]::EnumChildWindows($mdi, $cb2, [IntPtr]::Zero)
  $hit = $script:titleTmp
  if ($null -eq $hit) { return [IntPtr]::Zero }
  return $hit
}

# Close one block view and PROVE it closed.
# Ctrl+F4 alone is not enough: it is delivered to whatever window owns the keyboard, and in practice
# it silently did nothing here -- 16 block views piled up during one run (each run's pre-flight
# cleanup had been hiding it). WM_CLOSE goes straight to the MDI child, needs no focus, and is
# verified by re-testing for the window instead of assuming.
function Close-BlockView([string]$block) {
  for ($attempt = 1; $attempt -le 3; $attempt++) {
    $mc = Find-MdiChildByTitle $block
    if ($mc -eq [IntPtr]::Zero) { return $true }
    [void][W.U]::SendMessageW($mc, $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 320
    [void](Assert-NoDialog ("close '" + $block + "'"))
    for ($i = 0; $i -lt 8; $i++) {
      if ((Find-MdiChildByTitle $block) -eq [IntPtr]::Zero) { return $true }
      Start-Sleep -Milliseconds 150
    }
    Write-Output ("   [close] WM_CLOSE attempt {0} did not close '{1}'" -f $attempt, $block)
    Send '^{F4}' 350
    [void](Assert-NoDialog ("close fallback '" + $block + "'"))
  }
  return $false
}
function Find-DescendantByClass([IntPtr]$root, [string]$cls) {
  $script:clsTmp = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq $cls) { $script:clsTmp = $h; return $false }; return $true }
  [void][W.U]::EnumChildWindows($root, $cb, [IntPtr]::Zero)
  return $script:clsTmp
}
function Read-TextWin32([string]$block) {
  try {
    $mc = Find-MdiChildByTitle $block
    if ($mc -eq [IntPtr]::Zero) { return $null }
    $sc = Find-DescendantByClass $mc 'Scintilla'
    if ($sc -eq [IntPtr]::Zero) { return $null }
    $n = [int][W.U]::SendMessageW($sc, 0x000E, [IntPtr]::Zero, [IntPtr]::Zero)   # WM_GETTEXTLENGTH
    if ($n -le 0) { return '' }
    $cap = [Math]::Min($n + 4, 8*1024*1024)
    $buf = New-Object byte[] $cap
    [void][W.U]::SendMessageBuf($sc, 0x000D, [IntPtr]$cap, $buf)                  # WM_GETTEXT
    # Scintilla is a UTF-8 document: decode the bytes as UTF-8 (fall back to the code page)
    try { return $script:Utf8Strict.GetString($buf, 0, [Math]::Min($n, $cap)).TrimEnd([char]0) }
    catch { try { return [System.Text.Encoding]::GetEncoding(936).GetString($buf, 0, [Math]::Min($n,$cap)).TrimEnd([char]0) } catch { return $null } }
  } catch { return $null }
}

function RClickRaw([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($RD,0,0,0,0); Start-Sleep -Milliseconds 80
  [W.U]::mouse_event($RU,0,0,0,0) }
function TopWindows {
  $l = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ([W.U]::IsWindowVisible($h)) {
      $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
      [void]$l.Add([pscustomobject]@{ Hwnd=$h; Cls=(ClsOf $h); X=$r.Left; Y=$r.Top; W=($r.Right-$r.Left); H=($r.Bottom-$r.Top); Text=(TxtOf $h) }) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $l }
function PressButton([IntPtr]$btn) {
  $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($btn, [ref]$r)
  RawClick ([int](($r.Left+$r.Right)/2)) ([int](($r.Top+$r.Bottom)/2))
  Start-Sleep -Milliseconds 500 }
# No > Cancel > ESC. Never Yes/OK (the one documented exception lives inside Export-VarTable).
# PrintWindow draws a window into a memory DC WITHOUT activating it, so it captures an open popup
# menu without the capture itself closing the menu (a screen grab would).
function Save-WindowPng([IntPtr]$hwnd, [int]$w, [int]$h, [string]$path) {
  try {
    Add-Type -AssemblyName System.Drawing
    $hdcScreen = [W.U]::GetDC([IntPtr]::Zero)
    $hdcMem = [W.U]::CreateCompatibleDC($hdcScreen)
    $hBmp = [W.U]::CreateCompatibleBitmap($hdcScreen, $w, $h)
    $hOld = [W.U]::SelectObject($hdcMem, $hBmp)
    $ok = [W.U]::PrintWindow($hwnd, $hdcMem, 2)      # PW_RENDERFULLCONTENT
    if (-not $ok) { $ok = [W.U]::PrintWindow($hwnd, $hdcMem, 0) }
    $img = [System.Drawing.Image]::FromHbitmap($hBmp)
    $img.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $img.Dispose()
    [void][W.U]::SelectObject($hdcMem, $hOld)
    [void][W.U]::DeleteObject($hBmp); [void][W.U]::DeleteDC($hdcMem); [void][W.U]::ReleaseDC([IntPtr]::Zero, $hdcScreen)
    Write-Host ("   [var] popup captured to {0} ({1} bytes)" -f $path, (Get-Item -LiteralPath $path).Length)
    return $ok
  } catch { Write-Host ("   [var] capture failed: {0}" -f $_.Exception.Message); return $false }
}

function DismissSafe([IntPtr]$dlg) {  foreach ($b in (Get-Buttons $dlg)) {
    $t = TxtOf $b
    if ($t.Contains($S_NO) -or $t.Contains($S_CANCEL)) { PressButton $b; return $true } }
  Send '{ESC}' 450
  return $true }
function CleanupAllDialogs {
  $n = 0
  for ($i = 0; $i -lt 8; $i++) {
    $d = Get-Dialogs
    if ($d.Count -eq 0) { break }
    foreach ($x in $d) { [void](DismissSafe $x); $n++ }
    Start-Sleep -Milliseconds 500 }
  return $n }

# --- export one block's VARIABLE TABLE to CSV -------------------------------------------------
# Requires the block view to be OPEN (the caller opens it). Verified end to end on FB01_鎬荤嚎杞存帶鍒?
#
# Why the context menu: the variable table (a VSFlexGrid) has no export button anywhere in UIA.
# Why the fixed offset: the popup is an MFC toolbar-style menu (class 'Afx:...', NOT '#32768'), so
#   UIA exposes no MenuItems, and its mnemonic key does not reach it either (both were tried on the
#   real UI and both failed). Its item list is constant, so the '瀵煎嚭(X)' row sits at a fixed offset
#   inside it -- and the popup HEIGHT is checked first so a layout change can never be mis-clicked.
# Why the path is pasted: the '鍙﹀瓨涓? dialog's height varies (600 vs 209 px), but its filename Edit
#   already holds the focus, so paste + Enter works regardless of geometry.
#
# The ONLY place this project presses a confirming button: the Windows overwrite prompt
# '纭鍙﹀瓨涓?, recognised by its EXACT caption AND the presence of BOTH 鏄?&Y) and 鍚?&N).
# Replacing our own placeholder CSV is the intent; nothing else can ever be confirmed.
function Export-VarTable([string]$block, [string]$csvPath) {
  $mc = Find-MdiChildByTitle $block
  if ($mc -eq [IntPtr]::Zero) { Write-Host ("   [var] no open view for '{0}'" -f $block); return $false }
  $grids = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -like 'VSFlexGrid*' -and [W.U]::IsWindowVisible($h)) {
      $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
      if (($r.Right-$r.Left) -gt 50) { [void]$grids.Add([pscustomobject]@{ Hwnd=$h; R=$r }) } }
    return $true }
  [void][W.U]::EnumChildWindows($mc, $cb, [IntPtr]::Zero)
  if ($grids.Count -eq 0) { Write-Host ("   [var] no visible variable-table grid in '{0}'" -f $block); return $false }
  $g = $grids[0]
  $gx = [int](($g.R.Left + $g.R.Right) / 2)
  $gy = $g.R.Top + 60
  if ($gy -gt ($g.R.Bottom - 10)) { $gy = [int](($g.R.Top + $g.R.Bottom) / 2) }

  $before = TopWindows
  $beforeIds = @($before | ForEach-Object { $_.Hwnd })
  RawClick $gx $gy                     # warm-up: the first click can be consumed by activation
  Start-Sleep -Milliseconds 350
  [void](Assert-NoDialog 'warm-up click')
  RClickRaw $gx $gy
  Start-Sleep -Milliseconds 1300
  $popup = @((TopWindows) | Where-Object { $beforeIds -notcontains $_.Hwnd })
  if ($popup.Count -eq 0) { Write-Host ("   [var] no context menu appeared over the grid of '{0}'" -f $block); return $false }
  $p = $popup[0]
  Write-Host ("   [var] grid={0},{1} {2}x{3}   popup {4}x{5} at {6},{7}" -f $g.R.Left, $g.R.Top, ($g.R.Right-$g.R.Left), ($g.R.Bottom-$g.R.Top), $p.W, $p.H, $p.X, $p.Y)
  # The popup's item list depends on the VIEW: an FB/FC view gives a 512px menu, a 鍙橀噺琛?(GVL) view a
  # 632px one, so '瀵煎嚭(X)' sits at a different vertical offset. Measure it with
  # autoshop-menu-probe.ps1 -CaptureOut and pass -MenuOffsetY / -ExpectedMenuH.
  if ([Math]::Abs($p.H - $script:MenuH) -gt 60) {
    # Capture the unmeasured menu BEFORE dismissing it, so measuring the real layout becomes one
    # read of a PNG instead of another round of guessing.
    if ($script:PopupShot) { [void](Save-WindowPng $p.Hwnd $p.W $p.H $script:PopupShot) }
    Send '{ESC}' 400
    Write-Host ("   [var] popup height {0}px != expected {1} - refused to guess the row. Read the capture, then pass -MenuOffsetY/-ExpectedMenuH." -f $p.H, $script:MenuH)
    return $false
  }
  # PORTABILITY: MenuOffsetY was measured at $script:MenuH px on a 100% / 30px-toolbar machine. Scale it
  # by the ACTUALLY measured popup height so another DPI / font size / screen still hits the same ROW.
  # (The height tolerance above already refused the popup if its structure differs.)
  $menuScale = 1.0
  if ($script:MenuH -gt 0) { $menuScale = $p.H / [double]$script:MenuH }
  $dy = [int][Math]::Round($script:MenuOffsetY * $menuScale)
  Write-Host ("   [var] clicking the export row at offset +{0},+{1} inside the popup  [scale {2:N3} = {3}/{4}]" -f $script:MenuOffsetX, $dy, $menuScale, $p.H, $script:MenuH)
  RawClick ($p.X + $script:MenuOffsetX) ($p.Y + $dy)   # the export row
  Start-Sleep -Milliseconds 1600

  $dlg = [IntPtr]::Zero
  foreach ($d in (Get-Dialogs)) { if ((TxtOf $d) -eq $S_SAVEAS) { $dlg = $d; break } }
  if ($dlg -eq [IntPtr]::Zero) {
    $titles = ((Get-Dialogs) | ForEach-Object { TxtOf $_ }) -join '/'
    [void](CleanupAllDialogs)
    Write-Host ("   [var] expected the save-as dialog, got [{0}] - wrong menu row was hit" -f $titles)
    return $false
  }
  Write-Host ("   [var] grid hwnd={0} rect={{ {1},{2} {3}x{4} }}; popup {5}x{6} at {7},{8}; save-as dialog up" -f `
    $g.Hwnd, $g.R.Left, $g.R.Top, ($g.R.Right-$g.R.Left), ($g.R.Bottom-$g.R.Top), $p.W, $p.H, $p.X, $p.Y)

  # The paste only lands in the right place if the dialog's filename Edit owns the focus. FB/FC
  # views satisfy this; other views might not, and then nothing is written -- so CHECK it and say so.
  $tid = [W.U]::GetWindowThreadProcessId($dlg, [IntPtr]::Zero)
  $gti = New-Object W.U+GUITHREADINFO
  $gti.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($gti)
  [void][W.U]::GetGUIThreadInfo($tid, [ref]$gti)
  $focusCls = if ($gti.hwndFocus -ne [IntPtr]::Zero) { ClsOf $gti.hwndFocus } else { '(none)' }
  Write-Host ("   [var] focused control class = '{0}'" -f $focusCls)
  if ($focusCls -ne 'Edit') {
    Write-Host ("   [var] WARNING: the filename Edit does NOT have focus - the paste may go elsewhere")
  }

  $set = $false
  $ErrorActionPreference = 'Continue'
  for ($i = 0; $i -lt 6 -and -not $set; $i++) {
    try { [System.Windows.Forms.Clipboard]::SetText($csvPath); $set = $true } catch { Start-Sleep -Milliseconds 250 } }
  $ErrorActionPreference = 'Stop'
  if (-not $set) { [void](CleanupAllDialogs); Write-Host '   [var] could not set the clipboard'; return $false }
  Send '^a' 220
  Send '^v' 450
  Send '{ENTER}' 200
  Start-Sleep -Milliseconds 1600

  $replaced = $false
  for ($round = 0; $round -lt 6; $round++) {
    $open = Get-Dialogs
    if ($open.Count -eq 0) { break }
    foreach ($d in $open) {
      $t = TxtOf $d
      $btns = Get-Buttons $d
      $caps = @($btns | ForEach-Object { TxtOf $_ })
      $hasYes = @($caps | Where-Object { $_.Contains($S_YES) }).Count -gt 0
      $hasNo  = @($caps | Where-Object { $_.Contains($S_NO) }).Count -gt 0
      if ($t -eq $S_CONFSA -and $hasYes -and $hasNo) {
        $yes = $btns | Where-Object { (TxtOf $_).Contains($S_YES) } | Select-Object -First 1
        Write-Host ("   [var] overwrite prompt ('{0}') -> pressing Yes (the documented exception)" -f $t)
        PressButton $yes
        $replaced = $true
      } else { [void](DismissSafe $d) }
    }
    Start-Sleep -Milliseconds 700
  }
  $left = (Get-Dialogs).Count
  if ($left -gt 0) { Write-Host ("   [var] {0} dialog(s) still open after the export" -f $left) }
  # VERIFY ON DISK. The flow reaching the end does NOT mean a file was written: with the 鍙橀噺琛?nodes
  # the whole dialog sequence completed yet nothing appeared on disk. Never trust the flow's own
  # success -- check the file.
  $ok = $false
  if (Test-Path -LiteralPath $csvPath) {
    $sz = (Get-Item -LiteralPath $csvPath).Length
    $ok = ($sz -gt 0)
    Write-Host ("   [var] result file: {0} bytes" -f $sz)
  } else {
    Write-Host ("   [var] NO FILE was written to '{0}'" -f $csvPath)
  }
  return $ok
}

function Read-BlockText([string]$block) {
  # 1) UIA: the MDI child NAMED after the block, then its Scintilla descendant
  if ($script:UiaOk) {
    try {
      $AE = [System.Windows.Automation.AutomationElement]
      $root = $AE::FromHandle($script:MainHwnd)
      $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
        (New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, $block)))
      if ($null -eq $child) {
        $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
          (New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, "$block *")))
      }
      if ($null -ne $child) {
        $edit = $child.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
          (New-Object System.Windows.Automation.PropertyCondition($AE::ClassNameProperty, 'Scintilla')))
        if ($null -ne $edit) {
          $vp = $null
          if ($edit.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp)) {
            $v = ([System.Windows.Automation.ValuePattern]$vp).Current.Value
            if ($v -and $v.Length -gt 0) { return (Decode-ScintillaText $v) }
          }
          # ValuePattern unsupported -> TextPattern (whole document)
          $tp = $null
          if ($edit.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$tp)) {
            $v = ([System.Windows.Automation.TextPattern]$tp).DocumentRange.GetText(-1)
            if ($v -and $v.Length -gt 0) { return (Decode-ScintillaText $v) }
          }
          # ... then LegacyIAccessible
          $lp = $null
          if ($edit.TryGetCurrentPattern([System.Windows.Automation.LegacyIAccessiblePattern]::Pattern, [ref]$lp)) {
            $v = ([System.Windows.Automation.LegacyIAccessiblePattern]$lp).Current.Value
            if ($v -and $v.Length -gt 0) { return (Decode-ScintillaText $v) }
          }
          $v = $edit.Current.Name
          if ($v -and $v.Length -gt 0) { return (Decode-ScintillaText $v) }
        }
      }
    } catch { }
  }
  # 2) Win32 WM_GETTEXT fallback
  return (Read-TextWin32 $block)
}

# --- stale block windows ---------------------------------------------------------------------
# A previous run that was killed mid-sweep leaves MDI children open. At ~34 open windows AutoShop
# pops "open window count exceeded" and the whole UI goes disabled -- after which every click and
# keypress is silently swallowed and the sweep quietly produces garbage. So start from a clean slate.
# Closing is done with WM_CLOSE; if AutoShop asks anything, No/Cancel is pressed, never Yes.
function Close-StaleWindows {
  $mdi = [IntPtr]::Zero
  $cb = [W.U+EnumProc]{ param($h,$p) if ((ClsOf $h) -eq 'MDIClient') { $script:mdiTmp = $h }; return $true }
  [void][W.U]::EnumChildWindows($script:MainHwnd, $cb, [IntPtr]::Zero)
  $mdi = $script:mdiTmp
  if ($mdi -eq [IntPtr]::Zero) { return 0 }
  $closed = 0
  for ($i = 0; $i -lt 80; $i++) {
    # Initialise the holders first: when no visible child exists the callback never runs, and an
    # unset variable arrives as $null which the IntPtr parameters then reject.
    $script:kidTmp = [IntPtr]::Zero
    $kid = [IntPtr]::Zero
    $cb2 = [W.U+EnumProc]{ param($h,$p) if ([W.U]::IsWindowVisible($h)) { $script:kidTmp = $h; return $false }; return $true }
    [void][W.U]::EnumChildWindows($mdi, $cb2, [IntPtr]::Zero)
    $kid = $script:kidTmp
    if ($null -eq $kid -or $kid -eq [IntPtr]::Zero) { break }
    Write-Output ("  [stale] closing '{0}'" -f (TxtOf $kid))
    [void][W.U]::SendMessageW($kid, $WM_CLOSE, [IntPtr]::Zero, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 320
    [void](Assert-NoDialog 'closing stale window')
    $closed++
  }
  return $closed
}

# --- (removed) the walk helpers ---------------------------------------------------------------
# Focus-Tree / Go-TreeTop / Ensure-TreeFocus used to click a row, climb the tree with UP/DOWN and
# repair focus drift between blocks. All three are obsolete now that nodes are addressed by name:
# accSelect(3,id) both selects and scrolls, and Ctrl+O opens the block, so there is no walk
# position to protect and no coordinate to fall back on. 2026-09-19.
# The old UP-climb also encoded a hard-won lesson worth keeping in words: Ctrl+Home is a NO-OP in
# this tree (measured: sent at id=2 the selection stayed at id=2), and a single read right after a
# keypress can be stale -- but none of that matters now, because nothing is found by stepping.

# Dump what UIA actually exposes inside a block's MDI child. Used when a block opens (title
# verified) but no text could be read -- tells apart "the view has no Scintilla at all" from
# "Scintilla exists but the document is empty" from "the MDI child name did not match".
function Diagnose-Block([string]$block) {
  if (-not $script:UiaOk) { Write-Output '   [diag] UIA unavailable'; return }
  try {
    $AE = [System.Windows.Automation.AutomationElement]
    $root = $AE::FromHandle($script:MainHwnd)
    $cond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Window)
    $wins = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    Write-Output ("   [diag] MDI children visible to UIA: {0}" -f $wins.Count)
    foreach ($w in $wins) { Write-Output ("   [diag]   window '{0}'" -f $w.Current.Name) }
    $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
      (New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, $block)))
    if ($null -eq $child) {
      $child = $root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,
        (New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, "$block *")))
    }
    if ($null -eq $child) { Write-Output ("   [diag] no MDI child named '{0}' - title and UIA disagree" -f $block); return }
    Write-Output ("   [diag] matched MDI child '{0}'" -f $child.Current.Name)
    $all = $child.FindAll([System.Windows.Automation.TreeScope]::Descendants,
      [System.Windows.Automation.Condition]::TrueCondition)
    Write-Output ("   [diag] descendants: {0}" -f $all.Count)
    foreach ($e in $all) {
      $vp = $null; $len = -1; $head = ''
      if ($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$vp)) {
        $v = ([System.Windows.Automation.ValuePattern]$vp).Current.Value
        $len = $v.Length
        if ($len -gt 0) {
          $b = New-Object byte[] ($v.Length * 2)
          for ($i = 0; $i -lt $v.Length; $i++) { $u = [int][char]$v[$i]; $b[2*$i] = [byte]($u -band 0xFF); $b[2*$i+1] = [byte](($u -shr 8) -band 0xFF) }
          $dec = [System.Text.Encoding]::UTF8.GetString($b)
          $head = ($dec -split "`n")[0]
          if ($head.Length -gt 50) { $head = $head.Substring(0,50) }
        }
      }
      Write-Output ("   [diag]   {0,-22} class='{1}' valueLen={2} name='{3}'  first='{4}'" -f `
        $e.Current.ControlType.ProgrammaticName, $e.Current.ClassName, $len, $e.Current.Name, $head)
    }
  } catch { Write-Output ("   [diag] failed: {0}" -f $_.Exception.Message) }
}

# --- (removed) Ensure-TreeFocus ---------------------------------------------------------------
# It existed to put the keyboard back on the right tree row after a block view stole the focus, and
# to repair "DRIFT" when a re-anchor landed on the wrong node. With name addressing the next target
# is selected from the index anyway, so drift cannot derail anything. 2026-09-19.

# After a double-click the caption takes a moment to change, and a single double-click can be
# eaten. Poll for the expected title instead of sampling once -- sampling once produced a false
# MISMATCH in a real run (the title still named the block that had just been closed).
function Wait-ActiveBlock([string]$want, [int]$timeoutMs) {
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $t = ActiveBlock
  while ($sw.ElapsedMilliseconds -lt $timeoutMs) {
    if ($t -eq $want) { return $t }
    Start-Sleep -Milliseconds 150
    $t = ActiveBlock
  }
  return $t
}

# --- open a node: context menu with a PER-HEIGHT item offset, else a verified double-click ----
# 鈽?Ctrl+O IS BANNED HERE. Measured 2026-09-19: when the TREE does not hold the keyboard focus the
#   accelerator is handled by the MAIN FRAME instead, AutoShop pops one of its own dialogs, and
#   because this open path had no dialog check the run then failed block after block while the user
#   had to cancel that box over and over. A node context menu is raised ON the selection, so it
#   cannot land in the main frame.
# 鈽?'OPEN' IS NOT THE FIRST ITEM FOR EVERY NODE TYPE (measured):
#     program node 178x272 -> 鎵撳紑 is item 1 (+18)
#     FB node      122x246 -> 鎵撳紑 is item 1 (+18)
#     FC node      122x220 -> 鎵撳紑 is item 1 (+18)
#     鍙橀噺琛?GVL    153x168 -> 鏂板缓鍏ㄥ眬鍙橀噺琛?/ 鍒犻櫎 / **鎵撳紑 is item 3 (+70)** / 閲嶅懡鍚?/ 澶嶅埗 / 绮樿创
#   So the offset is looked up BY MENU HEIGHT and an unknown height is refused.
# 鈽?Fallback: a double-click on the row, with the row hit-tested first (accHitTest) so a wrong row
#   can never be clicked. This is what covers any menu we have not measured yet.
function HitName([int]$x, [int]$y) {
  $hit = $null
  try { $hit = $script:acc.accHitTest($x, $y) } catch { return '' }
  if ($null -eq $hit) { return '' }
  if ($hit -is [int]) { try { return [string]$script:acc.accName([int]$hit) } catch { return '' } }
  try { return [string]$hit.accName(0) } catch { return '' }
}
function Open-NodeByName([string]$name, [int]$timeoutMs) {
  # NB: every diagnostic inside this function MUST be Write-Host. Write-Output would be captured as
  # part of the return value and the caller would receive an array (that bug turned the caption into
  # the literal string 'System.Object[]' and failed 95 blocks in a row).
  # 2026-09-20 (user): open a node by DOUBLE-CLICKING it -- do not go through the context menu.
  # The old path pressed Shift+F10, guessed the "打开" item offset from the popup height
  # (168->70 / 220,246,272->18) and bailed out on any unmeasured height, which produced the
  # noisy "[open] unknown node menu 105x142" / "Shift+F10 raised no node menu" lines and, on
  # struct nodes (105x142), fell through to this very fallback anyway. Double-click is what the
  # user does by hand and it is the path that has always worked.
  $jm = Join-Path $PSScriptRoot 'autoshop-jump.ps1'
  for ($a = 1; $a -le 3; $a++) {
    [void](Assert-NoDialog 'before opening a node')
    $fg = [IntPtr]::Zero
    for ($ft = 1; $ft -le 4; $ft++) {
      [void][W.U]::SetForegroundWindow($script:MainHwnd)
      Start-Sleep -Milliseconds 200
      $fg = [W.U]::GetForegroundWindow()
      if ($fg -eq $script:MainHwnd) { break }
    }
    if ($fg -ne $script:MainHwnd) { Write-Host '  WARNING: AutoShop is not the foreground window - keys may be delivered elsewhere' }
    # --- FAST PATH: open in-process (no nested powershell, no 187-row scan) ----------------------
    # accSelect SCROLLS the row into view, so the rect read immediately after is FRESH -- the
    # "stale y" trap only bites rows that were never realized. Always verify with accHitTest first.
    $opened = ''
    $entry = $null
    try { $entry = Resolve-TargetNode $name } catch { }
    if ($null -eq $entry -and $index.ContainsKey($name)) { $entry = [pscustomobject]@{ Id = [int]$index[$name][0].Id; X = -1; Row = -1 } }
    if ($null -ne $entry) {
      # PORTABILITY/UX FIX (2026-09-20, measured): accSelect only scrolls the row into view when the TREE
      # has the focus. Without focus the rect comes back unrealized (measured y=-1762), the hit-test fails
      # and we fell back to autoshop-jump.ps1 -- which PAGES THROUGH THE TREE (nPos 141 -> 25) and that is
      # exactly the left-pane scrolling the user complained about (skill 11.25). Grab the focus first, and
      # if the row still is not realized, scroll to the estimated display row before giving up.
      $tr = $tree.rect
      $fx = $tr.Left + 20
      $fy = $tr.Top + [int](($tr.Bottom - $tr.Top) / 2)
      [void][W.U]::SetCursorPos($fx, $fy); Start-Sleep -Milliseconds 110
      [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40; [W.U]::mouse_event($LU,0,0,0,0)
      Start-Sleep -Milliseconds 260
      try { [void]$script:acc.accSelect(3, [int]$entry.Id) } catch { }
      Start-Sleep -Milliseconds 240
      $x = 0; $y = 0; $w = 0; $h = 0
      try { $script:acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$entry.Id) } catch { }
      if ($h -le 0 -or $y -lt $tr.Top -or $y -gt $tr.Bottom) {
        # still unrealized -> estimate the display row (nPos + (y - treeTop)/20) and scroll to it
        $si = New-Object W.U+SCROLLINFO
        $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
        $si.fMask = $SIF_ALL
        $npos = 0
        if ([W.U]::GetScrollInfo($tree.hwnd, 1, [ref]$si)) { $npos = [int]$si.nPos }   # 1 = SB_VERT
        $est = $npos + [int](($y - $tr.Top) / 20)
        if ($est -lt 0) { $est = 0 }
        Write-Host ("   [open] row not realized (y={0}) - scrolling to the estimated row {1}" -f $y, $est)
        for ($g = 1; $g -le 40; $g++) {
          $si2 = New-Object W.U+SCROLLINFO
          $si2.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si2)
          $si2.fMask = $SIF_ALL
          $n2 = 0
          if ([W.U]::GetScrollInfo($tree.hwnd, 1, [ref]$si2)) { $n2 = [int]$si2.nPos }
          if ([Math]::Abs($n2 - $est) -le 1) { break }
          $cmd = if ($n2 -gt $est) { 0 } else { 1 }        # SB_LINEUP / SB_LINEDOWN
          [void][W.U]::SendMessageW($tree.hwnd, 0x0115, [IntPtr]$cmd, [IntPtr]::Zero)
          Start-Sleep -Milliseconds 40
        }
        try { [void]$script:acc.accSelect(3, [int]$entry.Id) } catch { }
        Start-Sleep -Milliseconds 240
        try { $script:acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, [int]$entry.Id) } catch { }
      }
      if ($h -gt 0) {
        $cx = $x + 40; $cy = $y + [int]($h / 2)
        $hit = HitName $cx $cy
        if ($hit -eq $name) {
          Write-Host ("   [open] double-clicking '{0}' at {1},{2} (in-process, hit-test OK)" -f $name, $cx, $cy)
          RawClick $cx $cy; Start-Sleep -Milliseconds 110; RawClick $cx $cy
          Start-Sleep -Milliseconds 400
          [void](Assert-NoDialog 'after double-clicking a node')
          $opened = Wait-ActiveBlock $name $timeoutMs
          if ($opened -eq $name) { return $opened }
          Write-Host ("   [open] in-process double-click done but the title is '{0}'" -f $opened)
        } else {
          Write-Host ("   [open] hit-test at {0},{1} says '{2}' (not '{3}') - will fall back to the jump tool" -f $cx, $cy, $hit, $name)
        }
      }
    }
    # --- FALLBACK: the (slower) jump tool -- scans rows and scrolls precisely ---------------------
    if (Test-Path -LiteralPath $jm) {
      Write-Host ("   [open] handing over to autoshop-jump.ps1 -Node '{0}' -DoubleClick" -f $name)
      $jout = & powershell -STA -NoProfile -ExecutionPolicy Bypass -File $jm -Node $name -DoubleClick 2>&1
      foreach ($ln in $jout) { Write-Host ("   [jump] {0}" -f $ln) }
      $opened = Wait-ActiveBlock $name $timeoutMs
      if ($opened -eq $name) { return $opened }
      Write-Host ("   [open] the jump tool ran but the title is '{0}' (attempt {1}/3)" -f $opened, $a)
    } else {
      Write-Host '   [open] autoshop-jump.ps1 not found next to this script - cannot fall back'
      break
    }
    Start-Sleep -Milliseconds 200
  }
  return (ActiveBlock)
}

# --- expected blocks from folder.txt (order == tree order) -----------------------------------
# PORTABILITY (field report, skill 17.3): a BRAND-NEW project has NO folder.txt at all (it appears only
# after specific structure changes), and this line used to be an unconditional ReadAllLines -> the whole
# run died with FileNotFoundException before anything could be done. Tolerate it: warn, use an empty list,
# and let -TableNames / -OnlyBlock carry the run. A stub directory can also be passed as -ProjectDir.
$folderTxt = Join-Path $ProjectDir 'folder.txt'
if (Test-Path -LiteralPath $folderTxt) {
  $lines = [System.IO.File]::ReadAllLines($folderTxt, [System.Text.Encoding]::UTF8)
} else {
  $lines = @()
  Write-Host ("   [skeleton] no folder.txt in '{0}' - continuing with an EMPTY block list; pass -TableNames / -OnlyBlock (or a stub dir) to give this run targets" -f $ProjectDir)
}
$map = @{}; $order = New-Object System.Collections.ArrayList; $folders = @{}
$section = $null; $stack = @{}
foreach ($raw in $lines) {
  if ([string]::IsNullOrWhiteSpace($raw)) { continue }
  $tabs = 0; while ($tabs -lt $raw.Length -and $raw[$tabs] -eq "`t") { $tabs++ }
  $body = $raw.Substring($tabs).Trim(); if ($body -eq '') { continue }
  if ($body -eq 'PROG' -or $body -eq 'FB' -or $body -eq 'FC') { $section = $body; $stack = @{0=''}; continue }
  if ($body -eq 'ROOT') { continue }
  if ($null -eq $section) { continue }
  if ($body -like 'FOLDER*') {
    $parent = ''; for ($d=1; $d -lt $tabs; $d++) { if ($stack.ContainsKey($d) -and $stack[$d]) { $parent = if ($parent) { Join-Path $parent $stack[$d] } else { $stack[$d] } } }
    $stack[$tabs] = $body.Substring(6).Trim(); $stack[$tabs+1] = ''
    $stack["rel$tabs"] = if ($parent) { Join-Path $parent $stack[$tabs] } else { $stack[$tabs] }
    $folders[$body.Substring(6).Trim()] = $true
    continue
  }
  $file = $body.Substring(4).Trim()
  $rel = ''; for ($d=1; $d -lt $tabs; $d++) { if ($stack.ContainsKey("rel$d") -and $stack["rel$d"]) { $rel = $stack["rel$d"] } }
  $base = [System.IO.Path]::GetFileNameWithoutExtension($file)
  $lang = [System.IO.Path]::GetExtension($file).TrimStart('.').ToUpper()
  $kind = if ($section -eq 'PROG') { 'program' } elseif ($section -eq 'FB') { 'function_block' } else { 'function' }
  $root = if ($flat) {
    switch ($section) { 'PROG' { $ProgDir } 'FB' { $FbDir } 'FC' { $FcDir } }
  } else {
    switch ($section) { 'PROG' { "$ProgDir\$ProgDir" } 'FB' { "$ProgDir\$FbDir" } 'FC' { "$ProgDir\$FcDir" } }
  }
  $dir = if ($rel) { Join-Path $root $rel } else { $root }
  $md = if ($section -eq 'PROG') { Join-Path (Join-Path $MirrorDir $dir) "$base.md" }
        else { Join-Path (Join-Path (Join-Path $MirrorDir $dir) $base) "$base.md" }
  $map[$base] = @{ path=$md; kind=$kind; lang=$lang; src=$file }
  [void]$order.Add($base)
}
Write-Output ("expected blocks: {0}   folders: {1}" -f $map.Count, $folders.Count)

# --- retarget each block onto the existing skeleton file -------------------------------------
# The mirror already contains one placeholder .md per block (status: TODO) laid out under the real
# Chinese folder names. Using those files as the destination means the layout never has to be
# guessed -- and it guarantees we never write into a stray parallel tree.
$pending = @{}                  # block names whose skeleton says status: TODO (i.e. still wanted)
$skelUsed = $false
if ($UseSkeleton) {
  $skel = @{}
  $pending = @{}
  $skippedStray = 0
  foreach ($f in (Get-ChildItem -LiteralPath $MirrorDir -Recurse -Filter *.md -File -ErrorAction SilentlyContinue)) {
    # EXCLUDE the stray parallel tree. An older buggy run wrote a whole second layout under ASCII
    # 'program/fb/fc' directories; once every real .md is EXTRACTED there is no TODO to prefer, so
    # the scan would happily pick the stray file and the export would be written to the wrong place
    # (observed: FB04_TON resolved to program\fb\FB04_TON\). The real layout uses the Chinese
    # folder names, so anything under a top-level ASCII 'program' is by definition the stray tree.
    $rel = $f.FullName.Substring($MirrorDir.Length)
    if ($rel -match '(?i)^\\program\\') { $skippedStray++; continue }
    $head = ''
    try { $head = [System.IO.File]::ReadAllText($f.FullName) } catch { continue }
    if ($head.Length -gt 1500) { $head = $head.Substring(0,1500) }
    if ($head -notmatch '(?m)^block:[ \t]*(.+?)[ \t]*\r?$') { continue }
    $bn = $Matches[1].Trim()
    $isTodo = ($head -match '(?m)^status:[ \t]*TODO[ \t]*\r?$')
    if (-not $skel.ContainsKey($bn) -or ($isTodo -and -not $skel[$bn].Todo)) {
      $skel[$bn] = [pscustomobject]@{ Path=$f.FullName; Todo=$isTodo }
    }
  }
  $retargeted = 0
  foreach ($k in @($map.Keys)) { if ($skel.ContainsKey($k)) { $map[$k].path = $skel[$k].Path; $retargeted++ } }
  $todoCount = @($skel.Values | Where-Object { $_.Todo }).Count
  Write-Output ("skeleton: {0} placeholder .md found; {1}/{2} block targets retargeted; status=TODO: {3}" -f `
    $skel.Count, $retargeted, $map.Count, $todoCount)
  if ($skippedStray -gt 0) {
    Write-Output ("  ignored {0} .md file(s) under the stray ASCII 'program\' tree (wrong-path leftovers)" -f $skippedStray)
  }
  Write-Output ("  duplicate block names in the skeleton: {0}" -f ($retargeted - $skel.Count))
  # names still awaiting a body -> lets a re-run do only the remaining work
  $skelUsed = $true
  foreach ($k in @($map.Keys)) {
    if (-not $skel.ContainsKey($k) -or $skel[$k].Todo) { $pending[$k] = $true }
  }
}
if (-not $skelUsed) { foreach ($k in @($map.Keys)) { $pending[$k] = $true } }
if ($SkipDone) { Write-Output ("blocks still needing a body: {0} / {1}" -f $pending.Count, $map.Count) }

# --- start from a clean, known state ---------------------------------------------------------
[void][W.U]::SetForegroundWindow($script:MainHwnd); Start-Sleep -Milliseconds 400
[void](Assert-NoDialog 'pre-flight')
$stale = Close-StaleWindows
Write-Output ("stale block windows closed: {0}" -f $stale)
if ($stale) { [void][W.U]::SetForegroundWindow($script:MainHwnd); Start-Sleep -Milliseconds 400 }

# --- build the name index: ONE MSAA sweep, no arrow keys -------------------------------------
# The keyboard walk (DOWN row by row) is GONE. It was only ever needed because the tree used to be a
# UIA blind spot and rows could not be addressed; now accName(id) answers for ANY id in one sweep and
# accSelect(3,id) really moves the selection, so a block is addressed BY NAME in O(1):
#   * accChildCount is NOT the top of the id space (it reports ~188 while real ids reach 600+) and
#     the ids are reassigned on every tree change, so sweep wide and never cache an id.
#   * a full sweep of ~1000 ids costs ~0.3s -- cheaper than walking 20 rows.
#   * names are not unique (two 娴佺▼绠＄悊 nodes), so the index keeps a LIST of ids per name.
$sweepMax = ([int]$script:acc.accChildCount) + 3000   # NOT +800: the id space grows with the project.
                                                      # 2026-09-20: accChildCount=190 but real ids reached 1080,
                                                      # so +800 stopped at 988 and the index lost EVERY
                                                      # program/FB/FC block -> "0/95 extracted"; the failure
                                                      # LOOKED like "folders collapsed" but was this cap.
function Refresh-Index {
  # Re-sweep the tree and rebuild the name index.
  # MANDATORY before each target when a run handles MORE THAN ONE target: opening/exporting a node
  # closes and reopens MDI views, which renumbers every tree id (measured 2026-09-20: a run that built
  # the index once exported the 1st struct fine and then went for the WRONG node on the 2nd --
  # "could not select 'ST_气缸' (wanted id 52, got id 1049 'INT_001')" -- and aborted the whole batch).
  $script:index = @{}
  $c = 0
  for ($i = 1; $i -le $script:sweepMax; $i++) {
    $nm = ''
    try { $nm = [string]$script:acc.accName($i) } catch { continue }
    if ([string]::IsNullOrWhiteSpace($nm)) { continue }
    $st = -1; try { $st = [int]$script:acc.accState($i) } catch { }
    if (-not $script:index.ContainsKey($nm)) { $script:index[$nm] = New-Object System.Collections.ArrayList }
    [void]$script:index[$nm].Add([pscustomobject]@{ Id = $i; State = $st })
    $c++
  }
  $script:sweepCount = $c
}
$script:sweepCount = 0
Refresh-Index
Write-Output ("name index: {0} nodes in the tree (swept ids 1..{1})" -f $script:sweepCount, $script:sweepMax)

# --- duplicate-name resolution ---------------------------------------------------------------
# NAMES ARE NOT UNIQUE in this tree. Measured: MAIN exists twice -- the program under 绋嬪簭鍧?
# (indent x=127, display row 57) and an entry under 鍙橀噺鐩戞帶琛?(x=104, row 183) which opens a
# VSFlexGrid monitor view instead of a Scintilla editor. Taking the first id found (id order is NOT
# display order) silently grabbed the monitor entry and the block was reported as unreadable.
# Two independent signals are used, both measured by selecting the candidate and reading back:
#   * indent x  -- section blocks all sit at the same depth (x=127 here); the impostor was shallower
#   * display row -- row = nPos + (rect.top - treeTop)/20, and folder.txt order == tree order, so a
#     block's row must be greater than the previously processed block's row
# The row order is the primary filter, the deeper indent breaks ties. Decisions are printed.
function Get-TreeNPos {
  $si = New-Object W.U+SCROLLINFO
  $si.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($si)
  $si.fMask = 0x17
  [void][W.U]::GetScrollInfo($tree.hwnd, 1, [ref]$si)
  return [int]$si.nPos
}
function Measure-Node([int]$id) {
  try { $script:acc.accSelect(3, $id) } catch { }
  Start-Sleep -Milliseconds 250
  $x = 0; $y = 0; $w = 0; $h = 0
  try { $script:acc.accLocation([ref]$x, [ref]$y, [ref]$w, [ref]$h, $id) } catch { }
  $row = (Get-TreeNPos) + [int](($y - $tree.rect.Top) / 20)
  return [pscustomobject]@{ Id = $id; X = $x; Y = $y; Row = $row }
}
$script:lastRow = -1
function Resolve-TargetNode([string]$name) {
  # Diagnostics go to Write-Host on purpose: Write-Output would be swallowed into the return value.
  $cands = @($index[$name])
  if ($cands.Count -eq 0) { return $null }
  if ($cands.Count -eq 1) { return [pscustomobject]@{ Id = $cands[0].Id; X = -1; Row = -1 } }
  $meas = @($cands | ForEach-Object { Measure-Node $_.Id })
  Write-Host ("  DUP   {0,-30} : {1} nodes named this - {2}" -f $name, $meas.Count, (($meas | ForEach-Object { ("id={0} x={1} row={2}" -f $_.Id, $_.X, $_.Row) }) -join ' | '))
  # 2026-09-20 (user): "项目树第 1 个 MAIN 是程序开始" -- the FIRST occurrence in the project tree is the
  # real one. For MAIN that is the program block (display row 57); the impostor sits under 变量监控表
  # (display row 183). So the rule is now simply: SMALLEST display row wins, deeper indent breaks ties.
  # The old filter ("row must be greater than the previous target's row") was wrong: whenever MAIN was
  # processed after a later block, that filter kept ONLY the monitor entry and picked it.
  $pick = @($meas | Sort-Object -Property Row | Sort-Object -Property X -Descending | Select-Object -First 1)[0]
  Write-Host ("        -> chosen id={0} (x={1}, row={2}); the other is a different node with the same name" -f $pick.Id, $pick.X, $pick.Row)
  return $pick
}

# Folded folders hide their children from the index, so expand every known folder FIRST (MSAA state
# + accSelect + RIGHT -- name-addressed, no walking). The pre-flight -Deep already does this; this is
# the in-script safety net and it is cheap.
if ($ExpandFolded) {
  $fixed = 0
  for ($pass = 1; $pass -le 3; $pass++) {
    $folded = New-Object System.Collections.ArrayList
    foreach ($fn in @($folders.Keys)) {
      if (-not $index.ContainsKey($fn)) { continue }
      $e = $index[$fn][0]
      if (($e.State -ge 0) -and (($e.State -band $ST.collapsed) -ne 0)) { [void]$folded.Add($fn) }
    }
    if ($folded.Count -eq 0) { break }
    foreach ($fn in $folded) {
      try { $script:acc.accSelect(3, [int]$index[$fn][0].Id) } catch { continue }
      Start-Sleep -Milliseconds 150
      Send '{RIGHT}' 320
      [void](Assert-NoDialog ("expand '" + $fn + "'"))
      $fixed++
    }
    Start-Sleep -Milliseconds 300
  }
  Write-Output ("folded folders expanded: {0}" -f $fixed)
}

# --- target list (names, in folder.txt / tree order) ------------------------------------------
$targets = New-Object System.Collections.ArrayList
if ($tableMode) {
  foreach ($tn in @($tableSet.Keys)) { [void]$targets.Add($tn) }
} else {
  foreach ($bn in @($order)) { [void]$targets.Add($bn) }
}
if ($OnlyBlock) { $targets = @($targets | Where-Object { $_ -eq $OnlyBlock }) }
Write-Output ("targets: {0} name(s)" -f $targets.Count)

$notInTree = New-Object System.Collections.ArrayList

# --- iterate the targets BY NAME (no walking) -------------------------------------------------
$done = @{}; $count = 0; $skipped = @(); $failed = @()
$script:probeDone = $false
$step = 0
if ($DumpRows) {
  # -DumpRows used to mean "report every row the walk passes". There is no walk any more, so it now
  # dumps the whole name index (id + state + whether folder.txt knows the name).
  Write-Output '--- name index (id, state, known-to-folder.txt) ---'
  foreach ($k in ($index.Keys | Sort-Object { $index[$_][0].Id })) {
    $e = $index[$k][0]
    Write-Output ("  id={0,-4} state=0x{1:X6} {2} {3}" -f $e.Id, $e.State, $(if ($map.ContainsKey($k)) { 'BLOCK ' } elseif ($folders.ContainsKey($k)) { 'FOLDER' } else { '      ' }), $k)
  }
}
foreach ($targetName in $targets) {
  if ($script:probeDone) { Write-Output ("probe of '{0}' complete - stopping" -f $ProbeBlock); break }
  if ($Limit -gt 0 -and $count -ge $Limit) { break }
  $step++
  if ($targets.Count -gt 1 -and $step -gt 1) {
    # each previous target opened/closed an MDI view -> every tree id has been renumbered, so the
    # cached index is stale. Rebuild it (one sweep, ~1s) instead of clicking a wrong node.
    Refresh-Index
    Write-Host ("  [idx] re-swept the tree before '{0}' ({1} nodes)" -f $targetName, $script:sweepCount)
  }
  if (-not $index.ContainsKey($targetName)) {
    # a folded folder hides its children from the index -- say so instead of silently skipping
    Write-Output ("  NOT-IN-TREE {0,-28} : absent from the name index (folder collapsed? renamed?)" -f $targetName)
    [void]$notInTree.Add($targetName)
    continue
  }
  $entry = Resolve-TargetNode $targetName
  if ($null -eq $entry) {
    Write-Output ("  NOT-IN-TREE {0,-28} : absent from the name index (folder collapsed? renamed?)" -f $targetName)
    [void]$notInTree.Add($targetName)
    continue
  }
  if ($entry.Row -ge 0) { $script:lastRow = $entry.Row }
  $selOk = $false
  for ($try = 1; $try -le 3; $try++) {
    try { $script:acc.accSelect(3, [int]$entry.Id) } catch { }
    Start-Sleep -Milliseconds 250
    $chk = Read-Sel
    if ($chk.Name -eq $targetName) { $selOk = $true; break }
  }
  if (-not $selOk) {
    Write-Output ("  SELFAIL {0,-30} : could not select it (selection is '{1}')" -f $targetName, (Read-Sel).Name)
    $failed += $targetName
    continue
  }
  $s = Read-Sel

  # the target list IS the wanted set now; the old per-row predicates (isBlock / isFolder / rectOk /
  # wanted / "row is off screen" / "row centre falls in the no-click band") are all obsolete: the
  # node was addressed by name and accSelect put it on screen, and nothing is clicked by coordinate.
  $isBlock  = $map.ContainsKey($s.Name)
  $isFolder = $folders.ContainsKey($s.Name)
  $rectOk   = $true
  $wanted   = -not $done.ContainsKey($s.Name)
  if ($tableMode) {
    # Target the named 鍙橀噺琛?nodes. Skipped when their CSV already holds a real export (same
    # first-4-bytes test as below) so a chunked run stays resumable; -Redo forces a re-export.
    $already = $false
    if (-not $Redo) {
      $csvTry = Join-Path $TableOutDir ($s.Name + '.csv')
      if (Test-Path -LiteralPath $csvTry) {
        try {
          $fs = [System.IO.File]::OpenRead($csvTry); $buf = New-Object byte[] 4; [void]$fs.Read($buf,0,4); $fs.Close()
          $already = ($buf[0] -eq 0xD0 -and $buf[1] -eq 0xF2 -and $buf[2] -eq 0xBA -and $buf[3] -eq 0xC5)
        } catch { $already = $false }
      }
    }
    $wanted = $tableSet.ContainsKey($s.Name) -and -not $already -and -not $done.ContainsKey($s.Name)
  } elseif ($DumpRows) { $wanted = $false }
  elseif ($VarTableOnly) {
    # Every .md is already written, so the "pending" filter would skip everything. Target only the
    # FB/FC blocks and ignore the skeleton status -- their CSVs are the thing being filled in.
    # A CSV that has already been exported is skipped, which makes a chunked run resumable.
    # The test is the file's FIRST 4 BYTES: a real export starts with GBK-encoded '搴忓彿'
    # (D0 F2 BA C5) while the placeholder starts with 'name'. Size is NOT a usable test -- a block
    # with a one-row variable table exports to a few hundred bytes, which a size threshold would
    # misread as "not done yet".
    # NB: this branch runs for EVERY walked row including folders, and $map has no entry for those
    # -- taking .path unguarded yields an empty string and Test-Path then throws.
    $already = $false
    if ($isBlock -and $map.ContainsKey($s.Name)) {
      $csvTry = [System.IO.Path]::ChangeExtension([string]$map[$s.Name].path, '.csv')
      if ($csvTry -and (Test-Path -LiteralPath $csvTry)) {
        try {
          $fs = [System.IO.File]::OpenRead($csvTry)
          $buf = New-Object byte[] 4
          [void]$fs.Read($buf, 0, 4)
          $fs.Close()
          $already = ($buf[0] -eq 0xD0 -and $buf[1] -eq 0xF2 -and $buf[2] -eq 0xBA -and $buf[3] -eq 0xC5)
        } catch { $already = $false }
      }
    }
    $wanted = $isBlock -and -not $already -and -not $done.ContainsKey($s.Name) -and `
              ($map[$s.Name].kind -eq 'function_block' -or $map[$s.Name].kind -eq 'function')
  } elseif ($SkipDone -and $wanted) {
    # Two independent reasons to skip a block that still needs work:
    #  a) the skeleton tree says its body is already written ($pending), or
    #  b) its target .md already exists with status: EXTRACTED.
    # (b) is what makes a CHUNKED run resumable in the flat layout, where there is no skeleton tree
    # at all -- otherwise every chunk would restart from the top and redo the first N blocks.
    $skip = -not $pending.ContainsKey($s.Name)
    if (-not $skip -and $map.ContainsKey($s.Name)) {
      $mdTry = [string]$map[$s.Name].path
      if ($mdTry -and (Test-Path -LiteralPath $mdTry)) {
        try { if ([System.IO.File]::ReadAllText($mdTry) -match '(?m)^status:\s*EXTRACTED') { $skip = $true } } catch { }
      }
    }
    if ($skip) { $wanted = $false }
  }
  # -OnlyBlock: hard filter, so a single-block task does not process everything else on the way.
  if ($OnlyBlock -and $wanted -and $s.Name -ne $OnlyBlock) { $wanted = $false }

  if ($wanted) {
    if ($Limit -gt 0 -and $count -ge $Limit) { break }
    Write-Output ("  BLOCK {0,-30} id={1}" -f $s.Name, $s.Id)

    # OPEN THE BLOCK -- via its node context menu, never with Ctrl+O (see Open-NodeByName for the
    # measured reason: a main-frame Ctrl+O pops an AutoShop dialog and poisons the whole run).
    # The opener is taken APART: PowerShell functions leak the output of any inner call that was not
    # [void]'d, and a leaked value turned the caption into the string 'System.Object[]' (which then
    # failed every single block). Only a real string is accepted, and a leak is reported.
    $res = @(Open-NodeByName $s.Name 4000)
    if ($res.Count -gt 1) {
      Write-Output ("   [open] NOTE: the opener returned {0} values [{1}] - using the last string" -f $res.Count, (($res | ForEach-Object { if ($null -eq $_) { 'null' } else { $_.GetType().Name } }) -join ','))
    }
    $opened = [string](@($res | Where-Object { $_ -is [string] }) | Select-Object -Last 1)
    if ($opened -ne $s.Name) {
      Write-Output ("  MISMATCH {0,-26} : title says '{1}' -> closing, not writing" -f $s.Name, $opened)
      [void](Close-BlockView $s.Name)
      $failed += $s.Name
      continue
    }
      # --- variable-table mode: export the CSV, leave the .md files alone --------------------
      # Covers both the FB/FC blocks (-VarTableOnly, targets from folder.txt) and the 鍙橀噺琛?nodes
      # (-TableNames: Global_閫氱敤, GVL_*, 鍔熻兘鍧楀疄渚? ... which are not in folder.txt at all).
      if ($VarTableOnly -or $tableMode) {
        if ($tableMode) {
          $csvPath = Join-Path $TableOutDir ($s.Name + '.csv')
        } else {
          $info = $map[$s.Name]
          $csvPath = [System.IO.Path]::ChangeExtension($info.path, '.csv')
        }
        $dir = Split-Path -Parent $csvPath
        if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
        $ok = Export-VarTable $s.Name $csvPath
        if ($ok) {
          $sz = 0
          if (Test-Path -LiteralPath $csvPath) { $sz = (Get-Item -LiteralPath $csvPath).Length }
          Write-Output ("  VAR   {0,-30} -> {1} ({2} bytes)" -f $s.Name, (Split-Path $csvPath -Leaf), $sz)
          $count++
        } else {
          Write-Output ("  VARFAIL {0,-28} : variable table not exported" -f $s.Name)
          $failed += $s.Name
        }
        $done[$s.Name] = $true
        if ($ProbeBlock -and $s.Name -eq $ProbeBlock) { $script:probeDone = $true }
        if ($KeepOpen -and $ProbeBlock -and $s.Name -eq $ProbeBlock) {
          Write-Host ("   [keep-open] leaving '{0}' open for inspection" -f $s.Name)
        } else {
          [void](Close-BlockView $s.Name)
        }
        continue
      }
      $src = Read-BlockText $s.Name
      if ($null -eq $src) {
        # The caption can already name the block while its editor is still being built (measured on
        # MAIN: the title matched, but the MDI child had only 2 descendants and no readable text).
        # Give it a moment and try once more before declaring the block unreadable.
        Write-Output ("  WAIT  {0,-30} : title matched but no text yet - retrying the read" -f $s.Name)
        Start-Sleep -Milliseconds 1500
        $src = Read-BlockText $s.Name
      }
      if ($null -eq $src) {
        Write-Output ("  FAIL  {0,-30} : opened but no channel could read the body" -f $s.Name)
        Diagnose-Block $s.Name
        Send '^{F4}' 350; [void](Assert-NoDialog 'close unreadable')
        [void](Close-BlockView $s.Name)
        $failed += $s.Name
        if ($ProbeBlock -and $s.Name -eq $ProbeBlock) { $script:probeDone = $true }
        continue
      }
      # An empty body is reported, not treated as a failure: some blocks legitimately have no code.
      if ($src.Length -lt 2) { Write-Output ("  NOTE  {0,-30} : block body is empty ({1} chars)" -f $s.Name, $src.Length) }
      $info = $map[$s.Name]
      $body = @"
---
project: $(Split-Path -Leaf $ProjectDir)
kind: $($info.kind)
block: $($s.Name)
language: $($info.lang)
source: $ProjectDir\$($info.src)
chars: $($src.Length)
lines: $(($src -split "`n").Count)
status: EXTRACTED
---

``````$($info.lang.ToLower())
$src
``````
"@
      if ($Write) {
        $d = Split-Path -Parent $info.path
        if (-not (Test-Path -LiteralPath $d)) { [void](New-Item -ItemType Directory -Path $d -Force) }
        [System.IO.File]::WriteAllText($info.path, $body, $U8)
        Write-Output ("  OK    {0,-30} {1,6} chars -> {2}" -f $s.Name, $src.Length, (Split-Path -Leaf $info.path))
      } else {
        Write-Output ("  DRY   {0,-30} {1,6} chars | {2}" -f $s.Name, $src.Length, (($src -split "`n")[0]))
      }
      # Close the MDI child right away: leaving them open hits AutoShop's window limit
      # ("open window count exceeded"), which disables the whole UI. WM_CLOSE is verified, because
      # Ctrl+F4 alone silently did nothing here and the windows accumulated unnoticed.
      # -KeepOpen exempts the probed block so its UI can be inspected afterwards.
      if ($KeepOpen -and $ProbeBlock -and $s.Name -eq $ProbeBlock) {
        Write-Output ("  [keep-open] leaving the view for '{0}' open for inspection" -f $s.Name)
      } else {
        $closed = Close-BlockView $s.Name
        if (-not $closed) { Write-Output ("  WARNING: could not close the view for '{0}'" -f $s.Name) }
        [void](Assert-NoDialog 'after closing block')
      }
      $done[$s.Name] = $true; $count++
      if ($ProbeBlock -and $s.Name -eq $ProbeBlock) { $script:probeDone = $true }
      # No re-anchoring and no DOWN key any more: every block is addressed by name and re-selected
      # from the index, so focus drift cannot derail the run (the old DRIFT repair is obsolete).
      Start-Sleep -Milliseconds 80
  }
}

# --- report ----------------------------------------------------------------------------------
$missing = @($order | Where-Object { -not $done.ContainsKey($_) })
$stillWanted = @($pending.Keys | Where-Object { -not $done.ContainsKey($_) })
Write-Output ''
Write-Output ("extracted this run : {0}" -f $count)
Write-Output ("still needing a body (this run's target set): {0}" -f $stillWanted.Count)
Write-Output ("not touched this run (already done earlier): {0}" -f ($map.Count - $pending.Count))
Write-Output ("blocks not extracted in THIS run: {0} / {1}" -f $missing.Count, $map.Count)
Write-Output ("skipped (dialog/offscreen) : {0}" -f $skipped.Count)
Write-Output ("failed (mismatch/unreadable): {0}" -f $failed.Count)
Write-Output ("modal dialogs dismissed    : {0}" -f $script:DialogsSeen)
if ($skipped.Count) { Write-Output 'skipped:'; $skipped | Select-Object -Unique | ForEach-Object { Write-Output ("   - {0}" -f $_) } }
if ($failed.Count)  { Write-Output 'failed:';  $failed  | Select-Object -Unique | ForEach-Object { Write-Output ("   - {0}" -f $_) } }
if ($missing.Count) { Write-Output 'missing:'; $missing | Select-Object -First 40 | ForEach-Object { Write-Output ("   - {0}" -f $_) } }
if (-not $Write) { Write-Output 'DRY RUN - add -Write to write files.' }
[void](Assert-NoDialog)
# leave the app usable: hand the foreground back to AutoShop (these scripts took it to click)
Focus-AutoShop
Write-Output 'AutoShop has been brought back to the foreground - the user can operate it again.'

