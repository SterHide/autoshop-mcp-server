# Call a tool on the autoshop-mcp-server over HTTP (JSON-RPC 2.0) and print the human-readable text.
#
# Why this wrapper exists:
#  1. The MCP streamable-HTTP transport requires Accept: application/json, text/event-stream,
#     otherwise it answers 406 "Not Acceptable".
#  2. It sends Content-Type: application/json WITHOUT charset, so Windows PowerShell 5.1
#     Invoke-RestMethod decodes the body as Latin-1 and Chinese turns into mojibake.
#     Reading the body as UTF-8 explicitly (below) avoids that.
#
# Usage:
#   .\autoshop-mcp-call.ps1 -Tool autoshop_detect_open_instances
#   .\autoshop-mcp-call.ps1 -Tool autoshop_inspect_project_health -ProjectPath 'C:\path\to\project'
#   .\autoshop-mcp-call.ps1 -Tool autoshop_read_block_source -ProjectPath '...' -ExtraArgsJson '{"blockName":"MAIN"}'
param(
  [Parameter(Mandatory = $true)][string]$Tool,
  [string]$ProjectPath,
  [string]$InstallPath,
  [string]$BlockName,
  [string]$Query,
  [string]$ResponseFormat = 'markdown',
  [string]$ExtraArgsJson = '{}',
  [int]$Port = 18711
)

Add-Type -AssemblyName System.Net.Http

$arguments = @{}
if ($ProjectPath) { $arguments['projectPath'] = $ProjectPath }
if ($InstallPath) { $arguments['installPath'] = $InstallPath }
if ($BlockName) { $arguments['blockName'] = $BlockName }
if ($Query) { $arguments['query'] = $Query }
$arguments['response_format'] = $ResponseFormat
# NOTE: keep string values out of -ExtraArgsJson where possible. Passing inline JSON through a
# native-command argument list mangles quotes/backslashes on PowerShell 5.1
# ("Invalid JSON primitive: C" / "Invalid JSON primitive: MAIN"); dedicated parameters avoid it.
$extra = $ExtraArgsJson | ConvertFrom-Json
foreach ($prop in $extra.PSObject.Properties) { $arguments[$prop.Name] = $prop.Value }

$payload = @{
  jsonrpc = '2.0'
  id      = 1
  method  = 'tools/call'
  params  = @{ name = $Tool; arguments = $arguments }
}
$body = $payload | ConvertTo-Json -Depth 12 -Compress

$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromMinutes(5)
$request = New-Object System.Net.Http.HttpRequestMessage ([System.Net.Http.HttpMethod]::Post), "http://127.0.0.1:$Port/mcp"
[void]$request.Headers.Add('Accept', 'application/json, text/event-stream')
$request.Content = New-Object System.Net.Http.StringContent ($body, [Text.Encoding]::UTF8, 'application/json')

$response = $client.SendAsync($request).Result
$text = $response.Content.ReadAsStringAsync().Result

if (-not $response.IsSuccessStatusCode) {
  Write-Output "HTTP $([int]$response.StatusCode): $text"
  exit 1
}

$obj = $text | ConvertFrom-Json
if ($obj.error) {
  Write-Output "JSON-RPC error $($obj.error.code): $($obj.error.message)"
  exit 1
}
if ($obj.result.isError) {
  Write-Output "TOOL ERROR: $($obj.result.content[0].text)"
  exit 1
}
Write-Output $obj.result.content[0].text
