﻿# DEPRECATED 2026-09-19 (user instruction): this script walks the tree with arrow keys ({DOWN}/{UP}/Ctrl+Home). That method is abandoned -- address nodes BY NAME with accSelect(3,id) instead: see autoshop-jump.ps1 and autoshop-node-menu.ps1 (skill autoshop-uia sections 2.0 / 14 / 15). Kept only as a record of how the tree was found before.
# Probe 4: what is the real MSAA child-id space of this tree?
#
# Contradiction to resolve: accChildCount reads 188, yet accSelection returns 198 and
# accName(198) yields a real block name. Also accName/accRole throw for ids 87..188.
# So the ids are probably NOT 1..childCount.
#
# Also exercises accNavigate (MSAA tree walking) as a fallback if the id space is unusable.
# KEEP PURE ASCII.
param([int]$From = 1, [int]$To = 240)

$ErrorActionPreference = 'Stop'
if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

$LD = 0x02; $LU = 0x04
function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 120
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LU,0,0,0,0)
}
function Send([string]$k, [int]$w = 120) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }

# CORRECT MSAA state bits -- note EXPANDED/COLLAPSED are 0x200/0x400, NOT 0x2000/0x4000.
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000; selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
function Dec([int]$s) {
  $f = New-Object System.Collections.ArrayList
  foreach ($k in @('selected','focused','expanded','collapsed','focusable','selectable','invisible','offscreen')) { if ($s -band $ST[$k]) { [void]$f.Add($k) } }
  if ($f.Count) { return ($f -join '+') } else { return '-' }
}

$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$hwnd = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [W.U+EnumProc]{ param($h,$p)
  if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r); [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r }) }
  return $true }
[void][W.U]::EnumChildWindows($hwnd, $cb, [IntPtr]::Zero)
$t = $trees | Sort-Object { $_.rect.Left } | Select-Object -First 1
Write-Output ("tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $t.hwnd, $t.rect.Left, $t.rect.Top, ($t.rect.Right-$t.rect.Left), ($t.rect.Bottom-$t.rect.Top))
$iid = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
[void][W.U]::AccessibleObjectFromWindow($t.hwnd, [uint32]4294967292, [ref]$iid, [ref]$acc)
Write-Output ("accChildCount = {0}" -f $acc.accChildCount)

[void][W.U]::SetForegroundWindow($hwnd); Start-Sleep -Milliseconds 400
Click 100 400; Start-Sleep -Milliseconds 400
Send '^({HOME})' 700
Write-Output ("accSelection after Ctrl+Home = {0}" -f $acc.accSelection)

Write-Output ''
Write-Output ("--- id sweep {0}..{1} (only ids that answer) ---" -f $From, $To)
$good = 0; $bad = 0
for ($i = $From; $i -le $To; $i++) {
  $name = $null; $role = $null; $s = $null
  try { $name = [string]$acc.accName([int]$i) } catch { $name = $null }
  try { $role = [int]$acc.accRole([int]$i) } catch { $role = $null }
  try { $s = [int]$acc.accState([int]$i) } catch { $s = $null }
  if ($null -eq $name -and $null -eq $role) { $bad++; continue }
  $good++
  $x=0;$y=0;$w=0;$h=0
  try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$i) } catch { }
  Write-Output ("  id={0,4} role={1,-4} state={2,-46} rect={3},{4},{5},{6}  name='{7}'" -f $i, $role, $(if ($null -eq $s) {'<ERR>'} else {Dec $s}), $x,$y,$w,$h, $name)
}
Write-Output ("  answering ids: {0}   silent ids: {1}" -f $good, $bad)

# --- accNavigate as an independent walk ----------------------------------------------------
Write-Output ''
Write-Output '--- accNavigate from the selected node ---'
$NAV = @{ UP=1; DOWN=2; LEFT=3; RIGHT=4; NEXT=5; PREVIOUS=6; FIRSTCHILD=7; LASTCHILD=8 }
$sel = $acc.accSelection
Write-Output ("  accSelection = {0}" -f $sel)
foreach ($k in @('FIRSTCHILD','LASTCHILD','NEXT','PREVIOUS')) {
  try {
    $r = $acc.accNavigate($NAV[$k], [int]$sel)
    Write-Output ("  Navigate({0,-10}) => '{1}'  (accName: '{2}')" -f $k, $r, $(try { $acc.accName($r) } catch { '<ERR>' }))
  } catch { Write-Output ("  Navigate({0,-10}) => ERR {1}" -f $k, $_.Exception.Message) }
}
[void][W.U]::SetForegroundWindow($hwnd)
