# AutoShop AI Kit — 用代码驱动汇川 AutoShop 的界面自动化工具包

给 **AI 智能体**（或工程师）操作 **汇川 AutoShop（PLC 编程软件）** 用的自包含工具包：
自检 → 读工程树 → 建节点 → 导表 → 写程序正文 → 回读校验 → 保存落盘，全流程可被 AI 驱动。

**不含任何旧版 MCP 组件**，只依赖本包自身 + 你机器上的 AutoShop。

---

## 1. 这个包能干什么

| 能力 | 工具 |
|---|---|
| 开工自检（窗体位置/尺寸、左栏宽度、折叠状态、视图数、模态框） | `autoshop-preflight.ps1` |
| 读工程树（MSAA 名字索引，返回 id + 名称） | `autoshop-node-menu.ps1 -ListNodes` |
| 按名字打开节点（块 / 变量表 / 结构体 / 功能块实例） | `autoshop-open-node.ps1` |
| 新建节点（FB / 结构体 / 全局变量表 / 子程序） | `autoshop-node-menu.ps1` + `autoshop-fill-newdialog.ps1` |
| 导入整张表（结构体成员 / GVL 变量 / FB 变量表 / 功能块实例） | `autoshop-import-vartable.ps1` |
| 只读回读块正文 + 与本地文件逐字符比对 | `autoshop-read-block.ps1` |
| 写入块正文（带回读校验） | `autoshop-write-block.ps1` |
| 保存（先清弹窗 → 再保存 → 验星号，可重试） | `autoshop-save-until-clean.ps1` |
| 关视图、清弹窗、查弹窗、拖左栏宽度 | `autoshop-close-all-blocks.ps1` / `autoshop-dialog-answer.ps1` / `autoshop-set-pane.ps1` |
| 五条铁律自查（ST 结构 / 局部变量 / 全局变量 / 实例化 / 定时器实例） | `autoshop-check-block.ps1` |
| 由一份规格文件生成全部变量表 | `make-cylinder-tables.ps1` |
| 抽取 markdown 围栏正文成 `.st` | `md-to-st.ps1` |

---

## 2. 两种用法

### 方式 A：走 MCP（推荐 —— **不需要 shell，任何 MCP 客户端都能用**）

```
mcp/server.mjs        零依赖 MCP server（stdio + 换行分隔 JSON-RPC 2.0，不装任何 npm 包）
mcp/mcp-invoke.ps1    调用器：参数走 UTF-8 JSON 文件，不走命令行（避免中文/引号被多层转义破坏）
```

启动（任何 MCP 客户端都一样 —— 就是"起一个进程、说 stdio 上的 JSON-RPC"）：

```jsonc
// Claude Desktop / 通用 mcpServers 写法，见 mcp-config-examples/
{
  "mcpServers": {
    "autoshop": {
      "command": "D:\\Program Files\\nodejs\\node.exe",
      "args": ["<本包目录>\\mcp\\server.mjs"],
      "env": { "AUTOSHOP_TOOLS_DIR": "<本包目录>\\tools" }
    }
  }
}
```

`AUTOSHOP_TOOLS_DIR` 不传时默认取 `..\tools`（本包内的目录），所以整包搬到哪都能用。

**14 个 MCP 工具**（前缀由客户端配置的 `serverName` 决定，例如 DSH 下是 `mcp__autoshop__*`）：

```
autoshop_preflight   autoshop_tree        autoshop_open_node    autoshop_read_block
autoshop_write_block autoshop_save        autoshop_close_all    autoshop_create_node
autoshop_import_table autoshop_check_block autoshop_make_tables autoshop_md_to_st
autoshop_set_pane    autoshop_dialogs
```

★ **MCP 版把"纪律"和"坐标"写死在服务端**，用它的 AI 不需要读技能、也不会记错偏移：

- 每个视图的**导入偏移**内置（FB/FC `456/512`、GVL `409/632`、结构体 `386/442`、功能块实例 `409/476`）
- 每类节点的**新建菜单偏移**内置（FB `18/168`、结构体 `18/64`、全局变量 `18/64` 且自动改名、子程序 `72/116`）
- `autoshop_import_table` 默认自动完成 **开视图 → 导入 → 按确定 → 按保存 → 验星号**
- 每次工具调用**各起一个独立 powershell 进程**（多个脚本共用同一个 .NET 类型 `W.U`，串在一个进程里会互相顶掉）
- **工具调用在服务端串行执行** —— 界面自动化绝不能被并发（实测并发会让"读块"抢在"开块"之前跑）

### 方式 B：直接跑脚本（AI 需要有命令执行能力）

```powershell
powershell -STA -NoProfile -ExecutionPolicy Bypass -Command "[Console]::OutputEncoding=[Text.Encoding]::UTF8; & '<本包目录>\tools\autoshop-preflight.ps1'"
```

★ 三条硬要求：
1. 每个脚本**各起一个进程**（别在一个 `powershell -Command` 里串多个脚本）
2. `-STA`（MSAA/UIA 需要）
3. 子进程先设 `[Console]::OutputEncoding = UTF8`，否则中文输出会乱码

配合 `SKILL.md`（本包内）：把它放进你的 AI 的技能目录，或直接作为上下文喂给它。

---

## 3. 目录结构

```
AutoShop-AI-Kit\
├─ README.md                  本文件
├─ SKILL.md                   完整技能：坐标、偏移、判据、踩过的坑（**已剔除旧 MCP 路线**）
├─ mcp\
│   ├─ server.mjs             零依赖 MCP server
│   └─ mcp-invoke.ps1         调用器（纯 ASCII）
├─ tools\                     PowerShell 脚本全集（路径已改为可移植，可直接换目录）
└─ mcp-config-examples\
    ├─ dsh-cordis.patch.yml   DSH Desktop 的注册片段
    └─ claude-desktop.json    Claude Desktop / 通用 mcpServers 片段
```

---

## 4. 前置条件与环境事实

| 项 | 要求 |
|---|---|
| 系统 | Windows（本包实测于 Windows 10/11 + 中文区域） |
| AutoShop | 汇川 AutoShop V4.11.0.5（Easy523 机型实测；其它版本**坐标需重新量**） |
| 窗口几何 | 主窗口必须在 `x=0 y=1 1287×1144` **非最大化**（`autoshop-preflight.ps1 -Fix` 会自动归位） |
| Node | 仅走 MCP 时需要（实测 v24.18.0）；**直接跑脚本不需要 node** |
| 权限 | 需要能与 AutoShop 同机的桌面会话（UI 自动化跨不了机器/会话） |

**任何一批操作前后都跑一次自检**：

```powershell
& '.\tools\autoshop-preflight.ps1'            # 只看
& '.\tools\autoshop-preflight.ps1' -Fix -Deep # 自动归位 + 展开所有文件夹
#   ★ -Fix 的顺序是【先把左栏归位到 346px，再展开所有文件夹】—— 左栏太窄时树被裁，展开会点歪
```

---

## 5. 必须遵守的纪律（这些是真金白银换来的，别省）

1. **关窗体前必须先保存**，而且顺序是死的：
   **先按【确定】清掉弹窗 → 再按【保存】→ 再读标题确认 ` *` 消失 → 最后才关视图**。
   反了或省了 = 弹窗吞掉保存点击、日志却一切正常（实测 `.gvt` 一直停在 221 B 不变）。
2. **导入 = 整表替换且不可撤销**。基准必须来自**当前真实状态**；改别人的大表前先导出。
3. **变更只在本地做，然后导入一次**。不要"导出→导入→导出"来回跑（一圈要过 7 个界面动作）。
4. **依赖顺序不能跳**：结构体 → 全局变量表 → 功能块 → 功能块实例 → 子程序 → 主程序。
   实例引用不存在的 FB 会弹 `导入完成失败N条`（**这行字就是"顺序错了"的信号**）。
5. **写完必须回读**：`autoshop-read-block.ps1 -Diff <本地文件>` 逐字符比对，**不信任何"保存成功"提示**。
6. **PLC 编译 / 下载到 PLC 绝不自动执行** —— 必须由人明确要求并确认目标 PLC。
7. **无 BOM 的 `.ps1` 里绝不写中文字面量**（PowerShell 5.1 按 ANSI 读 ⇒ 乱码 ⇒ 静默匹配失败）。

---

## 6. 换机器 / 换 AutoShop 版本要重量的东西

坐标类偏移都是**实测量出来的**，换版本/换 DPI 会失效。本包带了测量工具：

| 要量什么 | 工具 |
|---|---|
| 左栏宽度 / 溢出 | `autoshop-pane-check.ps1` |
| 某节点的右键菜单布局 | `autoshop-menu-probe.ps1`、`autoshop-node-menu.ps1 -CaptureOut <png>` |
| 树结构 / 折叠状态 | `autoshop-tree-probe*.ps1`、`autoshop-tree-scan.ps1` |
| 变量表网格右键菜单 | `autoshop-extract-blocks2.ps1`（导出流程会打印实测到的菜单尺寸） |
| 窗口几何基线 | `autoshop-preflight.ps1` |

`SKILL.md` 里每个偏移都标了"在哪个视图上量的"，重新量完照着改即可。

---

## 7. 已知限制（如实说明）

- **MFC 工具栏按钮读不到**（MSAA/UIA 都不暴露），所以"保存"是**按窗口相对坐标点击**的 —— 窗口被挪动就会点歪（自检会拦）。
- 工程树**折叠的节点不在 MSAA 走行路径上**，会表现为"目标不存在" ⇒ 首次必须 `-Deep` 展开。
- 工程**索引**（外部文件级工具看到的那份）在 AutoShop 存盘/关闭前不刷新，**新建的块在工程开着时读不到**。
- 本包**不解析** `.FB` / `.ST` / `.stru` / `.gvt` 里的代码（都是打包容器，磁盘上没有明文）——
  正文只能**从编辑器回读**。
- 目前只在**单实例 AutoShop** 上验证过。

---

## 8. 快速上手（3 步）

```powershell
# 1) 自检（会自动把窗口归位、展开所有文件夹，并报告左栏/视图/弹窗状态）
& '.\tools\autoshop-preflight.ps1' -Fix -Deep

# 2) 看工程树（确认要操作的节点存在）
& '.\tools\autoshop-node-menu.ps1' -ListNodes

# 3) 回读某个块的正文并与本地文件比对（只读，不改动）
& '.\tools\autoshop-open-node.ps1' -Node 'MAIN'
& '.\tools\autoshop-read-block.ps1' -Block 'MAIN' -Diff '.\MAIN.st'
& '.\tools\autoshop-close-all-blocks.ps1'
```

走 MCP 的话，第 1 步就是工具 `autoshop_preflight`，第 2 步 `autoshop_tree`，第 3 步 `autoshop_open_node` + `autoshop_read_block`。
