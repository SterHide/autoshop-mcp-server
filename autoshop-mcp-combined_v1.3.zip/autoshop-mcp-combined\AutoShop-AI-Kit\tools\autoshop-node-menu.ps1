# Select a project-tree NODE by name via MSAA, then optionally open its context menu and use it.
#
# WHY THERE IS NO KEYBOARD WALK ANY MORE (all three facts measured on AutoShop V4.11.0.5):
#   * accName(id) works for EVERY id in 1..accChildCount -> the whole tree is read in ONE sweep.
#     No DOWN-key walking, no scrolling, no "stale read after a keypress" race.
#   * accSelect(3, id)  (SELFLAG_TAKEFOCUS|SELFLAG_TAKESELECTION) really moves the selection:
#     measured "before selection id=1 -> after selection id=15 'EXP-B'".
#   * Ctrl+Home is SILENTLY IGNORED by this tree (from id=2 it stayed at id=2), while {HOME} works.
#     That was the root cause of a whole failed round: the walk started in the FB/FC region, never
#     got back to the top, and reported "reached the end of the tree without finding 程序块".
#   * accLocation() returns STALE rectangles once the window has ever been resized or maximized
#     (a row reported y=1268 while the tree is only 148..959 tall), so ids are resolved fresh right
#     before every use and never cached between operations.
#   * the hidden duplicate SysTreeView32 must be filtered out: EnumChildWindows also returns a
#     non-visible tree that sits at the same rect as a real one.
#
# KEEP PURE ASCII. Chinese node names arrive via parameters.
param(
  [string]$Node = '',              # node name, exact match
  [string]$Match = '',             # node name, substring match (used when -Node is empty)
  [int]$NodeIndex = 0,             # which match to use when the name occurs more than once
  [int]$MaxId = 0,                 # highest id to probe (default: accChildCount + 200)
  [switch]$ListNodes,              # dump id -> name and exit (no selection, no menu)
  [switch]$SelectOnly,             # select the node and stop (no context menu)
  [string]$CaptureOut = '',        # PrintWindow the opened menu to this PNG
  [string]$MainShotOut = '',       # PrintWindow the WHOLE main window after the click (to see a dialog)
  [int]$ClickOffsetY = -1,         # if >= 0, click this offset inside the menu (X offset below)
  [int]$ClickOffsetX = 100,
  [int]$ExpectedMenuH = 0,         # if > 0, refuse to click unless the menu height matches +-60
  [switch]$NoMenu = $false
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }

if (-not ('N.U' -as [type])) {
if (-not ('N.U' -as [type])) {
Add-Type -Namespace N -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int w, int h);
[DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
[DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
[DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
[DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint flags);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}
}
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000; selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
function ClsOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 256;[void][N.U]::GetClassNameW($h,$b,256);$b.ToString().Trim()}
function TxtOf([IntPtr]$h){$b=New-Object System.Text.StringBuilder 512;[void][N.U]::GetWindowTextW($h,$b,512);$b.ToString()}
function RectOf([IntPtr]$h){$r=New-Object N.U+RECT;[void][N.U]::GetWindowRect($h,[ref]$r);return $r}
function ClickRaw([int]$x,[int]$y){[void][N.U]::SetCursorPos($x,$y);Start-Sleep -Milliseconds 150;[N.U]::mouse_event(0x02,0,0,0,0);Start-Sleep -Milliseconds 60;[N.U]::mouse_event(0x04,0,0,0,0)}
function Send([string]$k,[int]$w=140){[System.Windows.Forms.SendKeys]::SendWait($k);Start-Sleep -Milliseconds $w}
function TopWindows {
  $l=New-Object System.Collections.ArrayList
  $cb=[N.U+EnumProc]{ param($h,$p) if([N.U]::IsWindowVisible($h)){$r=RectOf $h;[void]$l.Add([pscustomobject]@{Hwnd=$h;Cls=(ClsOf $h);X=$r.Left;Y=$r.Top;W=($r.Right-$r.Left);H=($r.Bottom-$r.Top);Text=(TxtOf $h)})};return $true }
  [void][N.U]::EnumWindows($cb,[IntPtr]::Zero); return $l }
function SavePng([IntPtr]$hwnd,[int]$w,[int]$h,[string]$path){
  Add-Type -AssemblyName System.Drawing
  $hs=[N.U]::GetDC([IntPtr]::Zero);$hm=[N.U]::CreateCompatibleDC($hs);$hb=[N.U]::CreateCompatibleBitmap($hs,$w,$h)
  $ho=[N.U]::SelectObject($hm,$hb);$ok=[N.U]::PrintWindow($hwnd,$hm,2);if(-not $ok){$ok=[N.U]::PrintWindow($hwnd,$hm,0)}
  $img=[System.Drawing.Image]::FromHbitmap($hb);$img.Save($path,[System.Drawing.Imaging.ImageFormat]::Png);$img.Dispose()
  [void][N.U]::SelectObject($hm,$ho);[void][N.U]::DeleteObject($hb);[void][N.U]::DeleteDC($hm);[void][N.U]::ReleaseDC([IntPtr]::Zero,$hs)
}

# --- attach to the VISIBLE project tree -------------------------------------------------------
$proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
$main = (Get-AutoShopMainWindow $proc)
$trees = New-Object System.Collections.ArrayList
$cb = [N.U+EnumProc]{ param($h,$p) if((ClsOf $h) -eq 'SysTreeView32' -and [N.U]::IsWindowVisible($h)){[void]$trees.Add($h)};return $true }
[void][N.U]::EnumChildWindows($main,$cb,[IntPtr]::Zero)
if ($trees.Count -eq 0) { throw 'no visible SysTreeView32 found under the AutoShop main window' }
$tree = $trees | Sort-Object { (RectOf $_).Left } | Select-Object -First 1
$iid=[guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$script:acc=$null
[void][N.U]::AccessibleObjectFromWindow($tree,[uint32]4294967292,[ref]$iid,[ref]$script:acc)
$count = [int]$script:acc.accChildCount
Write-Output ("tree hwnd={0}  accessible children={1}" -f $tree, $count)

# --- dismiss any popup menu left over from an earlier run --------------------------------------
# While a menu is up, Shift+F10 does NOTHING, so a stale menu makes the whole run look like
# "the context menu cannot be opened". Clear it first, every time.
function Get-MenuPopups {
  return @((TopWindows) | Where-Object { $_.Cls -like 'Afx:*' -and $_.W -lt 600 -and $_.H -lt 800 })
}
function Close-AnyMenu {
  for ($k=1; $k -le 3; $k++) {
    $pop = @(Get-MenuPopups)
    if ($pop.Count -eq 0) { return $true }
    Send '{ESC}' 500
    $pop = @(Get-MenuPopups)
    if ($pop.Count -eq 0) { return $true }
    foreach ($q in $pop) {
      [void][N.U]::PostMessageW($q.Hwnd,0x0100,[IntPtr]0x1B,[IntPtr]::Zero)
      [void][N.U]::PostMessageW($q.Hwnd,0x0101,[IntPtr]0x1B,[IntPtr]::Zero)
    }
    Start-Sleep -Milliseconds 400
  }
  $pop = @(Get-MenuPopups)
  return ($pop.Count -eq 0)
}
if (@(Get-MenuPopups).Count -gt 0) {
  Write-Output ("  a popup menu was left open by an earlier run - dismissing it first")
  [void](Close-AnyMenu)
}

# --- read the whole tree in one sweep ---------------------------------------------------------
# accChildCount is NOT the top of the id space on this control and the id space is NOT stable:
#   * it reports 188-190 while real ids reach 617 in the same state.
#   * there is a WIDE hole band that GROWS as block views are opened: with one view open the band
#     was ids 87..513 (427 empty ids) while the named nodes sat at 514+. So do NOT stop early on a
#     run of empty ids -- a 300-hole cutoff silently lost every program/FB/FC node once already.
#   * ids are REASSIGNED whenever the tree changes: SBR_001 was id=190, then 357, then 515 across
#     three consecutive operations. NEVER cache an id between operations -- always sweep.
# A full sweep of 1000 ids costs ~340 ms, so sweeping wide is cheap.
$maxId = $MaxId
if ($maxId -le 0) { $maxId = $count + 3000 }   # +800 was NOT enough once the project grew (2026-09-20:
                                               # accChildCount=190 while real ids reached 1080 -> an index of
                                               # only 86 names, i.e. the whole program/FB/FC section missing)
$map = New-Object System.Collections.ArrayList
for ($i=1; $i -le $maxId; $i++) {
  $n = ''
  try { $n = [string]$script:acc.accName($i) } catch { continue }
  if ([string]::IsNullOrWhiteSpace($n)) { continue }
  $st = -1; try { $st = [int]$script:acc.accState($i) } catch {}
  [void]$map.Add([pscustomobject]@{ Id=$i; Name=$n; State=$st })
}
Write-Output ("named nodes: {0}" -f $map.Count)

if ($ListNodes) {
  foreach ($m in $map) {
    $fold = ''
    if ($m.State -band $ST.expanded)  { $fold = ' [expanded]' }
    if ($m.State -band $ST.collapsed) { $fold = ' [COLLAPSED]' }
    Write-Output ("  id={0,-4} {1}{2}" -f $m.Id, $m.Name, $fold)
  }
  exit 0
}

function Get-Sel {
  $id=$null; try{$id=$script:acc.accSelection}catch{}
  if ($id -isnot [int]) { return 'none' }
  $n=''; try{$n=[string]$script:acc.accName([int]$id)}catch{}
  return ("{0}|{1}" -f $id,$n)
}

# --- resolve the target name to ids (names are NOT unique: folders repeat) ---------------------
if ($Node) { $hits = @($map | Where-Object { $_.Name -eq $Node }) }
elseif ($Match) { $hits = @($map | Where-Object { $_.Name -like ("*" + $Match + "*") }) }
else { throw 'pass -Node NAME, -Match SUBSTRING or -ListNodes' }
if ($hits.Count -eq 0) { throw ("node not found: '{0}'" -f $(if($Node){$Node}else{$Match})) }
if ($hits.Count -gt 1) {
  Write-Output ("  {0} matches for '{1}':" -f $hits.Count, $(if($Node){$Node}else{$Match}))
  foreach ($h in $hits) { Write-Output ("    id={0} '{1}'" -f $h.Id, $h.Name) }
}
if ($NodeIndex -ge $hits.Count) { throw ("-NodeIndex {0} out of range ({1} matches)" -f $NodeIndex, $hits.Count) }
$target = $hits[$NodeIndex]
Write-Output ("target: id={0} '{1}'" -f $target.Id, $target.Name)

# --- select it --------------------------------------------------------------------------------
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1') }
$fgOk = $false
for ($ft=1; $ft -le 6; $ft++) {
  if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
  if ([N.U]::GetForegroundWindow() -eq $main) { $fgOk = $true; break }
  Write-Output ("  focus attempt {0}: foreground is still '{1}'" -f $ft, (TxtOf ([N.U]::GetForegroundWindow())))
  Start-Sleep -Milliseconds 400
}
if (-not $fgOk) {
  throw 'AutoShop never became the foreground window - Shift+F10 would go to the WRONG app and can open a completely different menu (measured: a 165x254 menu at 13,37 instead of the node menu). Refusing to continue.'
}

# Give the TREE the keyboard focus with a real click inside the pane (the centre of the pane is
# always a row, and a stray selection is harmless because accSelect fixes it immediately).
# Without this, Shift+F10 can reach the main window instead and raise a different popup.
$tr0 = RectOf $tree
ClickRaw ([int](($tr0.Left + $tr0.Right)/2)) ([int]($tr0.Top + ($tr0.Bottom - $tr0.Top) * 0.4))
Start-Sleep -Milliseconds 350

$selOk = $false
for ($try=1; $try -le 3; $try++) {
  # SELFLAG_TAKEFOCUS(1) | SELFLAG_TAKESELECTION(2) = 3
  try { $script:acc.accSelect(3, [int]$target.Id) } catch { Write-Output ("  accSelect threw: {0}" -f $_.Exception.Message) }
  Start-Sleep -Milliseconds 350
  $now = Get-Sel
  Write-Output ("  try {0}: selection is {1}" -f $try, $now)
  if ($now -eq ("{0}|{1}" -f $target.Id, $target.Name)) { $selOk = $true; break }
}
if (-not $selOk) { throw ("could not select '{0}' (id {1})" -f $target.Name, $target.Id) }
if ($SelectOnly -or $NoMenu) {
  if ($MainShotOut) { $r=RectOf $main; SavePng $main $r.Right-$r.Left $r.Bottom-$r.Top $MainShotOut; Write-Output ("  main window captured -> {0}" -f $MainShotOut) }
  exit 0
}

# --- open the node's context menu with Shift+F10 ----------------------------------------------
# The menu is an MFC popup: top-level, class 'Afx:00400000:800:...' (measured
# 'Afx:00400000:800:00010003:00000010:00000000'), small, with no title.
# DO NOT just take the largest NEW top-level window: AutoShop also pops unrelated top-level
# windows (measured: class 'SoPY_Status', 235x44 in the bottom-right corner) which both fool the
# detection AND steal the foreground so that Shift+F10 never reaches the tree.
$before = TopWindows; $beforeIds = @($before | ForEach-Object { $_.Hwnd })
$p = $null
for ($try=1; $try -le 4; $try++) {
  # Re-establish BOTH the foreground and the tree's keyboard focus before each attempt: the user may
  # be typing in another window, which steals the foreground between attempts.
  if ([N.U]::GetForegroundWindow() -ne $main) {
    if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
    if ([N.U]::GetForegroundWindow() -ne $main) { Write-Output ("  try {0}: could not take the foreground back" -f $try); Start-Sleep -Milliseconds 500; continue }
    ClickRaw ([int](($tr0.Left + $tr0.Right)/2)) ([int]($tr0.Top + ($tr0.Bottom - $tr0.Top) * 0.4))
    Start-Sleep -Milliseconds 300
    $now2 = Get-Sel
    if ($now2 -ne ("{0}|{1}" -f $target.Id, $target.Name)) {
      Write-Output ("  try {0}: focus click moved the selection to {1} - re-selecting" -f $try, $now2)
      try { $script:acc.accSelect(3, [int]$target.Id) } catch {}
      Start-Sleep -Milliseconds 300
    }
  }
  Send '+{F10}' 1200
  $new = @((TopWindows) | Where-Object {
      $beforeIds -notcontains $_.Hwnd -and $_.Cls -like 'Afx:*' -and $_.W -lt 600 -and $_.H -lt 800
    } | Sort-Object { -($_.W * $_.H) })
  if ($new.Count -gt 0) { $p = $new[0]; break }
  Write-Output ("  try {0}: Shift+F10 opened no menu - refocusing and retrying" -f $try)
  if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
  Start-Sleep -Milliseconds 400
}
if ($null -eq $p) {
  Write-Output '  new top-level windows seen (for diagnosis):'
  foreach ($w in (@((TopWindows) | Where-Object { $beforeIds -notcontains $_.Hwnd }))) {
    Write-Output ("    class='{0}' {1}x{2} at {3},{4} text='{5}'" -f $w.Cls,$w.W,$w.H,$w.X,$w.Y,$w.Text)
  }
  throw 'Shift+F10 did not open a context menu on the selected node'
}
Write-Output ("menu: {0}x{1} at {2},{3}  class='{4}'" -f $p.W, $p.H, $p.X, $p.Y, $p.Cls)
if ($CaptureOut) { SavePng $p.Hwnd $p.W $p.H $CaptureOut; Write-Output ("  captured -> {0}" -f $CaptureOut) }

# A menu left open BLOCKS every later attempt: while it is up, Shift+F10 does nothing at all and the
# next run reports "no menu" (measured -- a capture-only run poisoned the following delete run).
# So a capture-only invocation dismisses the menu before returning.
if ($ClickOffsetY -lt 0) { Write-Output ("  menu dismissed: {0}" -f (Close-AnyMenu)) }

if ($ClickOffsetY -ge 0) {
  if ($ExpectedMenuH -gt 0 -and [Math]::Abs($p.H - $ExpectedMenuH) -gt 60) {
    [void](Close-AnyMenu)
    throw ("menu height {0} (at {1},{2}) != expected {3} - refusing to guess the item row" -f $p.H, $p.X, $p.Y, $ExpectedMenuH)
  }
  # PORTABILITY: recorded offsets were measured at $ExpectedMenuH px; scale by the measured height so the
  # same ITEM is hit on another DPI / font size / screen. The tolerance above guards the structure.
  $menuScale = 1.0
  if ($ExpectedMenuH -gt 0) { $menuScale = $p.H / [double]$ExpectedMenuH }
  $dy = [int][Math]::Round($ClickOffsetY * $menuScale)
  Write-Output ("clicking item at menu + {0},{1}  [scale {2:N3} = {3}/{4}]" -f $ClickOffsetX, $dy, $menuScale, $p.H, $ExpectedMenuH)
  ClickRaw ($p.X + $ClickOffsetX) ($p.Y + $dy)
  Start-Sleep -Milliseconds 1800
  Write-Output '--- windows after the click ---'
  $after = TopWindows
  foreach ($w in (@($after | Where-Object { $beforeIds -notcontains $_.Hwnd }))) {
    Write-Output ("  '{0}' {1}x{2} at {3},{4} class='{5}'" -f $w.Text, $w.W, $w.H, $w.X, $w.Y, $w.Cls)
  }
  $dl = New-Object System.Collections.ArrayList
  $cb9 = [N.U+EnumProc]{ param($h,$p2) if((ClsOf $h) -eq '#32770' -and [N.U]::IsWindowVisible($h)){[void]$dl.Add($h)};return $true }
  [void][N.U]::EnumWindows($cb9,[IntPtr]::Zero)
  foreach ($d in $dl) {
    $dr = RectOf $d
    Write-Output ("  DIALOG '{0}' {{ {1},{2} {3}x{4} }}" -f (TxtOf $d), $dr.Left, $dr.Top, ($dr.Right-$dr.Left), ($dr.Bottom-$dr.Top))
    $kids=New-Object System.Collections.ArrayList
    $cb10=[N.U+EnumProc]{ param($h,$p3) if([N.U]::IsWindowVisible($h)){[void]$kids.Add($h)};return $true }
    [void][N.U]::EnumChildWindows($d,$cb10,[IntPtr]::Zero)
    foreach ($k in $kids) { $t=TxtOf $k; if($t){ $kr=RectOf $k; Write-Output ("      {0,-20} '{{ {1},{2} {3}x{4} }}' text='{5}'" -f (ClsOf $k), $kr.Left,$kr.Top,($kr.Right-$kr.Left),($kr.Bottom-$kr.Top),$t) } }
  }
}
if ($MainShotOut) { $r=RectOf $main; SavePng $main $r.Right-$r.Left $r.Bottom-$r.Top $MainShotOut; Write-Output ("  main window captured -> {0}" -f $MainShotOut) }

# Hand the foreground back to AutoShop (standing user instruction).
if (Get-Command Focus-AutoShop -ErrorAction SilentlyContinue) { [void](Focus-AutoShop -Quiet) }
