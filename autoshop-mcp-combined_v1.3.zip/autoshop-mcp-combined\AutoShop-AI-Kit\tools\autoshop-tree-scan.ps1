# Scan the AutoShop project tree via MSAA and report, for EVERY node:
#   * its NAME            -> tells a folder from a program block (matched against folder.txt)
#   * its FOLD STATE      -> STATE_SYSTEM_EXPANDED 0x200 / STATE_SYSTEM_COLLAPSED 0x400
#   * its SCREEN RECT     -> real, scroll-aware coordinates (verified: scrolling moved them)
#   * whether it is currently DISPLAYED (no invisible/offscreen flag AND a non-zero rect)
#
# This is what removes blind double-clicking: the two-channel "double-click + read MDI title"
# probe from the previous session is no longer needed to identify a row.
#
# --- MSAA facts established by probing (all verified on this machine) -------------------------
#   oleacc!AccessibleObjectFromWindow(hwnd, OBJID_CLIENT, IID_IAccessible) works on SysTreeView32.
#   PowerShell late binding rules:
#     * OBJID_CLIENT must be written [uint32]4294967292 (0xFFFFFFFC parses as Int32 -4)
#     * child ids must be a plain [int]; uint32/double make the provider throw E_INVALIDARG
#     * accLocation needs [ref] ints, otherwise it silently returns nothing
#     * accValue is not supported (DISP_E_MEMBERNOTFOUND); accName/accRole/accState/accSelection work
#   * accChildCount is NOT the number of tree items (reads 188 while real ids run past 230), and
#     there is a dead band of ids (87..188) that answer nothing -> always SWEEP a range, never loop 1..childCount
#   * there are THREE SysTreeView32 in the main window; the project tree is the leftmost (x<400).
#     The right-hand pair (x=1030) exposes 1002 children that reject accName entirely.
#
# KEEP THIS FILE PURE ASCII (PS 5.1 reads a BOM-less .ps1 as ANSI; literal Chinese becomes mojibake).
param(
  [string]$ProjectDir = '',
  [string]$OutCsv = '',
  [int]$MaxId = 420,
  [switch]$ExpandFolded,        # expand every folded folder with accSelect + RIGHT (no double-click)
  [int]$ExpandPasses = 3,
  [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
# --- shared helpers (portability patches, skill 17.4 / 17.6) ------------------------------------
$__shared = Join-Path $PSScriptRoot 'autoshop-shared.ps1'
if (Test-Path -LiteralPath $__shared) { . $__shared }


if (-not ('W.U' -as [type])) {
Add-Type -Namespace W -Name U -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetClassNameW")] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="GetWindowTextW")] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint id, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object acc);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

# MSAA state bits. NOTE: expanded/collapsed are 0x200/0x400 -- the 0x2000/0x4000 values that show
# up in some tables are WRONG for MSAA and silently make every folder look "neither".
$ST = @{ selected=0x2; focused=0x4; expanded=0x200; collapsed=0x400; focusable=0x100000;
         selectable=0x200000; invisible=0x8000; offscreen=0x10000 }
# MSAA SELFLAG_*
$SEL = @{ TAKEFOCUS=1; TAKESELECTION=2 }
$LD = 0x02; $LU = 0x04

# Non-ASCII literals, built from char codes so this file stays pure ASCII.
$S_YES     = [string][char]0x662F                       # Yes
$S_NO      = [string][char]0x5426                       # No
$S_CANCEL  = [string][char]0x53D6 + [string][char]0x6D88 # Cancel
$S_OK      = [string][char]0x786E + [string][char]0x5B9A # OK

function ClsOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 256; [void][W.U]::GetClassNameW($h, $sb, 256); $sb.ToString() }
function TxtOf([IntPtr]$h) { $sb = New-Object System.Text.StringBuilder 512; [void][W.U]::GetWindowTextW($h, $sb, 512); $sb.ToString() }
function Click([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 55
  [W.U]::mouse_event($LU,0,0,0,0)
}
function DoubleClick([int]$x, [int]$y) {
  [void][W.U]::SetCursorPos($x, $y); Start-Sleep -Milliseconds 110
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
  [W.U]::mouse_event($LU,0,0,0,0); Start-Sleep -Milliseconds 60
  [W.U]::mouse_event($LD,0,0,0,0); Start-Sleep -Milliseconds 40
  [W.U]::mouse_event($LU,0,0,0,0)
}
function Send([string]$k, [int]$w = 130) { [System.Windows.Forms.SendKeys]::SendWait($k); Start-Sleep -Milliseconds $w }

# --- dialog guard ---------------------------------------------------------------------------
# AutoShop's modal dialogs are #32770 owned children whose buttons UIA does not expose. Enumerate
# them with Win32, READ the button captions, and press only No / Cancel -- never Yes / OK -- so a
# stray dialog can never confirm a save or a destructive action.
function Get-Dialogs {
  $dlgs = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq '#32770' -and [W.U]::IsWindowVisible($h)) { [void]$dlgs.Add($h) }
    return $true }
  [void][W.U]::EnumWindows($cb, [IntPtr]::Zero)
  return $dlgs
}
function Get-DialogButtons([IntPtr]$dlg) {
  $kids = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq 'Button' -and [W.U]::IsWindowVisible($h)) { [void]$kids.Add($h) }
    return $true }
  [void][W.U]::EnumChildWindows($dlg, $cb, [IntPtr]::Zero)
  return $kids
}
# Returns $true if a dialog was present (and was dismissed). ALWAYS call this after any interaction.
function Assert-NoDialog([string]$where = '', [switch]$Quiet) {
  $hit = $false
  foreach ($d in (Get-Dialogs)) {
    $title = TxtOf $d
    $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($d, [ref]$r)
    $pressed = ''
    $btns = Get-DialogButtons $d
    # prefer No, then Cancel; never Yes/OK
    foreach ($want in @($S_NO, $S_CANCEL)) {
      foreach ($b in $btns) {
        if ((TxtOf $b) -eq $want) {
          $br = New-Object W.U+RECT; [void][W.U]::GetWindowRect($b, [ref]$br)
          Click ([int](($br.Left + $br.Right)/2)) ([int](($br.Top + $br.Bottom)/2))
          Start-Sleep -Milliseconds 450
          $pressed = (TxtOf $b)
          break
        }
      }
      if ($pressed) { break }
    }
    $still = (Get-Dialogs | Where-Object { $_ -eq $d }).Count
    if (-not $Quiet) {
      Write-Output ("   [dialog] '{0}' at {{ {1},{2} {3}x{4} }} buttons=[{5}] -> pressed '{6}'{7}" -f `
        $title, $r.Left, $r.Top, ($r.Right-$r.Left), ($r.Bottom-$r.Top), `
        (($btns | ForEach-Object { TxtOf $_ }) -join '/'), $pressed, $(if ($pressed) { '' } else { '  !!! NO No/Cancel BUTTON FOUND - LEFT OPEN' }))
    }
    $hit = $true
  }
  return $hit
}

# --- locate the project tree ----------------------------------------------------------------
# Writes $script:tree directly instead of returning it: this script keeps every value that other
# functions read inside script scope, so no object ever crosses a function boundary.
$script:tree = $null
function Find-ProjectTree {
  $proc = Get-Process -Name AutoShop -ErrorAction Stop | Where-Object { if ($env:AUTOSHOP_TITLE_FILTER) { $_.MainWindowTitle -like ('*'+$env:AUTOSHOP_TITLE_FILTER+'*') } else { $_.MainWindowTitle -notlike '*:\*' } } | Select-Object -First 1
  $trees = New-Object System.Collections.ArrayList
  $cb = [W.U+EnumProc]{ param($h,$p)
    if ((ClsOf $h) -eq 'SysTreeView32') { $r = New-Object W.U+RECT; [void][W.U]::GetWindowRect($h, [ref]$r)
      [void]$trees.Add([pscustomobject]@{ hwnd=$h; rect=$r; pid=$proc.Id }) }
    return $true }
  [void][W.U]::EnumChildWindows((Get-AutoShopMainWindow $proc), $cb, [IntPtr]::Zero)
  $script:tree = ($trees | Sort-Object { $_.rect.Left } | Select-Object -First 1)
}

Find-ProjectTree
$tree = $script:tree
if ($null -eq $tree) { throw 'no SysTreeView32 found - is AutoShop running?' }

# NB: do NOT wrap AccessibleObjectFromWindow in a function and return the object -- PowerShell
# mangles the __ComObject on the way out (observed: the caller received a bare [System.Int32] and
# every accName call then failed with "does not contain a method named 'accName'").
# The out-object must land in a plain script-scope variable, exactly like the probes do.
$iidAcc = [guid]'618736E0-3C3D-11CF-810C-00AA00389B71'
$acc = $null
$hrAcc = [W.U]::AccessibleObjectFromWindow($tree.hwnd, [uint32]4294967292, [ref]$iidAcc, [ref]$acc)
if ($hrAcc -ne 0 -or $null -eq $acc) { throw ("AccessibleObjectFromWindow failed hr=0x{0:X8}" -f $hrAcc) }
[void][W.U]::SetForegroundWindow($tree.hwnd)
Write-Output ("project tree hwnd={0} rect={{ {1},{2} {3}x{4} }}" -f $tree.hwnd, $tree.rect.Left, $tree.rect.Top, ($tree.rect.Right-$tree.rect.Left), ($tree.rect.Bottom-$tree.rect.Top))
# diagnostic: prove the MSAA object is live before trusting any loop on it
try { Write-Output ("diag: acc type={0} childCount={1} accName(1)='{2}'" -f $acc.GetType().FullName, $acc.accChildCount, $acc.accName([int]1)) }
catch { Write-Output ("diag: MSAA probe FAILED: {0}" -f $_.Exception.Message) }

function Scan-Tree {
  $res = New-Object System.Collections.ArrayList
  for ($i = 1; $i -le $MaxId; $i++) {
    $name = $null; $role = $null; $st = $null
    try { $name = [string]$acc.accName([int]$i) } catch { $name = $null }
    try { $role = [int]$acc.accRole([int]$i) } catch { $role = $null }
    try { $st   = [int]$acc.accState([int]$i) } catch { $st = $null }
    if ($null -eq $name -and $null -eq $st) { continue }
    $x=0;$y=0;$w=0;$h=0
    try { $acc.accLocation([ref]$x,[ref]$y,[ref]$w,[ref]$h,[int]$i) } catch { }
    $hidden = ($null -ne $st) -and (($st -band $ST.invisible) -or ($st -band $ST.offscreen))
    $shown  = (-not $hidden) -and $w -gt 0 -and $h -gt 0 -and $y -ge $tree.rect.Top -and ($y + $h) -le $tree.rect.Bottom -and $x -ge $tree.rect.Left -and $x -lt $tree.rect.Right
    [void]$res.Add([pscustomobject]@{
      Id=$i; Name=$name; Role=$role; State=$st; X=$x; Y=$y; W=$w; H=$h
      Expanded = ($null -ne $st -and ($st -band $ST.expanded))
      Collapsed= ($null -ne $st -and ($st -band $ST.collapsed))
      Selected = ($null -ne $st -and ($st -band $ST.selected))
      OnScreen = $shown
    })
  }
  return $res
}

# --- expand folded folders without ever double-clicking --------------------------------------
# accSelect moves the selection with NO mouse input at all; RIGHT then expands the folder. This is
# strictly safer than the old RIGHT+DOWN keyboard sweep, because we only ever touch nodes whose
# MSAA state says "collapsed".
function Expand-Folded([int]$passes) {
  for ($p = 1; $p -le $passes; $p++) {
    $nodes = Scan-Tree
    $folded = @($nodes | Where-Object { $_.Collapsed -and $_.OnScreen })
    if (-not $folded.Count) { Write-Output ("  expand pass {0}: nothing folded on screen" -f $p); return }
    Write-Output ("  expand pass {0}: {1} folded folder(s) on screen" -f $p, $folded.Count)
    foreach ($n in $folded) {
      try { $acc.accSelect(($SEL.TAKEFOCUS -bor $SEL.TAKESELECTION), [int]$n.Id) } catch { Write-Output ("     select '{0}' ERR {1}" -f $n.Name, $_.Exception.Message); continue }
      Start-Sleep -Milliseconds 140
      Send '{RIGHT}' 260
      [void](Assert-NoDialog -Quiet)
      Write-Output ("     expanded '{0}' (was collapsed)" -f $n.Name)
    }
  }
}

if ($ExpandFolded) {
  Write-Output 'expanding folded folders via accSelect + RIGHT ...'
  Expand-Folded $ExpandPasses
}

# --- report ---------------------------------------------------------------------------------
$nodes = Scan-Tree
$visible = @($nodes | Where-Object { $_.OnScreen })
Write-Output ''
Write-Output ("nodes answering MSAA: {0}   currently on screen: {1}" -f $nodes.Count, $visible.Count)
Write-Output ("folded (collapsed) folders: {0}   expanded folders: {1}" -f `
  @($nodes | Where-Object { $_.Collapsed }).Count, @($nodes | Where-Object { $_.Expanded }).Count)

# classify against folder.txt
$expect = @{}; $folders = @{}
$folderTxt = Join-Path $ProjectDir 'folder.txt'
if ($ProjectDir -and (Test-Path -LiteralPath $folderTxt)) {
  $section = $null
  foreach ($raw in [System.IO.File]::ReadAllLines($folderTxt, [System.Text.Encoding]::UTF8)) {
    if ([string]::IsNullOrWhiteSpace($raw)) { continue }
    $body = $raw.Trim()
    if ($body -eq 'PROG' -or $body -eq 'FB' -or $body -eq 'FC') { $section = $body; continue }
    if ($body -like 'FOLDER*') { $folders[$body.Substring(6).Trim()] = $true; continue }
    if ($body -like 'FILE*' -and $section) { $expect[[System.IO.Path]::GetFileNameWithoutExtension($body.Substring(4).Trim())] = $section }
  }
  Write-Output ("folder.txt: {0} expected blocks, {1} folder names" -f $expect.Count, $folders.Count)
}

if (-not $Quiet) {
  Write-Output ''
  Write-Output ("{0,4} {1,-5} {2,-34} {3,-11} {4}  {5}" -f 'id','kind','state','rect','name','')
  foreach ($n in $nodes) {
    $kind = if ($expect.ContainsKey($n.Name)) { 'BLOCK' } elseif ($folders.ContainsKey($n.Name)) { 'FOLDER' } else { '-' }
    $fold = if ($n.Expanded) { 'expanded' } elseif ($n.Collapsed) { 'COLLAPSED' } else { '' }
    $vis  = if ($n.OnScreen) { 'on-screen' } else { 'hidden' }
    Write-Output ("{0,4} {1,-5} {2,-34} {3,-11} rect={4},{5},{6},{7}  {8}" -f `
      $n.Id, $kind, $fold, $vis, $n.X, $n.Y, $n.W, $n.H, $n.Name)
  }
}

if ($expect.Count) {
  $found = @($nodes | Where-Object { $expect.ContainsKey($_.Name) })
  $names = @($found | ForEach-Object { $_.Name })
  $missing = @($expect.Keys | Where-Object { $names -notcontains $_ })
  Write-Output ''
  Write-Output ("blocks found in tree: {0} / {1}" -f $found.Count, $expect.Count)
  Write-Output ("  of those ON SCREEN now: {0}" -f @($found | Where-Object { $_.OnScreen }).Count)
  if ($missing.Count) {
    Write-Output ("missing ({0}):" -f $missing.Count)
    $missing | Sort-Object | Select-Object -First 40 | ForEach-Object { Write-Output ("   - {0}" -f $_) }
  }
}

if ($OutCsv) {
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.AppendLine('id,kind,expanded,collapsed,onscreen,x,y,w,h,name')
  foreach ($n in $nodes) {
    $kind = if ($expect.ContainsKey($n.Name)) { 'BLOCK' } elseif ($folders.ContainsKey($n.Name)) { 'FOLDER' } else { '' }
    $esc = '"' + (($n.Name) -replace '"','""') + '"'
    [void]$sb.AppendLine(('{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}' -f $n.Id,$kind,[int]$n.Expanded,[int]$n.Collapsed,[int]$n.OnScreen,$n.X,$n.Y,$n.W,$n.H,$esc))
  }
  [System.IO.File]::WriteAllText($OutCsv, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))
  Write-Output ''
  Write-Output ("wrote {0}" -f $OutCsv)
}

[void](Assert-NoDialog)

# --- hand the foreground back to AutoShop (user's standing instruction) ------------------------
# Dot-sourced ON PURPOSE: a child `powershell -File autoshop-focus.ps1` was tried first and the
# focus stayed on the terminal, because Windows only grants SetForegroundWindow to a process that
# owns the foreground. In-process is the version that actually works.
if ($PSScriptRoot) { . (Join-Path $PSScriptRoot 'autoshop-focus.ps1'); [void](Focus-AutoShop -Quiet) }