# List (and optionally click) the child controls of a Win32 dialog.
#
# Why this exists: for old MFC dialogs, UIA often exposes nothing and OCR cannot read the small
# Chinese button labels, so coordinates end up being guessed. But MFC buttons ARE real Win32 child
# windows -- EnumChildWindows + GetWindowText reads their captions exactly, and GetWindowRect gives
# their true rectangles. That turns "which button is No?" into a deterministic lookup.
#
# KEEP THIS FILE PURE ASCII.
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File win32-dialog-buttons.ps1 -Class "#32770" [-Title <substr>]
#   powershell ... -ClickText "取消"      # click the child whose caption equals/contains this text
param(
  [string]$Class = '#32770',
  [string]$Title = '',            # optional substring filter (matched in PowerShell, so CJK is fine)
  [string]$ClickText = '',        # caption (or substring) of the child to click
  [switch]$All                    # list every #32770, not just the first match
)

$ErrorActionPreference = 'Stop'
if (-not ('W.D' -as [type])) {
Add-Type -Namespace W -Name D -MemberDefinition @'
public delegate bool EnumProc(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr p);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr parent, EnumProc cb, IntPtr p);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, System.Text.StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f, uint x, uint y, uint d, int e);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
public struct RECT { public int Left, Top, Right, Bottom; }
'@
}

function TextOf([IntPtr]$h) {
  $sb = New-Object System.Text.StringBuilder 512
  [void][W.D]::GetWindowTextW($h, $sb, 512)
  return $sb.ToString()
}
function ClassOf([IntPtr]$h) {
  $sb = New-Object System.Text.StringBuilder 256
  [void][W.D]::GetClassNameW($h, $sb, 256)
  return $sb.ToString()
}

$targets = New-Object System.Collections.ArrayList
$cb = [W.D+EnumProc]{
  param($h, $p)
  if ((ClassOf $h) -eq $Class) {
    $t = TextOf $h
    if (-not $Title -or $t -like "*$Title*") { [void]$targets.Add([pscustomobject]@{ hwnd = $h; title = $t }) }
  }
  return $true
}
[void][W.D]::EnumWindows($cb, [IntPtr]::Zero)

if ($targets.Count -eq 0) { Write-Output "no top-level window of class '$Class' matched."; exit 1 }
Write-Output ("matched top-level windows: {0}" -f $targets.Count)

$n = if ($All) { $targets.Count } else { 1 }
for ($i = 0; $i -lt $n; $i++) {
  $w = $targets[$i]
  $r = New-Object W.D+RECT; [void][W.D]::GetWindowRect($w.hwnd, [ref]$r)
  Write-Output ''
  Write-Output ("=== top-level hwnd={0}  title='{1}'  rect=({2},{3})-({4},{5}) {6}x{7}" -f `
    $w.hwnd, $w.title, $r.Left, $r.Top, $r.Right, $r.Bottom, ($r.Right - $r.Left), ($r.Bottom - $r.Top))

  $children = New-Object System.Collections.ArrayList
  $cb2 = [W.D+EnumProc]{
    param($h, $p)
    $cr = New-Object W.D+RECT; [void][W.D]::GetWindowRect($h, [ref]$cr)
    [void]$children.Add([pscustomobject]@{
      hwnd = $h; cls = (ClassOf $h); text = (TextOf $h); vis = [W.D]::IsWindowVisible($h)
      x = $cr.Left; y = $cr.Top; w = ($cr.Right - $cr.Left); h = ($cr.Bottom - $cr.Top)
    })
    return $true
  }
  [void][W.D]::EnumChildWindows($w.hwnd, $cb2, [IntPtr]::Zero)

  foreach ($c in $children) {
    if (-not $c.vis) { continue }
    Write-Output ("  child hwnd={0,-10} cls={1,-20} rect=({2},{3}) {4}x{5}  text='{6}'" -f `
      $c.hwnd, $c.cls, $c.x, $c.y, $c.w, $c.h, $c.text)
  }

  if ($ClickText) {
    $hit = $children | Where-Object { $_.vis -and $_.text -eq $ClickText } | Select-Object -First 1
    if (-not $hit) { $hit = $children | Where-Object { $_.vis -and $_.text -like "*$ClickText*" } | Select-Object -First 1 }
    if ($hit) {
      $cx = $hit.x + [int]($hit.w / 2); $cy = $hit.y + [int]($hit.h / 2)
      [void][W.D]::SetForegroundWindow($w.hwnd)
      Start-Sleep -Milliseconds 200
      [void][W.D]::SetCursorPos($cx, $cy)
      Start-Sleep -Milliseconds 150
      [W.D]::mouse_event(0x02, 0, 0, 0, 0); Start-Sleep -Milliseconds 60; [W.D]::mouse_event(0x04, 0, 0, 0, 0)
      Write-Output ("  -> CLICKED '{0}' at ({1},{2})" -f $hit.text, $cx, $cy)
    } else {
      Write-Output ("  -> no child matched ClickText '{0}'" -f $ClickText)
    }
  }
}
