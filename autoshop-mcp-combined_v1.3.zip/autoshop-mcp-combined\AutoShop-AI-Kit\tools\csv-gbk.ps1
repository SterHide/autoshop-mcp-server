# csv-gbk.ps1 -- convert a UTF-8 CSV authored here into the GB2312/CP936 bytes AutoShop's importer wants.
# PURE ASCII.
param(
  [Parameter(Mandatory=$true)][string]$In,
  [Parameter(Mandatory=$true)][string]$Out
)
$txt = [System.IO.File]::ReadAllText($In, [System.Text.Encoding]::UTF8)
$gbk = [System.Text.Encoding]::GetEncoding(936)
[System.IO.File]::WriteAllBytes($Out, $gbk.GetBytes($txt))
$b = [System.IO.File]::ReadAllBytes($Out)
Write-Output ('{0} -> {1}  ({2} bytes, GBK)' -f $In, $Out, $b.Length)
if ($b.Length -ge 2 -and $b[0] -eq 0xEF) { Write-Output '  WARNING: source had a UTF-8 BOM' }
