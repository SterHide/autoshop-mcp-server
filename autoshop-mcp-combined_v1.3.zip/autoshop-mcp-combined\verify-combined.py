"""合并入口自检：起 proxy -> 列工具 -> 可选调用。

用法：
  python verify-combined.py
  python verify-combined.py --call r_autoshop_scan_project '{"projectPath":"D:\\...\\DAA-副本"}'
  python verify-combined.py --call-file calls.json   # {"tool": {args}}，绕开 shell 引号

输出走 UTF-8，避免中文工程节点名在控制台里变问号。
"""
import asyncio
import json
import os
import sys

from fastmcp import Client
from fastmcp.client.transports import StdioTransport

BASE = os.path.dirname(os.path.abspath(__file__))


def parse_calls(argv):
    calls, i = [], 0
    while i < len(argv):
        if argv[i] == "--call":
            name = argv[i + 1]
            payload = argv[i + 2] if i + 2 < len(argv) and not argv[i + 2].startswith("--") else "{}"
            calls.append((name, json.loads(payload)))
            i += 3
        elif argv[i] == "--call-file":
            with open(argv[i + 1], encoding="utf-8") as fh:
                spec = json.load(fh)
            for name, args in spec.items():
                calls.append((name, args or {}))
            i += 2
        else:
            i += 1
    return calls


async def main():
    sys.stdout.reconfigure(encoding="utf-8")
    calls = parse_calls(sys.argv[1:])
    # StdioTransport 默认只给子进程一份过滤过的环境，AUTOSHOP_* 开关必须显式带过去
    env = {k: str(v) for k, v in os.environ.items()}
    transport = StdioTransport(command=sys.executable, args=[os.path.join(BASE, "proxy.py")], cwd=BASE, env=env)
    async with Client(transport) as client:
        tools = await client.list_tools()
        groups = {}
        for t in tools:
            prefix = t.name.split("_", 1)[0]
            groups.setdefault(prefix, []).append(t.name)
        print(f"TOTAL={len(tools)} " + " ".join(f"{k}={len(v)}" for k, v in sorted(groups.items())))
        for k, v in sorted(groups.items()):
            print(f"{k}: {' '.join(v)}")
        for name, args in calls:
            try:
                res = await client.call_tool(name, args)
            except Exception as exc:  # 后端起不来时要看得懂原因
                print(f"CALL {name} THREW {type(exc).__name__}: {exc}")
                continue
            text = "\n".join(c.text for c in res.content if getattr(c, "text", None))
            print(f"CALL {name} {'IS_ERROR' if res.is_error else 'ok'} {len(text)} chars")
            print(text[:1200])


if __name__ == "__main__":
    asyncio.run(main())
