# 自检合并入口。默认只跑离线只读调用，不会碰 AutoShop 界面。
#   -Python   带 fastmcp 的 python（默认找 PATH，再退回 workbuddy 自带）
#   -Calls    调用清单 json（默认 verify-calls.example.json）
#   -Backends 只启用部分后端 kit,r（用 AUTOSHOP_COMBINED_BACKENDS 传下去）
#Requires -Version 7
param(
  [string]$Python = '',
  [string]$Calls = (Join-Path $PSScriptRoot 'verify-calls.example.json'),
  [string]$Backends = ''
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

if (-not $Python) {
  $Python = (Get-Command python.exe -EA SilentlyContinue).Source
  if (-not $Python) { $Python = Join-Path $HOME '.workbuddy\binaries\python\envs\default\Scripts\python.exe' }
}
if (-not (Test-Path -LiteralPath $Python)) { "python not found: $Python"; exit 1 }

& $Python -c "import fastmcp" 2>$null
if ($LASTEXITCODE -ne 0) { "fastmcp missing in $Python - install it (pip install fastmcp==4.1.8) or point -Python at one that has it."; exit 1 }

if ($Backends) { $env:AUTOSHOP_COMBINED_BACKENDS = $Backends }
& $Python (Join-Path $PSScriptRoot 'verify-combined.py') --call-file $Calls
